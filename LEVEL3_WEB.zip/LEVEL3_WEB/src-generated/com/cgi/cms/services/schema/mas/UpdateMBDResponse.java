
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HICN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="transactionStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="messageList" type="{http://mas.schema.services.cms.cgi.com/}messageList"/>
 *         &lt;element name="Beneficiary" type="{http://mas.schema.services.cms.cgi.com/}MBDBeneficiary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "hicn",
    "transactionId",
    "transactionStatus",
    "messageList",
    "beneficiary"
})
@XmlRootElement(name = "updateMBDResponse")
public class UpdateMBDResponse
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(name = "HICN", required = true)
    protected String hicn;
    protected long transactionId;
    protected boolean transactionStatus;
    @XmlElement(required = true)
    protected MessageList messageList;
    @XmlElement(name = "Beneficiary")
    protected MBDBeneficiary beneficiary;

    /**
     * Gets the value of the hicn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHICN() {
        return hicn;
    }

    /**
     * Sets the value of the hicn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHICN(String value) {
        this.hicn = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     */
    public long getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     */
    public void setTransactionId(long value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the transactionStatus property.
     * 
     */
    public boolean isTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Sets the value of the transactionStatus property.
     * 
     */
    public void setTransactionStatus(boolean value) {
        this.transactionStatus = value;
    }

    /**
     * Gets the value of the messageList property.
     * 
     * @return
     *     possible object is
     *     {@link MessageList }
     *     
     */
    public MessageList getMessageList() {
        return messageList;
    }

    /**
     * Sets the value of the messageList property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageList }
     *     
     */
    public void setMessageList(MessageList value) {
        this.messageList = value;
    }

    /**
     * Gets the value of the beneficiary property.
     * 
     * @return
     *     possible object is
     *     {@link MBDBeneficiary }
     *     
     */
    public MBDBeneficiary getBeneficiary() {
        return beneficiary;
    }

    /**
     * Sets the value of the beneficiary property.
     * 
     * @param value
     *     allowed object is
     *     {@link MBDBeneficiary }
     *     
     */
    public void setBeneficiary(MBDBeneficiary value) {
        this.beneficiary = value;
    }

}
