
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneSubsidiaryInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneSubsidiaryInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppealResolutionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationApprovalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AuditTimestamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChangeDeterminationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeterminationIncomeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EffectiveIndicatorSwitch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FederalPovertyLevelIncomePct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LISCopaymentLevelID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDPremiumSubsidyPercent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyApprDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecordAddedTimestamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecordUpdatedTimestamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResourceLevelCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SSAApplicationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StateCancellationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubsidyEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubsidySource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubsidyStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserModified" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneSubsidiaryInfo", propOrder = {
    "id",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "appealResolutionCode",
    "applicationApprovalCode",
    "auditTimestamp",
    "changeDeterminationCode",
    "determinationIncomeCode",
    "effectiveIndicatorSwitch",
    "federalPovertyLevelIncomePct",
    "lisCopaymentLevelID",
    "partDPremiumSubsidyPercent",
    "partDSubsidyApprDate",
    "recordAddedTimestamp",
    "recordUpdatedTimestamp",
    "resourceLevelCode",
    "ssaApplicationDate",
    "stateCancellationCode",
    "subsidyEndDate",
    "subsidySource",
    "subsidyStartDate",
    "userModified"
})
public class BeneSubsidiaryInfo
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "AppealResolutionCode")
    protected String appealResolutionCode;
    @XmlElement(name = "ApplicationApprovalCode")
    protected String applicationApprovalCode;
    @XmlElement(name = "AuditTimestamp")
    protected String auditTimestamp;
    @XmlElement(name = "ChangeDeterminationCode")
    protected String changeDeterminationCode;
    @XmlElement(name = "DeterminationIncomeCode")
    protected String determinationIncomeCode;
    @XmlElement(name = "EffectiveIndicatorSwitch")
    protected String effectiveIndicatorSwitch;
    @XmlElement(name = "FederalPovertyLevelIncomePct")
    protected String federalPovertyLevelIncomePct;
    @XmlElement(name = "LISCopaymentLevelID")
    protected String lisCopaymentLevelID;
    @XmlElement(name = "PartDPremiumSubsidyPercent")
    protected String partDPremiumSubsidyPercent;
    @XmlElement(name = "PartDSubsidyApprDate")
    protected String partDSubsidyApprDate;
    @XmlElement(name = "RecordAddedTimestamp")
    protected String recordAddedTimestamp;
    @XmlElement(name = "RecordUpdatedTimestamp")
    protected String recordUpdatedTimestamp;
    @XmlElement(name = "ResourceLevelCode")
    protected String resourceLevelCode;
    @XmlElement(name = "SSAApplicationDate")
    protected String ssaApplicationDate;
    @XmlElement(name = "StateCancellationCode")
    protected String stateCancellationCode;
    @XmlElement(name = "SubsidyEndDate")
    protected String subsidyEndDate;
    @XmlElement(name = "SubsidySource")
    protected String subsidySource;
    @XmlElement(name = "SubsidyStartDate")
    protected String subsidyStartDate;
    @XmlElement(name = "UserModified")
    protected String userModified;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the appealResolutionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealResolutionCode() {
        return appealResolutionCode;
    }

    /**
     * Sets the value of the appealResolutionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealResolutionCode(String value) {
        this.appealResolutionCode = value;
    }

    /**
     * Gets the value of the applicationApprovalCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationApprovalCode() {
        return applicationApprovalCode;
    }

    /**
     * Sets the value of the applicationApprovalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationApprovalCode(String value) {
        this.applicationApprovalCode = value;
    }

    /**
     * Gets the value of the auditTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditTimestamp() {
        return auditTimestamp;
    }

    /**
     * Sets the value of the auditTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditTimestamp(String value) {
        this.auditTimestamp = value;
    }

    /**
     * Gets the value of the changeDeterminationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeDeterminationCode() {
        return changeDeterminationCode;
    }

    /**
     * Sets the value of the changeDeterminationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeDeterminationCode(String value) {
        this.changeDeterminationCode = value;
    }

    /**
     * Gets the value of the determinationIncomeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeterminationIncomeCode() {
        return determinationIncomeCode;
    }

    /**
     * Sets the value of the determinationIncomeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeterminationIncomeCode(String value) {
        this.determinationIncomeCode = value;
    }

    /**
     * Gets the value of the effectiveIndicatorSwitch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffectiveIndicatorSwitch() {
        return effectiveIndicatorSwitch;
    }

    /**
     * Sets the value of the effectiveIndicatorSwitch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffectiveIndicatorSwitch(String value) {
        this.effectiveIndicatorSwitch = value;
    }

    /**
     * Gets the value of the federalPovertyLevelIncomePct property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFederalPovertyLevelIncomePct() {
        return federalPovertyLevelIncomePct;
    }

    /**
     * Sets the value of the federalPovertyLevelIncomePct property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFederalPovertyLevelIncomePct(String value) {
        this.federalPovertyLevelIncomePct = value;
    }

    /**
     * Gets the value of the lisCopaymentLevelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLISCopaymentLevelID() {
        return lisCopaymentLevelID;
    }

    /**
     * Sets the value of the lisCopaymentLevelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLISCopaymentLevelID(String value) {
        this.lisCopaymentLevelID = value;
    }

    /**
     * Gets the value of the partDPremiumSubsidyPercent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDPremiumSubsidyPercent() {
        return partDPremiumSubsidyPercent;
    }

    /**
     * Sets the value of the partDPremiumSubsidyPercent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDPremiumSubsidyPercent(String value) {
        this.partDPremiumSubsidyPercent = value;
    }

    /**
     * Gets the value of the partDSubsidyApprDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyApprDate() {
        return partDSubsidyApprDate;
    }

    /**
     * Sets the value of the partDSubsidyApprDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyApprDate(String value) {
        this.partDSubsidyApprDate = value;
    }

    /**
     * Gets the value of the recordAddedTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordAddedTimestamp() {
        return recordAddedTimestamp;
    }

    /**
     * Sets the value of the recordAddedTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordAddedTimestamp(String value) {
        this.recordAddedTimestamp = value;
    }

    /**
     * Gets the value of the recordUpdatedTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordUpdatedTimestamp() {
        return recordUpdatedTimestamp;
    }

    /**
     * Sets the value of the recordUpdatedTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordUpdatedTimestamp(String value) {
        this.recordUpdatedTimestamp = value;
    }

    /**
     * Gets the value of the resourceLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourceLevelCode() {
        return resourceLevelCode;
    }

    /**
     * Sets the value of the resourceLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourceLevelCode(String value) {
        this.resourceLevelCode = value;
    }

    /**
     * Gets the value of the ssaApplicationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSAApplicationDate() {
        return ssaApplicationDate;
    }

    /**
     * Sets the value of the ssaApplicationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSAApplicationDate(String value) {
        this.ssaApplicationDate = value;
    }

    /**
     * Gets the value of the stateCancellationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateCancellationCode() {
        return stateCancellationCode;
    }

    /**
     * Sets the value of the stateCancellationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateCancellationCode(String value) {
        this.stateCancellationCode = value;
    }

    /**
     * Gets the value of the subsidyEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidyEndDate() {
        return subsidyEndDate;
    }

    /**
     * Sets the value of the subsidyEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidyEndDate(String value) {
        this.subsidyEndDate = value;
    }

    /**
     * Gets the value of the subsidySource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidySource() {
        return subsidySource;
    }

    /**
     * Sets the value of the subsidySource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidySource(String value) {
        this.subsidySource = value;
    }

    /**
     * Gets the value of the subsidyStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidyStartDate() {
        return subsidyStartDate;
    }

    /**
     * Sets the value of the subsidyStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidyStartDate(String value) {
        this.subsidyStartDate = value;
    }

    /**
     * Gets the value of the userModified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserModified() {
        return userModified;
    }

    /**
     * Sets the value of the userModified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserModified(String value) {
        this.userModified = value;
    }

}
