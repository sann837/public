
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for promoteAppealRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="promoteAppealRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="level2AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalLevel3AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "promoteAppealRequest", propOrder = {
    "consumerId",
    "level2AppealNum",
    "externalLevel3AppealNum"
})
public class PromoteAppealRequest
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(namespace = "", required = true)
    protected String consumerId;
    @XmlElement(namespace = "", required = true)
    protected String level2AppealNum;
    @XmlElement(namespace = "", required = true)
    protected String externalLevel3AppealNum;

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the level2AppealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLevel2AppealNum() {
        return level2AppealNum;
    }

    /**
     * Sets the value of the level2AppealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLevel2AppealNum(String value) {
        this.level2AppealNum = value;
    }

    /**
     * Gets the value of the externalLevel3AppealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalLevel3AppealNum() {
        return externalLevel3AppealNum;
    }

    /**
     * Sets the value of the externalLevel3AppealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalLevel3AppealNum(String value) {
        this.externalLevel3AppealNum = value;
    }

}
