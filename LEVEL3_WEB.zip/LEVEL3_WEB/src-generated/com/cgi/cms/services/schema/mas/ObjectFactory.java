
package com.cgi.cms.services.schema.mas;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.cgi.cms.services.schema.mas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UnenactAppealRequest_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "unenactAppealRequest");
    private final static QName _PendAppealRequest_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "pendAppealRequest");
    private final static QName _UnpendAppealRequest_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "unpendAppealRequest");
    private final static QName _EnactAppealRequest_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "enactAppealRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.cgi.cms.services.schema.mas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UnenactAppealException }
     * 
     */
    public UnenactAppealException createUnenactAppealException() {
        return new UnenactAppealException();
    }

    /**
     * Create an instance of {@link MessageList }
     * 
     */
    public MessageList createMessageList() {
        return new MessageList();
    }

    /**
     * Create an instance of {@link UnenactAppealRequest }
     * 
     */
    public UnenactAppealRequest createUnenactAppealRequest() {
        return new UnenactAppealRequest();
    }

    /**
     * Create an instance of {@link UnenactAppealResponse }
     * 
     */
    public UnenactAppealResponse createUnenactAppealResponse() {
        return new UnenactAppealResponse();
    }

    /**
     * Create an instance of {@link SettlementErrors }
     * 
     */
    public SettlementErrors createSettlementErrors() {
        return new SettlementErrors();
    }

    /**
     * Create an instance of {@link UnpendAppealResponse }
     * 
     */
    public UnpendAppealResponse createUnpendAppealResponse() {
        return new UnpendAppealResponse();
    }

    /**
     * Create an instance of {@link PendAppealException }
     * 
     */
    public PendAppealException createPendAppealException() {
        return new PendAppealException();
    }

    /**
     * Create an instance of {@link PendAppealRequest }
     * 
     */
    public PendAppealRequest createPendAppealRequest() {
        return new PendAppealRequest();
    }

    /**
     * Create an instance of {@link EnactAppealException }
     * 
     */
    public EnactAppealException createEnactAppealException() {
        return new EnactAppealException();
    }

    /**
     * Create an instance of {@link EnactAppealRequest }
     * 
     */
    public EnactAppealRequest createEnactAppealRequest() {
        return new EnactAppealRequest();
    }

    /**
     * Create an instance of {@link EnactAppealResponse }
     * 
     */
    public EnactAppealResponse createEnactAppealResponse() {
        return new EnactAppealResponse();
    }

    /**
     * Create an instance of {@link PendAppealResponse }
     * 
     */
    public PendAppealResponse createPendAppealResponse() {
        return new PendAppealResponse();
    }

    /**
     * Create an instance of {@link UnpendAppealException }
     * 
     */
    public UnpendAppealException createUnpendAppealException() {
        return new UnpendAppealException();
    }

    /**
     * Create an instance of {@link UnpendAppealRequest }
     * 
     */
    public UnpendAppealRequest createUnpendAppealRequest() {
        return new UnpendAppealRequest();
    }

    /**
     * Create an instance of {@link UnpendAppeals }
     * 
     */
    public UnpendAppeals createUnpendAppeals() {
        return new UnpendAppeals();
    }

    /**
     * Create an instance of {@link UnpendAppeal }
     * 
     */
    public UnpendAppeal createUnpendAppeal() {
        return new UnpendAppeal();
    }

    /**
     * Create an instance of {@link UnenactAppeals }
     * 
     */
    public UnenactAppeals createUnenactAppeals() {
        return new UnenactAppeals();
    }

    /**
     * Create an instance of {@link MessageDetail }
     * 
     */
    public MessageDetail createMessageDetail() {
        return new MessageDetail();
    }

    /**
     * Create an instance of {@link EnactAppeal }
     * 
     */
    public EnactAppeal createEnactAppeal() {
        return new EnactAppeal();
    }

    /**
     * Create an instance of {@link PendAppeals }
     * 
     */
    public PendAppeals createPendAppeals() {
        return new PendAppeals();
    }

    /**
     * Create an instance of {@link PendAppeal }
     * 
     */
    public PendAppeal createPendAppeal() {
        return new PendAppeal();
    }

    /**
     * Create an instance of {@link EnactAppeals }
     * 
     */
    public EnactAppeals createEnactAppeals() {
        return new EnactAppeals();
    }

    /**
     * Create an instance of {@link UnenactAppeal }
     * 
     */
    public UnenactAppeal createUnenactAppeal() {
        return new UnenactAppeal();
    }

    /**
     * Create an instance of {@link SettlementError }
     * 
     */
    public SettlementError createSettlementError() {
        return new SettlementError();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnenactAppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "unenactAppealRequest")
    public JAXBElement<UnenactAppealRequest> createUnenactAppealRequest(UnenactAppealRequest value) {
        return new JAXBElement<UnenactAppealRequest>(_UnenactAppealRequest_QNAME, UnenactAppealRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PendAppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "pendAppealRequest")
    public JAXBElement<PendAppealRequest> createPendAppealRequest(PendAppealRequest value) {
        return new JAXBElement<PendAppealRequest>(_PendAppealRequest_QNAME, PendAppealRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnpendAppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "unpendAppealRequest")
    public JAXBElement<UnpendAppealRequest> createUnpendAppealRequest(UnpendAppealRequest value) {
        return new JAXBElement<UnpendAppealRequest>(_UnpendAppealRequest_QNAME, UnpendAppealRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnactAppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "enactAppealRequest")
    public JAXBElement<EnactAppealRequest> createEnactAppealRequest(EnactAppealRequest value) {
        return new JAXBElement<EnactAppealRequest>(_EnactAppealRequest_QNAME, EnactAppealRequest.class, null, value);
    }

}
