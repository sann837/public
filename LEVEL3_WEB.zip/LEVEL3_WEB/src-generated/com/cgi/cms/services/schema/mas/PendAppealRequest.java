
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for pendAppealRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="pendAppealRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="settlementIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pendAppeals" type="{http://mas.schema.services.cms.cgi.com/}pendAppeals"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pendAppealRequest", propOrder = {
    "consumerId",
    "settlementIndicator",
    "pendAppeals"
})
public class PendAppealRequest
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(namespace = "", required = true)
    protected String consumerId;
    @XmlElement(namespace = "", required = true)
    protected String settlementIndicator;
    @XmlElement(namespace = "", required = true)
    protected PendAppeals pendAppeals;

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the settlementIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlementIndicator() {
        return settlementIndicator;
    }

    /**
     * Sets the value of the settlementIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlementIndicator(String value) {
        this.settlementIndicator = value;
    }

    /**
     * Gets the value of the pendAppeals property.
     * 
     * @return
     *     possible object is
     *     {@link PendAppeals }
     *     
     */
    public PendAppeals getPendAppeals() {
        return pendAppeals;
    }

    /**
     * Sets the value of the pendAppeals property.
     * 
     * @param value
     *     allowed object is
     *     {@link PendAppeals }
     *     
     */
    public void setPendAppeals(PendAppeals value) {
        this.pendAppeals = value;
    }

}
