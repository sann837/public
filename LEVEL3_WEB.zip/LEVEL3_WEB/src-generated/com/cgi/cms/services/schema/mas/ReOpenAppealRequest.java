
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for reOpenAppealRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="reOpenAppealRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="appealNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalLevel3AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="partyType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="reasonForReopening" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reOpenAppealRequest", propOrder = {
    "consumerId",
    "appealNumber",
    "externalLevel3AppealNum",
    "partyType",
    "reasonForReopening"
})
public class ReOpenAppealRequest
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(namespace = "", required = true)
    protected String consumerId;
    @XmlElement(namespace = "", required = true)
    protected String appealNumber;
    @XmlElement(namespace = "", required = true)
    protected String externalLevel3AppealNum;
    @XmlElement(namespace = "", required = true)
    protected String partyType;
    @XmlElement(namespace = "", required = true)
    protected String reasonForReopening;

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the appealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNumber() {
        return appealNumber;
    }

    /**
     * Sets the value of the appealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNumber(String value) {
        this.appealNumber = value;
    }

    /**
     * Gets the value of the externalLevel3AppealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalLevel3AppealNum() {
        return externalLevel3AppealNum;
    }

    /**
     * Sets the value of the externalLevel3AppealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalLevel3AppealNum(String value) {
        this.externalLevel3AppealNum = value;
    }

    /**
     * Gets the value of the partyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyType() {
        return partyType;
    }

    /**
     * Sets the value of the partyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyType(String value) {
        this.partyType = value;
    }

    /**
     * Gets the value of the reasonForReopening property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForReopening() {
        return reasonForReopening;
    }

    /**
     * Sets the value of the reasonForReopening property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForReopening(String value) {
        this.reasonForReopening = value;
    }

}
