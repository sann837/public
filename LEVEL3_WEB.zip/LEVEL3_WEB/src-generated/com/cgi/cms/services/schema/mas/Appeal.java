
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Level2AppealNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AppealStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DecisionLetterMailedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppealDisposition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MASLevel3AppealNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Claim" type="{http://mas.schema.services.cms.cgi.com/}Claim" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "level2AppealNumber",
    "appealStatus",
    "decisionLetterMailedDate",
    "appealDisposition",
    "masLevel3AppealNumber",
    "medicareType",
    "claim"
})
public class Appeal
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(name = "Level2AppealNumber", required = true)
    protected String level2AppealNumber;
    @XmlElement(name = "AppealStatus", required = true)
    protected String appealStatus;
    @XmlElement(name = "DecisionLetterMailedDate")
    protected String decisionLetterMailedDate;
    @XmlElement(name = "AppealDisposition")
    protected String appealDisposition;
    @XmlElement(name = "MASLevel3AppealNumber")
    protected String masLevel3AppealNumber;
    @XmlElement(name = "MedicareType")
    protected String medicareType;
    @XmlElement(name = "Claim")
    protected Claim claim;

    /**
     * Gets the value of the level2AppealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLevel2AppealNumber() {
        return level2AppealNumber;
    }

    /**
     * Sets the value of the level2AppealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLevel2AppealNumber(String value) {
        this.level2AppealNumber = value;
    }

    /**
     * Gets the value of the appealStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealStatus() {
        return appealStatus;
    }

    /**
     * Sets the value of the appealStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealStatus(String value) {
        this.appealStatus = value;
    }

    /**
     * Gets the value of the decisionLetterMailedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionLetterMailedDate() {
        return decisionLetterMailedDate;
    }

    /**
     * Sets the value of the decisionLetterMailedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionLetterMailedDate(String value) {
        this.decisionLetterMailedDate = value;
    }

    /**
     * Gets the value of the appealDisposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealDisposition() {
        return appealDisposition;
    }

    /**
     * Sets the value of the appealDisposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealDisposition(String value) {
        this.appealDisposition = value;
    }

    /**
     * Gets the value of the masLevel3AppealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMASLevel3AppealNumber() {
        return masLevel3AppealNumber;
    }

    /**
     * Sets the value of the masLevel3AppealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMASLevel3AppealNumber(String value) {
        this.masLevel3AppealNumber = value;
    }

    /**
     * Gets the value of the medicareType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareType() {
        return medicareType;
    }

    /**
     * Sets the value of the medicareType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareType(String value) {
        this.medicareType = value;
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link Claim }
     *     
     */
    public Claim getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link Claim }
     *     
     */
    public void setClaim(Claim value) {
        this.claim = value;
    }

}
