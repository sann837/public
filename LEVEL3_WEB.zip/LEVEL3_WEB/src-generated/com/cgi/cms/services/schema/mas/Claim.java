
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Claim complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Claim">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClaimNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateOfServiceTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateOfServiceFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Beneficiary" type="{http://mas.schema.services.cms.cgi.com/}Beneficiary" minOccurs="0"/>
 *         &lt;element name="Provider" type="{http://mas.schema.services.cms.cgi.com/}Provider" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Claim", propOrder = {
    "claimNumber",
    "dateOfServiceTo",
    "beneIndicator",
    "dateOfServiceFrom",
    "beneficiary",
    "provider"
})
public class Claim
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(name = "ClaimNumber")
    protected String claimNumber;
    @XmlElement(name = "DateOfServiceTo")
    protected String dateOfServiceTo;
    @XmlElement(name = "BeneIndicator")
    protected String beneIndicator;
    @XmlElement(name = "DateOfServiceFrom")
    protected String dateOfServiceFrom;
    @XmlElement(name = "Beneficiary")
    protected Beneficiary beneficiary;
    @XmlElement(name = "Provider")
    protected Provider provider;

    /**
     * Gets the value of the claimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the claimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNumber(String value) {
        this.claimNumber = value;
    }

    /**
     * Gets the value of the dateOfServiceTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfServiceTo() {
        return dateOfServiceTo;
    }

    /**
     * Sets the value of the dateOfServiceTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfServiceTo(String value) {
        this.dateOfServiceTo = value;
    }

    /**
     * Gets the value of the beneIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneIndicator() {
        return beneIndicator;
    }

    /**
     * Sets the value of the beneIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneIndicator(String value) {
        this.beneIndicator = value;
    }

    /**
     * Gets the value of the dateOfServiceFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfServiceFrom() {
        return dateOfServiceFrom;
    }

    /**
     * Sets the value of the dateOfServiceFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfServiceFrom(String value) {
        this.dateOfServiceFrom = value;
    }

    /**
     * Gets the value of the beneficiary property.
     * 
     * @return
     *     possible object is
     *     {@link Beneficiary }
     *     
     */
    public Beneficiary getBeneficiary() {
        return beneficiary;
    }

    /**
     * Sets the value of the beneficiary property.
     * 
     * @param value
     *     allowed object is
     *     {@link Beneficiary }
     *     
     */
    public void setBeneficiary(Beneficiary value) {
        this.beneficiary = value;
    }

    /**
     * Gets the value of the provider property.
     * 
     * @return
     *     possible object is
     *     {@link Provider }
     *     
     */
    public Provider getProvider() {
        return provider;
    }

    /**
     * Sets the value of the provider property.
     * 
     * @param value
     *     allowed object is
     *     {@link Provider }
     *     
     */
    public void setProvider(Provider value) {
        this.provider = value;
    }

}
