
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for dataMigrateRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="dataMigrateRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="listOfAppeal" type="{http://mas.schema.services.cms.cgi.com/}listOfAppeal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "dataMigrateRequest", propOrder = {
    "consumerId",
    "listOfAppeal"
})
public class DataMigrateRequest
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(namespace = "", required = true)
    protected String consumerId;
    @XmlElement(namespace = "", required = true)
    protected ListOfAppeal listOfAppeal;

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the listOfAppeal property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfAppeal }
     *     
     */
    public ListOfAppeal getListOfAppeal() {
        return listOfAppeal;
    }

    /**
     * Sets the value of the listOfAppeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfAppeal }
     *     
     */
    public void setListOfAppeal(ListOfAppeal value) {
        this.listOfAppeal = value;
    }

}
