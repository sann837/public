
package com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL3SvcCloseEcmIo_QNAME = new QName("http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO", "ListOfMasL3SvcCloseEcmIo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseEcmIo }
     * 
     */
    public ListOfMasL3SvcCloseEcmIo createListOfMasL3SvcCloseEcmIo() {
        return new ListOfMasL3SvcCloseEcmIo();
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseEcmIoTopElmt }
     * 
     */
    public ListOfMasL3SvcCloseEcmIoTopElmt createListOfMasL3SvcCloseEcmIoTopElmt() {
        return new ListOfMasL3SvcCloseEcmIoTopElmt();
    }

    /**
     * Create an instance of {@link ECMDocuments }
     * 
     */
    public ECMDocuments createECMDocuments() {
        return new ECMDocuments();
    }

    /**
     * Create an instance of {@link ECMDocument }
     * 
     */
    public ECMDocument createECMDocument() {
        return new ECMDocument();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL3SvcCloseEcmIo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO", name = "ListOfMasL3SvcCloseEcmIo")
    public JAXBElement<ListOfMasL3SvcCloseEcmIo> createListOfMasL3SvcCloseEcmIo(ListOfMasL3SvcCloseEcmIo value) {
        return new JAXBElement<ListOfMasL3SvcCloseEcmIo>(_ListOfMasL3SvcCloseEcmIo_QNAME, ListOfMasL3SvcCloseEcmIo.class, null, value);
    }

}
