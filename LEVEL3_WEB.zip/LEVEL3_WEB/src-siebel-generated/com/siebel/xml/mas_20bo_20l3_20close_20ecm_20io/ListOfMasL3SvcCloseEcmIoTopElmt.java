
package com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfMasL3SvcCloseEcmIoTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfMasL3SvcCloseEcmIoTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfMasL3SvcCloseEcmIo" type="{http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO}ListOfMasL3SvcCloseEcmIo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfMasL3SvcCloseEcmIoTopElmt", propOrder = {
    "listOfMasL3SvcCloseEcmIo"
})
public class ListOfMasL3SvcCloseEcmIoTopElmt {

    @XmlElement(name = "ListOfMasL3SvcCloseEcmIo", required = true)
    protected ListOfMasL3SvcCloseEcmIo listOfMasL3SvcCloseEcmIo;

    /**
     * Gets the value of the listOfMasL3SvcCloseEcmIo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL3SvcCloseEcmIo }
     *     
     */
    public ListOfMasL3SvcCloseEcmIo getListOfMasL3SvcCloseEcmIo() {
        return listOfMasL3SvcCloseEcmIo;
    }

    /**
     * Sets the value of the listOfMasL3SvcCloseEcmIo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL3SvcCloseEcmIo }
     *     
     */
    public void setListOfMasL3SvcCloseEcmIo(ListOfMasL3SvcCloseEcmIo value) {
        this.listOfMasL3SvcCloseEcmIo = value;
    }

}
