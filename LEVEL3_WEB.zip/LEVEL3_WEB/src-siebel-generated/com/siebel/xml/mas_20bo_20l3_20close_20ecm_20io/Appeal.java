
package com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ECMDocuments" type="{http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO}ECMDocuments" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "appealNum",
    "transactionID",
    "ecmDocuments"
})
public class Appeal {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "TransactionID")
    protected String transactionID;
    @XmlElement(name = "ECMDocuments")
    protected ECMDocuments ecmDocuments;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the ecmDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link ECMDocuments }
     *     
     */
    public ECMDocuments getECMDocuments() {
        return ecmDocuments;
    }

    /**
     * Sets the value of the ecmDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ECMDocuments }
     *     
     */
    public void setECMDocuments(ECMDocuments value) {
        this.ecmDocuments = value;
    }

}
