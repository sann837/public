
package com.siebel.xml.mas_20settlement_20ii_20appeals;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfAppealTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfAppealTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfAppeal" type="{http://www.siebel.com/xml/MAS%20Settlement%20II%20Appeals}ListOfAppeal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfAppealTopElmt", propOrder = {
    "listOfAppeal"
})
public class ListOfAppealTopElmt {

    @XmlElement(name = "ListOfAppeal", required = true)
    protected ListOfAppeal listOfAppeal;

    /**
     * Gets the value of the listOfAppeal property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfAppeal }
     *     
     */
    public ListOfAppeal getListOfAppeal() {
        return listOfAppeal;
    }

    /**
     * Sets the value of the listOfAppeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfAppeal }
     *     
     */
    public void setListOfAppeal(ListOfAppeal value) {
        this.listOfAppeal = value;
    }

}
