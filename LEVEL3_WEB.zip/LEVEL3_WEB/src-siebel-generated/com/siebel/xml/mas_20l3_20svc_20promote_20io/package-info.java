@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20l3_20svc_20promote_20io;
