
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Beneficiary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Beneficiary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfBeneficiary_Address" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_Address" minOccurs="0"/>
 *         &lt;element name="ListOfBeneficiary_MARxPremiumCoverage" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_MARxPremiumCoverage" minOccurs="0"/>
 *         &lt;element name="ListOfBeneficiary_MARxCreditableCoverage" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_MARxCreditableCoverage" minOccurs="0"/>
 *         &lt;element name="ListOfBeneficiary_PartDEntitlement" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_PartDEntitlement" minOccurs="0"/>
 *         &lt;element name="ListOfBeneficiary_PartBEntitlement" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_PartBEntitlement" minOccurs="0"/>
 *         &lt;element name="ListOfBeneficiary_PartAEntitlement" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneficiary_PartAEntitlement" minOccurs="0"/>
 *         &lt;element name="ListOfBeneCopayInfo" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneCopayInfo" minOccurs="0"/>
 *         &lt;element name="ListOfBeneSubsidiaryInfo" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneSubsidiaryInfo" minOccurs="0"/>
 *         &lt;element name="ListOfBeneSubsidiaryDeniedInfo" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneSubsidiaryDeniedInfo" minOccurs="0"/>
 *         &lt;element name="ListOfBeneEnrollmentHistory" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneEnrollmentHistory" minOccurs="0"/>
 *         &lt;element name="ListOfBeneEligibilityHistory" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}ListOfBeneEligibilityHistory" minOccurs="0"/>
 *         &lt;element name="Id" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="BeneficiaryEligible" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CellPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DOB" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DODSource" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="DoD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnrolledinPartD" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string20" minOccurs="0"/>
 *         &lt;element name="HICNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string11"/>
 *         &lt;element name="MBDLastUpdated" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MBDStatus" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string350" minOccurs="0"/>
 *         &lt;element name="MiddleName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="OtherInsurance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Pager" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RetireeEmpSuppBenefits" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SocialSecurityNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string11" minOccurs="0"/>
 *         &lt;element name="Suffix" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string15" minOccurs="0"/>
 *         &lt;element name="WorkPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssociatedHICNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="Deceased" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Email" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string350" minOccurs="0"/>
 *         &lt;element name="Fax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50"/>
 *         &lt;element name="Gender" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="HomePhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50"/>
 *         &lt;element name="LanguagePreference" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="MediaPreference" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Prefix" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string15" minOccurs="0"/>
 *         &lt;element name="SupplementalBenefitsDescription" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiactive" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiselected" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Beneficiary", propOrder = {
    "listOfBeneficiaryAddress",
    "listOfBeneficiaryMARxPremiumCoverage",
    "listOfBeneficiaryMARxCreditableCoverage",
    "listOfBeneficiaryPartDEntitlement",
    "listOfBeneficiaryPartBEntitlement",
    "listOfBeneficiaryPartAEntitlement",
    "listOfBeneCopayInfo",
    "listOfBeneSubsidiaryInfo",
    "listOfBeneSubsidiaryDeniedInfo",
    "listOfBeneEnrollmentHistory",
    "listOfBeneEligibilityHistory",
    "id",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "beneficiaryEligible",
    "cellPhone",
    "dob",
    "dodSource",
    "doD",
    "enrolledinPartD",
    "hicNum",
    "mbdLastUpdated",
    "mbdStatus",
    "middleName",
    "otherInsurance",
    "pager",
    "retireeEmpSuppBenefits",
    "socialSecurityNumber",
    "suffix",
    "workPhone",
    "associatedHICNum",
    "deceased",
    "email",
    "fax",
    "firstName",
    "gender",
    "homePhone",
    "lastName",
    "languagePreference",
    "mediaPreference",
    "prefix",
    "supplementalBenefitsDescription"
})
public class Beneficiary {

    @XmlElement(name = "ListOfBeneficiary_Address")
    protected ListOfBeneficiaryAddress listOfBeneficiaryAddress;
    @XmlElement(name = "ListOfBeneficiary_MARxPremiumCoverage")
    protected ListOfBeneficiaryMARxPremiumCoverage listOfBeneficiaryMARxPremiumCoverage;
    @XmlElement(name = "ListOfBeneficiary_MARxCreditableCoverage")
    protected ListOfBeneficiaryMARxCreditableCoverage listOfBeneficiaryMARxCreditableCoverage;
    @XmlElement(name = "ListOfBeneficiary_PartDEntitlement")
    protected ListOfBeneficiaryPartDEntitlement listOfBeneficiaryPartDEntitlement;
    @XmlElement(name = "ListOfBeneficiary_PartBEntitlement")
    protected ListOfBeneficiaryPartBEntitlement listOfBeneficiaryPartBEntitlement;
    @XmlElement(name = "ListOfBeneficiary_PartAEntitlement")
    protected ListOfBeneficiaryPartAEntitlement listOfBeneficiaryPartAEntitlement;
    @XmlElement(name = "ListOfBeneCopayInfo")
    protected ListOfBeneCopayInfo listOfBeneCopayInfo;
    @XmlElement(name = "ListOfBeneSubsidiaryInfo")
    protected ListOfBeneSubsidiaryInfo listOfBeneSubsidiaryInfo;
    @XmlElement(name = "ListOfBeneSubsidiaryDeniedInfo")
    protected ListOfBeneSubsidiaryDeniedInfo listOfBeneSubsidiaryDeniedInfo;
    @XmlElement(name = "ListOfBeneEnrollmentHistory")
    protected ListOfBeneEnrollmentHistory listOfBeneEnrollmentHistory;
    @XmlElement(name = "ListOfBeneEligibilityHistory")
    protected ListOfBeneEligibilityHistory listOfBeneEligibilityHistory;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "BeneficiaryEligible")
    protected String beneficiaryEligible;
    @XmlElement(name = "CellPhone")
    protected String cellPhone;
    @XmlElement(name = "DOB")
    protected String dob;
    @XmlElement(name = "DODSource")
    protected String dodSource;
    @XmlElement(name = "DoD")
    protected String doD;
    @XmlElement(name = "EnrolledinPartD")
    protected String enrolledinPartD;
    @XmlElement(name = "HICNum", required = true)
    protected String hicNum;
    @XmlElement(name = "MBDLastUpdated")
    protected String mbdLastUpdated;
    @XmlElement(name = "MBDStatus")
    protected String mbdStatus;
    @XmlElement(name = "MiddleName")
    protected String middleName;
    @XmlElement(name = "OtherInsurance")
    protected String otherInsurance;
    @XmlElement(name = "Pager")
    protected String pager;
    @XmlElement(name = "RetireeEmpSuppBenefits")
    protected String retireeEmpSuppBenefits;
    @XmlElement(name = "SocialSecurityNumber")
    protected String socialSecurityNumber;
    @XmlElement(name = "Suffix")
    protected String suffix;
    @XmlElement(name = "WorkPhone")
    protected String workPhone;
    @XmlElement(name = "AssociatedHICNum")
    protected String associatedHICNum;
    @XmlElement(name = "Deceased")
    protected String deceased;
    @XmlElement(name = "Email")
    protected String email;
    @XmlElement(name = "Fax")
    protected String fax;
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    @XmlElement(name = "Gender")
    protected String gender;
    @XmlElement(name = "HomePhone")
    protected String homePhone;
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    @XmlElement(name = "LanguagePreference")
    protected String languagePreference;
    @XmlElement(name = "MediaPreference")
    protected String mediaPreference;
    @XmlElement(name = "Prefix")
    protected String prefix;
    @XmlElement(name = "SupplementalBenefitsDescription")
    protected String supplementalBenefitsDescription;
    @XmlAttribute(name = "Operation")
    protected String operation;
    @XmlAttribute(name = "Uiactive")
    protected String uiactive;
    @XmlAttribute(name = "Uiselected")
    protected String uiselected;

    /**
     * Gets the value of the listOfBeneficiaryAddress property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryAddress }
     *     
     */
    public ListOfBeneficiaryAddress getListOfBeneficiaryAddress() {
        return listOfBeneficiaryAddress;
    }

    /**
     * Sets the value of the listOfBeneficiaryAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryAddress }
     *     
     */
    public void setListOfBeneficiaryAddress(ListOfBeneficiaryAddress value) {
        this.listOfBeneficiaryAddress = value;
    }

    /**
     * Gets the value of the listOfBeneficiaryMARxPremiumCoverage property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryMARxPremiumCoverage }
     *     
     */
    public ListOfBeneficiaryMARxPremiumCoverage getListOfBeneficiaryMARxPremiumCoverage() {
        return listOfBeneficiaryMARxPremiumCoverage;
    }

    /**
     * Sets the value of the listOfBeneficiaryMARxPremiumCoverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryMARxPremiumCoverage }
     *     
     */
    public void setListOfBeneficiaryMARxPremiumCoverage(ListOfBeneficiaryMARxPremiumCoverage value) {
        this.listOfBeneficiaryMARxPremiumCoverage = value;
    }

    /**
     * Gets the value of the listOfBeneficiaryMARxCreditableCoverage property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryMARxCreditableCoverage }
     *     
     */
    public ListOfBeneficiaryMARxCreditableCoverage getListOfBeneficiaryMARxCreditableCoverage() {
        return listOfBeneficiaryMARxCreditableCoverage;
    }

    /**
     * Sets the value of the listOfBeneficiaryMARxCreditableCoverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryMARxCreditableCoverage }
     *     
     */
    public void setListOfBeneficiaryMARxCreditableCoverage(ListOfBeneficiaryMARxCreditableCoverage value) {
        this.listOfBeneficiaryMARxCreditableCoverage = value;
    }

    /**
     * Gets the value of the listOfBeneficiaryPartDEntitlement property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryPartDEntitlement }
     *     
     */
    public ListOfBeneficiaryPartDEntitlement getListOfBeneficiaryPartDEntitlement() {
        return listOfBeneficiaryPartDEntitlement;
    }

    /**
     * Sets the value of the listOfBeneficiaryPartDEntitlement property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryPartDEntitlement }
     *     
     */
    public void setListOfBeneficiaryPartDEntitlement(ListOfBeneficiaryPartDEntitlement value) {
        this.listOfBeneficiaryPartDEntitlement = value;
    }

    /**
     * Gets the value of the listOfBeneficiaryPartBEntitlement property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryPartBEntitlement }
     *     
     */
    public ListOfBeneficiaryPartBEntitlement getListOfBeneficiaryPartBEntitlement() {
        return listOfBeneficiaryPartBEntitlement;
    }

    /**
     * Sets the value of the listOfBeneficiaryPartBEntitlement property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryPartBEntitlement }
     *     
     */
    public void setListOfBeneficiaryPartBEntitlement(ListOfBeneficiaryPartBEntitlement value) {
        this.listOfBeneficiaryPartBEntitlement = value;
    }

    /**
     * Gets the value of the listOfBeneficiaryPartAEntitlement property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneficiaryPartAEntitlement }
     *     
     */
    public ListOfBeneficiaryPartAEntitlement getListOfBeneficiaryPartAEntitlement() {
        return listOfBeneficiaryPartAEntitlement;
    }

    /**
     * Sets the value of the listOfBeneficiaryPartAEntitlement property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneficiaryPartAEntitlement }
     *     
     */
    public void setListOfBeneficiaryPartAEntitlement(ListOfBeneficiaryPartAEntitlement value) {
        this.listOfBeneficiaryPartAEntitlement = value;
    }

    /**
     * Gets the value of the listOfBeneCopayInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneCopayInfo }
     *     
     */
    public ListOfBeneCopayInfo getListOfBeneCopayInfo() {
        return listOfBeneCopayInfo;
    }

    /**
     * Sets the value of the listOfBeneCopayInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneCopayInfo }
     *     
     */
    public void setListOfBeneCopayInfo(ListOfBeneCopayInfo value) {
        this.listOfBeneCopayInfo = value;
    }

    /**
     * Gets the value of the listOfBeneSubsidiaryInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneSubsidiaryInfo }
     *     
     */
    public ListOfBeneSubsidiaryInfo getListOfBeneSubsidiaryInfo() {
        return listOfBeneSubsidiaryInfo;
    }

    /**
     * Sets the value of the listOfBeneSubsidiaryInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneSubsidiaryInfo }
     *     
     */
    public void setListOfBeneSubsidiaryInfo(ListOfBeneSubsidiaryInfo value) {
        this.listOfBeneSubsidiaryInfo = value;
    }

    /**
     * Gets the value of the listOfBeneSubsidiaryDeniedInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneSubsidiaryDeniedInfo }
     *     
     */
    public ListOfBeneSubsidiaryDeniedInfo getListOfBeneSubsidiaryDeniedInfo() {
        return listOfBeneSubsidiaryDeniedInfo;
    }

    /**
     * Sets the value of the listOfBeneSubsidiaryDeniedInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneSubsidiaryDeniedInfo }
     *     
     */
    public void setListOfBeneSubsidiaryDeniedInfo(ListOfBeneSubsidiaryDeniedInfo value) {
        this.listOfBeneSubsidiaryDeniedInfo = value;
    }

    /**
     * Gets the value of the listOfBeneEnrollmentHistory property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneEnrollmentHistory }
     *     
     */
    public ListOfBeneEnrollmentHistory getListOfBeneEnrollmentHistory() {
        return listOfBeneEnrollmentHistory;
    }

    /**
     * Sets the value of the listOfBeneEnrollmentHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneEnrollmentHistory }
     *     
     */
    public void setListOfBeneEnrollmentHistory(ListOfBeneEnrollmentHistory value) {
        this.listOfBeneEnrollmentHistory = value;
    }

    /**
     * Gets the value of the listOfBeneEligibilityHistory property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfBeneEligibilityHistory }
     *     
     */
    public ListOfBeneEligibilityHistory getListOfBeneEligibilityHistory() {
        return listOfBeneEligibilityHistory;
    }

    /**
     * Sets the value of the listOfBeneEligibilityHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfBeneEligibilityHistory }
     *     
     */
    public void setListOfBeneEligibilityHistory(ListOfBeneEligibilityHistory value) {
        this.listOfBeneEligibilityHistory = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the beneficiaryEligible property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryEligible() {
        return beneficiaryEligible;
    }

    /**
     * Sets the value of the beneficiaryEligible property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryEligible(String value) {
        this.beneficiaryEligible = value;
    }

    /**
     * Gets the value of the cellPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     * Sets the value of the cellPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellPhone(String value) {
        this.cellPhone = value;
    }

    /**
     * Gets the value of the dob property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOB() {
        return dob;
    }

    /**
     * Sets the value of the dob property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOB(String value) {
        this.dob = value;
    }

    /**
     * Gets the value of the dodSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDODSource() {
        return dodSource;
    }

    /**
     * Sets the value of the dodSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDODSource(String value) {
        this.dodSource = value;
    }

    /**
     * Gets the value of the doD property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoD() {
        return doD;
    }

    /**
     * Sets the value of the doD property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoD(String value) {
        this.doD = value;
    }

    /**
     * Gets the value of the enrolledinPartD property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrolledinPartD() {
        return enrolledinPartD;
    }

    /**
     * Sets the value of the enrolledinPartD property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrolledinPartD(String value) {
        this.enrolledinPartD = value;
    }

    /**
     * Gets the value of the hicNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHICNum() {
        return hicNum;
    }

    /**
     * Sets the value of the hicNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHICNum(String value) {
        this.hicNum = value;
    }

    /**
     * Gets the value of the mbdLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMBDLastUpdated() {
        return mbdLastUpdated;
    }

    /**
     * Sets the value of the mbdLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMBDLastUpdated(String value) {
        this.mbdLastUpdated = value;
    }

    /**
     * Gets the value of the mbdStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMBDStatus() {
        return mbdStatus;
    }

    /**
     * Sets the value of the mbdStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMBDStatus(String value) {
        this.mbdStatus = value;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Gets the value of the otherInsurance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherInsurance() {
        return otherInsurance;
    }

    /**
     * Sets the value of the otherInsurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherInsurance(String value) {
        this.otherInsurance = value;
    }

    /**
     * Gets the value of the pager property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPager() {
        return pager;
    }

    /**
     * Sets the value of the pager property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPager(String value) {
        this.pager = value;
    }

    /**
     * Gets the value of the retireeEmpSuppBenefits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetireeEmpSuppBenefits() {
        return retireeEmpSuppBenefits;
    }

    /**
     * Sets the value of the retireeEmpSuppBenefits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetireeEmpSuppBenefits(String value) {
        this.retireeEmpSuppBenefits = value;
    }

    /**
     * Gets the value of the socialSecurityNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    /**
     * Sets the value of the socialSecurityNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSocialSecurityNumber(String value) {
        this.socialSecurityNumber = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the workPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkPhone() {
        return workPhone;
    }

    /**
     * Sets the value of the workPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkPhone(String value) {
        this.workPhone = value;
    }

    /**
     * Gets the value of the associatedHICNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssociatedHICNum() {
        return associatedHICNum;
    }

    /**
     * Sets the value of the associatedHICNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssociatedHICNum(String value) {
        this.associatedHICNum = value;
    }

    /**
     * Gets the value of the deceased property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeceased() {
        return deceased;
    }

    /**
     * Sets the value of the deceased property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeceased(String value) {
        this.deceased = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the fax property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFax() {
        return fax;
    }

    /**
     * Sets the value of the fax property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFax(String value) {
        this.fax = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the homePhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     * Sets the value of the homePhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePhone(String value) {
        this.homePhone = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the languagePreference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguagePreference() {
        return languagePreference;
    }

    /**
     * Sets the value of the languagePreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguagePreference(String value) {
        this.languagePreference = value;
    }

    /**
     * Gets the value of the mediaPreference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMediaPreference() {
        return mediaPreference;
    }

    /**
     * Sets the value of the mediaPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMediaPreference(String value) {
        this.mediaPreference = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the supplementalBenefitsDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSupplementalBenefitsDescription() {
        return supplementalBenefitsDescription;
    }

    /**
     * Sets the value of the supplementalBenefitsDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSupplementalBenefitsDescription(String value) {
        this.supplementalBenefitsDescription = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Gets the value of the uiactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiactive() {
        return uiactive;
    }

    /**
     * Sets the value of the uiactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiactive(String value) {
        this.uiactive = value;
    }

    /**
     * Gets the value of the uiselected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiselected() {
        return uiselected;
    }

    /**
     * Sets the value of the uiselected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiselected(String value) {
        this.uiselected = value;
    }

}
