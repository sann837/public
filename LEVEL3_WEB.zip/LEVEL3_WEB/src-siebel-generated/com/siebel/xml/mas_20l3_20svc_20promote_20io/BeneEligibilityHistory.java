
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneEligibilityHistory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneEligibilityHistory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="DrugCoverageCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="DualEligibilityCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="FederalPovertyLevelCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="FederalPovertyLevelSourceCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="InstitutionalStatusCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PartDEligibilityFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDEnrollmentFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareEligibilityEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareEligibilityStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareEligibilityStateCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="MedicareEligibilityStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiactive" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiselected" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneEligibilityHistory", propOrder = {
    "id",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "drugCoverageCode",
    "dualEligibilityCode",
    "federalPovertyLevelCode",
    "federalPovertyLevelSourceCode",
    "institutionalStatusCode",
    "partDEligibilityFlag",
    "partDEnrollmentFlag",
    "medicareEligibilityEndDate",
    "medicareEligibilityStartDate",
    "medicareEligibilityStateCode",
    "medicareEligibilityStatusCode"
})
public class BeneEligibilityHistory {

    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "DrugCoverageCode")
    protected String drugCoverageCode;
    @XmlElement(name = "DualEligibilityCode")
    protected String dualEligibilityCode;
    @XmlElement(name = "FederalPovertyLevelCode")
    protected String federalPovertyLevelCode;
    @XmlElement(name = "FederalPovertyLevelSourceCode")
    protected String federalPovertyLevelSourceCode;
    @XmlElement(name = "InstitutionalStatusCode")
    protected String institutionalStatusCode;
    @XmlElement(name = "PartDEligibilityFlag")
    protected String partDEligibilityFlag;
    @XmlElement(name = "PartDEnrollmentFlag")
    protected String partDEnrollmentFlag;
    @XmlElement(name = "MedicareEligibilityEndDate")
    protected String medicareEligibilityEndDate;
    @XmlElement(name = "MedicareEligibilityStartDate")
    protected String medicareEligibilityStartDate;
    @XmlElement(name = "MedicareEligibilityStateCode")
    protected String medicareEligibilityStateCode;
    @XmlElement(name = "MedicareEligibilityStatusCode")
    protected String medicareEligibilityStatusCode;
    @XmlAttribute(name = "Operation")
    protected String operation;
    @XmlAttribute(name = "Uiactive")
    protected String uiactive;
    @XmlAttribute(name = "Uiselected")
    protected String uiselected;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the drugCoverageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugCoverageCode() {
        return drugCoverageCode;
    }

    /**
     * Sets the value of the drugCoverageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugCoverageCode(String value) {
        this.drugCoverageCode = value;
    }

    /**
     * Gets the value of the dualEligibilityCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDualEligibilityCode() {
        return dualEligibilityCode;
    }

    /**
     * Sets the value of the dualEligibilityCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDualEligibilityCode(String value) {
        this.dualEligibilityCode = value;
    }

    /**
     * Gets the value of the federalPovertyLevelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFederalPovertyLevelCode() {
        return federalPovertyLevelCode;
    }

    /**
     * Sets the value of the federalPovertyLevelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFederalPovertyLevelCode(String value) {
        this.federalPovertyLevelCode = value;
    }

    /**
     * Gets the value of the federalPovertyLevelSourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFederalPovertyLevelSourceCode() {
        return federalPovertyLevelSourceCode;
    }

    /**
     * Sets the value of the federalPovertyLevelSourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFederalPovertyLevelSourceCode(String value) {
        this.federalPovertyLevelSourceCode = value;
    }

    /**
     * Gets the value of the institutionalStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstitutionalStatusCode() {
        return institutionalStatusCode;
    }

    /**
     * Sets the value of the institutionalStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstitutionalStatusCode(String value) {
        this.institutionalStatusCode = value;
    }

    /**
     * Gets the value of the partDEligibilityFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDEligibilityFlag() {
        return partDEligibilityFlag;
    }

    /**
     * Sets the value of the partDEligibilityFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDEligibilityFlag(String value) {
        this.partDEligibilityFlag = value;
    }

    /**
     * Gets the value of the partDEnrollmentFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDEnrollmentFlag() {
        return partDEnrollmentFlag;
    }

    /**
     * Sets the value of the partDEnrollmentFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDEnrollmentFlag(String value) {
        this.partDEnrollmentFlag = value;
    }

    /**
     * Gets the value of the medicareEligibilityEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareEligibilityEndDate() {
        return medicareEligibilityEndDate;
    }

    /**
     * Sets the value of the medicareEligibilityEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareEligibilityEndDate(String value) {
        this.medicareEligibilityEndDate = value;
    }

    /**
     * Gets the value of the medicareEligibilityStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareEligibilityStartDate() {
        return medicareEligibilityStartDate;
    }

    /**
     * Sets the value of the medicareEligibilityStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareEligibilityStartDate(String value) {
        this.medicareEligibilityStartDate = value;
    }

    /**
     * Gets the value of the medicareEligibilityStateCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareEligibilityStateCode() {
        return medicareEligibilityStateCode;
    }

    /**
     * Sets the value of the medicareEligibilityStateCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareEligibilityStateCode(String value) {
        this.medicareEligibilityStateCode = value;
    }

    /**
     * Gets the value of the medicareEligibilityStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareEligibilityStatusCode() {
        return medicareEligibilityStatusCode;
    }

    /**
     * Sets the value of the medicareEligibilityStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareEligibilityStatusCode(String value) {
        this.medicareEligibilityStatusCode = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Gets the value of the uiactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiactive() {
        return uiactive;
    }

    /**
     * Sets the value of the uiactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiactive(String value) {
        this.uiactive = value;
    }

    /**
     * Gets the value of the uiselected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiselected() {
        return uiselected;
    }

    /**
     * Sets the value of the uiselected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiselected(String value) {
        this.uiselected = value;
    }

}
