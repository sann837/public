
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneCopayInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneCopayInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="CoPayEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoPayLevel" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CoPayStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneCopayInfo", propOrder = {
    "searchspec",
    "coPayEndDate",
    "coPayLevel",
    "coPayStartDate"
})
public class BeneCopayInfo {

    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "CoPayEndDate")
    protected String coPayEndDate;
    @XmlElement(name = "CoPayLevel")
    protected String coPayLevel;
    @XmlElement(name = "CoPayStartDate")
    protected String coPayStartDate;
    @XmlAttribute(name = "Operation")
    protected String operation;

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the coPayEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoPayEndDate() {
        return coPayEndDate;
    }

    /**
     * Sets the value of the coPayEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoPayEndDate(String value) {
        this.coPayEndDate = value;
    }

    /**
     * Gets the value of the coPayLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoPayLevel() {
        return coPayLevel;
    }

    /**
     * Sets the value of the coPayLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoPayLevel(String value) {
        this.coPayLevel = value;
    }

    /**
     * Gets the value of the coPayStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoPayStartDate() {
        return coPayStartDate;
    }

    /**
     * Sets the value of the coPayStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoPayStartDate(String value) {
        this.coPayStartDate = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

}
