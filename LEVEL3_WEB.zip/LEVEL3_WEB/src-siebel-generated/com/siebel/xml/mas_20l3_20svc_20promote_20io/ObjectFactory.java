
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l3_20svc_20promote_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL3MbdSvcIO_QNAME = new QName("http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO", "ListOfMasL3MbdSvcIO");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l3_20svc_20promote_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL3MbdSvcIO }
     * 
     */
    public ListOfMasL3MbdSvcIO createListOfMasL3MbdSvcIO() {
        return new ListOfMasL3MbdSvcIO();
    }

    /**
     * Create an instance of {@link BeneEligibilityHistory }
     * 
     */
    public BeneEligibilityHistory createBeneEligibilityHistory() {
        return new BeneEligibilityHistory();
    }

    /**
     * Create an instance of {@link MARxPremiumCoverage }
     * 
     */
    public MARxPremiumCoverage createMARxPremiumCoverage() {
        return new MARxPremiumCoverage();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryAddress }
     * 
     */
    public ListOfBeneficiaryAddress createListOfBeneficiaryAddress() {
        return new ListOfBeneficiaryAddress();
    }

    /**
     * Create an instance of {@link Beneficiary }
     * 
     */
    public Beneficiary createBeneficiary() {
        return new Beneficiary();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryPartDEntitlement }
     * 
     */
    public ListOfBeneficiaryPartDEntitlement createListOfBeneficiaryPartDEntitlement() {
        return new ListOfBeneficiaryPartDEntitlement();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryPartBEntitlement }
     * 
     */
    public ListOfBeneficiaryPartBEntitlement createListOfBeneficiaryPartBEntitlement() {
        return new ListOfBeneficiaryPartBEntitlement();
    }

    /**
     * Create an instance of {@link BeneCopayInfo }
     * 
     */
    public BeneCopayInfo createBeneCopayInfo() {
        return new BeneCopayInfo();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link ListOfMasL3MbdSvcIOTopElmt }
     * 
     */
    public ListOfMasL3MbdSvcIOTopElmt createListOfMasL3MbdSvcIOTopElmt() {
        return new ListOfMasL3MbdSvcIOTopElmt();
    }

    /**
     * Create an instance of {@link PartDEntitlement }
     * 
     */
    public PartDEntitlement createPartDEntitlement() {
        return new PartDEntitlement();
    }

    /**
     * Create an instance of {@link PartBEntitlement }
     * 
     */
    public PartBEntitlement createPartBEntitlement() {
        return new PartBEntitlement();
    }

    /**
     * Create an instance of {@link ListOfBeneEnrollmentHistory }
     * 
     */
    public ListOfBeneEnrollmentHistory createListOfBeneEnrollmentHistory() {
        return new ListOfBeneEnrollmentHistory();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryMARxCreditableCoverage }
     * 
     */
    public ListOfBeneficiaryMARxCreditableCoverage createListOfBeneficiaryMARxCreditableCoverage() {
        return new ListOfBeneficiaryMARxCreditableCoverage();
    }

    /**
     * Create an instance of {@link ListOfBeneSubsidiaryDeniedInfo }
     * 
     */
    public ListOfBeneSubsidiaryDeniedInfo createListOfBeneSubsidiaryDeniedInfo() {
        return new ListOfBeneSubsidiaryDeniedInfo();
    }

    /**
     * Create an instance of {@link ListOfBeneSubsidiaryInfo }
     * 
     */
    public ListOfBeneSubsidiaryInfo createListOfBeneSubsidiaryInfo() {
        return new ListOfBeneSubsidiaryInfo();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryPartAEntitlement }
     * 
     */
    public ListOfBeneficiaryPartAEntitlement createListOfBeneficiaryPartAEntitlement() {
        return new ListOfBeneficiaryPartAEntitlement();
    }

    /**
     * Create an instance of {@link ListOfBeneficiary }
     * 
     */
    public ListOfBeneficiary createListOfBeneficiary() {
        return new ListOfBeneficiary();
    }

    /**
     * Create an instance of {@link BeneSubsidiaryDeniedInfo }
     * 
     */
    public BeneSubsidiaryDeniedInfo createBeneSubsidiaryDeniedInfo() {
        return new BeneSubsidiaryDeniedInfo();
    }

    /**
     * Create an instance of {@link MARxCreditableCoverage }
     * 
     */
    public MARxCreditableCoverage createMARxCreditableCoverage() {
        return new MARxCreditableCoverage();
    }

    /**
     * Create an instance of {@link BeneSubsidiaryInfo }
     * 
     */
    public BeneSubsidiaryInfo createBeneSubsidiaryInfo() {
        return new BeneSubsidiaryInfo();
    }

    /**
     * Create an instance of {@link ListOfBeneficiaryMARxPremiumCoverage }
     * 
     */
    public ListOfBeneficiaryMARxPremiumCoverage createListOfBeneficiaryMARxPremiumCoverage() {
        return new ListOfBeneficiaryMARxPremiumCoverage();
    }

    /**
     * Create an instance of {@link BeneEnrollmentHistory }
     * 
     */
    public BeneEnrollmentHistory createBeneEnrollmentHistory() {
        return new BeneEnrollmentHistory();
    }

    /**
     * Create an instance of {@link ListOfBeneEligibilityHistory }
     * 
     */
    public ListOfBeneEligibilityHistory createListOfBeneEligibilityHistory() {
        return new ListOfBeneEligibilityHistory();
    }

    /**
     * Create an instance of {@link ListOfBeneCopayInfo }
     * 
     */
    public ListOfBeneCopayInfo createListOfBeneCopayInfo() {
        return new ListOfBeneCopayInfo();
    }

    /**
     * Create an instance of {@link PartAEntitlement }
     * 
     */
    public PartAEntitlement createPartAEntitlement() {
        return new PartAEntitlement();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL3MbdSvcIO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO", name = "ListOfMasL3MbdSvcIO")
    public JAXBElement<ListOfMasL3MbdSvcIO> createListOfMasL3MbdSvcIO(ListOfMasL3MbdSvcIO value) {
        return new JAXBElement<ListOfMasL3MbdSvcIO>(_ListOfMasL3MbdSvcIO_QNAME, ListOfMasL3MbdSvcIO.class, null, value);
    }

}
