
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneEnrollmentHistory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneEnrollmentHistory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="CoverageType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="DisenrollmentReasonCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PBPEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PBPStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDContractNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="PartDContractPayType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PartDPlanName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string100" minOccurs="0"/>
 *         &lt;element name="PlanId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="SegmentEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SegmentId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="SegmentStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Source" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiactive" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiselected" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneEnrollmentHistory", propOrder = {
    "id",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "coverageType",
    "disenrollmentReasonCode",
    "pbpEndDate",
    "pbpStartDate",
    "partDContractNumber",
    "partDContractPayType",
    "partDPlanName",
    "planId",
    "segmentEndDate",
    "segmentId",
    "segmentStartDate",
    "source"
})
public class BeneEnrollmentHistory {

    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "CoverageType")
    protected String coverageType;
    @XmlElement(name = "DisenrollmentReasonCode")
    protected String disenrollmentReasonCode;
    @XmlElement(name = "PBPEndDate")
    protected String pbpEndDate;
    @XmlElement(name = "PBPStartDate")
    protected String pbpStartDate;
    @XmlElement(name = "PartDContractNumber")
    protected String partDContractNumber;
    @XmlElement(name = "PartDContractPayType")
    protected String partDContractPayType;
    @XmlElement(name = "PartDPlanName")
    protected String partDPlanName;
    @XmlElement(name = "PlanId")
    protected String planId;
    @XmlElement(name = "SegmentEndDate")
    protected String segmentEndDate;
    @XmlElement(name = "SegmentId")
    protected String segmentId;
    @XmlElement(name = "SegmentStartDate")
    protected String segmentStartDate;
    @XmlElement(name = "Source")
    protected String source;
    @XmlAttribute(name = "Operation")
    protected String operation;
    @XmlAttribute(name = "Uiactive")
    protected String uiactive;
    @XmlAttribute(name = "Uiselected")
    protected String uiselected;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the coverageType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverageType() {
        return coverageType;
    }

    /**
     * Sets the value of the coverageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverageType(String value) {
        this.coverageType = value;
    }

    /**
     * Gets the value of the disenrollmentReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisenrollmentReasonCode() {
        return disenrollmentReasonCode;
    }

    /**
     * Sets the value of the disenrollmentReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisenrollmentReasonCode(String value) {
        this.disenrollmentReasonCode = value;
    }

    /**
     * Gets the value of the pbpEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPBPEndDate() {
        return pbpEndDate;
    }

    /**
     * Sets the value of the pbpEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPBPEndDate(String value) {
        this.pbpEndDate = value;
    }

    /**
     * Gets the value of the pbpStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPBPStartDate() {
        return pbpStartDate;
    }

    /**
     * Sets the value of the pbpStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPBPStartDate(String value) {
        this.pbpStartDate = value;
    }

    /**
     * Gets the value of the partDContractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDContractNumber() {
        return partDContractNumber;
    }

    /**
     * Sets the value of the partDContractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDContractNumber(String value) {
        this.partDContractNumber = value;
    }

    /**
     * Gets the value of the partDContractPayType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDContractPayType() {
        return partDContractPayType;
    }

    /**
     * Sets the value of the partDContractPayType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDContractPayType(String value) {
        this.partDContractPayType = value;
    }

    /**
     * Gets the value of the partDPlanName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDPlanName() {
        return partDPlanName;
    }

    /**
     * Sets the value of the partDPlanName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDPlanName(String value) {
        this.partDPlanName = value;
    }

    /**
     * Gets the value of the planId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanId() {
        return planId;
    }

    /**
     * Sets the value of the planId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanId(String value) {
        this.planId = value;
    }

    /**
     * Gets the value of the segmentEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegmentEndDate() {
        return segmentEndDate;
    }

    /**
     * Sets the value of the segmentEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegmentEndDate(String value) {
        this.segmentEndDate = value;
    }

    /**
     * Gets the value of the segmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegmentId() {
        return segmentId;
    }

    /**
     * Sets the value of the segmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegmentId(String value) {
        this.segmentId = value;
    }

    /**
     * Gets the value of the segmentStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSegmentStartDate() {
        return segmentStartDate;
    }

    /**
     * Sets the value of the segmentStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSegmentStartDate(String value) {
        this.segmentStartDate = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Gets the value of the uiactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiactive() {
        return uiactive;
    }

    /**
     * Sets the value of the uiactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiactive(String value) {
        this.uiactive = value;
    }

    /**
     * Gets the value of the uiselected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiselected() {
        return uiselected;
    }

    /**
     * Sets the value of the uiselected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiselected(String value) {
        this.uiselected = value;
    }

}
