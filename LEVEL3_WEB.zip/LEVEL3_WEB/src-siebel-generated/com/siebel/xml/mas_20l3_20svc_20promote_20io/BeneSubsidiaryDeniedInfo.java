
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneSubsidiaryDeniedInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneSubsidiaryDeniedInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Id" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="AuditSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeniedSubsidyStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyDenial1Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyDenial2Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyDenial3Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyDenial4Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartDSubsidyDenial5Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubsidyDisapprovalDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppealResolutionCodeDenied" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="ApplicationApprovalCodeDenied" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ChangeDeterminationCodeDenied" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string50" minOccurs="0"/>
 *         &lt;element name="PartDPremiumSubsidyPercentDenied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SSAApplicationDateDenied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StateCancellationCodeDenied" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="SubsidySourceDenied" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="UserModifiedDenied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiactive" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiselected" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneSubsidiaryDeniedInfo", propOrder = {
    "id",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "auditSequenceNumber",
    "deniedSubsidyStartDate",
    "partDSubsidyDenial1Flag",
    "partDSubsidyDenial2Flag",
    "partDSubsidyDenial3Flag",
    "partDSubsidyDenial4Flag",
    "partDSubsidyDenial5Flag",
    "subsidyDisapprovalDate",
    "appealResolutionCodeDenied",
    "applicationApprovalCodeDenied",
    "changeDeterminationCodeDenied",
    "partDPremiumSubsidyPercentDenied",
    "ssaApplicationDateDenied",
    "stateCancellationCodeDenied",
    "subsidySourceDenied",
    "userModifiedDenied"
})
public class BeneSubsidiaryDeniedInfo {

    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "AuditSequenceNumber")
    protected String auditSequenceNumber;
    @XmlElement(name = "DeniedSubsidyStartDate")
    protected String deniedSubsidyStartDate;
    @XmlElement(name = "PartDSubsidyDenial1Flag")
    protected String partDSubsidyDenial1Flag;
    @XmlElement(name = "PartDSubsidyDenial2Flag")
    protected String partDSubsidyDenial2Flag;
    @XmlElement(name = "PartDSubsidyDenial3Flag")
    protected String partDSubsidyDenial3Flag;
    @XmlElement(name = "PartDSubsidyDenial4Flag")
    protected String partDSubsidyDenial4Flag;
    @XmlElement(name = "PartDSubsidyDenial5Flag")
    protected String partDSubsidyDenial5Flag;
    @XmlElement(name = "SubsidyDisapprovalDate")
    protected String subsidyDisapprovalDate;
    @XmlElement(name = "AppealResolutionCodeDenied")
    protected String appealResolutionCodeDenied;
    @XmlElement(name = "ApplicationApprovalCodeDenied")
    protected String applicationApprovalCodeDenied;
    @XmlElement(name = "ChangeDeterminationCodeDenied")
    protected String changeDeterminationCodeDenied;
    @XmlElement(name = "PartDPremiumSubsidyPercentDenied")
    protected String partDPremiumSubsidyPercentDenied;
    @XmlElement(name = "SSAApplicationDateDenied")
    protected String ssaApplicationDateDenied;
    @XmlElement(name = "StateCancellationCodeDenied")
    protected String stateCancellationCodeDenied;
    @XmlElement(name = "SubsidySourceDenied")
    protected String subsidySourceDenied;
    @XmlElement(name = "UserModifiedDenied")
    protected String userModifiedDenied;
    @XmlAttribute(name = "Operation")
    protected String operation;
    @XmlAttribute(name = "Uiactive")
    protected String uiactive;
    @XmlAttribute(name = "Uiselected")
    protected String uiselected;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the auditSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuditSequenceNumber() {
        return auditSequenceNumber;
    }

    /**
     * Sets the value of the auditSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuditSequenceNumber(String value) {
        this.auditSequenceNumber = value;
    }

    /**
     * Gets the value of the deniedSubsidyStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeniedSubsidyStartDate() {
        return deniedSubsidyStartDate;
    }

    /**
     * Sets the value of the deniedSubsidyStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeniedSubsidyStartDate(String value) {
        this.deniedSubsidyStartDate = value;
    }

    /**
     * Gets the value of the partDSubsidyDenial1Flag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyDenial1Flag() {
        return partDSubsidyDenial1Flag;
    }

    /**
     * Sets the value of the partDSubsidyDenial1Flag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyDenial1Flag(String value) {
        this.partDSubsidyDenial1Flag = value;
    }

    /**
     * Gets the value of the partDSubsidyDenial2Flag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyDenial2Flag() {
        return partDSubsidyDenial2Flag;
    }

    /**
     * Sets the value of the partDSubsidyDenial2Flag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyDenial2Flag(String value) {
        this.partDSubsidyDenial2Flag = value;
    }

    /**
     * Gets the value of the partDSubsidyDenial3Flag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyDenial3Flag() {
        return partDSubsidyDenial3Flag;
    }

    /**
     * Sets the value of the partDSubsidyDenial3Flag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyDenial3Flag(String value) {
        this.partDSubsidyDenial3Flag = value;
    }

    /**
     * Gets the value of the partDSubsidyDenial4Flag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyDenial4Flag() {
        return partDSubsidyDenial4Flag;
    }

    /**
     * Sets the value of the partDSubsidyDenial4Flag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyDenial4Flag(String value) {
        this.partDSubsidyDenial4Flag = value;
    }

    /**
     * Gets the value of the partDSubsidyDenial5Flag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDSubsidyDenial5Flag() {
        return partDSubsidyDenial5Flag;
    }

    /**
     * Sets the value of the partDSubsidyDenial5Flag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDSubsidyDenial5Flag(String value) {
        this.partDSubsidyDenial5Flag = value;
    }

    /**
     * Gets the value of the subsidyDisapprovalDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidyDisapprovalDate() {
        return subsidyDisapprovalDate;
    }

    /**
     * Sets the value of the subsidyDisapprovalDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidyDisapprovalDate(String value) {
        this.subsidyDisapprovalDate = value;
    }

    /**
     * Gets the value of the appealResolutionCodeDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealResolutionCodeDenied() {
        return appealResolutionCodeDenied;
    }

    /**
     * Sets the value of the appealResolutionCodeDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealResolutionCodeDenied(String value) {
        this.appealResolutionCodeDenied = value;
    }

    /**
     * Gets the value of the applicationApprovalCodeDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationApprovalCodeDenied() {
        return applicationApprovalCodeDenied;
    }

    /**
     * Sets the value of the applicationApprovalCodeDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationApprovalCodeDenied(String value) {
        this.applicationApprovalCodeDenied = value;
    }

    /**
     * Gets the value of the changeDeterminationCodeDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeDeterminationCodeDenied() {
        return changeDeterminationCodeDenied;
    }

    /**
     * Sets the value of the changeDeterminationCodeDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeDeterminationCodeDenied(String value) {
        this.changeDeterminationCodeDenied = value;
    }

    /**
     * Gets the value of the partDPremiumSubsidyPercentDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDPremiumSubsidyPercentDenied() {
        return partDPremiumSubsidyPercentDenied;
    }

    /**
     * Sets the value of the partDPremiumSubsidyPercentDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDPremiumSubsidyPercentDenied(String value) {
        this.partDPremiumSubsidyPercentDenied = value;
    }

    /**
     * Gets the value of the ssaApplicationDateDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSSAApplicationDateDenied() {
        return ssaApplicationDateDenied;
    }

    /**
     * Sets the value of the ssaApplicationDateDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSSAApplicationDateDenied(String value) {
        this.ssaApplicationDateDenied = value;
    }

    /**
     * Gets the value of the stateCancellationCodeDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateCancellationCodeDenied() {
        return stateCancellationCodeDenied;
    }

    /**
     * Sets the value of the stateCancellationCodeDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateCancellationCodeDenied(String value) {
        this.stateCancellationCodeDenied = value;
    }

    /**
     * Gets the value of the subsidySourceDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidySourceDenied() {
        return subsidySourceDenied;
    }

    /**
     * Sets the value of the subsidySourceDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidySourceDenied(String value) {
        this.subsidySourceDenied = value;
    }

    /**
     * Gets the value of the userModifiedDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserModifiedDenied() {
        return userModifiedDenied;
    }

    /**
     * Sets the value of the userModifiedDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserModifiedDenied(String value) {
        this.userModifiedDenied = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Gets the value of the uiactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiactive() {
        return uiactive;
    }

    /**
     * Sets the value of the uiactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiactive(String value) {
        this.uiactive = value;
    }

    /**
     * Gets the value of the uiselected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiselected() {
        return uiselected;
    }

    /**
     * Sets the value of the uiselected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiselected(String value) {
        this.uiselected = value;
    }

}
