
package com.siebel.xml.mas_20l3_20svc_20promote_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MARxPremiumCoverage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MARxPremiumCoverage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string250" minOccurs="0"/>
 *         &lt;element name="ContractNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Promote%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PartDLatePenaltyAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlanNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PremiumEffectiveStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserModified" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SequenceNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UncoveredMonths" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PremiumEffectiveEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MARxPremiumCoverage", propOrder = {
    "searchspec",
    "contractNum",
    "partDLatePenaltyAmount",
    "planNum",
    "premiumEffectiveStartDate",
    "userModified",
    "sequenceNum",
    "uncoveredMonths",
    "premiumEffectiveEndDate"
})
public class MARxPremiumCoverage {

    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "ContractNum")
    protected String contractNum;
    @XmlElement(name = "PartDLatePenaltyAmount")
    protected String partDLatePenaltyAmount;
    @XmlElement(name = "PlanNum")
    protected String planNum;
    @XmlElement(name = "PremiumEffectiveStartDate")
    protected String premiumEffectiveStartDate;
    @XmlElement(name = "UserModified")
    protected String userModified;
    @XmlElement(name = "SequenceNum")
    protected String sequenceNum;
    @XmlElement(name = "UncoveredMonths")
    protected String uncoveredMonths;
    @XmlElement(name = "PremiumEffectiveEndDate")
    protected String premiumEffectiveEndDate;
    @XmlAttribute(name = "Operation")
    protected String operation;

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the contractNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNum() {
        return contractNum;
    }

    /**
     * Sets the value of the contractNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNum(String value) {
        this.contractNum = value;
    }

    /**
     * Gets the value of the partDLatePenaltyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartDLatePenaltyAmount() {
        return partDLatePenaltyAmount;
    }

    /**
     * Sets the value of the partDLatePenaltyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartDLatePenaltyAmount(String value) {
        this.partDLatePenaltyAmount = value;
    }

    /**
     * Gets the value of the planNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanNum() {
        return planNum;
    }

    /**
     * Sets the value of the planNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanNum(String value) {
        this.planNum = value;
    }

    /**
     * Gets the value of the premiumEffectiveStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumEffectiveStartDate() {
        return premiumEffectiveStartDate;
    }

    /**
     * Sets the value of the premiumEffectiveStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumEffectiveStartDate(String value) {
        this.premiumEffectiveStartDate = value;
    }

    /**
     * Gets the value of the userModified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserModified() {
        return userModified;
    }

    /**
     * Sets the value of the userModified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserModified(String value) {
        this.userModified = value;
    }

    /**
     * Gets the value of the sequenceNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequenceNum() {
        return sequenceNum;
    }

    /**
     * Sets the value of the sequenceNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequenceNum(String value) {
        this.sequenceNum = value;
    }

    /**
     * Gets the value of the uncoveredMonths property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUncoveredMonths() {
        return uncoveredMonths;
    }

    /**
     * Sets the value of the uncoveredMonths property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUncoveredMonths(String value) {
        this.uncoveredMonths = value;
    }

    /**
     * Gets the value of the premiumEffectiveEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumEffectiveEndDate() {
        return premiumEffectiveEndDate;
    }

    /**
     * Sets the value of the premiumEffectiveEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumEffectiveEndDate(String value) {
        this.premiumEffectiveEndDate = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

}
