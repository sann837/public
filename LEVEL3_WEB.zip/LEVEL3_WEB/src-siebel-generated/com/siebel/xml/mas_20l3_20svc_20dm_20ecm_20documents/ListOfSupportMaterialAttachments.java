
package com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfSupportMaterialAttachments complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfSupportMaterialAttachments">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SupportMaterialAttachment" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}SupportMaterialAttachment" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfSupportMaterialAttachments", propOrder = {
    "supportMaterialAttachment"
})
public class ListOfSupportMaterialAttachments {

    @XmlElement(name = "SupportMaterialAttachment")
    protected List<SupportMaterialAttachment> supportMaterialAttachment;

    /**
     * Gets the value of the supportMaterialAttachment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the supportMaterialAttachment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSupportMaterialAttachment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SupportMaterialAttachment }
     * 
     * 
     */
    public List<SupportMaterialAttachment> getSupportMaterialAttachment() {
        if (supportMaterialAttachment == null) {
            supportMaterialAttachment = new ArrayList<SupportMaterialAttachment>();
        }
        return this.supportMaterialAttachment;
    }

}
