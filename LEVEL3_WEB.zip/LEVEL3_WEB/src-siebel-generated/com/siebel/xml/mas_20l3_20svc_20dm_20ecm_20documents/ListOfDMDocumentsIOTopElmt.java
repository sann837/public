
package com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfDMDocumentsIOTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfDMDocumentsIOTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfDMDocumentsIO" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}ListOfDMDocumentsIO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfDMDocumentsIOTopElmt", propOrder = {
    "listOfDMDocumentsIO"
})
public class ListOfDMDocumentsIOTopElmt {

    @XmlElement(name = "ListOfDMDocumentsIO", required = true)
    protected ListOfDMDocumentsIO listOfDMDocumentsIO;

    /**
     * Gets the value of the listOfDMDocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDMDocumentsIO }
     *     
     */
    public ListOfDMDocumentsIO getListOfDMDocumentsIO() {
        return listOfDMDocumentsIO;
    }

    /**
     * Sets the value of the listOfDMDocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDMDocumentsIO }
     *     
     */
    public void setListOfDMDocumentsIO(ListOfDMDocumentsIO value) {
        this.listOfDMDocumentsIO = value;
    }

}
