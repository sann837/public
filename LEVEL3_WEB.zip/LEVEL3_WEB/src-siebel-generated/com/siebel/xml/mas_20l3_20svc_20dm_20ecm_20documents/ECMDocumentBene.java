
package com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ECMDocument_Bene complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ECMDocument_Bene">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}string250" minOccurs="0"/>
 *         &lt;element name="BeneHIC" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}string11"/>
 *         &lt;element name="BeneLastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}string50"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ECMDocument_Bene", propOrder = {
    "searchspec",
    "beneHIC",
    "beneLastName"
})
public class ECMDocumentBene {

    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "BeneHIC", required = true)
    protected String beneHIC;
    @XmlElement(name = "BeneLastName", required = true)
    protected String beneLastName;
    @XmlAttribute(name = "Operation")
    protected String operation;

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the beneHIC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneHIC() {
        return beneHIC;
    }

    /**
     * Sets the value of the beneHIC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneHIC(String value) {
        this.beneHIC = value;
    }

    /**
     * Gets the value of the beneLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneLastName() {
        return beneLastName;
    }

    /**
     * Sets the value of the beneLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneLastName(String value) {
        this.beneLastName = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

}
