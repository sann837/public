@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Smoke%20Test%20ECM%20Documents%20IO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20l3_20svc_20smoke_20test_20ecm_20documents_20io;
