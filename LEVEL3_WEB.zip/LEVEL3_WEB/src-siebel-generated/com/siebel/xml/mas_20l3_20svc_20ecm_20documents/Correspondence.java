
package com.siebel.xml.mas_20l3_20svc_20ecm_20documents;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Correspondence complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Correspondence">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AttachmentId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="CreatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="Updated" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="UpdatedBy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="ConflictId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="ModId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string30" minOccurs="0"/>
 *         &lt;element name="Searchspec" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string250" minOccurs="0"/>
 *         &lt;element name="FileExt" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string10" minOccurs="0"/>
 *         &lt;element name="FileName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}string200"/>
 *         &lt;element name="FileSize" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiactive" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Uiselected" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Correspondence", propOrder = {
    "attachmentId",
    "created",
    "createdBy",
    "updated",
    "updatedBy",
    "conflictId",
    "modId",
    "searchspec",
    "fileExt",
    "fileName",
    "fileSize"
})
public class Correspondence {

    @XmlElement(name = "AttachmentId")
    protected String attachmentId;
    @XmlElement(name = "Created")
    protected String created;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "Updated")
    protected String updated;
    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "ConflictId")
    protected String conflictId;
    @XmlElement(name = "ModId")
    protected String modId;
    @XmlElement(name = "Searchspec")
    protected String searchspec;
    @XmlElement(name = "FileExt")
    protected String fileExt;
    @XmlElement(name = "FileName", required = true)
    protected String fileName;
    @XmlElement(name = "FileSize")
    protected String fileSize;
    @XmlAttribute(name = "Operation")
    protected String operation;
    @XmlAttribute(name = "Uiactive")
    protected String uiactive;
    @XmlAttribute(name = "Uiselected")
    protected String uiselected;

    /**
     * Gets the value of the attachmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentId() {
        return attachmentId;
    }

    /**
     * Sets the value of the attachmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentId(String value) {
        this.attachmentId = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreated(String value) {
        this.created = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdated(String value) {
        this.updated = value;
    }

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the conflictId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConflictId() {
        return conflictId;
    }

    /**
     * Sets the value of the conflictId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConflictId(String value) {
        this.conflictId = value;
    }

    /**
     * Gets the value of the modId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModId() {
        return modId;
    }

    /**
     * Sets the value of the modId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModId(String value) {
        this.modId = value;
    }

    /**
     * Gets the value of the searchspec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchspec() {
        return searchspec;
    }

    /**
     * Sets the value of the searchspec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchspec(String value) {
        this.searchspec = value;
    }

    /**
     * Gets the value of the fileExt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileExt() {
        return fileExt;
    }

    /**
     * Sets the value of the fileExt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileExt(String value) {
        this.fileExt = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the fileSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileSize() {
        return fileSize;
    }

    /**
     * Sets the value of the fileSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileSize(String value) {
        this.fileSize = value;
    }

    /**
     * Gets the value of the operation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Sets the value of the operation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperation(String value) {
        this.operation = value;
    }

    /**
     * Gets the value of the uiactive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiactive() {
        return uiactive;
    }

    /**
     * Sets the value of the uiactive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiactive(String value) {
        this.uiactive = value;
    }

    /**
     * Gets the value of the uiselected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUiselected() {
        return uiselected;
    }

    /**
     * Sets the value of the uiselected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUiselected(String value) {
        this.uiselected = value;
    }

}
