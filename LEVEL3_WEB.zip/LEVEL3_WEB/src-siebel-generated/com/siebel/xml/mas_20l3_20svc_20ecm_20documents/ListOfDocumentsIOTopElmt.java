
package com.siebel.xml.mas_20l3_20svc_20ecm_20documents;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfDocumentsIOTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfDocumentsIOTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfDocumentsIO" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20ECM%20Documents}ListOfDocumentsIO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfDocumentsIOTopElmt", propOrder = {
    "listOfDocumentsIO"
})
public class ListOfDocumentsIOTopElmt {

    @XmlElement(name = "ListOfDocumentsIO", required = true)
    protected ListOfDocumentsIO listOfDocumentsIO;

    /**
     * Gets the value of the listOfDocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDocumentsIO }
     *     
     */
    public ListOfDocumentsIO getListOfDocumentsIO() {
        return listOfDocumentsIO;
    }

    /**
     * Sets the value of the listOfDocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDocumentsIO }
     *     
     */
    public void setListOfDocumentsIO(ListOfDocumentsIO value) {
        this.listOfDocumentsIO = value;
    }

}
