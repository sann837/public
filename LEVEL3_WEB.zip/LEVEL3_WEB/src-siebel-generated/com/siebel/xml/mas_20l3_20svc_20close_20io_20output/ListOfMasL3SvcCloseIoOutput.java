
package com.siebel.xml.mas_20l3_20svc_20close_20io_20output;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfMasL3SvcCloseIoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfMasL3SvcCloseIoOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Appeal" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output}Appeal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfMasL3SvcCloseIoOutput", propOrder = {
    "appeal"
})
public class ListOfMasL3SvcCloseIoOutput {

    @XmlElement(name = "Appeal", required = true)
    protected Appeal appeal;

    /**
     * Gets the value of the appeal property.
     * 
     * @return
     *     possible object is
     *     {@link Appeal }
     *     
     */
    public Appeal getAppeal() {
        return appeal;
    }

    /**
     * Sets the value of the appeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link Appeal }
     *     
     */
    public void setAppeal(Appeal value) {
        this.appeal = value;
    }

}
