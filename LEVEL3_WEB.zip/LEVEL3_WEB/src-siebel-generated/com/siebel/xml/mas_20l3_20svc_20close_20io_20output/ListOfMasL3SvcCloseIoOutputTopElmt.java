
package com.siebel.xml.mas_20l3_20svc_20close_20io_20output;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfMasL3SvcCloseIoOutputTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfMasL3SvcCloseIoOutputTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfMasL3SvcCloseIoOutput" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output}ListOfMasL3SvcCloseIoOutput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfMasL3SvcCloseIoOutputTopElmt", propOrder = {
    "listOfMasL3SvcCloseIoOutput"
})
public class ListOfMasL3SvcCloseIoOutputTopElmt {

    @XmlElement(name = "ListOfMasL3SvcCloseIoOutput", required = true)
    protected ListOfMasL3SvcCloseIoOutput listOfMasL3SvcCloseIoOutput;

    /**
     * Gets the value of the listOfMasL3SvcCloseIoOutput property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL3SvcCloseIoOutput }
     *     
     */
    public ListOfMasL3SvcCloseIoOutput getListOfMasL3SvcCloseIoOutput() {
        return listOfMasL3SvcCloseIoOutput;
    }

    /**
     * Sets the value of the listOfMasL3SvcCloseIoOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL3SvcCloseIoOutput }
     *     
     */
    public void setListOfMasL3SvcCloseIoOutput(ListOfMasL3SvcCloseIoOutput value) {
        this.listOfMasL3SvcCloseIoOutput = value;
    }

}
