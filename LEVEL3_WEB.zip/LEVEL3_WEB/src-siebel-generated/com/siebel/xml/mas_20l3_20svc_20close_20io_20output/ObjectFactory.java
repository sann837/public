
package com.siebel.xml.mas_20l3_20svc_20close_20io_20output;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l3_20svc_20close_20io_20output package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL3SvcCloseIoOutput_QNAME = new QName("http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output", "ListOfMasL3SvcCloseIoOutput");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l3_20svc_20close_20io_20output
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseIoOutput }
     * 
     */
    public ListOfMasL3SvcCloseIoOutput createListOfMasL3SvcCloseIoOutput() {
        return new ListOfMasL3SvcCloseIoOutput();
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseIoOutputTopElmt }
     * 
     */
    public ListOfMasL3SvcCloseIoOutputTopElmt createListOfMasL3SvcCloseIoOutputTopElmt() {
        return new ListOfMasL3SvcCloseIoOutputTopElmt();
    }

    /**
     * Create an instance of {@link EcmDocuments }
     * 
     */
    public EcmDocuments createEcmDocuments() {
        return new EcmDocuments();
    }

    /**
     * Create an instance of {@link EcmDocument }
     * 
     */
    public EcmDocument createEcmDocument() {
        return new EcmDocument();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL3SvcCloseIoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output", name = "ListOfMasL3SvcCloseIoOutput")
    public JAXBElement<ListOfMasL3SvcCloseIoOutput> createListOfMasL3SvcCloseIoOutput(ListOfMasL3SvcCloseIoOutput value) {
        return new JAXBElement<ListOfMasL3SvcCloseIoOutput>(_ListOfMasL3SvcCloseIoOutput_QNAME, ListOfMasL3SvcCloseIoOutput.class, null, value);
    }

}
