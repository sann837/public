
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l3_20svc_20close_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL3SvcCloseIo_QNAME = new QName("http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO", "ListOfMasL3SvcCloseIo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l3_20svc_20close_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseIo }
     * 
     */
    public ListOfMasL3SvcCloseIo createListOfMasL3SvcCloseIo() {
        return new ListOfMasL3SvcCloseIo();
    }

    /**
     * Create an instance of {@link Providers }
     * 
     */
    public Providers createProviders() {
        return new Providers();
    }

    /**
     * Create an instance of {@link ClaimLineItemDiagnosisCode }
     * 
     */
    public ClaimLineItemDiagnosisCode createClaimLineItemDiagnosisCode() {
        return new ClaimLineItemDiagnosisCode();
    }

    /**
     * Create an instance of {@link ClaimLineItemBillingModifierCode }
     * 
     */
    public ClaimLineItemBillingModifierCode createClaimLineItemBillingModifierCode() {
        return new ClaimLineItemBillingModifierCode();
    }

    /**
     * Create an instance of {@link PartyOrgAddresses }
     * 
     */
    public PartyOrgAddresses createPartyOrgAddresses() {
        return new PartyOrgAddresses();
    }

    /**
     * Create an instance of {@link EcmDocuments }
     * 
     */
    public EcmDocuments createEcmDocuments() {
        return new EcmDocuments();
    }

    /**
     * Create an instance of {@link ListOfDispositionLineItems }
     * 
     */
    public ListOfDispositionLineItems createListOfDispositionLineItems() {
        return new ListOfDispositionLineItems();
    }

    /**
     * Create an instance of {@link ProviderAddresses }
     * 
     */
    public ProviderAddresses createProviderAddresses() {
        return new ProviderAddresses();
    }

    /**
     * Create an instance of {@link Provider }
     * 
     */
    public Provider createProvider() {
        return new Provider();
    }

    /**
     * Create an instance of {@link PartiesOrgs }
     * 
     */
    public PartiesOrgs createPartiesOrgs() {
        return new PartiesOrgs();
    }

    /**
     * Create an instance of {@link Hearing }
     * 
     */
    public Hearing createHearing() {
        return new Hearing();
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcCloseIoTopElmt }
     * 
     */
    public ListOfMasL3SvcCloseIoTopElmt createListOfMasL3SvcCloseIoTopElmt() {
        return new ListOfMasL3SvcCloseIoTopElmt();
    }

    /**
     * Create an instance of {@link ClaimsProviders }
     * 
     */
    public ClaimsProviders createClaimsProviders() {
        return new ClaimsProviders();
    }

    /**
     * Create an instance of {@link Claim }
     * 
     */
    public Claim createClaim() {
        return new Claim();
    }

    /**
     * Create an instance of {@link ClaimBeneficiary }
     * 
     */
    public ClaimBeneficiary createClaimBeneficiary() {
        return new ClaimBeneficiary();
    }

    /**
     * Create an instance of {@link ProviderAddress }
     * 
     */
    public ProviderAddress createProviderAddress() {
        return new ProviderAddress();
    }

    /**
     * Create an instance of {@link Beneficiaries }
     * 
     */
    public Beneficiaries createBeneficiaries() {
        return new Beneficiaries();
    }

    /**
     * Create an instance of {@link PartyPersonAddresses }
     * 
     */
    public PartyPersonAddresses createPartyPersonAddresses() {
        return new PartyPersonAddresses();
    }

    /**
     * Create an instance of {@link EcmDocument }
     * 
     */
    public EcmDocument createEcmDocument() {
        return new EcmDocument();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link ClaimLineItemDiagnosisCodes }
     * 
     */
    public ClaimLineItemDiagnosisCodes createClaimLineItemDiagnosisCodes() {
        return new ClaimLineItemDiagnosisCodes();
    }

    /**
     * Create an instance of {@link CloseAppealCombine }
     * 
     */
    public CloseAppealCombine createCloseAppealCombine() {
        return new CloseAppealCombine();
    }

    /**
     * Create an instance of {@link PartyPersonAddress }
     * 
     */
    public PartyPersonAddress createPartyPersonAddress() {
        return new PartyPersonAddress();
    }

    /**
     * Create an instance of {@link PartiesPersons }
     * 
     */
    public PartiesPersons createPartiesPersons() {
        return new PartiesPersons();
    }

    /**
     * Create an instance of {@link CloseAppealCombines }
     * 
     */
    public CloseAppealCombines createCloseAppealCombines() {
        return new CloseAppealCombines();
    }

    /**
     * Create an instance of {@link ClaimsBeneficiaries }
     * 
     */
    public ClaimsBeneficiaries createClaimsBeneficiaries() {
        return new ClaimsBeneficiaries();
    }

    /**
     * Create an instance of {@link Dispositions }
     * 
     */
    public Dispositions createDispositions() {
        return new Dispositions();
    }

    /**
     * Create an instance of {@link FoiaPaCis }
     * 
     */
    public FoiaPaCis createFoiaPaCis() {
        return new FoiaPaCis();
    }

    /**
     * Create an instance of {@link Beneficiary }
     * 
     */
    public Beneficiary createBeneficiary() {
        return new Beneficiary();
    }

    /**
     * Create an instance of {@link ClaimLineItemBillingModifierCodes }
     * 
     */
    public ClaimLineItemBillingModifierCodes createClaimLineItemBillingModifierCodes() {
        return new ClaimLineItemBillingModifierCodes();
    }

    /**
     * Create an instance of {@link HearingDates }
     * 
     */
    public HearingDates createHearingDates() {
        return new HearingDates();
    }

    /**
     * Create an instance of {@link ClaimProvider }
     * 
     */
    public ClaimProvider createClaimProvider() {
        return new ClaimProvider();
    }

    /**
     * Create an instance of {@link HearingParticipants }
     * 
     */
    public HearingParticipants createHearingParticipants() {
        return new HearingParticipants();
    }

    /**
     * Create an instance of {@link DispositionLineItems }
     * 
     */
    public DispositionLineItems createDispositionLineItems() {
        return new DispositionLineItems();
    }

    /**
     * Create an instance of {@link PartyOrgAddress }
     * 
     */
    public PartyOrgAddress createPartyOrgAddress() {
        return new PartyOrgAddress();
    }

    /**
     * Create an instance of {@link Claims }
     * 
     */
    public Claims createClaims() {
        return new Claims();
    }

    /**
     * Create an instance of {@link PartiesPerson }
     * 
     */
    public PartiesPerson createPartiesPerson() {
        return new PartiesPerson();
    }

    /**
     * Create an instance of {@link BeneficiaryAddresses }
     * 
     */
    public BeneficiaryAddresses createBeneficiaryAddresses() {
        return new BeneficiaryAddresses();
    }

    /**
     * Create an instance of {@link Hearings }
     * 
     */
    public Hearings createHearings() {
        return new Hearings();
    }

    /**
     * Create an instance of {@link PartiesOrg }
     * 
     */
    public PartiesOrg createPartiesOrg() {
        return new PartiesOrg();
    }

    /**
     * Create an instance of {@link HearingDate }
     * 
     */
    public HearingDate createHearingDate() {
        return new HearingDate();
    }

    /**
     * Create an instance of {@link ClaimLineItem }
     * 
     */
    public ClaimLineItem createClaimLineItem() {
        return new ClaimLineItem();
    }

    /**
     * Create an instance of {@link HearingOrgParticipant }
     * 
     */
    public HearingOrgParticipant createHearingOrgParticipant() {
        return new HearingOrgParticipant();
    }

    /**
     * Create an instance of {@link BeneficiaryAddress }
     * 
     */
    public BeneficiaryAddress createBeneficiaryAddress() {
        return new BeneficiaryAddress();
    }

    /**
     * Create an instance of {@link ClaimLineItems }
     * 
     */
    public ClaimLineItems createClaimLineItems() {
        return new ClaimLineItems();
    }

    /**
     * Create an instance of {@link HearingOrgParticipants }
     * 
     */
    public HearingOrgParticipants createHearingOrgParticipants() {
        return new HearingOrgParticipants();
    }

    /**
     * Create an instance of {@link ListOfDispositions }
     * 
     */
    public ListOfDispositions createListOfDispositions() {
        return new ListOfDispositions();
    }

    /**
     * Create an instance of {@link FoiaPaCi }
     * 
     */
    public FoiaPaCi createFoiaPaCi() {
        return new FoiaPaCi();
    }

    /**
     * Create an instance of {@link HearingParticipant }
     * 
     */
    public HearingParticipant createHearingParticipant() {
        return new HearingParticipant();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL3SvcCloseIo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO", name = "ListOfMasL3SvcCloseIo")
    public JAXBElement<ListOfMasL3SvcCloseIo> createListOfMasL3SvcCloseIo(ListOfMasL3SvcCloseIo value) {
        return new JAXBElement<ListOfMasL3SvcCloseIo>(_ListOfMasL3SvcCloseIo_QNAME, ListOfMasL3SvcCloseIo.class, null, value);
    }

}
