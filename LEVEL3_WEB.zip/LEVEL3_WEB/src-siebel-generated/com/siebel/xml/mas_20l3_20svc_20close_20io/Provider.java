
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Provider complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Provider">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NPI" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *         &lt;element name="ProviderAddresses" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ProviderAddresses" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Provider", propOrder = {
    "npi",
    "providerAddresses"
})
public class Provider {

    @XmlElement(name = "NPI", required = true)
    protected String npi;
    @XmlElement(name = "ProviderAddresses")
    protected ProviderAddresses providerAddresses;

    /**
     * Gets the value of the npi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNPI() {
        return npi;
    }

    /**
     * Sets the value of the npi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNPI(String value) {
        this.npi = value;
    }

    /**
     * Gets the value of the providerAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link ProviderAddresses }
     *     
     */
    public ProviderAddresses getProviderAddresses() {
        return providerAddresses;
    }

    /**
     * Sets the value of the providerAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProviderAddresses }
     *     
     */
    public void setProviderAddresses(ProviderAddresses value) {
        this.providerAddresses = value;
    }

}
