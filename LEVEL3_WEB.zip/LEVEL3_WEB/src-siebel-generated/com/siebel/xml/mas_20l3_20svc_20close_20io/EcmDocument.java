
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EcmDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EcmDocument">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Category" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *         &lt;element name="FileName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="FileSize" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Type" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="CheckSum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="DateImported" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DocDescription" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string250" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EcmDocument", propOrder = {
    "category",
    "fileName",
    "fileSize",
    "type",
    "checkSum",
    "dateImported",
    "docDescription"
})
public class EcmDocument {

    @XmlElement(name = "Category", required = true)
    protected String category;
    @XmlElement(name = "FileName")
    protected String fileName;
    @XmlElement(name = "FileSize")
    protected String fileSize;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "CheckSum")
    protected String checkSum;
    @XmlElement(name = "DateImported")
    protected String dateImported;
    @XmlElement(name = "DocDescription")
    protected String docDescription;

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the fileSize property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileSize() {
        return fileSize;
    }

    /**
     * Sets the value of the fileSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileSize(String value) {
        this.fileSize = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the checkSum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckSum() {
        return checkSum;
    }

    /**
     * Sets the value of the checkSum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckSum(String value) {
        this.checkSum = value;
    }

    /**
     * Gets the value of the dateImported property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateImported() {
        return dateImported;
    }

    /**
     * Sets the value of the dateImported property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateImported(String value) {
        this.dateImported = value;
    }

    /**
     * Gets the value of the docDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocDescription() {
        return docDescription;
    }

    /**
     * Sets the value of the docDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocDescription(String value) {
        this.docDescription = value;
    }

}
