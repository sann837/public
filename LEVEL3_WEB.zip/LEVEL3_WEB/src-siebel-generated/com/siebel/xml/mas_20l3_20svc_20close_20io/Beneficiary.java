
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Beneficiary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Beneficiary">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HICN" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string15"/>
 *         &lt;element name="BeneficiaryAddresses" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}BeneficiaryAddresses" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Beneficiary", propOrder = {
    "hicn",
    "beneficiaryAddresses"
})
public class Beneficiary {

    @XmlElement(name = "HICN", required = true)
    protected String hicn;
    @XmlElement(name = "BeneficiaryAddresses")
    protected BeneficiaryAddresses beneficiaryAddresses;

    /**
     * Gets the value of the hicn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHICN() {
        return hicn;
    }

    /**
     * Sets the value of the hicn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHICN(String value) {
        this.hicn = value;
    }

    /**
     * Gets the value of the beneficiaryAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link BeneficiaryAddresses }
     *     
     */
    public BeneficiaryAddresses getBeneficiaryAddresses() {
        return beneficiaryAddresses;
    }

    /**
     * Sets the value of the beneficiaryAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeneficiaryAddresses }
     *     
     */
    public void setBeneficiaryAddresses(BeneficiaryAddresses value) {
        this.beneficiaryAddresses = value;
    }

}
