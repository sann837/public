
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HearingOrgParticipant complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HearingOrgParticipant">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OrganizationParticipantName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="OrgUId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="ParticipantNotified" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string1" minOccurs="0"/>
 *         &lt;element name="ParticipationFormat" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HearingOrgParticipant", propOrder = {
    "organizationParticipantName",
    "orgUId",
    "participantNotified",
    "participationFormat"
})
public class HearingOrgParticipant {

    @XmlElement(name = "OrganizationParticipantName")
    protected String organizationParticipantName;
    @XmlElement(name = "OrgUId")
    protected String orgUId;
    @XmlElement(name = "ParticipantNotified")
    protected String participantNotified;
    @XmlElement(name = "ParticipationFormat")
    protected String participationFormat;

    /**
     * Gets the value of the organizationParticipantName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganizationParticipantName() {
        return organizationParticipantName;
    }

    /**
     * Sets the value of the organizationParticipantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganizationParticipantName(String value) {
        this.organizationParticipantName = value;
    }

    /**
     * Gets the value of the orgUId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUId() {
        return orgUId;
    }

    /**
     * Sets the value of the orgUId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUId(String value) {
        this.orgUId = value;
    }

    /**
     * Gets the value of the participantNotified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticipantNotified() {
        return participantNotified;
    }

    /**
     * Sets the value of the participantNotified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticipantNotified(String value) {
        this.participantNotified = value;
    }

    /**
     * Gets the value of the participationFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticipationFormat() {
        return participationFormat;
    }

    /**
     * Sets the value of the participationFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticipationFormat(String value) {
        this.participationFormat = value;
    }

}
