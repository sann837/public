
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="Deadline" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DtInitialRequestRecd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="AppealDisposition" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="AppealCategory" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="BigBoxAppeal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateCompleteRequestReceived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeadlineWaived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DtReopenRqstDenied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExcludedProvider" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ExternalAppealNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="FiledTimely" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string5" minOccurs="0"/>
 *         &lt;element name="MSP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="MeetsMinimumDollarAmount" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string5" minOccurs="0"/>
 *         &lt;element name="NonBIPA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OTRDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OTRRequested" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string5" minOccurs="0"/>
 *         &lt;element name="PSCZPIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PotentialOTRReview" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string10" minOccurs="0"/>
 *         &lt;element name="PrimaryAdjudicatingEntity" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="AppealPriority" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="RAC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="RequestorType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="E-CaseFile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ALJName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DecLtrMailed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EcmDocuments" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}EcmDocuments" minOccurs="0"/>
 *         &lt;element name="Providers" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Providers" minOccurs="0"/>
 *         &lt;element name="Beneficiaries" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Beneficiaries" minOccurs="0"/>
 *         &lt;element name="PartiesPersons" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}PartiesPersons" minOccurs="0"/>
 *         &lt;element name="PartiesOrgs" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}PartiesOrgs" minOccurs="0"/>
 *         &lt;element name="Claims" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Claims" minOccurs="0"/>
 *         &lt;element name="ListOfDispositions" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ListOfDispositions" minOccurs="0"/>
 *         &lt;element name="CloseAppealCombines" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}CloseAppealCombines" minOccurs="0"/>
 *         &lt;element name="Foia_Pa_Cis" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Foia_Pa_Cis" minOccurs="0"/>
 *         &lt;element name="Hearings" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Hearings" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "appealNum",
    "deadline",
    "dtInitialRequestRecd",
    "transactionId",
    "appealDisposition",
    "appealCategory",
    "bigBoxAppeal",
    "dateCompleteRequestReceived",
    "deadlineWaived",
    "dtReopenRqstDenied",
    "excludedProvider",
    "externalAppealNum",
    "filedTimely",
    "msp",
    "medicareType",
    "meetsMinimumDollarAmount",
    "nonBIPA",
    "otrDecision",
    "otrRequested",
    "psczpic",
    "potentialOTRReview",
    "primaryAdjudicatingEntity",
    "appealPriority",
    "rac",
    "requestType",
    "requestorType",
    "eCaseFile",
    "aljName",
    "decLtrMailed",
    "ecmDocuments",
    "providers",
    "beneficiaries",
    "partiesPersons",
    "partiesOrgs",
    "claims",
    "listOfDispositions",
    "closeAppealCombines",
    "foiaPaCis",
    "hearings"
})
public class Appeal {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "Deadline")
    protected String deadline;
    @XmlElement(name = "DtInitialRequestRecd", required = true)
    protected String dtInitialRequestRecd;
    @XmlElement(name = "TransactionId")
    protected String transactionId;
    @XmlElement(name = "AppealDisposition")
    protected String appealDisposition;
    @XmlElement(name = "AppealCategory")
    protected String appealCategory;
    @XmlElement(name = "BigBoxAppeal")
    protected String bigBoxAppeal;
    @XmlElement(name = "DateCompleteRequestReceived")
    protected String dateCompleteRequestReceived;
    @XmlElement(name = "DeadlineWaived")
    protected String deadlineWaived;
    @XmlElement(name = "DtReopenRqstDenied")
    protected String dtReopenRqstDenied;
    @XmlElement(name = "ExcludedProvider")
    protected String excludedProvider;
    @XmlElement(name = "ExternalAppealNum", required = true)
    protected String externalAppealNum;
    @XmlElement(name = "FiledTimely")
    protected String filedTimely;
    @XmlElement(name = "MSP")
    protected String msp;
    @XmlElement(name = "MedicareType")
    protected String medicareType;
    @XmlElement(name = "MeetsMinimumDollarAmount")
    protected String meetsMinimumDollarAmount;
    @XmlElement(name = "NonBIPA")
    protected String nonBIPA;
    @XmlElement(name = "OTRDecision")
    protected String otrDecision;
    @XmlElement(name = "OTRRequested")
    protected String otrRequested;
    @XmlElement(name = "PSCZPIC")
    protected String psczpic;
    @XmlElement(name = "PotentialOTRReview")
    protected String potentialOTRReview;
    @XmlElement(name = "PrimaryAdjudicatingEntity", required = true)
    protected String primaryAdjudicatingEntity;
    @XmlElement(name = "AppealPriority")
    protected String appealPriority;
    @XmlElement(name = "RAC")
    protected String rac;
    @XmlElement(name = "RequestType")
    protected String requestType;
    @XmlElement(name = "RequestorType")
    protected String requestorType;
    @XmlElement(name = "E-CaseFile")
    protected String eCaseFile;
    @XmlElement(name = "ALJName")
    protected String aljName;
    @XmlElement(name = "DecLtrMailed")
    protected String decLtrMailed;
    @XmlElement(name = "EcmDocuments")
    protected EcmDocuments ecmDocuments;
    @XmlElement(name = "Providers")
    protected Providers providers;
    @XmlElement(name = "Beneficiaries")
    protected Beneficiaries beneficiaries;
    @XmlElement(name = "PartiesPersons")
    protected PartiesPersons partiesPersons;
    @XmlElement(name = "PartiesOrgs")
    protected PartiesOrgs partiesOrgs;
    @XmlElement(name = "Claims")
    protected Claims claims;
    @XmlElement(name = "ListOfDispositions")
    protected ListOfDispositions listOfDispositions;
    @XmlElement(name = "CloseAppealCombines")
    protected CloseAppealCombines closeAppealCombines;
    @XmlElement(name = "Foia_Pa_Cis")
    protected FoiaPaCis foiaPaCis;
    @XmlElement(name = "Hearings")
    protected Hearings hearings;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the deadline property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeadline() {
        return deadline;
    }

    /**
     * Sets the value of the deadline property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeadline(String value) {
        this.deadline = value;
    }

    /**
     * Gets the value of the dtInitialRequestRecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtInitialRequestRecd() {
        return dtInitialRequestRecd;
    }

    /**
     * Sets the value of the dtInitialRequestRecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtInitialRequestRecd(String value) {
        this.dtInitialRequestRecd = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionId(String value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the appealDisposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealDisposition() {
        return appealDisposition;
    }

    /**
     * Sets the value of the appealDisposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealDisposition(String value) {
        this.appealDisposition = value;
    }

    /**
     * Gets the value of the appealCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealCategory() {
        return appealCategory;
    }

    /**
     * Sets the value of the appealCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealCategory(String value) {
        this.appealCategory = value;
    }

    /**
     * Gets the value of the bigBoxAppeal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBigBoxAppeal() {
        return bigBoxAppeal;
    }

    /**
     * Sets the value of the bigBoxAppeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBigBoxAppeal(String value) {
        this.bigBoxAppeal = value;
    }

    /**
     * Gets the value of the dateCompleteRequestReceived property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateCompleteRequestReceived() {
        return dateCompleteRequestReceived;
    }

    /**
     * Sets the value of the dateCompleteRequestReceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateCompleteRequestReceived(String value) {
        this.dateCompleteRequestReceived = value;
    }

    /**
     * Gets the value of the deadlineWaived property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeadlineWaived() {
        return deadlineWaived;
    }

    /**
     * Sets the value of the deadlineWaived property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeadlineWaived(String value) {
        this.deadlineWaived = value;
    }

    /**
     * Gets the value of the dtReopenRqstDenied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtReopenRqstDenied() {
        return dtReopenRqstDenied;
    }

    /**
     * Sets the value of the dtReopenRqstDenied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtReopenRqstDenied(String value) {
        this.dtReopenRqstDenied = value;
    }

    /**
     * Gets the value of the excludedProvider property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExcludedProvider() {
        return excludedProvider;
    }

    /**
     * Sets the value of the excludedProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExcludedProvider(String value) {
        this.excludedProvider = value;
    }

    /**
     * Gets the value of the externalAppealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalAppealNum() {
        return externalAppealNum;
    }

    /**
     * Sets the value of the externalAppealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalAppealNum(String value) {
        this.externalAppealNum = value;
    }

    /**
     * Gets the value of the filedTimely property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiledTimely() {
        return filedTimely;
    }

    /**
     * Sets the value of the filedTimely property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiledTimely(String value) {
        this.filedTimely = value;
    }

    /**
     * Gets the value of the msp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSP() {
        return msp;
    }

    /**
     * Sets the value of the msp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSP(String value) {
        this.msp = value;
    }

    /**
     * Gets the value of the medicareType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareType() {
        return medicareType;
    }

    /**
     * Sets the value of the medicareType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareType(String value) {
        this.medicareType = value;
    }

    /**
     * Gets the value of the meetsMinimumDollarAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMeetsMinimumDollarAmount() {
        return meetsMinimumDollarAmount;
    }

    /**
     * Sets the value of the meetsMinimumDollarAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMeetsMinimumDollarAmount(String value) {
        this.meetsMinimumDollarAmount = value;
    }

    /**
     * Gets the value of the nonBIPA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonBIPA() {
        return nonBIPA;
    }

    /**
     * Sets the value of the nonBIPA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonBIPA(String value) {
        this.nonBIPA = value;
    }

    /**
     * Gets the value of the otrDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOTRDecision() {
        return otrDecision;
    }

    /**
     * Sets the value of the otrDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOTRDecision(String value) {
        this.otrDecision = value;
    }

    /**
     * Gets the value of the otrRequested property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOTRRequested() {
        return otrRequested;
    }

    /**
     * Sets the value of the otrRequested property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOTRRequested(String value) {
        this.otrRequested = value;
    }

    /**
     * Gets the value of the psczpic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSCZPIC() {
        return psczpic;
    }

    /**
     * Sets the value of the psczpic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSCZPIC(String value) {
        this.psczpic = value;
    }

    /**
     * Gets the value of the potentialOTRReview property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPotentialOTRReview() {
        return potentialOTRReview;
    }

    /**
     * Sets the value of the potentialOTRReview property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPotentialOTRReview(String value) {
        this.potentialOTRReview = value;
    }

    /**
     * Gets the value of the primaryAdjudicatingEntity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryAdjudicatingEntity() {
        return primaryAdjudicatingEntity;
    }

    /**
     * Sets the value of the primaryAdjudicatingEntity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryAdjudicatingEntity(String value) {
        this.primaryAdjudicatingEntity = value;
    }

    /**
     * Gets the value of the appealPriority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealPriority() {
        return appealPriority;
    }

    /**
     * Sets the value of the appealPriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealPriority(String value) {
        this.appealPriority = value;
    }

    /**
     * Gets the value of the rac property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRAC() {
        return rac;
    }

    /**
     * Sets the value of the rac property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRAC(String value) {
        this.rac = value;
    }

    /**
     * Gets the value of the requestType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the requestorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorType() {
        return requestorType;
    }

    /**
     * Sets the value of the requestorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorType(String value) {
        this.requestorType = value;
    }

    /**
     * Gets the value of the eCaseFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECaseFile() {
        return eCaseFile;
    }

    /**
     * Sets the value of the eCaseFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECaseFile(String value) {
        this.eCaseFile = value;
    }

    /**
     * Gets the value of the aljName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getALJName() {
        return aljName;
    }

    /**
     * Sets the value of the aljName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setALJName(String value) {
        this.aljName = value;
    }

    /**
     * Gets the value of the decLtrMailed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecLtrMailed() {
        return decLtrMailed;
    }

    /**
     * Sets the value of the decLtrMailed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecLtrMailed(String value) {
        this.decLtrMailed = value;
    }

    /**
     * Gets the value of the ecmDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link EcmDocuments }
     *     
     */
    public EcmDocuments getEcmDocuments() {
        return ecmDocuments;
    }

    /**
     * Sets the value of the ecmDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link EcmDocuments }
     *     
     */
    public void setEcmDocuments(EcmDocuments value) {
        this.ecmDocuments = value;
    }

    /**
     * Gets the value of the providers property.
     * 
     * @return
     *     possible object is
     *     {@link Providers }
     *     
     */
    public Providers getProviders() {
        return providers;
    }

    /**
     * Sets the value of the providers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Providers }
     *     
     */
    public void setProviders(Providers value) {
        this.providers = value;
    }

    /**
     * Gets the value of the beneficiaries property.
     * 
     * @return
     *     possible object is
     *     {@link Beneficiaries }
     *     
     */
    public Beneficiaries getBeneficiaries() {
        return beneficiaries;
    }

    /**
     * Sets the value of the beneficiaries property.
     * 
     * @param value
     *     allowed object is
     *     {@link Beneficiaries }
     *     
     */
    public void setBeneficiaries(Beneficiaries value) {
        this.beneficiaries = value;
    }

    /**
     * Gets the value of the partiesPersons property.
     * 
     * @return
     *     possible object is
     *     {@link PartiesPersons }
     *     
     */
    public PartiesPersons getPartiesPersons() {
        return partiesPersons;
    }

    /**
     * Sets the value of the partiesPersons property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartiesPersons }
     *     
     */
    public void setPartiesPersons(PartiesPersons value) {
        this.partiesPersons = value;
    }

    /**
     * Gets the value of the partiesOrgs property.
     * 
     * @return
     *     possible object is
     *     {@link PartiesOrgs }
     *     
     */
    public PartiesOrgs getPartiesOrgs() {
        return partiesOrgs;
    }

    /**
     * Sets the value of the partiesOrgs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartiesOrgs }
     *     
     */
    public void setPartiesOrgs(PartiesOrgs value) {
        this.partiesOrgs = value;
    }

    /**
     * Gets the value of the claims property.
     * 
     * @return
     *     possible object is
     *     {@link Claims }
     *     
     */
    public Claims getClaims() {
        return claims;
    }

    /**
     * Sets the value of the claims property.
     * 
     * @param value
     *     allowed object is
     *     {@link Claims }
     *     
     */
    public void setClaims(Claims value) {
        this.claims = value;
    }

    /**
     * Gets the value of the listOfDispositions property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDispositions }
     *     
     */
    public ListOfDispositions getListOfDispositions() {
        return listOfDispositions;
    }

    /**
     * Sets the value of the listOfDispositions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDispositions }
     *     
     */
    public void setListOfDispositions(ListOfDispositions value) {
        this.listOfDispositions = value;
    }

    /**
     * Gets the value of the closeAppealCombines property.
     * 
     * @return
     *     possible object is
     *     {@link CloseAppealCombines }
     *     
     */
    public CloseAppealCombines getCloseAppealCombines() {
        return closeAppealCombines;
    }

    /**
     * Sets the value of the closeAppealCombines property.
     * 
     * @param value
     *     allowed object is
     *     {@link CloseAppealCombines }
     *     
     */
    public void setCloseAppealCombines(CloseAppealCombines value) {
        this.closeAppealCombines = value;
    }

    /**
     * Gets the value of the foiaPaCis property.
     * 
     * @return
     *     possible object is
     *     {@link FoiaPaCis }
     *     
     */
    public FoiaPaCis getFoiaPaCis() {
        return foiaPaCis;
    }

    /**
     * Sets the value of the foiaPaCis property.
     * 
     * @param value
     *     allowed object is
     *     {@link FoiaPaCis }
     *     
     */
    public void setFoiaPaCis(FoiaPaCis value) {
        this.foiaPaCis = value;
    }

    /**
     * Gets the value of the hearings property.
     * 
     * @return
     *     possible object is
     *     {@link Hearings }
     *     
     */
    public Hearings getHearings() {
        return hearings;
    }

    /**
     * Sets the value of the hearings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Hearings }
     *     
     */
    public void setHearings(Hearings value) {
        this.hearings = value;
    }

}
