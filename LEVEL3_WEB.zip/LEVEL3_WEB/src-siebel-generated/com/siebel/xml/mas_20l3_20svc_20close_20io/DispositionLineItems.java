
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DispositionLineItems complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DispositionLineItems">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CLINumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Disposition" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="DispositionDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Explanation" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string250" minOccurs="0"/>
 *         &lt;element name="ProceduralDecisionReason" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DispositionLineItems", propOrder = {
    "cliNumber",
    "disposition",
    "dispositionDate",
    "explanation",
    "proceduralDecisionReason"
})
public class DispositionLineItems {

    @XmlElement(name = "CLINumber", required = true)
    protected String cliNumber;
    @XmlElement(name = "Disposition", required = true)
    protected String disposition;
    @XmlElement(name = "DispositionDate", required = true)
    protected String dispositionDate;
    @XmlElement(name = "Explanation")
    protected String explanation;
    @XmlElement(name = "ProceduralDecisionReason")
    protected String proceduralDecisionReason;

    /**
     * Gets the value of the cliNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLINumber() {
        return cliNumber;
    }

    /**
     * Sets the value of the cliNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLINumber(String value) {
        this.cliNumber = value;
    }

    /**
     * Gets the value of the disposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisposition() {
        return disposition;
    }

    /**
     * Sets the value of the disposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisposition(String value) {
        this.disposition = value;
    }

    /**
     * Gets the value of the dispositionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDispositionDate() {
        return dispositionDate;
    }

    /**
     * Sets the value of the dispositionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDispositionDate(String value) {
        this.dispositionDate = value;
    }

    /**
     * Gets the value of the explanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExplanation() {
        return explanation;
    }

    /**
     * Sets the value of the explanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExplanation(String value) {
        this.explanation = value;
    }

    /**
     * Gets the value of the proceduralDecisionReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProceduralDecisionReason() {
        return proceduralDecisionReason;
    }

    /**
     * Sets the value of the proceduralDecisionReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProceduralDecisionReason(String value) {
        this.proceduralDecisionReason = value;
    }

}
