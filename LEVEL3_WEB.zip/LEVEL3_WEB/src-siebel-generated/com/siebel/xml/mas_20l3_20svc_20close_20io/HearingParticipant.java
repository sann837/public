
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HearingParticipant complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HearingParticipant">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ParticipationFormat" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="PartyUId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="ParticipantNotified" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string1" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HearingParticipant", propOrder = {
    "participationFormat",
    "firstName",
    "partyUId",
    "lastName",
    "participantNotified"
})
public class HearingParticipant {

    @XmlElement(name = "ParticipationFormat")
    protected String participationFormat;
    @XmlElement(name = "FirstName")
    protected String firstName;
    @XmlElement(name = "PartyUId")
    protected String partyUId;
    @XmlElement(name = "LastName")
    protected String lastName;
    @XmlElement(name = "ParticipantNotified")
    protected String participantNotified;

    /**
     * Gets the value of the participationFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticipationFormat() {
        return participationFormat;
    }

    /**
     * Sets the value of the participationFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticipationFormat(String value) {
        this.participationFormat = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the partyUId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyUId() {
        return partyUId;
    }

    /**
     * Sets the value of the partyUId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyUId(String value) {
        this.partyUId = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the participantNotified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParticipantNotified() {
        return participantNotified;
    }

    /**
     * Sets the value of the participantNotified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParticipantNotified(String value) {
        this.participantNotified = value;
    }

}
