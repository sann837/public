
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClaimLineItem_BillingModifierCode complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimLineItem_BillingModifierCode">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BillingModifierCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimLineItem_BillingModifierCode", propOrder = {
    "billingModifierCode"
})
public class ClaimLineItemBillingModifierCode {

    @XmlElement(name = "BillingModifierCode", required = true)
    protected String billingModifierCode;

    /**
     * Gets the value of the billingModifierCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingModifierCode() {
        return billingModifierCode;
    }

    /**
     * Sets the value of the billingModifierCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingModifierCode(String value) {
        this.billingModifierCode = value;
    }

}
