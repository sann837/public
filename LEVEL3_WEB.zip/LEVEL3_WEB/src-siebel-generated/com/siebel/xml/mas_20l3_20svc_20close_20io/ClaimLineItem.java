
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClaimLineItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimLineItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AllowedAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BrandNameDrug" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="CLINumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DRGCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="DateofServiceFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateofServiceTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DosageForm" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="DrugCategory" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DrugClass" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DrugName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="FormularyKeyDrugType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string255" minOccurs="0"/>
 *         &lt;element name="FormularyName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="FormularyType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="HIPPSCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ItemAmountinDispute" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MCSAuditCodeValue" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string2000" minOccurs="0"/>
 *         &lt;element name="MsgActionCodeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NABPNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="NewPrescription" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string10" minOccurs="0"/>
 *         &lt;element name="OtherFormularyClassification" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string255" minOccurs="0"/>
 *         &lt;element name="OutofNetworkPharmacy" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string10" minOccurs="0"/>
 *         &lt;element name="PlaceofService" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ProcedureClassCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="ProcedureCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="RevenueCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="RxNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ServiceDaysUnits" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrOOPAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClaimLineItem_BillingModifierCodes" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ClaimLineItem_BillingModifierCodes" minOccurs="0"/>
 *         &lt;element name="ClaimLineItem_DiagnosisCodes" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ClaimLineItem_DiagnosisCodes" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimLineItem", propOrder = {
    "allowedAmount",
    "brandNameDrug",
    "cliNumber",
    "drgCode",
    "dateofServiceFrom",
    "dateofServiceTo",
    "dosageForm",
    "drugCategory",
    "drugClass",
    "drugName",
    "formularyKeyDrugType",
    "formularyName",
    "formularyType",
    "hippsCode",
    "itemAmountinDispute",
    "mcsAuditCodeValue",
    "msgActionCodeValue",
    "nabpNumber",
    "newPrescription",
    "otherFormularyClassification",
    "outofNetworkPharmacy",
    "placeofService",
    "procedureClassCode",
    "procedureCode",
    "revenueCode",
    "rxNumber",
    "serviceDaysUnits",
    "trOOPAmount",
    "claimLineItemBillingModifierCodes",
    "claimLineItemDiagnosisCodes"
})
public class ClaimLineItem {

    @XmlElement(name = "AllowedAmount")
    protected String allowedAmount;
    @XmlElement(name = "BrandNameDrug")
    protected String brandNameDrug;
    @XmlElement(name = "CLINumber", required = true)
    protected String cliNumber;
    @XmlElement(name = "DRGCode")
    protected String drgCode;
    @XmlElement(name = "DateofServiceFrom")
    protected String dateofServiceFrom;
    @XmlElement(name = "DateofServiceTo")
    protected String dateofServiceTo;
    @XmlElement(name = "DosageForm")
    protected String dosageForm;
    @XmlElement(name = "DrugCategory")
    protected String drugCategory;
    @XmlElement(name = "DrugClass")
    protected String drugClass;
    @XmlElement(name = "DrugName")
    protected String drugName;
    @XmlElement(name = "FormularyKeyDrugType")
    protected String formularyKeyDrugType;
    @XmlElement(name = "FormularyName")
    protected String formularyName;
    @XmlElement(name = "FormularyType")
    protected String formularyType;
    @XmlElement(name = "HIPPSCode")
    protected String hippsCode;
    @XmlElement(name = "ItemAmountinDispute")
    protected String itemAmountinDispute;
    @XmlElement(name = "MCSAuditCodeValue")
    protected String mcsAuditCodeValue;
    @XmlElement(name = "MsgActionCodeValue")
    protected String msgActionCodeValue;
    @XmlElement(name = "NABPNumber")
    protected String nabpNumber;
    @XmlElement(name = "NewPrescription")
    protected String newPrescription;
    @XmlElement(name = "OtherFormularyClassification")
    protected String otherFormularyClassification;
    @XmlElement(name = "OutofNetworkPharmacy")
    protected String outofNetworkPharmacy;
    @XmlElement(name = "PlaceofService")
    protected String placeofService;
    @XmlElement(name = "ProcedureClassCode")
    protected String procedureClassCode;
    @XmlElement(name = "ProcedureCode")
    protected String procedureCode;
    @XmlElement(name = "RevenueCode")
    protected String revenueCode;
    @XmlElement(name = "RxNumber")
    protected String rxNumber;
    @XmlElement(name = "ServiceDaysUnits")
    protected String serviceDaysUnits;
    @XmlElement(name = "TrOOPAmount")
    protected String trOOPAmount;
    @XmlElement(name = "ClaimLineItem_BillingModifierCodes")
    protected ClaimLineItemBillingModifierCodes claimLineItemBillingModifierCodes;
    @XmlElement(name = "ClaimLineItem_DiagnosisCodes")
    protected ClaimLineItemDiagnosisCodes claimLineItemDiagnosisCodes;

    /**
     * Gets the value of the allowedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllowedAmount() {
        return allowedAmount;
    }

    /**
     * Sets the value of the allowedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowedAmount(String value) {
        this.allowedAmount = value;
    }

    /**
     * Gets the value of the brandNameDrug property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandNameDrug() {
        return brandNameDrug;
    }

    /**
     * Sets the value of the brandNameDrug property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandNameDrug(String value) {
        this.brandNameDrug = value;
    }

    /**
     * Gets the value of the cliNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLINumber() {
        return cliNumber;
    }

    /**
     * Sets the value of the cliNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLINumber(String value) {
        this.cliNumber = value;
    }

    /**
     * Gets the value of the drgCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDRGCode() {
        return drgCode;
    }

    /**
     * Sets the value of the drgCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDRGCode(String value) {
        this.drgCode = value;
    }

    /**
     * Gets the value of the dateofServiceFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateofServiceFrom() {
        return dateofServiceFrom;
    }

    /**
     * Sets the value of the dateofServiceFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateofServiceFrom(String value) {
        this.dateofServiceFrom = value;
    }

    /**
     * Gets the value of the dateofServiceTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateofServiceTo() {
        return dateofServiceTo;
    }

    /**
     * Sets the value of the dateofServiceTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateofServiceTo(String value) {
        this.dateofServiceTo = value;
    }

    /**
     * Gets the value of the dosageForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosageForm() {
        return dosageForm;
    }

    /**
     * Sets the value of the dosageForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosageForm(String value) {
        this.dosageForm = value;
    }

    /**
     * Gets the value of the drugCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugCategory() {
        return drugCategory;
    }

    /**
     * Sets the value of the drugCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugCategory(String value) {
        this.drugCategory = value;
    }

    /**
     * Gets the value of the drugClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugClass() {
        return drugClass;
    }

    /**
     * Sets the value of the drugClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugClass(String value) {
        this.drugClass = value;
    }

    /**
     * Gets the value of the drugName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugName() {
        return drugName;
    }

    /**
     * Sets the value of the drugName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugName(String value) {
        this.drugName = value;
    }

    /**
     * Gets the value of the formularyKeyDrugType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormularyKeyDrugType() {
        return formularyKeyDrugType;
    }

    /**
     * Sets the value of the formularyKeyDrugType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormularyKeyDrugType(String value) {
        this.formularyKeyDrugType = value;
    }

    /**
     * Gets the value of the formularyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormularyName() {
        return formularyName;
    }

    /**
     * Sets the value of the formularyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormularyName(String value) {
        this.formularyName = value;
    }

    /**
     * Gets the value of the formularyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormularyType() {
        return formularyType;
    }

    /**
     * Sets the value of the formularyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormularyType(String value) {
        this.formularyType = value;
    }

    /**
     * Gets the value of the hippsCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIPPSCode() {
        return hippsCode;
    }

    /**
     * Sets the value of the hippsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIPPSCode(String value) {
        this.hippsCode = value;
    }

    /**
     * Gets the value of the itemAmountinDispute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemAmountinDispute() {
        return itemAmountinDispute;
    }

    /**
     * Sets the value of the itemAmountinDispute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemAmountinDispute(String value) {
        this.itemAmountinDispute = value;
    }

    /**
     * Gets the value of the mcsAuditCodeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCSAuditCodeValue() {
        return mcsAuditCodeValue;
    }

    /**
     * Sets the value of the mcsAuditCodeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCSAuditCodeValue(String value) {
        this.mcsAuditCodeValue = value;
    }

    /**
     * Gets the value of the msgActionCodeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgActionCodeValue() {
        return msgActionCodeValue;
    }

    /**
     * Sets the value of the msgActionCodeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgActionCodeValue(String value) {
        this.msgActionCodeValue = value;
    }

    /**
     * Gets the value of the nabpNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNABPNumber() {
        return nabpNumber;
    }

    /**
     * Sets the value of the nabpNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNABPNumber(String value) {
        this.nabpNumber = value;
    }

    /**
     * Gets the value of the newPrescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewPrescription() {
        return newPrescription;
    }

    /**
     * Sets the value of the newPrescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewPrescription(String value) {
        this.newPrescription = value;
    }

    /**
     * Gets the value of the otherFormularyClassification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherFormularyClassification() {
        return otherFormularyClassification;
    }

    /**
     * Sets the value of the otherFormularyClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherFormularyClassification(String value) {
        this.otherFormularyClassification = value;
    }

    /**
     * Gets the value of the outofNetworkPharmacy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOutofNetworkPharmacy() {
        return outofNetworkPharmacy;
    }

    /**
     * Sets the value of the outofNetworkPharmacy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOutofNetworkPharmacy(String value) {
        this.outofNetworkPharmacy = value;
    }

    /**
     * Gets the value of the placeofService property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceofService() {
        return placeofService;
    }

    /**
     * Sets the value of the placeofService property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceofService(String value) {
        this.placeofService = value;
    }

    /**
     * Gets the value of the procedureClassCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcedureClassCode() {
        return procedureClassCode;
    }

    /**
     * Sets the value of the procedureClassCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcedureClassCode(String value) {
        this.procedureClassCode = value;
    }

    /**
     * Gets the value of the procedureCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcedureCode() {
        return procedureCode;
    }

    /**
     * Sets the value of the procedureCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcedureCode(String value) {
        this.procedureCode = value;
    }

    /**
     * Gets the value of the revenueCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevenueCode() {
        return revenueCode;
    }

    /**
     * Sets the value of the revenueCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevenueCode(String value) {
        this.revenueCode = value;
    }

    /**
     * Gets the value of the rxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRxNumber() {
        return rxNumber;
    }

    /**
     * Sets the value of the rxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRxNumber(String value) {
        this.rxNumber = value;
    }

    /**
     * Gets the value of the serviceDaysUnits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceDaysUnits() {
        return serviceDaysUnits;
    }

    /**
     * Sets the value of the serviceDaysUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceDaysUnits(String value) {
        this.serviceDaysUnits = value;
    }

    /**
     * Gets the value of the trOOPAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrOOPAmount() {
        return trOOPAmount;
    }

    /**
     * Sets the value of the trOOPAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrOOPAmount(String value) {
        this.trOOPAmount = value;
    }

    /**
     * Gets the value of the claimLineItemBillingModifierCodes property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimLineItemBillingModifierCodes }
     *     
     */
    public ClaimLineItemBillingModifierCodes getClaimLineItemBillingModifierCodes() {
        return claimLineItemBillingModifierCodes;
    }

    /**
     * Sets the value of the claimLineItemBillingModifierCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimLineItemBillingModifierCodes }
     *     
     */
    public void setClaimLineItemBillingModifierCodes(ClaimLineItemBillingModifierCodes value) {
        this.claimLineItemBillingModifierCodes = value;
    }

    /**
     * Gets the value of the claimLineItemDiagnosisCodes property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimLineItemDiagnosisCodes }
     *     
     */
    public ClaimLineItemDiagnosisCodes getClaimLineItemDiagnosisCodes() {
        return claimLineItemDiagnosisCodes;
    }

    /**
     * Sets the value of the claimLineItemDiagnosisCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimLineItemDiagnosisCodes }
     *     
     */
    public void setClaimLineItemDiagnosisCodes(ClaimLineItemDiagnosisCodes value) {
        this.claimLineItemDiagnosisCodes = value;
    }

}
