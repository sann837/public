
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BeneficiaryAddresses complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneficiaryAddresses">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BeneficiaryAddress" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}BeneficiaryAddress" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficiaryAddresses", propOrder = {
    "beneficiaryAddress"
})
public class BeneficiaryAddresses {

    @XmlElement(name = "BeneficiaryAddress")
    protected List<BeneficiaryAddress> beneficiaryAddress;

    /**
     * Gets the value of the beneficiaryAddress property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the beneficiaryAddress property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBeneficiaryAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BeneficiaryAddress }
     * 
     * 
     */
    public List<BeneficiaryAddress> getBeneficiaryAddress() {
        if (beneficiaryAddress == null) {
            beneficiaryAddress = new ArrayList<BeneficiaryAddress>();
        }
        return this.beneficiaryAddress;
    }

}
