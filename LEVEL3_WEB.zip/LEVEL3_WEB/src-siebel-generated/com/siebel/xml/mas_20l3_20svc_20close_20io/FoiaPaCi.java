
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Foia_Pa_Ci complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Foia_Pa_Ci">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ActionTaken" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ActualEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActualStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneficiaryHICNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DateFormReturned" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateFormSent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateRequestApproved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateRequestReceived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateofRequest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestReviewed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestorFirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="RequestorLastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="RequestorPersonRelationship" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="RequestorType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Resolution" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string255" minOccurs="0"/>
 *         &lt;element name="SRType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Foia_Pa_Ci", propOrder = {
    "actionTaken",
    "actualEndDate",
    "actualStartDate",
    "beneficiaryHICNumber",
    "dateFormReturned",
    "dateFormSent",
    "dateRequestApproved",
    "dateRequestReceived",
    "dateofRequest",
    "requestReviewed",
    "requestorFirstName",
    "requestorLastName",
    "requestorPersonRelationship",
    "requestorType",
    "resolution",
    "srType",
    "status"
})
public class FoiaPaCi {

    @XmlElement(name = "ActionTaken")
    protected String actionTaken;
    @XmlElement(name = "ActualEndDate")
    protected String actualEndDate;
    @XmlElement(name = "ActualStartDate")
    protected String actualStartDate;
    @XmlElement(name = "BeneficiaryHICNumber")
    protected String beneficiaryHICNumber;
    @XmlElement(name = "DateFormReturned")
    protected String dateFormReturned;
    @XmlElement(name = "DateFormSent")
    protected String dateFormSent;
    @XmlElement(name = "DateRequestApproved")
    protected String dateRequestApproved;
    @XmlElement(name = "DateRequestReceived")
    protected String dateRequestReceived;
    @XmlElement(name = "DateofRequest")
    protected String dateofRequest;
    @XmlElement(name = "RequestReviewed")
    protected String requestReviewed;
    @XmlElement(name = "RequestorFirstName")
    protected String requestorFirstName;
    @XmlElement(name = "RequestorLastName")
    protected String requestorLastName;
    @XmlElement(name = "RequestorPersonRelationship")
    protected String requestorPersonRelationship;
    @XmlElement(name = "RequestorType")
    protected String requestorType;
    @XmlElement(name = "Resolution")
    protected String resolution;
    @XmlElement(name = "SRType")
    protected String srType;
    @XmlElement(name = "Status")
    protected String status;

    /**
     * Gets the value of the actionTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionTaken() {
        return actionTaken;
    }

    /**
     * Sets the value of the actionTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionTaken(String value) {
        this.actionTaken = value;
    }

    /**
     * Gets the value of the actualEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActualEndDate() {
        return actualEndDate;
    }

    /**
     * Sets the value of the actualEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActualEndDate(String value) {
        this.actualEndDate = value;
    }

    /**
     * Gets the value of the actualStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActualStartDate() {
        return actualStartDate;
    }

    /**
     * Sets the value of the actualStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActualStartDate(String value) {
        this.actualStartDate = value;
    }

    /**
     * Gets the value of the beneficiaryHICNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryHICNumber() {
        return beneficiaryHICNumber;
    }

    /**
     * Sets the value of the beneficiaryHICNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryHICNumber(String value) {
        this.beneficiaryHICNumber = value;
    }

    /**
     * Gets the value of the dateFormReturned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateFormReturned() {
        return dateFormReturned;
    }

    /**
     * Sets the value of the dateFormReturned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateFormReturned(String value) {
        this.dateFormReturned = value;
    }

    /**
     * Gets the value of the dateFormSent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateFormSent() {
        return dateFormSent;
    }

    /**
     * Sets the value of the dateFormSent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateFormSent(String value) {
        this.dateFormSent = value;
    }

    /**
     * Gets the value of the dateRequestApproved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateRequestApproved() {
        return dateRequestApproved;
    }

    /**
     * Sets the value of the dateRequestApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateRequestApproved(String value) {
        this.dateRequestApproved = value;
    }

    /**
     * Gets the value of the dateRequestReceived property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateRequestReceived() {
        return dateRequestReceived;
    }

    /**
     * Sets the value of the dateRequestReceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateRequestReceived(String value) {
        this.dateRequestReceived = value;
    }

    /**
     * Gets the value of the dateofRequest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateofRequest() {
        return dateofRequest;
    }

    /**
     * Sets the value of the dateofRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateofRequest(String value) {
        this.dateofRequest = value;
    }

    /**
     * Gets the value of the requestReviewed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestReviewed() {
        return requestReviewed;
    }

    /**
     * Sets the value of the requestReviewed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestReviewed(String value) {
        this.requestReviewed = value;
    }

    /**
     * Gets the value of the requestorFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorFirstName() {
        return requestorFirstName;
    }

    /**
     * Sets the value of the requestorFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorFirstName(String value) {
        this.requestorFirstName = value;
    }

    /**
     * Gets the value of the requestorLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorLastName() {
        return requestorLastName;
    }

    /**
     * Sets the value of the requestorLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorLastName(String value) {
        this.requestorLastName = value;
    }

    /**
     * Gets the value of the requestorPersonRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorPersonRelationship() {
        return requestorPersonRelationship;
    }

    /**
     * Sets the value of the requestorPersonRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorPersonRelationship(String value) {
        this.requestorPersonRelationship = value;
    }

    /**
     * Gets the value of the requestorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorType() {
        return requestorType;
    }

    /**
     * Sets the value of the requestorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorType(String value) {
        this.requestorType = value;
    }

    /**
     * Gets the value of the resolution property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Sets the value of the resolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResolution(String value) {
        this.resolution = value;
    }

    /**
     * Gets the value of the srType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRType() {
        return srType;
    }

    /**
     * Sets the value of the srType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRType(String value) {
        this.srType = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
