
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartiesPerson complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartiesPerson">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppellantFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppointedRepresentative" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneficiaryFirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="BeneficiaryHICNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="BeneficiaryLastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="CellPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailAddress" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string350" minOccurs="0"/>
 *         &lt;element name="FaxPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50"/>
 *         &lt;element name="Gender" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="HomePhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50"/>
 *         &lt;element name="MiddleName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="Prefix" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string15" minOccurs="0"/>
 *         &lt;element name="PrimaryContactAppellantFlg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestorFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Role" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="Suffix" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string15" minOccurs="0"/>
 *         &lt;element name="WorkPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PartyUId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="PartyPersonAddresses" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}PartyPersonAddresses" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartiesPerson", propOrder = {
    "appellantFlag",
    "appointedRepresentative",
    "beneficiaryFirstName",
    "beneficiaryHICNumber",
    "beneficiaryLastName",
    "cellPhone",
    "emailAddress",
    "faxPhoneNumber",
    "firstName",
    "gender",
    "homePhoneNumber",
    "lastName",
    "middleName",
    "prefix",
    "primaryContactAppellantFlg",
    "requestorFlag",
    "role",
    "suffix",
    "workPhoneNumber",
    "partyUId",
    "partyPersonAddresses"
})
public class PartiesPerson {

    @XmlElement(name = "AppellantFlag")
    protected String appellantFlag;
    @XmlElement(name = "AppointedRepresentative")
    protected String appointedRepresentative;
    @XmlElement(name = "BeneficiaryFirstName")
    protected String beneficiaryFirstName;
    @XmlElement(name = "BeneficiaryHICNumber")
    protected String beneficiaryHICNumber;
    @XmlElement(name = "BeneficiaryLastName")
    protected String beneficiaryLastName;
    @XmlElement(name = "CellPhone")
    protected String cellPhone;
    @XmlElement(name = "EmailAddress")
    protected String emailAddress;
    @XmlElement(name = "FaxPhoneNumber")
    protected String faxPhoneNumber;
    @XmlElement(name = "FirstName", required = true)
    protected String firstName;
    @XmlElement(name = "Gender")
    protected String gender;
    @XmlElement(name = "HomePhoneNumber")
    protected String homePhoneNumber;
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    @XmlElement(name = "MiddleName")
    protected String middleName;
    @XmlElement(name = "Prefix")
    protected String prefix;
    @XmlElement(name = "PrimaryContactAppellantFlg")
    protected String primaryContactAppellantFlg;
    @XmlElement(name = "RequestorFlag")
    protected String requestorFlag;
    @XmlElement(name = "Role")
    protected String role;
    @XmlElement(name = "Suffix")
    protected String suffix;
    @XmlElement(name = "WorkPhoneNumber")
    protected String workPhoneNumber;
    @XmlElement(name = "PartyUId", required = true)
    protected String partyUId;
    @XmlElement(name = "PartyPersonAddresses")
    protected PartyPersonAddresses partyPersonAddresses;

    /**
     * Gets the value of the appellantFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppellantFlag() {
        return appellantFlag;
    }

    /**
     * Sets the value of the appellantFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppellantFlag(String value) {
        this.appellantFlag = value;
    }

    /**
     * Gets the value of the appointedRepresentative property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppointedRepresentative() {
        return appointedRepresentative;
    }

    /**
     * Sets the value of the appointedRepresentative property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppointedRepresentative(String value) {
        this.appointedRepresentative = value;
    }

    /**
     * Gets the value of the beneficiaryFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryFirstName() {
        return beneficiaryFirstName;
    }

    /**
     * Sets the value of the beneficiaryFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryFirstName(String value) {
        this.beneficiaryFirstName = value;
    }

    /**
     * Gets the value of the beneficiaryHICNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryHICNumber() {
        return beneficiaryHICNumber;
    }

    /**
     * Sets the value of the beneficiaryHICNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryHICNumber(String value) {
        this.beneficiaryHICNumber = value;
    }

    /**
     * Gets the value of the beneficiaryLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryLastName() {
        return beneficiaryLastName;
    }

    /**
     * Sets the value of the beneficiaryLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryLastName(String value) {
        this.beneficiaryLastName = value;
    }

    /**
     * Gets the value of the cellPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     * Sets the value of the cellPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellPhone(String value) {
        this.cellPhone = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the faxPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaxPhoneNumber() {
        return faxPhoneNumber;
    }

    /**
     * Sets the value of the faxPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaxPhoneNumber(String value) {
        this.faxPhoneNumber = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the homePhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    /**
     * Sets the value of the homePhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePhoneNumber(String value) {
        this.homePhoneNumber = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the primaryContactAppellantFlg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryContactAppellantFlg() {
        return primaryContactAppellantFlg;
    }

    /**
     * Sets the value of the primaryContactAppellantFlg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryContactAppellantFlg(String value) {
        this.primaryContactAppellantFlg = value;
    }

    /**
     * Gets the value of the requestorFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorFlag() {
        return requestorFlag;
    }

    /**
     * Sets the value of the requestorFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorFlag(String value) {
        this.requestorFlag = value;
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRole(String value) {
        this.role = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the workPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkPhoneNumber() {
        return workPhoneNumber;
    }

    /**
     * Sets the value of the workPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkPhoneNumber(String value) {
        this.workPhoneNumber = value;
    }

    /**
     * Gets the value of the partyUId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyUId() {
        return partyUId;
    }

    /**
     * Sets the value of the partyUId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyUId(String value) {
        this.partyUId = value;
    }

    /**
     * Gets the value of the partyPersonAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link PartyPersonAddresses }
     *     
     */
    public PartyPersonAddresses getPartyPersonAddresses() {
        return partyPersonAddresses;
    }

    /**
     * Sets the value of the partyPersonAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyPersonAddresses }
     *     
     */
    public void setPartyPersonAddresses(PartyPersonAddresses value) {
        this.partyPersonAddresses = value;
    }

}
