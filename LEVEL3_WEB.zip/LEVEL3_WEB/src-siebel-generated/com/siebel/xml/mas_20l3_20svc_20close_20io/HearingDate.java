
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HearingDate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HearingDate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HearingEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HearingStartDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HearingDate", propOrder = {
    "hearingEndDate",
    "hearingStartDate"
})
public class HearingDate {

    @XmlElement(name = "HearingEndDate")
    protected String hearingEndDate;
    @XmlElement(name = "HearingStartDate", required = true)
    protected String hearingStartDate;

    /**
     * Gets the value of the hearingEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHearingEndDate() {
        return hearingEndDate;
    }

    /**
     * Sets the value of the hearingEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHearingEndDate(String value) {
        this.hearingEndDate = value;
    }

    /**
     * Gets the value of the hearingStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHearingStartDate() {
        return hearingStartDate;
    }

    /**
     * Sets the value of the hearingStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHearingStartDate(String value) {
        this.hearingStartDate = value;
    }

}
