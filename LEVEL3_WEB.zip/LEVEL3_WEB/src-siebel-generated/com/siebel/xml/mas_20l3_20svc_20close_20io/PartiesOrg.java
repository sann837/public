
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartiesOrg complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartiesOrg">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppellantFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppointedRepresentative" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneficiaryFirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="BeneficiaryHICNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="BeneficiaryLastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="LegalEntityName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="MainEmailAddress" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string350" minOccurs="0"/>
 *         &lt;element name="MainFaxNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MainPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrgContactFirstName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="OrgContactLastName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="OrgContactTitle" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string75" minOccurs="0"/>
 *         &lt;element name="OrgContactType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="OrgContactUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrgUId" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="PrimaryAppellant" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestorFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Role" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PartyOrgAddresses" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}PartyOrgAddresses" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartiesOrg", propOrder = {
    "appellantFlag",
    "appointedRepresentative",
    "beneficiaryFirstName",
    "beneficiaryHICNumber",
    "beneficiaryLastName",
    "legalEntityName",
    "mainEmailAddress",
    "mainFaxNumber",
    "mainPhoneNumber",
    "orgContactFirstName",
    "orgContactLastName",
    "orgContactTitle",
    "orgContactType",
    "orgContactUID",
    "orgUId",
    "primaryAppellant",
    "requestorFlag",
    "role",
    "partyOrgAddresses"
})
public class PartiesOrg {

    @XmlElement(name = "AppellantFlag")
    protected String appellantFlag;
    @XmlElement(name = "AppointedRepresentative")
    protected String appointedRepresentative;
    @XmlElement(name = "BeneficiaryFirstName")
    protected String beneficiaryFirstName;
    @XmlElement(name = "BeneficiaryHICNumber")
    protected String beneficiaryHICNumber;
    @XmlElement(name = "BeneficiaryLastName")
    protected String beneficiaryLastName;
    @XmlElement(name = "LegalEntityName", required = true)
    protected String legalEntityName;
    @XmlElement(name = "MainEmailAddress")
    protected String mainEmailAddress;
    @XmlElement(name = "MainFaxNumber")
    protected String mainFaxNumber;
    @XmlElement(name = "MainPhoneNumber")
    protected String mainPhoneNumber;
    @XmlElement(name = "OrgContactFirstName")
    protected String orgContactFirstName;
    @XmlElement(name = "OrgContactLastName")
    protected String orgContactLastName;
    @XmlElement(name = "OrgContactTitle")
    protected String orgContactTitle;
    @XmlElement(name = "OrgContactType")
    protected String orgContactType;
    @XmlElement(name = "OrgContactUID")
    protected String orgContactUID;
    @XmlElement(name = "OrgUId")
    protected String orgUId;
    @XmlElement(name = "PrimaryAppellant")
    protected String primaryAppellant;
    @XmlElement(name = "RequestorFlag")
    protected String requestorFlag;
    @XmlElement(name = "Role")
    protected String role;
    @XmlElement(name = "PartyOrgAddresses")
    protected PartyOrgAddresses partyOrgAddresses;

    /**
     * Gets the value of the appellantFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppellantFlag() {
        return appellantFlag;
    }

    /**
     * Sets the value of the appellantFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppellantFlag(String value) {
        this.appellantFlag = value;
    }

    /**
     * Gets the value of the appointedRepresentative property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppointedRepresentative() {
        return appointedRepresentative;
    }

    /**
     * Sets the value of the appointedRepresentative property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppointedRepresentative(String value) {
        this.appointedRepresentative = value;
    }

    /**
     * Gets the value of the beneficiaryFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryFirstName() {
        return beneficiaryFirstName;
    }

    /**
     * Sets the value of the beneficiaryFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryFirstName(String value) {
        this.beneficiaryFirstName = value;
    }

    /**
     * Gets the value of the beneficiaryHICNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryHICNumber() {
        return beneficiaryHICNumber;
    }

    /**
     * Sets the value of the beneficiaryHICNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryHICNumber(String value) {
        this.beneficiaryHICNumber = value;
    }

    /**
     * Gets the value of the beneficiaryLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryLastName() {
        return beneficiaryLastName;
    }

    /**
     * Sets the value of the beneficiaryLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryLastName(String value) {
        this.beneficiaryLastName = value;
    }

    /**
     * Gets the value of the legalEntityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalEntityName() {
        return legalEntityName;
    }

    /**
     * Sets the value of the legalEntityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalEntityName(String value) {
        this.legalEntityName = value;
    }

    /**
     * Gets the value of the mainEmailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainEmailAddress() {
        return mainEmailAddress;
    }

    /**
     * Sets the value of the mainEmailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainEmailAddress(String value) {
        this.mainEmailAddress = value;
    }

    /**
     * Gets the value of the mainFaxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainFaxNumber() {
        return mainFaxNumber;
    }

    /**
     * Sets the value of the mainFaxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainFaxNumber(String value) {
        this.mainFaxNumber = value;
    }

    /**
     * Gets the value of the mainPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainPhoneNumber() {
        return mainPhoneNumber;
    }

    /**
     * Sets the value of the mainPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainPhoneNumber(String value) {
        this.mainPhoneNumber = value;
    }

    /**
     * Gets the value of the orgContactFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgContactFirstName() {
        return orgContactFirstName;
    }

    /**
     * Sets the value of the orgContactFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgContactFirstName(String value) {
        this.orgContactFirstName = value;
    }

    /**
     * Gets the value of the orgContactLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgContactLastName() {
        return orgContactLastName;
    }

    /**
     * Sets the value of the orgContactLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgContactLastName(String value) {
        this.orgContactLastName = value;
    }

    /**
     * Gets the value of the orgContactTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgContactTitle() {
        return orgContactTitle;
    }

    /**
     * Sets the value of the orgContactTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgContactTitle(String value) {
        this.orgContactTitle = value;
    }

    /**
     * Gets the value of the orgContactType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgContactType() {
        return orgContactType;
    }

    /**
     * Sets the value of the orgContactType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgContactType(String value) {
        this.orgContactType = value;
    }

    /**
     * Gets the value of the orgContactUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgContactUID() {
        return orgContactUID;
    }

    /**
     * Sets the value of the orgContactUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgContactUID(String value) {
        this.orgContactUID = value;
    }

    /**
     * Gets the value of the orgUId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUId() {
        return orgUId;
    }

    /**
     * Sets the value of the orgUId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUId(String value) {
        this.orgUId = value;
    }

    /**
     * Gets the value of the primaryAppellant property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryAppellant() {
        return primaryAppellant;
    }

    /**
     * Sets the value of the primaryAppellant property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryAppellant(String value) {
        this.primaryAppellant = value;
    }

    /**
     * Gets the value of the requestorFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorFlag() {
        return requestorFlag;
    }

    /**
     * Sets the value of the requestorFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorFlag(String value) {
        this.requestorFlag = value;
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRole(String value) {
        this.role = value;
    }

    /**
     * Gets the value of the partyOrgAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link PartyOrgAddresses }
     *     
     */
    public PartyOrgAddresses getPartyOrgAddresses() {
        return partyOrgAddresses;
    }

    /**
     * Sets the value of the partyOrgAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyOrgAddresses }
     *     
     */
    public void setPartyOrgAddresses(PartyOrgAddresses value) {
        this.partyOrgAddresses = value;
    }

}
