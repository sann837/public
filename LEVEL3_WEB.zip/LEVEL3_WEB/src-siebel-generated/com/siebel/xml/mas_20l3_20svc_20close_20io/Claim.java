
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Claim complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Claim">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AdjCancelCode" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="AdmissionTime" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="AdmitDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AmendmentClaim" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneDedAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BenefitSavingsIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BenefitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COBCrossoverErrorIndicator" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="COBAIDPartner" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="CancelDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClaimAssgntCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClaimDateofServiceFrom" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimDateofServiceTo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimDescription" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string255" minOccurs="0"/>
 *         &lt;element name="ClaimNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimPaidDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoinsuranceDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContractNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="CoveredCharge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoveredDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoveredUnits" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CurrentLocation" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DischargeTime" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="LifetimeReserveDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MSPApportionIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicalRecordNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="MedicarePatientDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicareType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="NonCoveredCharge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NonCoveredDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoticeofElection" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoticeofElectionDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumberofDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OriginalAppellantType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="PaidtoBeneAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaidtoProviderAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PatientDischargedStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PatientPaidAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayerName" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="PeerReviewOrgID" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="Provider_SupplierType" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30" minOccurs="0"/>
 *         &lt;element name="SourceofAdmission" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpecialtyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalAllowedAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalOriginalAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalPaidAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeofAdmission" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeofBill" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="TypeofService" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100" minOccurs="0"/>
 *         &lt;element name="Claims_Beneficiaries" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Claims_Beneficiaries" minOccurs="0"/>
 *         &lt;element name="Claims_Providers" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Claims_Providers" minOccurs="0"/>
 *         &lt;element name="ClaimLineItems" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ClaimLineItems" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Claim", propOrder = {
    "adjCancelCode",
    "admissionTime",
    "admitDate",
    "amendmentClaim",
    "beneDedAmount",
    "benefitSavingsIndicator",
    "benefitType",
    "cobCrossoverErrorIndicator",
    "cobaidPartner",
    "cancelDate",
    "claimAssgntCode",
    "claimDateofServiceFrom",
    "claimDateofServiceTo",
    "claimDescription",
    "claimNum",
    "claimPaidDate",
    "coinsuranceDays",
    "contractNumber",
    "coveredCharge",
    "coveredDays",
    "coveredUnits",
    "currentLocation",
    "dischargeTime",
    "lifetimeReserveDays",
    "mspApportionIndicator",
    "medicalRecordNum",
    "medicarePatientDays",
    "medicareType",
    "nonCoveredCharge",
    "nonCoveredDays",
    "noticeofElection",
    "noticeofElectionDate",
    "numberofDays",
    "originalAppellantType",
    "paidtoBeneAmount",
    "paidtoProviderAmount",
    "patientDischargedStatus",
    "patientPaidAmount",
    "payerName",
    "peerReviewOrgID",
    "providerSupplierType",
    "sourceofAdmission",
    "specialtyCode",
    "totalAllowedAmount",
    "totalOriginalAmount",
    "totalPaidAmount",
    "typeofAdmission",
    "typeofBill",
    "typeofService",
    "claimsBeneficiaries",
    "claimsProviders",
    "claimLineItems"
})
public class Claim {

    @XmlElement(name = "AdjCancelCode")
    protected String adjCancelCode;
    @XmlElement(name = "AdmissionTime")
    protected String admissionTime;
    @XmlElement(name = "AdmitDate")
    protected String admitDate;
    @XmlElement(name = "AmendmentClaim")
    protected String amendmentClaim;
    @XmlElement(name = "BeneDedAmount")
    protected String beneDedAmount;
    @XmlElement(name = "BenefitSavingsIndicator")
    protected String benefitSavingsIndicator;
    @XmlElement(name = "BenefitType")
    protected String benefitType;
    @XmlElement(name = "COBCrossoverErrorIndicator")
    protected String cobCrossoverErrorIndicator;
    @XmlElement(name = "COBAIDPartner")
    protected String cobaidPartner;
    @XmlElement(name = "CancelDate")
    protected String cancelDate;
    @XmlElement(name = "ClaimAssgntCode")
    protected String claimAssgntCode;
    @XmlElement(name = "ClaimDateofServiceFrom", required = true)
    protected String claimDateofServiceFrom;
    @XmlElement(name = "ClaimDateofServiceTo", required = true)
    protected String claimDateofServiceTo;
    @XmlElement(name = "ClaimDescription")
    protected String claimDescription;
    @XmlElement(name = "ClaimNum", required = true)
    protected String claimNum;
    @XmlElement(name = "ClaimPaidDate")
    protected String claimPaidDate;
    @XmlElement(name = "CoinsuranceDays")
    protected String coinsuranceDays;
    @XmlElement(name = "ContractNumber")
    protected String contractNumber;
    @XmlElement(name = "CoveredCharge")
    protected String coveredCharge;
    @XmlElement(name = "CoveredDays")
    protected String coveredDays;
    @XmlElement(name = "CoveredUnits")
    protected String coveredUnits;
    @XmlElement(name = "CurrentLocation")
    protected String currentLocation;
    @XmlElement(name = "DischargeTime")
    protected String dischargeTime;
    @XmlElement(name = "LifetimeReserveDays")
    protected String lifetimeReserveDays;
    @XmlElement(name = "MSPApportionIndicator")
    protected String mspApportionIndicator;
    @XmlElement(name = "MedicalRecordNum")
    protected String medicalRecordNum;
    @XmlElement(name = "MedicarePatientDays")
    protected String medicarePatientDays;
    @XmlElement(name = "MedicareType")
    protected String medicareType;
    @XmlElement(name = "NonCoveredCharge")
    protected String nonCoveredCharge;
    @XmlElement(name = "NonCoveredDays")
    protected String nonCoveredDays;
    @XmlElement(name = "NoticeofElection")
    protected String noticeofElection;
    @XmlElement(name = "NoticeofElectionDate")
    protected String noticeofElectionDate;
    @XmlElement(name = "NumberofDays")
    protected String numberofDays;
    @XmlElement(name = "OriginalAppellantType")
    protected String originalAppellantType;
    @XmlElement(name = "PaidtoBeneAmount")
    protected String paidtoBeneAmount;
    @XmlElement(name = "PaidtoProviderAmount")
    protected String paidtoProviderAmount;
    @XmlElement(name = "PatientDischargedStatus")
    protected String patientDischargedStatus;
    @XmlElement(name = "PatientPaidAmount")
    protected String patientPaidAmount;
    @XmlElement(name = "PayerName")
    protected String payerName;
    @XmlElement(name = "PeerReviewOrgID")
    protected String peerReviewOrgID;
    @XmlElement(name = "Provider_SupplierType")
    protected String providerSupplierType;
    @XmlElement(name = "SourceofAdmission")
    protected String sourceofAdmission;
    @XmlElement(name = "SpecialtyCode")
    protected String specialtyCode;
    @XmlElement(name = "TotalAllowedAmount")
    protected String totalAllowedAmount;
    @XmlElement(name = "TotalOriginalAmount")
    protected String totalOriginalAmount;
    @XmlElement(name = "TotalPaidAmount")
    protected String totalPaidAmount;
    @XmlElement(name = "TypeofAdmission")
    protected String typeofAdmission;
    @XmlElement(name = "TypeofBill")
    protected String typeofBill;
    @XmlElement(name = "TypeofService")
    protected String typeofService;
    @XmlElement(name = "Claims_Beneficiaries")
    protected ClaimsBeneficiaries claimsBeneficiaries;
    @XmlElement(name = "Claims_Providers")
    protected ClaimsProviders claimsProviders;
    @XmlElement(name = "ClaimLineItems")
    protected ClaimLineItems claimLineItems;

    /**
     * Gets the value of the adjCancelCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdjCancelCode() {
        return adjCancelCode;
    }

    /**
     * Sets the value of the adjCancelCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdjCancelCode(String value) {
        this.adjCancelCode = value;
    }

    /**
     * Gets the value of the admissionTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdmissionTime() {
        return admissionTime;
    }

    /**
     * Sets the value of the admissionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdmissionTime(String value) {
        this.admissionTime = value;
    }

    /**
     * Gets the value of the admitDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdmitDate() {
        return admitDate;
    }

    /**
     * Sets the value of the admitDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdmitDate(String value) {
        this.admitDate = value;
    }

    /**
     * Gets the value of the amendmentClaim property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmendmentClaim() {
        return amendmentClaim;
    }

    /**
     * Sets the value of the amendmentClaim property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmendmentClaim(String value) {
        this.amendmentClaim = value;
    }

    /**
     * Gets the value of the beneDedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneDedAmount() {
        return beneDedAmount;
    }

    /**
     * Sets the value of the beneDedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneDedAmount(String value) {
        this.beneDedAmount = value;
    }

    /**
     * Gets the value of the benefitSavingsIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenefitSavingsIndicator() {
        return benefitSavingsIndicator;
    }

    /**
     * Sets the value of the benefitSavingsIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenefitSavingsIndicator(String value) {
        this.benefitSavingsIndicator = value;
    }

    /**
     * Gets the value of the benefitType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenefitType() {
        return benefitType;
    }

    /**
     * Sets the value of the benefitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenefitType(String value) {
        this.benefitType = value;
    }

    /**
     * Gets the value of the cobCrossoverErrorIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOBCrossoverErrorIndicator() {
        return cobCrossoverErrorIndicator;
    }

    /**
     * Sets the value of the cobCrossoverErrorIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOBCrossoverErrorIndicator(String value) {
        this.cobCrossoverErrorIndicator = value;
    }

    /**
     * Gets the value of the cobaidPartner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOBAIDPartner() {
        return cobaidPartner;
    }

    /**
     * Sets the value of the cobaidPartner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOBAIDPartner(String value) {
        this.cobaidPartner = value;
    }

    /**
     * Gets the value of the cancelDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelDate() {
        return cancelDate;
    }

    /**
     * Sets the value of the cancelDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelDate(String value) {
        this.cancelDate = value;
    }

    /**
     * Gets the value of the claimAssgntCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimAssgntCode() {
        return claimAssgntCode;
    }

    /**
     * Sets the value of the claimAssgntCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimAssgntCode(String value) {
        this.claimAssgntCode = value;
    }

    /**
     * Gets the value of the claimDateofServiceFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimDateofServiceFrom() {
        return claimDateofServiceFrom;
    }

    /**
     * Sets the value of the claimDateofServiceFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimDateofServiceFrom(String value) {
        this.claimDateofServiceFrom = value;
    }

    /**
     * Gets the value of the claimDateofServiceTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimDateofServiceTo() {
        return claimDateofServiceTo;
    }

    /**
     * Sets the value of the claimDateofServiceTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimDateofServiceTo(String value) {
        this.claimDateofServiceTo = value;
    }

    /**
     * Gets the value of the claimDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimDescription() {
        return claimDescription;
    }

    /**
     * Sets the value of the claimDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimDescription(String value) {
        this.claimDescription = value;
    }

    /**
     * Gets the value of the claimNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNum() {
        return claimNum;
    }

    /**
     * Sets the value of the claimNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNum(String value) {
        this.claimNum = value;
    }

    /**
     * Gets the value of the claimPaidDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimPaidDate() {
        return claimPaidDate;
    }

    /**
     * Sets the value of the claimPaidDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimPaidDate(String value) {
        this.claimPaidDate = value;
    }

    /**
     * Gets the value of the coinsuranceDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoinsuranceDays() {
        return coinsuranceDays;
    }

    /**
     * Sets the value of the coinsuranceDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoinsuranceDays(String value) {
        this.coinsuranceDays = value;
    }

    /**
     * Gets the value of the contractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     * Sets the value of the contractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNumber(String value) {
        this.contractNumber = value;
    }

    /**
     * Gets the value of the coveredCharge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveredCharge() {
        return coveredCharge;
    }

    /**
     * Sets the value of the coveredCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveredCharge(String value) {
        this.coveredCharge = value;
    }

    /**
     * Gets the value of the coveredDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveredDays() {
        return coveredDays;
    }

    /**
     * Sets the value of the coveredDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveredDays(String value) {
        this.coveredDays = value;
    }

    /**
     * Gets the value of the coveredUnits property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveredUnits() {
        return coveredUnits;
    }

    /**
     * Sets the value of the coveredUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveredUnits(String value) {
        this.coveredUnits = value;
    }

    /**
     * Gets the value of the currentLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentLocation() {
        return currentLocation;
    }

    /**
     * Sets the value of the currentLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentLocation(String value) {
        this.currentLocation = value;
    }

    /**
     * Gets the value of the dischargeTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDischargeTime() {
        return dischargeTime;
    }

    /**
     * Sets the value of the dischargeTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDischargeTime(String value) {
        this.dischargeTime = value;
    }

    /**
     * Gets the value of the lifetimeReserveDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifetimeReserveDays() {
        return lifetimeReserveDays;
    }

    /**
     * Sets the value of the lifetimeReserveDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifetimeReserveDays(String value) {
        this.lifetimeReserveDays = value;
    }

    /**
     * Gets the value of the mspApportionIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSPApportionIndicator() {
        return mspApportionIndicator;
    }

    /**
     * Sets the value of the mspApportionIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSPApportionIndicator(String value) {
        this.mspApportionIndicator = value;
    }

    /**
     * Gets the value of the medicalRecordNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicalRecordNum() {
        return medicalRecordNum;
    }

    /**
     * Sets the value of the medicalRecordNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicalRecordNum(String value) {
        this.medicalRecordNum = value;
    }

    /**
     * Gets the value of the medicarePatientDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePatientDays() {
        return medicarePatientDays;
    }

    /**
     * Sets the value of the medicarePatientDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePatientDays(String value) {
        this.medicarePatientDays = value;
    }

    /**
     * Gets the value of the medicareType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareType() {
        return medicareType;
    }

    /**
     * Sets the value of the medicareType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareType(String value) {
        this.medicareType = value;
    }

    /**
     * Gets the value of the nonCoveredCharge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonCoveredCharge() {
        return nonCoveredCharge;
    }

    /**
     * Sets the value of the nonCoveredCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonCoveredCharge(String value) {
        this.nonCoveredCharge = value;
    }

    /**
     * Gets the value of the nonCoveredDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNonCoveredDays() {
        return nonCoveredDays;
    }

    /**
     * Sets the value of the nonCoveredDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonCoveredDays(String value) {
        this.nonCoveredDays = value;
    }

    /**
     * Gets the value of the noticeofElection property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoticeofElection() {
        return noticeofElection;
    }

    /**
     * Sets the value of the noticeofElection property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoticeofElection(String value) {
        this.noticeofElection = value;
    }

    /**
     * Gets the value of the noticeofElectionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoticeofElectionDate() {
        return noticeofElectionDate;
    }

    /**
     * Sets the value of the noticeofElectionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoticeofElectionDate(String value) {
        this.noticeofElectionDate = value;
    }

    /**
     * Gets the value of the numberofDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumberofDays() {
        return numberofDays;
    }

    /**
     * Sets the value of the numberofDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumberofDays(String value) {
        this.numberofDays = value;
    }

    /**
     * Gets the value of the originalAppellantType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalAppellantType() {
        return originalAppellantType;
    }

    /**
     * Sets the value of the originalAppellantType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalAppellantType(String value) {
        this.originalAppellantType = value;
    }

    /**
     * Gets the value of the paidtoBeneAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaidtoBeneAmount() {
        return paidtoBeneAmount;
    }

    /**
     * Sets the value of the paidtoBeneAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaidtoBeneAmount(String value) {
        this.paidtoBeneAmount = value;
    }

    /**
     * Gets the value of the paidtoProviderAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaidtoProviderAmount() {
        return paidtoProviderAmount;
    }

    /**
     * Sets the value of the paidtoProviderAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaidtoProviderAmount(String value) {
        this.paidtoProviderAmount = value;
    }

    /**
     * Gets the value of the patientDischargedStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientDischargedStatus() {
        return patientDischargedStatus;
    }

    /**
     * Sets the value of the patientDischargedStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientDischargedStatus(String value) {
        this.patientDischargedStatus = value;
    }

    /**
     * Gets the value of the patientPaidAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientPaidAmount() {
        return patientPaidAmount;
    }

    /**
     * Sets the value of the patientPaidAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientPaidAmount(String value) {
        this.patientPaidAmount = value;
    }

    /**
     * Gets the value of the payerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayerName() {
        return payerName;
    }

    /**
     * Sets the value of the payerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayerName(String value) {
        this.payerName = value;
    }

    /**
     * Gets the value of the peerReviewOrgID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeerReviewOrgID() {
        return peerReviewOrgID;
    }

    /**
     * Sets the value of the peerReviewOrgID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeerReviewOrgID(String value) {
        this.peerReviewOrgID = value;
    }

    /**
     * Gets the value of the providerSupplierType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderSupplierType() {
        return providerSupplierType;
    }

    /**
     * Sets the value of the providerSupplierType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderSupplierType(String value) {
        this.providerSupplierType = value;
    }

    /**
     * Gets the value of the sourceofAdmission property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceofAdmission() {
        return sourceofAdmission;
    }

    /**
     * Sets the value of the sourceofAdmission property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceofAdmission(String value) {
        this.sourceofAdmission = value;
    }

    /**
     * Gets the value of the specialtyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialtyCode() {
        return specialtyCode;
    }

    /**
     * Sets the value of the specialtyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialtyCode(String value) {
        this.specialtyCode = value;
    }

    /**
     * Gets the value of the totalAllowedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalAllowedAmount() {
        return totalAllowedAmount;
    }

    /**
     * Sets the value of the totalAllowedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalAllowedAmount(String value) {
        this.totalAllowedAmount = value;
    }

    /**
     * Gets the value of the totalOriginalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalOriginalAmount() {
        return totalOriginalAmount;
    }

    /**
     * Sets the value of the totalOriginalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalOriginalAmount(String value) {
        this.totalOriginalAmount = value;
    }

    /**
     * Gets the value of the totalPaidAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalPaidAmount() {
        return totalPaidAmount;
    }

    /**
     * Sets the value of the totalPaidAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalPaidAmount(String value) {
        this.totalPaidAmount = value;
    }

    /**
     * Gets the value of the typeofAdmission property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeofAdmission() {
        return typeofAdmission;
    }

    /**
     * Sets the value of the typeofAdmission property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeofAdmission(String value) {
        this.typeofAdmission = value;
    }

    /**
     * Gets the value of the typeofBill property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeofBill() {
        return typeofBill;
    }

    /**
     * Sets the value of the typeofBill property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeofBill(String value) {
        this.typeofBill = value;
    }

    /**
     * Gets the value of the typeofService property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeofService() {
        return typeofService;
    }

    /**
     * Sets the value of the typeofService property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeofService(String value) {
        this.typeofService = value;
    }

    /**
     * Gets the value of the claimsBeneficiaries property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimsBeneficiaries }
     *     
     */
    public ClaimsBeneficiaries getClaimsBeneficiaries() {
        return claimsBeneficiaries;
    }

    /**
     * Sets the value of the claimsBeneficiaries property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimsBeneficiaries }
     *     
     */
    public void setClaimsBeneficiaries(ClaimsBeneficiaries value) {
        this.claimsBeneficiaries = value;
    }

    /**
     * Gets the value of the claimsProviders property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimsProviders }
     *     
     */
    public ClaimsProviders getClaimsProviders() {
        return claimsProviders;
    }

    /**
     * Sets the value of the claimsProviders property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimsProviders }
     *     
     */
    public void setClaimsProviders(ClaimsProviders value) {
        this.claimsProviders = value;
    }

    /**
     * Gets the value of the claimLineItems property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimLineItems }
     *     
     */
    public ClaimLineItems getClaimLineItems() {
        return claimLineItems;
    }

    /**
     * Sets the value of the claimLineItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimLineItems }
     *     
     */
    public void setClaimLineItems(ClaimLineItems value) {
        this.claimLineItems = value;
    }

}
