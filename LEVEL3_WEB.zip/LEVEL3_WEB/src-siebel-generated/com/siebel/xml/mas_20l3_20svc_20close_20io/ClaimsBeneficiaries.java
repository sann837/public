
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Claims_Beneficiaries complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Claims_Beneficiaries">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Claim_Beneficiary" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}Claim_Beneficiary"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Claims_Beneficiaries", propOrder = {
    "claimBeneficiary"
})
public class ClaimsBeneficiaries {

    @XmlElement(name = "Claim_Beneficiary", required = true)
    protected ClaimBeneficiary claimBeneficiary;

    /**
     * Gets the value of the claimBeneficiary property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimBeneficiary }
     *     
     */
    public ClaimBeneficiary getClaimBeneficiary() {
        return claimBeneficiary;
    }

    /**
     * Sets the value of the claimBeneficiary property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimBeneficiary }
     *     
     */
    public void setClaimBeneficiary(ClaimBeneficiary value) {
        this.claimBeneficiary = value;
    }

}
