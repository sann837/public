
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Hearing complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Hearing">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ActualHearingFormat" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="CancellationReason" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string40" minOccurs="0"/>
 *         &lt;element name="CompletionDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoticeofHearingMailedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *         &lt;element name="Type" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *         &lt;element name="HearingDates" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}HearingDates" minOccurs="0"/>
 *         &lt;element name="HearingOrgParticipants" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}HearingOrgParticipants" minOccurs="0"/>
 *         &lt;element name="HearingParticipants" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}HearingParticipants" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Hearing", propOrder = {
    "actualHearingFormat",
    "cancellationReason",
    "completionDate",
    "noticeofHearingMailedDate",
    "status",
    "type",
    "hearingDates",
    "hearingOrgParticipants",
    "hearingParticipants"
})
public class Hearing {

    @XmlElement(name = "ActualHearingFormat")
    protected String actualHearingFormat;
    @XmlElement(name = "CancellationReason")
    protected String cancellationReason;
    @XmlElement(name = "CompletionDate")
    protected String completionDate;
    @XmlElement(name = "NoticeofHearingMailedDate")
    protected String noticeofHearingMailedDate;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "HearingDates")
    protected HearingDates hearingDates;
    @XmlElement(name = "HearingOrgParticipants")
    protected HearingOrgParticipants hearingOrgParticipants;
    @XmlElement(name = "HearingParticipants")
    protected HearingParticipants hearingParticipants;

    /**
     * Gets the value of the actualHearingFormat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActualHearingFormat() {
        return actualHearingFormat;
    }

    /**
     * Sets the value of the actualHearingFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActualHearingFormat(String value) {
        this.actualHearingFormat = value;
    }

    /**
     * Gets the value of the cancellationReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancellationReason() {
        return cancellationReason;
    }

    /**
     * Sets the value of the cancellationReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancellationReason(String value) {
        this.cancellationReason = value;
    }

    /**
     * Gets the value of the completionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompletionDate() {
        return completionDate;
    }

    /**
     * Sets the value of the completionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompletionDate(String value) {
        this.completionDate = value;
    }

    /**
     * Gets the value of the noticeofHearingMailedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoticeofHearingMailedDate() {
        return noticeofHearingMailedDate;
    }

    /**
     * Sets the value of the noticeofHearingMailedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoticeofHearingMailedDate(String value) {
        this.noticeofHearingMailedDate = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the hearingDates property.
     * 
     * @return
     *     possible object is
     *     {@link HearingDates }
     *     
     */
    public HearingDates getHearingDates() {
        return hearingDates;
    }

    /**
     * Sets the value of the hearingDates property.
     * 
     * @param value
     *     allowed object is
     *     {@link HearingDates }
     *     
     */
    public void setHearingDates(HearingDates value) {
        this.hearingDates = value;
    }

    /**
     * Gets the value of the hearingOrgParticipants property.
     * 
     * @return
     *     possible object is
     *     {@link HearingOrgParticipants }
     *     
     */
    public HearingOrgParticipants getHearingOrgParticipants() {
        return hearingOrgParticipants;
    }

    /**
     * Sets the value of the hearingOrgParticipants property.
     * 
     * @param value
     *     allowed object is
     *     {@link HearingOrgParticipants }
     *     
     */
    public void setHearingOrgParticipants(HearingOrgParticipants value) {
        this.hearingOrgParticipants = value;
    }

    /**
     * Gets the value of the hearingParticipants property.
     * 
     * @return
     *     possible object is
     *     {@link HearingParticipants }
     *     
     */
    public HearingParticipants getHearingParticipants() {
        return hearingParticipants;
    }

    /**
     * Sets the value of the hearingParticipants property.
     * 
     * @param value
     *     allowed object is
     *     {@link HearingParticipants }
     *     
     */
    public void setHearingParticipants(HearingParticipants value) {
        this.hearingParticipants = value;
    }

}
