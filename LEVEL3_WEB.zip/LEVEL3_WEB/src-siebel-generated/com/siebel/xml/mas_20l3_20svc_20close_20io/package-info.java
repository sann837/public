@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20l3_20svc_20close_20io;
