
package com.siebel.xml.mas_20l3_20svc_20close_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Dispositions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Dispositions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClaimNum" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string30"/>
 *         &lt;element name="ContractNumber" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50"/>
 *         &lt;element name="Disposition" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string100"/>
 *         &lt;element name="Explanation" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string250" minOccurs="0"/>
 *         &lt;element name="ProceduralDecisionReason" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}string50" minOccurs="0"/>
 *         &lt;element name="ListOfDispositionLineItems" type="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ListOfDispositionLineItems" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Dispositions", propOrder = {
    "claimNum",
    "contractNumber",
    "disposition",
    "explanation",
    "proceduralDecisionReason",
    "listOfDispositionLineItems"
})
public class Dispositions {

    @XmlElement(name = "ClaimNum", required = true)
    protected String claimNum;
    @XmlElement(name = "ContractNumber", required = true)
    protected String contractNumber;
    @XmlElement(name = "Disposition", required = true)
    protected String disposition;
    @XmlElement(name = "Explanation")
    protected String explanation;
    @XmlElement(name = "ProceduralDecisionReason")
    protected String proceduralDecisionReason;
    @XmlElement(name = "ListOfDispositionLineItems")
    protected ListOfDispositionLineItems listOfDispositionLineItems;

    /**
     * Gets the value of the claimNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNum() {
        return claimNum;
    }

    /**
     * Sets the value of the claimNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNum(String value) {
        this.claimNum = value;
    }

    /**
     * Gets the value of the contractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     * Sets the value of the contractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNumber(String value) {
        this.contractNumber = value;
    }

    /**
     * Gets the value of the disposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisposition() {
        return disposition;
    }

    /**
     * Sets the value of the disposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisposition(String value) {
        this.disposition = value;
    }

    /**
     * Gets the value of the explanation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExplanation() {
        return explanation;
    }

    /**
     * Sets the value of the explanation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExplanation(String value) {
        this.explanation = value;
    }

    /**
     * Gets the value of the proceduralDecisionReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProceduralDecisionReason() {
        return proceduralDecisionReason;
    }

    /**
     * Sets the value of the proceduralDecisionReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProceduralDecisionReason(String value) {
        this.proceduralDecisionReason = value;
    }

    /**
     * Gets the value of the listOfDispositionLineItems property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDispositionLineItems }
     *     
     */
    public ListOfDispositionLineItems getListOfDispositionLineItems() {
        return listOfDispositionLineItems;
    }

    /**
     * Sets the value of the listOfDispositionLineItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDispositionLineItems }
     *     
     */
    public void setListOfDispositionLineItems(ListOfDispositionLineItems value) {
        this.listOfDispositionLineItems = value;
    }

}
