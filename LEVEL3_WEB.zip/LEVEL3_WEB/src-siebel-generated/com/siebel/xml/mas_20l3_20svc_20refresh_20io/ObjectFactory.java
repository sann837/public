
package com.siebel.xml.mas_20l3_20svc_20refresh_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l3_20svc_20refresh_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL3SvcRefreshIo_QNAME = new QName("http://www.siebel.com/xml/MAS%20L3%20Svc%20Refresh%20IO", "ListOfMasL3SvcRefreshIo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l3_20svc_20refresh_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcRefreshIo }
     * 
     */
    public ListOfMasL3SvcRefreshIo createListOfMasL3SvcRefreshIo() {
        return new ListOfMasL3SvcRefreshIo();
    }

    /**
     * Create an instance of {@link ListOfSupportMaterial }
     * 
     */
    public ListOfSupportMaterial createListOfSupportMaterial() {
        return new ListOfSupportMaterial();
    }

    /**
     * Create an instance of {@link ListOfMasL3SvcRefreshIoTopElmt }
     * 
     */
    public ListOfMasL3SvcRefreshIoTopElmt createListOfMasL3SvcRefreshIoTopElmt() {
        return new ListOfMasL3SvcRefreshIoTopElmt();
    }

    /**
     * Create an instance of {@link ListOfSupportMaterialAttachment }
     * 
     */
    public ListOfSupportMaterialAttachment createListOfSupportMaterialAttachment() {
        return new ListOfSupportMaterialAttachment();
    }

    /**
     * Create an instance of {@link SupportMaterial }
     * 
     */
    public SupportMaterial createSupportMaterial() {
        return new SupportMaterial();
    }

    /**
     * Create an instance of {@link SupportMaterialAttachment }
     * 
     */
    public SupportMaterialAttachment createSupportMaterialAttachment() {
        return new SupportMaterialAttachment();
    }

    /**
     * Create an instance of {@link EcmDocuments }
     * 
     */
    public EcmDocuments createEcmDocuments() {
        return new EcmDocuments();
    }

    /**
     * Create an instance of {@link ListOfEcmDocuments }
     * 
     */
    public ListOfEcmDocuments createListOfEcmDocuments() {
        return new ListOfEcmDocuments();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL3SvcRefreshIo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Refresh%20IO", name = "ListOfMasL3SvcRefreshIo")
    public JAXBElement<ListOfMasL3SvcRefreshIo> createListOfMasL3SvcRefreshIo(ListOfMasL3SvcRefreshIo value) {
        return new JAXBElement<ListOfMasL3SvcRefreshIo>(_ListOfMasL3SvcRefreshIo_QNAME, ListOfMasL3SvcRefreshIo.class, null, value);
    }

}
