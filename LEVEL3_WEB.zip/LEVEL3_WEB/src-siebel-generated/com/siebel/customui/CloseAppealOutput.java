
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l3_20svc_20close_20io_20output.ListOfMasL3SvcCloseIoOutput;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output}ListOfMasL3SvcCloseIoOutput"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfMasL3SvcCloseIoOutput",
    "errCode",
    "errMsg",
    "status"
})
@XmlRootElement(name = "CloseAppeal_Output")
public class CloseAppealOutput {

    @XmlElement(name = "ListOfMasL3SvcCloseIoOutput", namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO%20Output", required = true)
    protected ListOfMasL3SvcCloseIoOutput listOfMasL3SvcCloseIoOutput;
    @XmlElement(required = true)
    protected String errCode;
    @XmlElement(required = true)
    protected String errMsg;
    @XmlElement(required = true)
    protected String status;

    /**
     * Gets the value of the listOfMasL3SvcCloseIoOutput property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL3SvcCloseIoOutput }
     *     
     */
    public ListOfMasL3SvcCloseIoOutput getListOfMasL3SvcCloseIoOutput() {
        return listOfMasL3SvcCloseIoOutput;
    }

    /**
     * Sets the value of the listOfMasL3SvcCloseIoOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL3SvcCloseIoOutput }
     *     
     */
    public void setListOfMasL3SvcCloseIoOutput(ListOfMasL3SvcCloseIoOutput value) {
        this.listOfMasL3SvcCloseIoOutput = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
