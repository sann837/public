
package com.siebel.customui;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.customui package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.customui
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetNextAppealOutput }
     * 
     */
    public GetNextAppealOutput createGetNextAppealOutput() {
        return new GetNextAppealOutput();
    }

    /**
     * Create an instance of {@link SettlementIIPendOutput }
     * 
     */
    public SettlementIIPendOutput createSettlementIIPendOutput() {
        return new SettlementIIPendOutput();
    }

    /**
     * Create an instance of {@link GetAppealDocumentsOutput }
     * 
     */
    public GetAppealDocumentsOutput createGetAppealDocumentsOutput() {
        return new GetAppealDocumentsOutput();
    }

    /**
     * Create an instance of {@link GetMBDDataInput }
     * 
     */
    public GetMBDDataInput createGetMBDDataInput() {
        return new GetMBDDataInput();
    }

    /**
     * Create an instance of {@link ValidateCloseAppealOutput }
     * 
     */
    public ValidateCloseAppealOutput createValidateCloseAppealOutput() {
        return new ValidateCloseAppealOutput();
    }

    /**
     * Create an instance of {@link ReOpenAppealOutput }
     * 
     */
    public ReOpenAppealOutput createReOpenAppealOutput() {
        return new ReOpenAppealOutput();
    }

    /**
     * Create an instance of {@link SettlementIIUnPendInput }
     * 
     */
    public SettlementIIUnPendInput createSettlementIIUnPendInput() {
        return new SettlementIIUnPendInput();
    }

    /**
     * Create an instance of {@link RFHValidationInput }
     * 
     */
    public RFHValidationInput createRFHValidationInput() {
        return new RFHValidationInput();
    }

    /**
     * Create an instance of {@link SettlementIIUnEnactOutput }
     * 
     */
    public SettlementIIUnEnactOutput createSettlementIIUnEnactOutput() {
        return new SettlementIIUnEnactOutput();
    }

    /**
     * Create an instance of {@link GetTransStatusOutput }
     * 
     */
    public GetTransStatusOutput createGetTransStatusOutput() {
        return new GetTransStatusOutput();
    }

    /**
     * Create an instance of {@link SettlementIIEnactOutput }
     * 
     */
    public SettlementIIEnactOutput createSettlementIIEnactOutput() {
        return new SettlementIIEnactOutput();
    }

    /**
     * Create an instance of {@link UpdateTransactionInput }
     * 
     */
    public UpdateTransactionInput createUpdateTransactionInput() {
        return new UpdateTransactionInput();
    }

    /**
     * Create an instance of {@link PromoteValidationInput }
     * 
     */
    public PromoteValidationInput createPromoteValidationInput() {
        return new PromoteValidationInput();
    }

    /**
     * Create an instance of {@link OptStatusCtrInput }
     * 
     */
    public OptStatusCtrInput createOptStatusCtrInput() {
        return new OptStatusCtrInput();
    }

    /**
     * Create an instance of {@link DataMigrationValidationInput }
     * 
     */
    public DataMigrationValidationInput createDataMigrationValidationInput() {
        return new DataMigrationValidationInput();
    }

    /**
     * Create an instance of {@link RefreshValidationOutput }
     * 
     */
    public RefreshValidationOutput createRefreshValidationOutput() {
        return new RefreshValidationOutput();
    }

    /**
     * Create an instance of {@link GetNextDMAppealInput }
     * 
     */
    public GetNextDMAppealInput createGetNextDMAppealInput() {
        return new GetNextDMAppealInput();
    }

    /**
     * Create an instance of {@link SettlementIIUnEnactInput }
     * 
     */
    public SettlementIIUnEnactInput createSettlementIIUnEnactInput() {
        return new SettlementIIUnEnactInput();
    }

    /**
     * Create an instance of {@link GetDocAttachmentOutput }
     * 
     */
    public GetDocAttachmentOutput createGetDocAttachmentOutput() {
        return new GetDocAttachmentOutput();
    }

    /**
     * Create an instance of {@link GetMBDDataOutput }
     * 
     */
    public GetMBDDataOutput createGetMBDDataOutput() {
        return new GetMBDDataOutput();
    }

    /**
     * Create an instance of {@link GetAppealDocumentsInput }
     * 
     */
    public GetAppealDocumentsInput createGetAppealDocumentsInput() {
        return new GetAppealDocumentsInput();
    }

    /**
     * Create an instance of {@link RefreshValidationInput }
     * 
     */
    public RefreshValidationInput createRefreshValidationInput() {
        return new RefreshValidationInput();
    }

    /**
     * Create an instance of {@link CloseECMDocumentsOutput }
     * 
     */
    public CloseECMDocumentsOutput createCloseECMDocumentsOutput() {
        return new CloseECMDocumentsOutput();
    }

    /**
     * Create an instance of {@link ReOpenValidationInput }
     * 
     */
    public ReOpenValidationInput createReOpenValidationInput() {
        return new ReOpenValidationInput();
    }

    /**
     * Create an instance of {@link GetCMLoginDetailsInput }
     * 
     */
    public GetCMLoginDetailsInput createGetCMLoginDetailsInput() {
        return new GetCMLoginDetailsInput();
    }

    /**
     * Create an instance of {@link OptStatusCtrOutput }
     * 
     */
    public OptStatusCtrOutput createOptStatusCtrOutput() {
        return new OptStatusCtrOutput();
    }

    /**
     * Create an instance of {@link DeleteAppealOutput }
     * 
     */
    public DeleteAppealOutput createDeleteAppealOutput() {
        return new DeleteAppealOutput();
    }

    /**
     * Create an instance of {@link GetCMLoginDetailsOutput }
     * 
     */
    public GetCMLoginDetailsOutput createGetCMLoginDetailsOutput() {
        return new GetCMLoginDetailsOutput();
    }

    /**
     * Create an instance of {@link UnPromoteAppealOutput }
     * 
     */
    public UnPromoteAppealOutput createUnPromoteAppealOutput() {
        return new UnPromoteAppealOutput();
    }

    /**
     * Create an instance of {@link SettlementIIEnactInput }
     * 
     */
    public SettlementIIEnactInput createSettlementIIEnactInput() {
        return new SettlementIIEnactInput();
    }

    /**
     * Create an instance of {@link CloseECMDocumentsInput }
     * 
     */
    public CloseECMDocumentsInput createCloseECMDocumentsInput() {
        return new CloseECMDocumentsInput();
    }

    /**
     * Create an instance of {@link GetTransStatusInput }
     * 
     */
    public GetTransStatusInput createGetTransStatusInput() {
        return new GetTransStatusInput();
    }

    /**
     * Create an instance of {@link GetDocAttachmentInput }
     * 
     */
    public GetDocAttachmentInput createGetDocAttachmentInput() {
        return new GetDocAttachmentInput();
    }

    /**
     * Create an instance of {@link RefreshAppealInput }
     * 
     */
    public RefreshAppealInput createRefreshAppealInput() {
        return new RefreshAppealInput();
    }

    /**
     * Create an instance of {@link RefreshAppealOutput }
     * 
     */
    public RefreshAppealOutput createRefreshAppealOutput() {
        return new RefreshAppealOutput();
    }

    /**
     * Create an instance of {@link ReOpenAppealInput }
     * 
     */
    public ReOpenAppealInput createReOpenAppealInput() {
        return new ReOpenAppealInput();
    }

    /**
     * Create an instance of {@link CloseAppealOutput }
     * 
     */
    public CloseAppealOutput createCloseAppealOutput() {
        return new CloseAppealOutput();
    }

    /**
     * Create an instance of {@link GetJavaRestartFlagOutput }
     * 
     */
    public GetJavaRestartFlagOutput createGetJavaRestartFlagOutput() {
        return new GetJavaRestartFlagOutput();
    }

    /**
     * Create an instance of {@link SettlementIIPendInput }
     * 
     */
    public SettlementIIPendInput createSettlementIIPendInput() {
        return new SettlementIIPendInput();
    }

    /**
     * Create an instance of {@link GetNextDMAppealOutput }
     * 
     */
    public GetNextDMAppealOutput createGetNextDMAppealOutput() {
        return new GetNextDMAppealOutput();
    }

    /**
     * Create an instance of {@link UnPromoteAppealInput }
     * 
     */
    public UnPromoteAppealInput createUnPromoteAppealInput() {
        return new UnPromoteAppealInput();
    }

    /**
     * Create an instance of {@link DataMigrationValidationOutput }
     * 
     */
    public DataMigrationValidationOutput createDataMigrationValidationOutput() {
        return new DataMigrationValidationOutput();
    }

    /**
     * Create an instance of {@link GetNextAppealInput }
     * 
     */
    public GetNextAppealInput createGetNextAppealInput() {
        return new GetNextAppealInput();
    }

    /**
     * Create an instance of {@link DeleteAppealInput }
     * 
     */
    public DeleteAppealInput createDeleteAppealInput() {
        return new DeleteAppealInput();
    }

    /**
     * Create an instance of {@link PromoteValidationOutput }
     * 
     */
    public PromoteValidationOutput createPromoteValidationOutput() {
        return new PromoteValidationOutput();
    }

    /**
     * Create an instance of {@link ReOpenValidationOutput }
     * 
     */
    public ReOpenValidationOutput createReOpenValidationOutput() {
        return new ReOpenValidationOutput();
    }

    /**
     * Create an instance of {@link UpdateTransactionOutput }
     * 
     */
    public UpdateTransactionOutput createUpdateTransactionOutput() {
        return new UpdateTransactionOutput();
    }

    /**
     * Create an instance of {@link GetJavaRestartFlagInput }
     * 
     */
    public GetJavaRestartFlagInput createGetJavaRestartFlagInput() {
        return new GetJavaRestartFlagInput();
    }

    /**
     * Create an instance of {@link CloseAppealInput }
     * 
     */
    public CloseAppealInput createCloseAppealInput() {
        return new CloseAppealInput();
    }

    /**
     * Create an instance of {@link SettlementIIUnPendOutput }
     * 
     */
    public SettlementIIUnPendOutput createSettlementIIUnPendOutput() {
        return new SettlementIIUnPendOutput();
    }

    /**
     * Create an instance of {@link RFHValidationOutput }
     * 
     */
    public RFHValidationOutput createRFHValidationOutput() {
        return new RFHValidationOutput();
    }

    /**
     * Create an instance of {@link CheckConsumerInfoOutput }
     * 
     */
    public CheckConsumerInfoOutput createCheckConsumerInfoOutput() {
        return new CheckConsumerInfoOutput();
    }

    /**
     * Create an instance of {@link CheckConsumerInfoInput }
     * 
     */
    public CheckConsumerInfoInput createCheckConsumerInfoInput() {
        return new CheckConsumerInfoInput();
    }

    /**
     * Create an instance of {@link ValidateCloseAppealInput }
     * 
     */
    public ValidateCloseAppealInput createValidateCloseAppealInput() {
        return new ValidateCloseAppealInput();
    }

}
