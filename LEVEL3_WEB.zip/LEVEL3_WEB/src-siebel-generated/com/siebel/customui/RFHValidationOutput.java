
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="appealNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="appealDisposition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appealStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appealDLMDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appealL3Number" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="appealMedType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="claimNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="claimStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="claimEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="claimBeneIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beneFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beneLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beneHICNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beneMBI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="providerNPI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="providerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "appealNumber",
    "appealDisposition",
    "appealStatus",
    "appealDLMDate",
    "appealL3Number",
    "appealMedType",
    "claimNumber",
    "claimStartDate",
    "claimEndDate",
    "claimBeneIndicator",
    "beneFirstName",
    "beneLastName",
    "beneHICNumber",
    "beneMBI",
    "providerNPI",
    "providerName",
    "transId",
    "errCode",
    "errMsg"
})
@XmlRootElement(name = "RFHValidation_Output")
public class RFHValidationOutput {

    @XmlElement(required = true)
    protected String appealNumber;
    protected String appealDisposition;
    protected String appealStatus;
    protected String appealDLMDate;
    protected String appealL3Number;
    protected String appealMedType;
    protected String claimNumber;
    protected String claimStartDate;
    protected String claimEndDate;
    protected String claimBeneIndicator;
    protected String beneFirstName;
    protected String beneLastName;
    protected String beneHICNumber;
    protected String beneMBI;
    protected String providerNPI;
    protected String providerName;
    @XmlElement(required = true)
    protected String transId;
    protected String errCode;
    protected String errMsg;

    /**
     * Gets the value of the appealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNumber() {
        return appealNumber;
    }

    /**
     * Sets the value of the appealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNumber(String value) {
        this.appealNumber = value;
    }

    /**
     * Gets the value of the appealDisposition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealDisposition() {
        return appealDisposition;
    }

    /**
     * Sets the value of the appealDisposition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealDisposition(String value) {
        this.appealDisposition = value;
    }

    /**
     * Gets the value of the appealStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealStatus() {
        return appealStatus;
    }

    /**
     * Sets the value of the appealStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealStatus(String value) {
        this.appealStatus = value;
    }

    /**
     * Gets the value of the appealDLMDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealDLMDate() {
        return appealDLMDate;
    }

    /**
     * Sets the value of the appealDLMDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealDLMDate(String value) {
        this.appealDLMDate = value;
    }

    /**
     * Gets the value of the appealL3Number property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealL3Number() {
        return appealL3Number;
    }

    /**
     * Sets the value of the appealL3Number property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealL3Number(String value) {
        this.appealL3Number = value;
    }

    /**
     * Gets the value of the appealMedType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealMedType() {
        return appealMedType;
    }

    /**
     * Sets the value of the appealMedType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealMedType(String value) {
        this.appealMedType = value;
    }

    /**
     * Gets the value of the claimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the claimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNumber(String value) {
        this.claimNumber = value;
    }

    /**
     * Gets the value of the claimStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimStartDate() {
        return claimStartDate;
    }

    /**
     * Sets the value of the claimStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimStartDate(String value) {
        this.claimStartDate = value;
    }

    /**
     * Gets the value of the claimEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimEndDate() {
        return claimEndDate;
    }

    /**
     * Sets the value of the claimEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimEndDate(String value) {
        this.claimEndDate = value;
    }

    /**
     * Gets the value of the claimBeneIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimBeneIndicator() {
        return claimBeneIndicator;
    }

    /**
     * Sets the value of the claimBeneIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimBeneIndicator(String value) {
        this.claimBeneIndicator = value;
    }

    /**
     * Gets the value of the beneFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneFirstName() {
        return beneFirstName;
    }

    /**
     * Sets the value of the beneFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneFirstName(String value) {
        this.beneFirstName = value;
    }

    /**
     * Gets the value of the beneLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneLastName() {
        return beneLastName;
    }

    /**
     * Sets the value of the beneLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneLastName(String value) {
        this.beneLastName = value;
    }

    /**
     * Gets the value of the beneHICNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneHICNumber() {
        return beneHICNumber;
    }

    /**
     * Sets the value of the beneHICNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneHICNumber(String value) {
        this.beneHICNumber = value;
    }

    /**
     * Gets the value of the beneMBI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneMBI() {
        return beneMBI;
    }

    /**
     * Sets the value of the beneMBI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneMBI(String value) {
        this.beneMBI = value;
    }

    /**
     * Gets the value of the providerNPI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNPI() {
        return providerNPI;
    }

    /**
     * Sets the value of the providerNPI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNPI(String value) {
        this.providerNPI = value;
    }

    /**
     * Gets the value of the providerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * Sets the value of the providerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderName(String value) {
        this.providerName = value;
    }

    /**
     * Gets the value of the transId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransId() {
        return transId;
    }

    /**
     * Sets the value of the transId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransId(String value) {
        this.transId = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

}
