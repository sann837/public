
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfDMDocumentsIO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents}ListOfDMDocumentsIO" minOccurs="0"/>
 *         &lt;element name="TransactionOperation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UniqueId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfDMDocumentsIO",
    "transactionOperation",
    "uniqueId",
    "errCode",
    "errMsg"
})
@XmlRootElement(name = "GetNextDMAppeal_Output")
public class GetNextDMAppealOutput {

    @XmlElement(name = "ListOfDMDocumentsIO", namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20DM%20ECM%20Documents")
    protected ListOfDMDocumentsIO listOfDMDocumentsIO;
    @XmlElement(name = "TransactionOperation", required = true)
    protected String transactionOperation;
    @XmlElement(name = "UniqueId", required = true)
    protected String uniqueId;
    @XmlElement(required = true)
    protected String errCode;
    @XmlElement(required = true)
    protected String errMsg;

    /**
     * Gets the value of the listOfDMDocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDMDocumentsIO }
     *     
     */
    public ListOfDMDocumentsIO getListOfDMDocumentsIO() {
        return listOfDMDocumentsIO;
    }

    /**
     * Sets the value of the listOfDMDocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDMDocumentsIO }
     *     
     */
    public void setListOfDMDocumentsIO(ListOfDMDocumentsIO value) {
        this.listOfDMDocumentsIO = value;
    }

    /**
     * Gets the value of the transactionOperation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionOperation() {
        return transactionOperation;
    }

    /**
     * Sets the value of the transactionOperation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionOperation(String value) {
        this.transactionOperation = value;
    }

    /**
     * Gets the value of the uniqueId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueId() {
        return uniqueId;
    }

    /**
     * Sets the value of the uniqueId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueId(String value) {
        this.uniqueId = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

}
