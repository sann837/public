
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l3_20svc_20close_20io.ListOfMasL3SvcCloseIo;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO}ListOfMasL3SvcCloseIo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfMasL3SvcCloseIo"
})
@XmlRootElement(name = "CloseAppeal_Input")
public class CloseAppealInput {

    @XmlElement(name = "ListOfMasL3SvcCloseIo", namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Close%20IO", required = true)
    protected ListOfMasL3SvcCloseIo listOfMasL3SvcCloseIo;

    /**
     * Gets the value of the listOfMasL3SvcCloseIo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL3SvcCloseIo }
     *     
     */
    public ListOfMasL3SvcCloseIo getListOfMasL3SvcCloseIo() {
        return listOfMasL3SvcCloseIo;
    }

    /**
     * Sets the value of the listOfMasL3SvcCloseIo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL3SvcCloseIo }
     *     
     */
    public void setListOfMasL3SvcCloseIo(ListOfMasL3SvcCloseIo value) {
        this.listOfMasL3SvcCloseIo = value;
    }

}
