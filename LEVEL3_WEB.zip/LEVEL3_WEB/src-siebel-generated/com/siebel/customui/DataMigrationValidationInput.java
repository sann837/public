
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.masl3_20data_20migration_20appeals.ListOfAppeal;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{http://www.siebel.com/xml/MASL3%20Data%20Migration%20Appeals}ListOfAppeal"/>
 *         &lt;element name="publicKey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "consumerId",
    "listOfAppeal",
    "publicKey",
    "transId"
})
@XmlRootElement(name = "DataMigrationValidation_Input")
public class DataMigrationValidationInput {

    @XmlElement(required = true)
    protected String consumerId;
    @XmlElement(name = "ListOfAppeal", namespace = "http://www.siebel.com/xml/MASL3%20Data%20Migration%20Appeals", required = true)
    protected ListOfAppeal listOfAppeal;
    @XmlElement(required = true)
    protected String publicKey;
    @XmlElement(required = true)
    protected String transId;

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the listOfAppeal property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfAppeal }
     *     
     */
    public ListOfAppeal getListOfAppeal() {
        return listOfAppeal;
    }

    /**
     * Sets the value of the listOfAppeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfAppeal }
     *     
     */
    public void setListOfAppeal(ListOfAppeal value) {
        this.listOfAppeal = value;
    }

    /**
     * Gets the value of the publicKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicKey() {
        return publicKey;
    }

    /**
     * Sets the value of the publicKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicKey(String value) {
        this.publicKey = value;
    }

    /**
     * Gets the value of the transId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransId() {
        return transId;
    }

    /**
     * Sets the value of the transId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransId(String value) {
        this.transId = value;
    }

}
