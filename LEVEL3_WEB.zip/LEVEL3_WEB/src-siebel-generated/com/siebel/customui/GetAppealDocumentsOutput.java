
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l3_20svc_20smoke_20test_20ecm_20documents_20io.ListOfDocumentsIO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L3%20Svc%20Smoke%20Test%20ECM%20Documents%20IO}ListOfDocumentsIO" minOccurs="0"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfDocumentsIO",
    "errCode",
    "errMsg",
    "status"
})
@XmlRootElement(name = "GetAppealDocuments_Output")
public class GetAppealDocumentsOutput {

    @XmlElement(name = "ListOfDocumentsIO", namespace = "http://www.siebel.com/xml/MAS%20L3%20Svc%20Smoke%20Test%20ECM%20Documents%20IO")
    protected ListOfDocumentsIO listOfDocumentsIO;
    @XmlElement(required = true)
    protected String errCode;
    @XmlElement(required = true)
    protected String errMsg;
    @XmlElement(required = true)
    protected String status;

    /**
     * Gets the value of the listOfDocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfDocumentsIO }
     *     
     */
    public ListOfDocumentsIO getListOfDocumentsIO() {
        return listOfDocumentsIO;
    }

    /**
     * Sets the value of the listOfDocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfDocumentsIO }
     *     
     */
    public void setListOfDocumentsIO(ListOfDocumentsIO value) {
        this.listOfDocumentsIO = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
