
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sAttachmentId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DMappealNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sAttachmentId",
    "dMappealNum",
    "transId"
})
@XmlRootElement(name = "GetDocAttachment_Input")
public class GetDocAttachmentInput {

    @XmlElement(required = true)
    protected String sAttachmentId;
    @XmlElement(name = "DMappealNum")
    protected String dMappealNum;
    @XmlElement(required = true)
    protected String transId;

    /**
     * Gets the value of the sAttachmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAttachmentId() {
        return sAttachmentId;
    }

    /**
     * Sets the value of the sAttachmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAttachmentId(String value) {
        this.sAttachmentId = value;
    }

    /**
     * Gets the value of the dMappealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDMappealNum() {
        return dMappealNum;
    }

    /**
     * Sets the value of the dMappealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDMappealNum(String value) {
        this.dMappealNum = value;
    }

    /**
     * Gets the value of the transId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransId() {
        return transId;
    }

    /**
     * Sets the value of the transId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransId(String value) {
        this.transId = value;
    }

}
