
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ReopenReason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ReopeningPartyType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="publicKey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="extAppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "appealNum",
    "reopenReason",
    "consumerId",
    "reopeningPartyType",
    "publicKey",
    "extAppealNum",
    "transId"
})
@XmlRootElement(name = "ReOpenValidation_Input")
public class ReOpenValidationInput {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "ReopenReason", required = true)
    protected String reopenReason;
    @XmlElement(required = true)
    protected String consumerId;
    @XmlElement(name = "ReopeningPartyType", required = true)
    protected String reopeningPartyType;
    @XmlElement(required = true)
    protected String publicKey;
    @XmlElement(required = true)
    protected String extAppealNum;
    @XmlElement(required = true)
    protected String transId;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the reopenReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenReason() {
        return reopenReason;
    }

    /**
     * Sets the value of the reopenReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenReason(String value) {
        this.reopenReason = value;
    }

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the reopeningPartyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopeningPartyType() {
        return reopeningPartyType;
    }

    /**
     * Sets the value of the reopeningPartyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopeningPartyType(String value) {
        this.reopeningPartyType = value;
    }

    /**
     * Gets the value of the publicKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicKey() {
        return publicKey;
    }

    /**
     * Sets the value of the publicKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicKey(String value) {
        this.publicKey = value;
    }

    /**
     * Gets the value of the extAppealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtAppealNum() {
        return extAppealNum;
    }

    /**
     * Sets the value of the extAppealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtAppealNum(String value) {
        this.extAppealNum = value;
    }

    /**
     * Gets the value of the transId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransId() {
        return transId;
    }

    /**
     * Sets the value of the transId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransId(String value) {
        this.transId = value;
    }

}
