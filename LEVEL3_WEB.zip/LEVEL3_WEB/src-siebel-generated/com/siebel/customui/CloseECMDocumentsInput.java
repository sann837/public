
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ListOfMasL3SvcCloseEcmIo;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO}ListOfMasL3SvcCloseEcmIo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfMasL3SvcCloseEcmIo"
})
@XmlRootElement(name = "CloseECMDocuments_Input")
public class CloseECMDocumentsInput {

    @XmlElement(name = "ListOfMasL3SvcCloseEcmIo", namespace = "http://www.siebel.com/xml/MAS%20BO%20L3%20Close%20ECM%20IO", required = true)
    protected ListOfMasL3SvcCloseEcmIo listOfMasL3SvcCloseEcmIo;

    /**
     * Gets the value of the listOfMasL3SvcCloseEcmIo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL3SvcCloseEcmIo }
     *     
     */
    public ListOfMasL3SvcCloseEcmIo getListOfMasL3SvcCloseEcmIo() {
        return listOfMasL3SvcCloseEcmIo;
    }

    /**
     * Sets the value of the listOfMasL3SvcCloseEcmIo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL3SvcCloseEcmIo }
     *     
     */
    public void setListOfMasL3SvcCloseEcmIo(ListOfMasL3SvcCloseEcmIo value) {
        this.listOfMasL3SvcCloseEcmIo = value;
    }

}
