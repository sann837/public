package com.cgi.mas.provider;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ConstantConfig {
	private String ecmServerName;
	private String ecmServerType;
 
	private String tempFileLocation; 
	private String eftLocation; 
	private String incomingEftLocation; 
	
	private String siebelAppealUrl;
	
	private String siebelWSAddress;	
	private String siebelUserName;
	private String siebelPassWord;	
	
	private String closeAppealXsdPath;
	
	private String keystorePassword;
	private String keyAlias;
	private String keystoreName;
	private String keyPassword;
	
	private String eftFilePrefix;
	private String eftOrgName;
	
	private long totalJVMs;
	private long thisJVMid;
	
	private long siebelWsConnectTimeout;
	private long siebelWsRespondTimeout;
	
	private long closeAppealWsRespondTimeout;
	
	private int httpWsConnectTimeout;
	private int httpWsRespondTimeout;
 
	private HashMap<String,String> mimeType;
	
	private Map<String,String> docAuditCode;
 
	private boolean extraLogging = false;
	private boolean performanceLogging = true;
	
	
	private int stopAfterFailedAppeals;
	private int stopAfterFailedInterfaceCalls;
	private int resetFailedInterfaceCallsAfter;
	
	private String siebelLevel1DocCategory;
	private String siebelLevel2DocCategory;
	private String siebelLevel3DocCategory;
	private String level1;
	private String level2;
	private String level3;
	private String ecmDocTypeLevel1Code;
	private String ecmDocTypeLevel2Code;
	private String ecmDocTypeLevel3Code;
	
	private String level3ItemType;
	
	private String tibcoTimeStampRegEx;
	private List<String> prefixTIBCOName;
	
	private String fileprefixName;
		
	private int delayTransfer;
	
	private String eftClosePrefix;
	private String eftCloseOrgName;
	
	private String eftPostClosePrefix;
	private String eftPostCloseOrgName;
	private String eftPostCloseIncomingPrefix;
	
	private String eftPostCloseOutboundFilePrefix;
	private String eftCloseOutboundFilePrefix;
	
	private String eftPromoteFilePrefix;
	private String eftReOpenFilePrefix;
	private String eftRefreshFilePrefix;
	
	private long expiredDay;
	private long irmaaExpiredDay;
	
	private String eftIRMAAAppealFilePath;
	private String eftIRMAAAppealFilePrefix;
	
	private String eftDataMigrationFilePrefix;
	
	private String settlementInFilePrefix;
	private String settlementOutFilePrefix;
	private int maxAppealsPerSettlementFile;
 
	public long getExpiredDay() {
		return expiredDay;
	}
	public void setExpiredDay(long expiredDay) {
		this.expiredDay = expiredDay;
	}
	
	public String getCloseAppealXsdPath() {
		return closeAppealXsdPath;
	}
	public void setCloseAppealXsdPath(String closeAppealXsdPath) {
		this.closeAppealXsdPath = closeAppealXsdPath;
	}
		
	 
	
	public String getSettlementInFilePrefix() {
		return settlementInFilePrefix;
	}
	public void setSettlementInFilePrefix(String settlementInFilePrefix) {
		this.settlementInFilePrefix = settlementInFilePrefix;
	}
	
	public String getSettlementOutFilePrefix() {
		return settlementOutFilePrefix;
	}
	public void setSettlementOutFilePrefix(String settlementOutFilePrefix) {
		this.settlementOutFilePrefix = settlementOutFilePrefix;
	}
	
	
	public String getEftCloseOrgName() {
		return eftCloseOrgName;
	}
	public void setEftCloseOrgName(String eftCloseOrgName) {
		this.eftCloseOrgName = eftCloseOrgName;
	}
		
	public String getEftPostCloseIncomingPrefix() {
		return eftPostCloseIncomingPrefix;
	}
	public void setEftPostCloseIncomingPrefix(String eftPostCloseIncomingPrefix) {
		this.eftPostCloseIncomingPrefix = eftPostCloseIncomingPrefix;
	}
	
	public String getEftPostCloseOrgName() {
		return eftPostCloseOrgName;
	}
	public void setEftPostCloseOrgName(String eftPostCloseOrgName) {
		this.eftPostCloseOrgName = eftPostCloseOrgName;
	}
	
	
	public int getMaxAppealsPerSettlementFile() {
		return maxAppealsPerSettlementFile;
	}
	public void setMaxAppealsPerSettlementFile(int maxAppealsPerSettlementFile) {
		this.maxAppealsPerSettlementFile = maxAppealsPerSettlementFile;
	}
	
	
	public int getStopAfterFailedAppeals() {
		return stopAfterFailedAppeals;
	}
	public void setStopAfterFailedAppeals(int stopAfterFailedAppeals) {
		this.stopAfterFailedAppeals = stopAfterFailedAppeals;
	}
	
	public int getStopAfterFailedInterfaceCalls() {
		return stopAfterFailedInterfaceCalls;
	}
	public void setStopAfterFailedInterfaceCalls(int stopAfterFailedInterfaceCalls) {
		this.stopAfterFailedInterfaceCalls = stopAfterFailedInterfaceCalls;
	}
	
	public int getResetFailedInterfaceCallsAfter() {
		return resetFailedInterfaceCallsAfter;
	}
	public void setResetFailedInterfaceCallsAfter(int resetFailedInterfaceCallsAfter) {
		this.resetFailedInterfaceCallsAfter = resetFailedInterfaceCallsAfter;
	}
	
	
	
	public String getEftFilePrefix() {
		return eftFilePrefix;
	}
	public void setEftFilePrefix(String eftFilePrefix) {
		this.eftFilePrefix = eftFilePrefix;
	}
	
	public String getEftOrgName() {
		return eftOrgName;
	}
	public void setEftOrgName(String eftOrgName) {
		this.eftOrgName = eftOrgName;
	}
	
	public int getHttpWsConnectTimeout() {
		return httpWsConnectTimeout;
	}
	public void setHttpWsConnectTimeout(int httpWsConnectTimeout) {
		this.httpWsConnectTimeout = httpWsConnectTimeout;
	}

	public int getHttpWsRespondTimeout() {
		return httpWsRespondTimeout;
	}
	public void setHttpWsRespondTimeout(int httpWsRespondTimeout) {
		this.httpWsRespondTimeout = httpWsRespondTimeout;
	}
	
	public long getSiebelWsConnectTimeout() {
		return siebelWsConnectTimeout;
	}
	public void setSiebelWsConnectTimeout(long siebelWsConnectTimeout) {
		this.siebelWsConnectTimeout = siebelWsConnectTimeout;
	}
	
	public long getSiebelWsRespondTimeout() {
		return siebelWsRespondTimeout;
	}
	public void setSiebelWsRespondTimeout(long siebelWsRespondTimeout) {
		this.siebelWsRespondTimeout = siebelWsRespondTimeout;
	}
	
	public long getCloseAppealWsRespondTimeout() {
		return closeAppealWsRespondTimeout;
	}
	public void setCloseAppealWsRespondTimeout(long closeAppealWsRespondTimeout) {
		this.closeAppealWsRespondTimeout = closeAppealWsRespondTimeout;
	}
	
	public String getKeyPassword() {
		return keyPassword;
	}
	public void setKeyPassword(String keyPassword) {
		this.keyPassword = keyPassword;
	}
	
	
	public String getKeystorePassword() {
		return keystorePassword;
	}
	public void setKeystorePassword(String keystorePassword) {
		this.keystorePassword = keystorePassword;
	}
	
	public String getKeyAlias() {
		return keyAlias;
	}
	public void setKeyAlias(String keyAlias) {
		this.keyAlias = keyAlias;
	}
	
	public String getKeystoreName() {
		return keystoreName;
	}
	public void setKeystoreName(String keystoreName) {
		this.keystoreName = keystoreName;
	}
	
 
	
	
	public String getSiebelUserName() {
		return siebelUserName;
	}
	public void setSiebelUserName(String siebelUserName) {
		this.siebelUserName = siebelUserName;
	}
	public String getSiebelPassWord() {
		return siebelPassWord;
	}
	public void setSiebelPassWord(String siebelPassWord) {
		this.siebelPassWord = siebelPassWord;
	}
	public String getSiebelWSAddress() {
		return siebelWSAddress;
	}
	public void setSiebelWSAddress(String siebelWSAddress) {
		this.siebelWSAddress = siebelWSAddress;
	}
 
 
	public long getTotalJVMs() {
		return totalJVMs;
	}
	public void setTotalJVMs(long totalJVMs) {
		this.totalJVMs = totalJVMs;
	}
	
	public long getThisJVMid() {
		return thisJVMid;
	}
	public void setThisJVMid(long thisJVMid) {
		this.thisJVMid = thisJVMid;
	}
	
	public String getSiebelAppealUrl() {
		return siebelAppealUrl;
	}
	public void setSiebelAppealUrl(String siebelAppealUrl) {
		this.siebelAppealUrl = siebelAppealUrl;
	}
	
	public String getTempFileLocation() {
		return tempFileLocation;
	}
	public void setTempFileLocation(String tempFileLocation) {
		this.tempFileLocation = tempFileLocation;
	}
	
	public String getEftLocation() {
		return eftLocation;
	}
	public void setEftLocation(String eftLocation) {
		this.eftLocation = eftLocation;
	}
	
	public String getIncomingEftLocation() {
		return incomingEftLocation;
	}
	public void setIncomingEftLocation(String incomingEftLocation) {
		this.incomingEftLocation = incomingEftLocation;
	}
	 
	public String getEcmServerName() {
		return ecmServerName;
	}
	public void setEcmServerName(String ecmServerName) {
		this.ecmServerName = ecmServerName;
	}
	public String getEcmServerType() {
		return ecmServerType;
	}
	public void setEcmServerType(String ecmServerType) {
		this.ecmServerType = ecmServerType;
	}
	public void setExtraLogging(boolean extraLogging) {
		this.extraLogging = extraLogging;
	}
	public boolean isExtraLogging() {
		return extraLogging;
	}
	public void setPerformanceLogging(boolean performanceLogging) {
		this.performanceLogging = performanceLogging;
	}
	public boolean isPerformanceLogging() {
		return performanceLogging;
	}
	 
	
	
	public HashMap<String, String> getMimeType() {
		return mimeType;
	}
	public void setMimeType(HashMap<String, String> mimeType) {
		this.mimeType = mimeType;
	}
	
	
	public String getSiebelLevel1DocCategory() {
		return siebelLevel1DocCategory;
	}
	public void setSiebelLevel1DocCategory(String siebelLevel1DocCategory) {
		this.siebelLevel1DocCategory = siebelLevel1DocCategory;
	}
	public String getSiebelLevel2DocCategory() {
		return siebelLevel2DocCategory;
	}
	public void setSiebelLevel2DocCategory(String siebelLevel2DocCategory) {
		this.siebelLevel2DocCategory = siebelLevel2DocCategory;
	}	
	public String getSiebelLevel3DocCategory() {
		return siebelLevel3DocCategory;
	}
	public void setSiebelLevel3DocCategory(String siebelLevel3DocCategory) {
		this.siebelLevel3DocCategory = siebelLevel3DocCategory;
	}
	public String getLevel1() {
		return level1;
	}
	public void setLevel1(String level1) {
		this.level1 = level1;
	}
	public String getLevel2() {
		return level2;
	}
	public void setLevel2(String level2) {
		this.level2 = level2;
	}	
	public String getLevel3() {
		return level3;
	}
	public void setLevel3(String level3) {
		this.level3 = level3;
	}
	public String getEcmDocTypeLevel1Code() {
		return ecmDocTypeLevel1Code;
	}
	public void setEcmDocTypeLevel1Code(String ecmDocTypeLevel1Code) {
		this.ecmDocTypeLevel1Code = ecmDocTypeLevel1Code;
	}
	public String getEcmDocTypeLevel2Code() {
		return ecmDocTypeLevel2Code;
	}
	public void setEcmDocTypeLevel2Code(String ecmDocTypeLevel2Code) {
		this.ecmDocTypeLevel2Code = ecmDocTypeLevel2Code;
	}	
	public String getEcmDocTypeLevel3Code() {
		return ecmDocTypeLevel3Code;
	}
	public void setEcmDocTypeLevel3Code(String ecmDocTypeLevel3Code) {
		this.ecmDocTypeLevel3Code = ecmDocTypeLevel3Code;
	}
	
	public Map<String, String> getDocAuditCode() {
		return docAuditCode;
	}
	public void setDocAuditCode(Map<String, String> docAuditCode) {
		this.docAuditCode = docAuditCode;
	}
	
	public String getLevel3ItemType() {
		return level3ItemType;
	}
	public void setLevel3ItemType(String level3ItemType) {
		this.level3ItemType = level3ItemType;
	}
	
	public String getTibcoTimeStampRegEx() {
		return tibcoTimeStampRegEx;
	}
	public void setTibcoTimeStampRegEx(String tibcoTimeStampRegEx) {
		this.tibcoTimeStampRegEx = tibcoTimeStampRegEx;
	}
	
	public List<String> getPrefixTIBCOName() {
		return prefixTIBCOName;
	}
	public void setPrefixTIBCOName(List<String> prefixTIBCOName) {
		this.prefixTIBCOName = prefixTIBCOName;
	}
	
	public int getDelayTransfer() {
		return delayTransfer;
	}
	public void setDelayTransfer(int delayTransfer) {
		this.delayTransfer = delayTransfer;
	}
	
	public String getFileprefixName() {
		return fileprefixName;
	}
	public void setFileprefixName(String fileprefixName) {
		this.fileprefixName = fileprefixName;
	}
	public String getEftPostCloseOutboundFilePrefix() {
		return eftPostCloseOutboundFilePrefix;
	}
	public void setEftPostCloseOutboundFilePrefix(
			String eftPostCloseOutboundFilePrefix) {
		this.eftPostCloseOutboundFilePrefix = eftPostCloseOutboundFilePrefix;
	}
	public String getEftCloseOutboundFilePrefix() {
		return eftCloseOutboundFilePrefix;
	}
	public void setEftCloseOutboundFilePrefix(String eftCloseOutboundFilePrefix) {
		this.eftCloseOutboundFilePrefix = eftCloseOutboundFilePrefix;
	}
	public String getEftPromoteFilePrefix() {
		return eftPromoteFilePrefix;
	}
	public void setEftPromoteFilePrefix(String eftPromoteFilePrefix) {
		this.eftPromoteFilePrefix = eftPromoteFilePrefix;
	}
	public String getEftReOpenFilePrefix() {
		return eftReOpenFilePrefix;
	}
	public void setEftReOpenFilePrefix(String eftReOpenFilePrefix) {
		this.eftReOpenFilePrefix = eftReOpenFilePrefix;
	}
	public String getEftIRMAAAppealFilePath() {
		return eftIRMAAAppealFilePath;
	}
	public void setEftIRMAAAppealFilePath(String eftIRMAAAppealFilePath) {
		this.eftIRMAAAppealFilePath = eftIRMAAAppealFilePath;
	}
	public String getEftIRMAAAppealFilePrefix() {
		return eftIRMAAAppealFilePrefix;
	}
	public void setEftIRMAAAppealFilePrefix(String eftIRMAAAppealFilePrefix) {
		this.eftIRMAAAppealFilePrefix = eftIRMAAAppealFilePrefix;
	}
	public long getIrmaaExpiredDay() {
		return irmaaExpiredDay;
	}
	public void setIrmaaExpiredDay(long irmaaExpiredDay) {
		this.irmaaExpiredDay = irmaaExpiredDay;
	}
	public String getEftDataMigrationFilePrefix() {
		return eftDataMigrationFilePrefix;
	}
	public void setEftDataMigrationFilePrefix(String eftDataMigrationFilePrefix) {
		this.eftDataMigrationFilePrefix = eftDataMigrationFilePrefix;
	}

	public String getEftRefreshFilePrefix() {
		return eftRefreshFilePrefix;
	}
	public void setEftRefreshFilePrefix(String eftRefreshFilePrefix) {
		this.eftRefreshFilePrefix = eftRefreshFilePrefix;
	}
}
