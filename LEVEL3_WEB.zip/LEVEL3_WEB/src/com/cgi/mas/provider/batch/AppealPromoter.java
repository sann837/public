package com.cgi.mas.provider.batch;

 
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
 
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
 
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.logger.CustomLogger;

import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.util.Util;
import com.siebel.customui.GetNextAppealOutput;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.Appeal;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.Correspondence;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.EcmDocument;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOSupportMaterials;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfCorrespondence;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfDocumentsIO;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfEcmDocuments;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfSupportMaterialAttachments;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.SupportMaterial;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.SupportMaterialAttachment;

import java.security.*;  
 

public class AppealPromoter implements Tasklet {
	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
 
	private static CustomLogger theLogger = new CustomLogger(AppealPromoter.class);
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelService siebelService;
	
	@Autowired
	private IECMService ecmService;
	
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception 
    {
    	ExecutionContext context = chunkContext.getStepContext().getStepExecution().getExecutionContext();
    	
    	int maxAppealsPerThread = context.getInt(MAX_APPEALS);
		long batchUID = context.getLong(BATCH_UID);
		String threadId = context.getString(THREAD_NAME);
		
    	theLogger.debug(batchUID, "Started task " + threadId + " to process up to " + maxAppealsPerThread + " appeals");
    	
    	runDataExport(batchUID, maxAppealsPerThread);
    	
		return RepeatStatus.FINISHED;
	}
    


	
	private int runDataExport(long batchUID, int maxAppealsPerThread) {	
		
		int errCode = 0;
		int processedAppeals = 0;
		long startTime = System.currentTimeMillis();
		String appealOp = "promote";
		String appealNumber = "";
		long transactionId = 0;
		int ecmIndex = 0;
		String ecmUsername = "";
		String ecmPassword = "";
		List<String> documentList = new ArrayList<String>();
		
		ListOfCorrespondence correspDocs = null;
		ListOSupportMaterials supportMat = null;
		
		int promotedAppeals = 0;
		
		try
		{	
			// Run this as long as we can still get appeals from Siebel
			
			while (processedAppeals < maxAppealsPerThread)
			{
				 
				int typeOfAppeal = 0;  // 0 = PROMOTE; 1 = REOPEN
				 appealOp = "Promote";
				
				
				processedAppeals++;
				// Get appealNumber and transactionId from Siebel
				
				// !!!!!!!!!!!!!!!!!!!!!!!!!!
				
				GetNextAppealOutput promotedInfo = siebelService.getNextAppeal(batchUID, "General");
				
				if (promotedInfo != null)
				{
					
					
					
					ListOfDocumentsIO docsList = promotedInfo.getListOfDocumentsIO();
					
					appealOp = promotedInfo.getTransactionOperation();
					
					if (docsList != null && appealOp != null)
					{
						
						List<Appeal> appeals = docsList.getAppeal();
						if (appeals != null && appeals.size() == 1)
						{
							Appeal appeal = appeals.get(0);
							
							if (appeal != null)
							{
								try
								{
									if ("ReOpen".compareToIgnoreCase(appealOp) == 0)
									{
										typeOfAppeal = 1;
									}
									else if ("Promote".compareToIgnoreCase(appealOp) == 0)
									{
										typeOfAppeal = 0;
									}
									else if ("Refresh".compareToIgnoreCase(appealOp) == 0)
									{
										typeOfAppeal = 2;
									}
									
									appealNumber = appeal.getAppealNumber();
									transactionId = Long.valueOf(appeal.getTransactionId()).longValue();
									ecmIndex = Integer.valueOf(appeal.getECMIndex()).intValue(); 
									
									
									ecmUsername =   appeal.getECMUserName();
									ecmPassword =   appeal.getECMPassword();
									
									ListOfEcmDocuments ecmDocsContainer = appeal.getListOfEcmDocuments();
									if (ecmDocsContainer != null)
									{
										List<EcmDocument> ecmDocs = ecmDocsContainer.getEcmDocument();
										
										if (ecmDocs != null)
										{
											for (int ecmIdx = 0; ecmIdx < ecmDocs.size(); ecmIdx++)
											{
												EcmDocument ecmDoc = ecmDocs.get(ecmIdx);
												if (ecmDoc != null)
												{
													String ecmId = ecmDoc.getDocECMId();
													if (ecmId != null)
													{
														documentList.add(ecmId);
													}
												}
											}
										}
									}
									
									 
									correspDocs = appeal.getListOfCorrespondence();
									
									supportMat = appeal.getListOSupportMaterials();
								}
								catch (Exception ex)
								{
									
									theLogger.error(batchUID, "Exception while retrieving the values returned by the  Siebel web service to process the appeal documents: " + ex.getMessage() );									
									errCode  = -1;
									siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while retrieving the values returned by the  Siebel web service to process the appeal documents", null, null);
								}
							}
							else
							{
								theLogger.error(batchUID, "Null appeal received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen." );
								
								errCode = -1;
								siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Null appeal received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen.", null, null);
							}
						}
						else
						{
							theLogger.error(batchUID, "Invalid number of appeals received while calling the Siebel web service to process the appeal documents: " + appeals.size() + ". Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen." );
							
							errCode = -1;
							siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Invalid appeal received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen.", null, null);
						}
					}
					else
					{
						theLogger.error(batchUID, "Invalid ListOfDocumentsIO received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen." );

						errCode = -1;
						siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Invalid ListOfDocumentsIO received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen.", null, null);
					}
				}
				else
				{
					theLogger.error(batchUID, "Error while calling the Siebel web service to to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen." );

					errCode = -1;
					siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while calling the Siebel web service to to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready to promote or reopen.", null, null);
				}
				
				
				if (errCode == 0)
				{
					int success = promoteAppeal(appealNumber, transactionId, ecmIndex,
							documentList, ecmUsername, ecmPassword,  correspDocs,  supportMat, typeOfAppeal, appealOp) ;
					
					if (success == 0)
					{
						// REPORT SUCCESS TO SIEBEL;
						
						theLogger.resetFailedAppeals();
						
						promotedAppeals++;
						
						siebelService.updateTransactionStatus(transactionId, "Completed", null, null, null, null);
						
						theLogger.debug(transactionId, "Processed appeal from ECM to EFT: " + appealNumber + " for " + appealOp + " transaction Id: "  + transactionId);
						
					} else if (success > 0)
					{
						
						int failedAppeals = theLogger.incrementFailedAppeals();
						if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
						{
							theLogger.debug(transactionId, "Java promote and re-open process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
						}
						
						// RECOVERABLE ERROR
						errCode  = success;
						// REPORT TO SIEBEL, UNDO PROMOTE
						
						//siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while processing appeal in Level3WS", null, null);
						
						
						theLogger.error(transactionId, "Recoverable error while processing appeal: " + appealNumber + " for " + appealOp + " transaction Id: "  + transactionId + ". Error Code: " + errCode);
						
						
						break;
					} else if (success < 0)
					{
						// NONRECOVERABLE ERROR
						
						int failedAppeals = theLogger.incrementFailedAppeals();
						if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
						{
							theLogger.debug(transactionId, "Java promote and re-open process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
						}
						
						errCode  = success;
						// REPORT TO SIEBEL, UNDO PROMOTE
						//siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while processing appeal in Level3WS", null, null);
						
						theLogger.error(transactionId, "Unrecoverable error while processing appeal: " + appealNumber + " for " + appealOp + " transaction Id: "  + transactionId + ". Error Code: " + errCode);
						
						break;
					}
				}
				else
				{
					// errCode was not 0
					
					// no more appeals available to promote
					// this is not a real error, as other threads or JVMs might have promoted all appeals
					// just finish this thread
					if (errCode == -5) 	
					{
						errCode = 0;
						break;
					}
					else
					{
						// the error was already logged; do nothing, let the thread try again for a new appeal
					}
				}
				
			}
			
			
		} catch(Exception e) {
			theLogger.error(batchUID, "Exception while processing and exporting appeals from ECM to EFT: " + e.getMessage() );
			
			errCode  = -1;
			
			// REPORT TO SIEBEL, UNDO PROMOTE
			
		} finally {
			theLogger.performanceStartOnly(batchUID, "Promoted and reopened " + promotedAppeals  + " appeals in batch of " +processedAppeals + " appeals: ", startTime);

			theLogger.debug(batchUID, "Finished promoting and reopening " + promotedAppeals  + " appeals in batch of " +processedAppeals + " appeals: ");

		}
		if ("Refresh".compareToIgnoreCase(appealOp) == 0){
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			//tempDirectoryBuilder.append(WebUtils.getTempDir(getServletContext()));
			//tempDirectoryBuilder.append("/");
			tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
			tempDirectoryBuilder.append("/");			
			theLogger.debug(transactionId, "Root export directory: " + tempDirectoryBuilder.toString());			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(transactionId, "Root export directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
			
				// RECOVERABLE ERROR
				errCode = 1;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Root export directory does not exist and could not be created", null, null);
				return errCode;
			}
			
			FileWriter fw = null;
			FileOutputStream sigfos = null;
			if(errCode<0 || errCode>0){
				StringBuilder tempAppealFolderBuilder=	buildTempFolder(tempDirectoryBuilder, appealNumber, transactionId);
				if (false == Util.directoryCheck(tempAppealFolderBuilder.toString(), true) )
				{
					theLogger.debug(transactionId, "Appeal export directory does not exist and could not be created: " + tempAppealFolderBuilder.toString());
					
					// RECOVERABLE ERROR
					errCode = 2;
					siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Appeal export directory does not exist and could not be created", null, null);
					return errCode;
				}
				try{
				 fw =createManifestFile(tempAppealFolderBuilder,appealNumber,transactionId);
				 fw.write("\r\n================================================================\r\n");
				 fw.write("ERROR: Unable to process request."  );
				 fw.write("\r\n================================================================\r\n");
			}
				catch (Exception ioe)
				{
					theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());					
					// RECOVERABLE ERROR
					errCode = 4;
					siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while adding appeal data to manifest file", null, null);
				
				}
				finally 
				{
					if (fw != null)
					{
						try
						{
							fw.close();
							fw = null;
						} catch (Exception clex)
						{
							fw = null;
						}
					}
				}
				try{
				sendResponseViaEft(transactionId, appealNumber, 2, tempAppealFolderBuilder, tempDirectoryBuilder);
				}
				catch(Exception e){
					
				}
			finally 
				{
					
					if (sigfos != null)
					{
						try
						{
							sigfos.close();
						} catch (Exception ex)
						{
							
						}
						sigfos = null;
					}
				
				}
			}
		}
		
		return errCode;
	}
	
	
	private int promoteAppeal(String appealNumber, long transactionId, int ecmIndex,
					List<String> documentList, String ecmUsername, String ecmPassword, 
					ListOfCorrespondence correspDocs, ListOSupportMaterials supportMat,
					int typeOfAppeal, String appealOp) 
	{
		int errCode = 0;
		long startTime = System.currentTimeMillis();
		
		try
		{
			
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			//tempDirectoryBuilder.append(WebUtils.getTempDir(getServletContext()));
			//tempDirectoryBuilder.append("/");
			tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
			tempDirectoryBuilder.append("/");
			
			theLogger.debug(transactionId, "Root export directory: " + tempDirectoryBuilder.toString());
			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(transactionId, "Root export directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
				
				// RECOVERABLE ERROR
				errCode = 1;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Root export directory does not exist and could not be created", null, null);
				return errCode;
			}
			
			 
			/*StringBuilder tempAppealFolderBuilder = new StringBuilder(tempDirectoryBuilder.toString());
			// BUG FOUND
			//tempAppealFolderBuilder.append("/");
			tempAppealFolderBuilder.append(appealNumber);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(transactionId);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(Util.getCurrentTimeStamp());*/
			
			
			 StringBuilder tempAppealFolderBuilder = buildTempFolder(tempDirectoryBuilder,appealNumber,transactionId);
			if (false == Util.directoryCheck(tempAppealFolderBuilder.toString(), true) )
			{
				theLogger.debug(transactionId, "Appeal export directory does not exist and could not be created: " + tempAppealFolderBuilder.toString());
				
				// RECOVERABLE ERROR
				errCode = 2;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Appeal export directory does not exist and could not be created", null, null);
				return errCode;
			}
			

			
			
			// create manifest file
			FileWriter fw = null;
			try
			{
				fw = createManifestFile(tempAppealFolderBuilder,appealNumber,transactionId);
				
			    //fw.write("Documents in the appeal:\r\n");
			    fw.write("============================================================================\r\n");
			    fw.write("Document Type\tDocument Id\tFile Name\tFile Size\tMD5 Checksum\r\n");
			    fw.write("============================================================================\r\n");
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());
				
				errCode = -1;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while adding appeal data to manifest file", null, null);
				
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				return errCode;
			}
			finally 
			{
				if (fw != null)
				{
					fw.close();
					fw = null;
				}
			}
			

			// Save  Siebel attachements to tempAppealFolderBuilder
			
			if (correspDocs != null)
			{
				List<Correspondence> correspList = correspDocs.getCorrespondence();
				if (correspList != null)
				{
					for (int cdx=0; cdx < correspList.size(); cdx++)
					{
						Correspondence corresp = correspList.get(cdx);
						if (corresp != null)
						{
							String fileExt = corresp.getFileExt();
							String fileName = corresp.getFileName();
							String fileSize = corresp.getFileSize();
							String uid = corresp.getAttachmentId();
						  
							errCode = saveSiebelAttachement(transactionId, fileExt, 
									fileName, fileSize, uid,
									tempAppealFolderBuilder.toString(), "Correspondence");
							if (errCode != 0)
							{
								Util.deleteDirectory(tempAppealFolderBuilder.toString());
								
								return errCode;
							}
						 
						}
					}
				}
				
			}
			
			if (supportMat != null)
			{
				List<SupportMaterial> mattList = supportMat.getSupportMaterial();
				if (mattList != null)
				{
					for (int mdx=0; mdx < mattList.size(); mdx++)
					{
						SupportMaterial matt = mattList.get(mdx);
						if (matt != null)
						{
							ListOfSupportMaterialAttachments materialAttachments = matt.getListOfSupportMaterialAttachments();
							if (materialAttachments != null)
							{
								List<SupportMaterialAttachment> mattAttList = materialAttachments.getSupportMaterialAttachment();
								
								if (mattAttList != null)
								{
									for (int adx = 0; adx < mattAttList.size(); adx++)
									{
										SupportMaterialAttachment att = mattAttList.get(adx);
										if (att != null)
										{
											String fileExt = att.getFileExt();
											String fileName = att.getFileName();
											String fileSize = att.getFileSize();
											String uid = att.getAttachmentId();
										 
											errCode = saveSiebelAttachement(transactionId, fileExt, 
																			fileName, fileSize, uid,
																			tempAppealFolderBuilder.toString(), "Support Material");
											if (errCode != 0)
											{
												Util.deleteDirectory(tempAppealFolderBuilder.toString());
												
												return errCode;
											}
										 
										}
									}
								}
							}
						}
					}
				}
				
			}

			// !!!!!!!!!!!!!!!!!!!!!!!!!!
			
			//StringBuilder exportFilePath = new StringBuilder();	
			
			//siebelService.updateTransactionStatus(transactionId, "Retrieving ECM Data", null, null, null);
			
			errCode = ecmService.exportECMContent(appealNumber, ecmUsername, ecmPassword, tempAppealFolderBuilder.toString(), documentList, transactionId);
			
			 
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while downloading ECM files: " + appealNumber + " to: " + tempAppealFolderBuilder.toString());
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while downloading ECM files: " + appealNumber, null, null);
				return errCode;
			}
			 
			theLogger.debug(transactionId, "Downloaded ECM Files for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
			 
			
			
			
			//siebelService.updateTransactionStatus(transactionId, "Retrieving Appeal Data", null, null, null);
			
			// Download appealData from Siebel
			
			String tempAppealFile = tempAppealFolderBuilder.toString() + "/AppealData.xml";
			
			if (typeOfAppeal == 0) // Promote
			{
				errCode = siebelService.getPromotedAppealData(appealNumber, transactionId, tempAppealFile);
			} else if (typeOfAppeal == 1) // Reopen
			{
				errCode = siebelService.getReopenedAppealData(appealNumber, transactionId, tempAppealFile);
			}
			else if (typeOfAppeal == 2) // Refresh
			{
				errCode = siebelService.getRefreshAppealData(appealNumber, transactionId, tempAppealFile);
			}

		 
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while downloading appeal data from Siebel for appeal: " + appealNumber + " to: " + tempAppealFile);
				//siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while downloading appeal data from Siebel for appeal: " + appealNumber, null, null);
				return errCode;
			}
			
			theLogger.debug(transactionId, "Downloaded appeal data from Siebel for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
						
			// Add info to manifest file
			try
			{
				File appealFile = new File(tempAppealFile);
 
				String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";

			    fw = new FileWriter(manifestFilename, true);  
				
			    fw.write("Appeal Data\t" + appealNumber + "\tAppealData.xml\t" + appealFile.length() + "\t" + Util.getMD5CheckSum(appealFile) + "\r\n"); //appends the string to the file
			    
			}
			catch (Exception ioe)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Exception while writing to the manifest file: " + ioe.getMessage());				
				
				errCode = -1;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while writing to the manifest file", null, null);
				return errCode;
			}
			finally 
			{
				if (fw != null)
				{
					fw.close();
					fw = null;
				}
			}
		 
			errCode = sendResponseViaEft(transactionId, appealNumber, typeOfAppeal,
					tempAppealFolderBuilder, tempDirectoryBuilder);
			
			if (errCode != 0)
				return errCode;
			
			// Sign manifest file
			
			/*
			FileOutputStream sigfos = null;
			try
			{
				// String keyStoreFile = "/resources/mykeystore.jks";  
			    // String password = "mypassword";  
			    //  String alias = "mycert"; 
			    
				theLogger.debug(transactionId, "Generating signature file...");
				
				
				String keyStoreFile =  constantConfig.getKeystoreName();
			    String password = constantConfig.getKeystorePassword();
			    String alias = constantConfig.getKeyAlias(); 
			    String keyPassword = constantConfig.getKeyPassword();
				
				KeyStore keystore = KeyStore.getInstance("JKS");  
	            char[] storePass = password.toCharArray();  
	            char[] keyPasswd = keyPassword.toCharArray(); 
	  
	            //load the key store from file system  
	            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
	            keystore.load(fileInputStream, storePass);  
	            fileInputStream.close();  
	  
	             
	            //read the private key  
	            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
	            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
	            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
	  
	            //initialize the signature with signature algorithm and private key  
	            Signature signature = Signature.getInstance("SHA256withRSA");  
	            signature.initSign(privateKey);  
	            
	            // read manifest and s sign
	            String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";
	
	            FileInputStream fis = new FileInputStream(manifestFilename);
	            BufferedInputStream bufin = new BufferedInputStream(fis);
	            byte[] buffer = new byte[10000];
	            int len;
	            while ((len = bufin.read(buffer)) >= 0) {
	            	signature.update(buffer, 0, len);
	            };
	            bufin.close();
  
	            byte[] digitalSignature = signature.sign();
 
				String signatureFilename = tempAppealFolderBuilder.toString() + "/signature.txt";
 
				sigfos = new FileOutputStream(signatureFilename);
			    sigfos.write(digitalSignature);
			    sigfos.close(); 
			    
			    theLogger.debug(transactionId, "Signature file generated: " + signatureFilename);
			}
			catch (Exception ioe)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Exception while writing signature file: " + ioe.getMessage());
				
				errCode = -1;
				return errCode;
			}
			finally 
			{
				if (sigfos != null)
				{
					sigfos.close();
					sigfos = null;
				}
			}
 
			// Compress and move file
 
			StringBuilder compressFilePath = new StringBuilder();		
			compressFilePath.append(tempDirectoryBuilder.toString());
			// BUG FOUND
			// compressFilePath.append("/");
			compressFilePath.append(appealNumber);
			compressFilePath.append("_");
			compressFilePath.append(transactionId);
			compressFilePath.append(".zip");
			
			errCode =  Util.compressContent(tempAppealFolderBuilder.toString(), compressFilePath.toString(), transactionId);
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while compressing appeal: " + appealNumber + " to: " + compressFilePath.toString());
				return errCode;
			}
			theLogger.debug(transactionId, "Compressed appeal: " + appealNumber + " to: " + compressFilePath.toString());
						
			Util.deleteDirectory(tempAppealFolderBuilder.toString());
			theLogger.debug(transactionId, "Removed temporary appeal folder: " + tempAppealFolderBuilder.toString());

			// Move compressFilePath ZIP file to EFT
			//T#EFT.ON.MAS.L3SVC.ORGID.DYYMMDD.THHMMSST
			 
			//File zipFile = new File(compressFilePath.toString());
			//String zipFileName = zipFile.getName();
			
			StringBuilder eftFileLocation = new StringBuilder(constantConfig.getEftLocation());	
			eftFileLocation.append("/");
			eftFileLocation.append(constantConfig.getEftFilePrefix());
			
			if (typeOfAppeal == 0)
			{	
				eftFileLocation.append(constantConfig.getEftPromoteFilePrefix());
				eftFileLocation.append(".");
			}
			else if (typeOfAppeal == 1)
			{
				eftFileLocation.append(constantConfig.getEftReOpenFilePrefix());
				eftFileLocation.append(".");
			}
			
			eftFileLocation.append(constantConfig.getEftOrgName());
			eftFileLocation.append(".D");
			
			//DYYMMDD.THHMMSST   
			
			Date rightNow = new Date();
			String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
			String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
			
			eftFileLocation.append(dateStamp);	
			eftFileLocation.append(".T");
			eftFileLocation.append(timeStamp);
			
			String destFile = eftFileLocation.toString();
			boolean fileNameAvailable = false;
			for (int fidx = 0;  fidx <= 9; fidx++)
			{
				String tryFileName = destFile + fidx;
				 
				File f = new File(tryFileName);
				if(f.exists() == false)
				{
					destFile = tryFileName;

					theLogger.debug(transactionId, "Copying ZIP file : " + compressFilePath.toString() + " to EFT: " + destFile);
					
					errCode =  Util.copyFile(compressFilePath.toString(), destFile);
					if (errCode != 0)
					{
						theLogger.error(transactionId, "Try " + fidx + ": Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder: " + destFile);
						//return errCode;
					}
					else
					{
						theLogger.debug(transactionId, "Copied compressed file for appeal " + appealNumber + " to EFT folder: " + destFile);
						fileNameAvailable = true;
						break;
					}

				}
				
			}
			
			if (fileNameAvailable == false)
			{
				errCode = -1;
				Util.deleteFile(compressFilePath.toString());
				theLogger.error(transactionId, "Could not find available file name on EFT for appeal: " + appealNumber + " for generated filename: " + destFile);
				return errCode;
			}
			//String destFile = eftFileLocation.toString();
			
						
			// Delete original ZIP File
			errCode =  Util.deleteFile(compressFilePath.toString());
			if (errCode != 0)
			{
				theLogger.error(transactionId, "Error while deleting compressed appeal file for appeal: " + appealNumber + " from temp folder: " + compressFilePath.toString());
				return errCode;
			}
			theLogger.debug(transactionId, "Deleted compressed file for appeal " + appealNumber + " from temp folder: " + compressFilePath.toString());
		 
			*/
			

					
		} catch(Exception e) {
			if (typeOfAppeal == 0)
			{
				theLogger.error(transactionId, "Exception while promoting appeal : " + appealNumber +  ". Exception: " + e.getMessage() );
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while promoting appeal : " + appealNumber, null, null);
			}
			else if (typeOfAppeal == 1)
			{
				theLogger.error(transactionId, "Exception while reopening appeal : " + appealNumber +  ". Exception: " + e.getMessage() );
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while reopening appeal : " + appealNumber, null, null);
			}
			else if (typeOfAppeal == 2)
			{
				theLogger.error(transactionId, "Exception while refreshing appeal : " + appealNumber +  ". Exception: " + e.getMessage() );
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while refreshing appeal : " + appealNumber, null, null);
			}
			
			// UNRECOVERABLE ERROR
			errCode = -1;
		} finally {
			if (typeOfAppeal == 0)
			{
				theLogger.performanceStartOnly(transactionId, "Promoting appeal took: ", startTime);
				theLogger.debug(transactionId, "Finished promoting appeal: " + appealNumber);
			}
			else if (typeOfAppeal == 1)
			{
				theLogger.performanceStartOnly(transactionId, "Reopening appeal took: ", startTime);
				theLogger.debug(transactionId, "Finished reopening appeal: " + appealNumber);
			}
		}

		return errCode;
 
	}
	
	
	private FileWriter createManifestFile(
			StringBuilder tempAppealFolderBuilder, String appealNumber, long transactionId) {
		FileWriter fw = null;
		String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";
	    try {
			fw = new FileWriter(manifestFilename, true);
		
	    fw.write("Manifest file for Appeal Number " + appealNumber +  "\r\n");
	    fw.write("============================================================================\r\n");
	    fw.write("Appeal  Number: " + appealNumber + "\r\n");
	    fw.write("Transaction Id: " + transactionId + "\r\n");
	    fw.write("Processed Date: " + Util.convertCalendarToString(Calendar.getInstance(), "MM/dd/yyyy HH:mm:ss") +  "\r\n");
	    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	    return fw;
	}




	private StringBuilder buildTempFolder(StringBuilder tempDirectoryBuilder, String appealNumber, long transactionId) {
		StringBuilder tempAppealFolderBuilder = new StringBuilder(tempDirectoryBuilder.toString());
		// BUG FOUND
		//tempAppealFolderBuilder.append("/");
		tempAppealFolderBuilder.append(appealNumber);
		tempAppealFolderBuilder.append("_");
		tempAppealFolderBuilder.append(transactionId);
		tempAppealFolderBuilder.append("_");
		tempAppealFolderBuilder.append(Util.getCurrentTimeStamp());
		theLogger.debug(transactionId, "Appeal export directory: " + tempAppealFolderBuilder.toString());
		return tempAppealFolderBuilder;
	}




	private int sendResponseViaEft(long transactionId, String appealNumber, int typeOfAppeal,
					StringBuilder tempAppealFolderBuilder, StringBuilder tempDirectoryBuilder )
	{
		int errCode = 0;
		
		// Sign manifest file
		
		FileOutputStream sigfos = null;
		try
		{		    
			theLogger.debug(transactionId, "Generating signature file...");
			
			
			String keyStoreFile =  constantConfig.getKeystoreName();
		    String password = constantConfig.getKeystorePassword();
		    String alias = constantConfig.getKeyAlias(); 
		    String keyPassword = constantConfig.getKeyPassword();
			
			KeyStore keystore = KeyStore.getInstance("JKS");  
            char[] storePass = password.toCharArray();  
            char[] keyPasswd = keyPassword.toCharArray(); 
  
            //load the key store from file system  
            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
            keystore.load(fileInputStream, storePass);  
            fileInputStream.close();  
  
             
            //read the private key  
            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
  
            //initialize the signature with signature algorithm and private key  
            Signature signature = Signature.getInstance("SHA256withRSA");  
            signature.initSign(privateKey);  
            
            // read manifest and s sign
            String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";

            FileInputStream fis = new FileInputStream(manifestFilename);
            BufferedInputStream bufin = new BufferedInputStream(fis);
            byte[] buffer = new byte[10000];
            int len;
            while ((len = bufin.read(buffer)) >= 0) {
            	signature.update(buffer, 0, len);
            };
            bufin.close();

            byte[] digitalSignature = signature.sign();

			String signatureFilename = tempAppealFolderBuilder.toString() + "/signature.txt";

			sigfos = new FileOutputStream(signatureFilename);
		    sigfos.write(digitalSignature);
		    sigfos.close(); 
		    
		    theLogger.debug(transactionId, "Signature file generated: " + signatureFilename);
		}
		catch (Exception ioe)
		{
			Util.deleteDirectory(tempAppealFolderBuilder.toString());
			
			theLogger.error(transactionId, "Exception while writing signature file: " + ioe.getMessage());
			
			errCode = -1;
			siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while writing signature file", null, null);
			return errCode;
		}
		finally 
		{
			if (sigfos != null)
			{
				try
				{
					sigfos.close();
				} catch (Exception ex)
				{
					
				}
				sigfos = null;
			}
		}

		// Compress and move file

		StringBuilder compressFilePath = new StringBuilder();		
		compressFilePath.append(tempDirectoryBuilder.toString());
		// BUG FOUND
		// compressFilePath.append("/");
		compressFilePath.append(appealNumber);
		compressFilePath.append("_");
		compressFilePath.append(transactionId);
		compressFilePath.append(".zip");
		
		errCode =  Util.compressContent(tempAppealFolderBuilder.toString(), compressFilePath.toString(), transactionId);
		if (errCode != 0)
		{
			Util.deleteDirectory(tempAppealFolderBuilder.toString());
			
			theLogger.error(transactionId, "Error while compressing appeal: " + appealNumber + " to: " + compressFilePath.toString());
			siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while compressing appeal: " + appealNumber, null, null);
			return errCode;
		}
		theLogger.debug(transactionId, "Compressed appeal: " + appealNumber + " to: " + compressFilePath.toString());
					
		Util.deleteDirectory(tempAppealFolderBuilder.toString());
		theLogger.debug(transactionId, "Removed temporary appeal folder: " + tempAppealFolderBuilder.toString());

		// Move compressFilePath ZIP file to EFT
		//T#EFT.ON.MAS.L3SVC.ORGID.DYYMMDD.THHMMSST
		 
		//File zipFile = new File(compressFilePath.toString());
		//String zipFileName = zipFile.getName();
		
		StringBuilder eftFileLocation = new StringBuilder(constantConfig.getEftLocation());	
		eftFileLocation.append("/");
		eftFileLocation.append(constantConfig.getEftFilePrefix());
		
		if (typeOfAppeal == 0)
		{	
			eftFileLocation.append(constantConfig.getEftPromoteFilePrefix());
			eftFileLocation.append(".");
		}
		else if (typeOfAppeal == 1)
		{
			eftFileLocation.append(constantConfig.getEftReOpenFilePrefix());
			eftFileLocation.append(".");
		}
		
		else if (typeOfAppeal == 2)
		{
			eftFileLocation.append(constantConfig.getEftRefreshFilePrefix());
			eftFileLocation.append(".");
		}
		
		eftFileLocation.append(constantConfig.getEftOrgName());
		eftFileLocation.append(".D");
		
		//DYYMMDD.THHMMSST   
		
		Date rightNow = new Date();
		String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
		String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
		
		eftFileLocation.append(dateStamp);	
		eftFileLocation.append(".T");
		eftFileLocation.append(timeStamp);
		
		String destFile = eftFileLocation.toString();
		boolean fileNameAvailable = false;
		for (int fidx = 0;  fidx <= 9; fidx++)
		{
			String tryFileName = destFile + fidx;
			 
			File f = new File(tryFileName);
			if(f.exists() == false)
			{
				theLogger.debug(transactionId, "Copying ZIP file : " + compressFilePath.toString() + " to EFT: " + tryFileName);
				
				errCode =  Util.copyFile(compressFilePath.toString(), tryFileName);
				if (errCode != 0)
				{
					theLogger.error(transactionId, "Try " + fidx + ": Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder: " + tryFileName);
					siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder", null, null);
				}
				else
				{
					theLogger.debug(transactionId, "Copied compressed file for appeal " + appealNumber + " to EFT folder: " + tryFileName);
					fileNameAvailable = true;
					break;
				}

			}
			
		}
		
		if (fileNameAvailable == false)
		{
			errCode = -1;
			//Util.deleteFile(compressFilePath.toString());
			theLogger.error(transactionId, "Could not find available file name on EFT for appeal: " + appealNumber + " for generated filename: " + destFile + ". Original ZIP file will be kept in the temp folder.");
			siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Could not find available file name on EFT for appeal: " + appealNumber + " for generated filename: " + destFile + ". Original ZIP file will be kept in the temp folder.", null, null);
			return errCode;
		}
		else
		{
			// Delete original ZIP File
			errCode =  Util.deleteFile(compressFilePath.toString());
			
			if (errCode != 0)
			{
				theLogger.error(transactionId, "Error while deleting compressed appeal file for appeal: " + appealNumber + " from temp folder: " + compressFilePath.toString());
				//return errCode;
				errCode = 0;
				siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while deleting compressed appeal file for appeal: " + appealNumber + " from temp folder", null, null);
			}
			else
			{
				theLogger.debug(transactionId, "Deleted compressed file for appeal " + appealNumber + " from temp folder: " + compressFilePath.toString());
			}
		}
		
					
		

		if (typeOfAppeal == 0)
		{
			theLogger.debug(transactionId, "Successfully promoted appeal " + appealNumber);
		}
		else if (typeOfAppeal == 1)
		{
			theLogger.debug(transactionId, "Successfully reopened appeal " + appealNumber);
		}
		else if (typeOfAppeal == 2)
		{
			theLogger.debug(transactionId, "Successfully refreshed appeal " + appealNumber);
		}
		
		return errCode;
	}
	
	
	private int saveSiebelAttachement(long transactionId, String fileExt,	String fileName, String fileSize, String attachementId, String folderName, String docType)
	{
			 if (folderName == null || fileExt == null || fileName == null || fileSize == null || attachementId == null )
			 {
				 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where null." );
				 
				 siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(-1), "Error while saving Siebel attachement: input parameters where null.", null, null);
				 return -1;
			 }
			 
			 if (folderName.length() < 1 || fileExt.length() < 1 || fileName.length() < 1 || fileSize.length() < 1 || attachementId.length() < 1)
			 {
				 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where empty." );
				 siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(-1), "Error while saving Siebel attachement: input parameters where empty.", null, null);
				 return -1;
			 }
			 
			 String siebelAttachementPath = folderName + "/" + attachementId + "_" + fileName + "." + fileExt;
			 
			 theLogger.debug(transactionId, "Saving Siebel Attachement: " + fileName + " to: " + siebelAttachementPath);
				
			 
			 FileOutputStream fos = null;
			 
			 byte[] fileContent = siebelService.getDocAttachment(attachementId, transactionId, null);
		 
			 if (fileContent == null)
			 {
				 // already logged the error message
				 return -1;
			 }
			 
		 	try
			{
				 fos = new FileOutputStream(siebelAttachementPath);
				 fos.write(fileContent);
				 fos.close();
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while writing the Siebel atatchement to file: " + ioe.getMessage());
				 siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(-2), "Exception while writing the Siebel atatchement to file", null, null);
				
				return -2;
			}
			finally 
			{
				if (fos != null)
				{
					try { fos.close(); } catch (Exception iex) {}
				}
			}
			
			
		 	FileWriter fw = null;
			try
			{
			    String manifestFilename = folderName + "/manifest.txt";
			    fw = new FileWriter(manifestFilename, true); //the true will append the new data
			    
			    File exportedFile = new File(siebelAttachementPath);
				String fName = exportedFile.getName();
				
			    fw.write(docType + "\t" + attachementId + "\t" + fName + "\t" + exportedFile.length() + "\t" + Util.getMD5CheckSum(exportedFile) + "\r\n"); //appends the string to the file
			    
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while writing to the manifest file: " + ioe.getMessage());
				 siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(-2), "Exception while writing to the manifest file", null, null);
				
				return -2;
			}
			finally 
			{
				if (fw != null)
				{
					try 
					{ 
						fw.close(); 
					} catch (Exception iex) {}
				}
			}
			
			return 0;
	}
	
	private int addTextToManifestFile(long transactionId, String manifestFolder, String message)
	{
		int errCode = 0;
		
		FileWriter fw = null;
		try
		{
			String manifestFilename = manifestFolder + "/manifest.txt";
		    fw = new FileWriter(manifestFilename, true);  
		    fw.write(message);
		    fw.write("\r\n================================================================\r\n");
		}
		catch (Exception ioe)
		{
			theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());
			
			// RECOVERABLE ERROR
			errCode = 4;
		}
		finally 
		{
			if (fw != null)
			{
				try
				{
					fw.close();
					fw = null;
				} catch (Exception clex)
				{
					fw = null;
				}
			}
		}
		
		return errCode;
	}
	
	
}
