package com.cgi.mas.provider.batch;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FilenameUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.SettlementSiebelResponse;
import com.cgi.mas.provider.util.Util;

public class AppealSettlement implements Tasklet {
	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String DEFAULT_KEY_NAME = "fileName";
 
	private static CustomLogger theLogger = new CustomLogger(AppealSettlement.class);
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelService siebelService;
	
 
	
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception 
    {
    	long batchUID = 0;
    	
    	try
    	{
	    	ExecutionContext context = chunkContext.getStepContext().getStepExecution().getExecutionContext();
	    	
	    	int maxAppealsPerThread = context.getInt(MAX_APPEALS);
			batchUID = context.getLong(BATCH_UID);
			String threadId = context.getString(THREAD_NAME);
			
			
			ArrayList<String> fileList = (ArrayList<String>) context.get(DEFAULT_KEY_NAME);
			
			if (fileList != null && fileList.size() > 0)
			{
				theLogger.debug(batchUID, "Starting task " + threadId + " to process up to " + maxAppealsPerThread + " settlement files");
	    	
				runSettlement(batchUID, maxAppealsPerThread, fileList);
			}
			else
			{
				theLogger.error(batchUID, "No settlement files received by the thread for processing. This can happen if other threads allready processed the files.");
			}
    	}
    	catch (Exception ex)
    	{
    		theLogger.error(batchUID, "Exception in job scheduler.", ex);
    	}
		
		return RepeatStatus.FINISHED;
	}
    


	
	private int runSettlement(long batchUID, int maxAppealsPerThread, ArrayList<String> fileList) 
	{	
		int processedFiles = 0;
		int succesfullFiles = 0;
		
		int processedAppeals = 0;
		
		long startTime = System.currentTimeMillis();
		
		try
		{	
			// GET THE ROOT CLOSE DIRECTORY
			
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
			tempDirectoryBuilder.append("/");
			
			//theLogger.debug(transactionId, "Root close directory: " + tempDirectoryBuilder.toString());
			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(batchUID, "Root settlement directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
				
				// RECOVERABLE ERROR
				return -1;
			}
			
			// Run this as long as we have files to process

			for (int fileIdx = 0; fileIdx < fileList.size(); fileIdx++)
			{
				processedFiles++;
				
				int errCode = 0;
				
				
				//long transactionId = batchUID;
				boolean siebelCalled = false;
				String settlementFilePrefix = null;
				 
				String selFileName = fileList.get(fileIdx);

				if (selFileName != null && selFileName.length() > 0)
				{

					String filePath = checkFile(batchUID, selFileName);
					if (filePath != null)
					{
						 
						
						// FILE IS RENAMED WITH LOCK EXTENSION NOW
						// MAKE SURE TO DELETE OR RENAME AT THE END
						
						// UNZIP AND MANIFEST FOLDER NAMES
						
						String randomUniqueString = UUID.randomUUID().toString();
						
						
						StringBuilder settlementFolder  = new StringBuilder(tempDirectoryBuilder.toString());
						settlementFolder.append(randomUniqueString);
						settlementFolder.append("_");
						settlementFolder.append(Util.getCurrentTimeStamp());
						theLogger.debug(batchUID, "Settlement directory: " + settlementFolder.toString());
						 
						StringBuilder manifestFolder  = new StringBuilder(settlementFolder.toString());
						manifestFolder.append("_OUT");
						theLogger.debug(batchUID, "Settlement manifest directory: " + manifestFolder.toString());
						 
						
						String baseFileName = FilenameUtils.getBaseName(filePath);
						
						
						// CREATE FOLDER FOR UNZIP 
						if (true == Util.directoryCheck(settlementFolder.toString(), true) )
						{
							// CREATE FOLDER FOR MANIFEST
							if (true == Util.directoryCheck(manifestFolder.toString(), true) )
							{
								// CREATE MANIFEST FILE

								FileWriter fw = null;
								try
								{
									String manifestFilename = manifestFolder.toString() + "/manifest.txt";
								    fw = new FileWriter(manifestFilename, true);  
								    
								    fw.write("Manifest file for settlement file " + baseFileName +  "\r\n");
								     
								    
								    fw.write("================================================================\r\n");
								    fw.write("Processed Date: " + Util.convertCalendarToString(Calendar.getInstance(), "MM/dd/yyyy HH:mm:ss") +  "\r\n");
								    fw.write("================================================================\r\n");
								}
								catch (Exception ioe)
								{
									theLogger.error(batchUID, "Exception while adding settlement data to manifest file: " + ioe.getMessage());
									
									// RECOVERABLE ERROR
									errCode = 4;
								}
								finally 
								{
									if (fw != null)
									{
										fw.close();
										fw = null;
									}
								}
								
								if (errCode == 0)
								{
									// UNZIP FILE
									
									boolean zipOk = Util.extractZipToFolder(filePath, settlementFolder.toString());
									
									if (zipOk == true)
									{
										// Check that it has manifest and appeal data
										
										String incomingAppealDataFileName = settlementFolder.toString() + "/appealFile.xml";
										String incomingManifestFileName = settlementFolder.toString() + "/manifest.txt";
										
										File incomingAppealDataFile  =  new File(incomingAppealDataFileName);
										File incomingManifestFile = new File(incomingManifestFileName);
										
										if (incomingAppealDataFile.exists() && incomingManifestFile.exists())
										{
											// Read manifest file
											
											Properties manifestProps = new Properties();
											InputStream manifestStream = null;
											
											String consumerId =  null;
											String settlementIndicator = null;
											String functionName  =  null;
											String appealFileChecksum  =  null;


											try 
											{
												manifestStream = new FileInputStream(incomingManifestFile);
												manifestProps.load(manifestStream);

												// get the property value  
												consumerId =  manifestProps.getProperty("ConsumerId");
												settlementIndicator =  manifestProps.getProperty("SettlementIndicator");
												functionName =  manifestProps.getProperty("Function");
												appealFileChecksum =  manifestProps.getProperty("AppealFileChecksum");
												if (functionName != null && functionName.compareToIgnoreCase("pend")==0){
												if (consumerId == null || consumerId.length() <= 0 || 
														settlementIndicator == null || settlementIndicator.length() <= 0 ||
													functionName == null || functionName.length() <= 0 ||
													appealFileChecksum == null || appealFileChecksum.length() <= 0)
												{
													
													
													theLogger.error(batchUID, "Could not read ConsumerId, SettlementIndicator, Function, and AppealFileChecksum from manifest file: " + incomingManifestFile);
													
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not read ConsumerId, SettlementIndicator, Function, and AppealFileChecksum  from the manifest.txt file.");
													
													// UNRECOVERABLE ERROR
													errCode = -7;
												}
												else
												{
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "Transaction Id: " + batchUID );
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested ConsumerId: " + consumerId );
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested SettlementIndicator: " + settlementIndicator );
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested Function: " + functionName );
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested AppealFileChecksum: " + appealFileChecksum );
													

													theLogger.debug(batchUID, "Found in manifest file: ConsumerId = " + consumerId + "SettlementIndicator = " + settlementIndicator + " Function = " + functionName + " AppealFileChecksum = " + appealFileChecksum);
												}}
												else{
													if (consumerId == null || consumerId.length() <= 0 || 															
														functionName == null || functionName.length() <= 0 ||
														appealFileChecksum == null || appealFileChecksum.length() <= 0)
													{
														
														theLogger.error(batchUID, "Could not read ConsumerId, Function, and AppealFileChecksum from manifest file: " + incomingManifestFile);
														
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not read ConsumerId, Function, and AppealFileChecksum  from the manifest.txt file.");
														
														// UNRECOVERABLE ERROR
														errCode = -7;
													}
													else
													{
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "Transaction Id: " + batchUID );
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested ConsumerId: " + consumerId );													
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested Function: " + functionName );
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "Requested AppealFileChecksum: " + appealFileChecksum );
														

														theLogger.debug(batchUID, "Found in manifest file: ConsumerId = " + consumerId  + " Function = " + functionName + " AppealFileChecksum = " + appealFileChecksum);
													}
												}
												
											} 
											catch (Exception manex) 
											{
												theLogger.error(batchUID, "Exception while readng info from manifest file: " + incomingManifestFile, manex);
												
												addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Failed to read the manifest.txt file.");
												
												// UNRECOVERABLE ERROR
												errCode = -6;
											} 
											finally 
											{
												if (manifestStream != null) 
												{
													try {
														manifestStream.close();
													} catch (Exception clex) {
														theLogger.error(batchUID, "Exception while closing manifest file stream: " + incomingManifestFile, clex);
													}
												}
											}


											if (errCode == 0)
											{
												List<String> appealList = new ArrayList<String>();
												int appealsInFile = 0;
												
												// Check appealData checksum
												String realChecksum = Util.getMD5CheckSum(incomingAppealDataFile);
												if (realChecksum != null && realChecksum.compareToIgnoreCase(appealFileChecksum) == 0) 
												{
													// Check function name
													if (functionName.compareToIgnoreCase("pend") == 0 || functionName.compareToIgnoreCase("un-enact") == 0)
													{
														// Extract appeals from appealData
														
														try
														{
															DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
															DocumentBuilder builder = factory.newDocumentBuilder();
																 
															Document document = builder.parse(incomingAppealDataFile);
															
															Element root = document.getDocumentElement();
															root.normalize();
																
															if (root != null)
															{
																NodeList nodeList = document.getElementsByTagName("appeal");
																
																if (nodeList != null)
																{
																	int numAppeals = nodeList.getLength();
																	
																	if (numAppeals > 0)
																	{
																		for (int nodeIdx = 0; nodeIdx < numAppeals; nodeIdx++) 
																		{
																            Node node = nodeList.item(nodeIdx);
																            if (node != null)
																            {
																            	String appealNumber = node.getTextContent();
																            	if (appealNumber != null && appealNumber.length() > 0)
																            	{
																            		appealList.add(appealNumber);
																            	}
																            	else
																            	{
																            		theLogger.error(batchUID, "Found empty appeal value in the appealFile.xml file. Will be skipped");
																            	}
																            	
																            	
																            }
																            else
																            {
																            	theLogger.error(batchUID, "Found empty <appeal> node in the appealFile.xml file. Will be skipped");
																				
																            }
																		}
																		
																		appealsInFile = appealList.size();
																		if (appealsInFile > constantConfig.getMaxAppealsPerSettlementFile())
																		{
																			theLogger.error(batchUID, "Found too many appeals in the appealFile.xml file: " + appealsInFile + " vs. maximum number of appeals per file: " + constantConfig.getMaxAppealsPerSettlementFile());
																			
																			addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file contains: " + appealsInFile + " appeals. The maximum number of appeals per file is: " + constantConfig.getMaxAppealsPerSettlementFile());
																			
																			// UNRECOVERABLE ERROR
																			errCode = -19;
																		}
																	}
																	else
																	{
																		theLogger.error(batchUID, "Failed to parse the <appeal> nodes in the appealFile.xml file");
																		
																		addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																		
																		// UNRECOVERABLE ERROR
																		errCode = -16;
																	}
																}
																else
																{
																	theLogger.error(batchUID, "Could not find any <appeal> nodes in the appealFile.xml file");
																	
																	addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																	
																	// UNRECOVERABLE ERROR
																	errCode = -15;	
																}
															}
															else
															{
																theLogger.error(batchUID, "Root element in appealFile.xml file is not defined");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Root element in appealFile.xml file is not defined.");
																
																// UNRECOVERABLE ERROR
																errCode = -14;	
															}
																
 
														}
														catch (Exception xmlEx)
														{
															theLogger.error(batchUID, "Exception while readng data from appealFile.xml file: ", xmlEx);
															
															addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file is not a valid XML file.");
															
															// UNRECOVERABLE ERROR
															errCode = -12;
														}
													} // end pend
													else
													if (functionName.compareToIgnoreCase("un-pend") == 0)
													{
															// Extract appeals from appealData
															
															try
															{
																DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
																DocumentBuilder builder = factory.newDocumentBuilder();
																	 
																Document document = builder.parse(incomingAppealDataFile);
																
																Element root = document.getDocumentElement();
																root.normalize();
																	
																if (root != null)
																{
																	NodeList nodeList = document.getElementsByTagName("appeal");
																	
																	if (nodeList != null)
																	{
																		int numAppeals = nodeList.getLength();
																		
																		if (numAppeals > 0)
																		{
																			for (int nodeIdx = 0; nodeIdx < numAppeals; nodeIdx++) 
																			{
																				int adjNodeIdx = nodeIdx + 1;
																	            Node node = nodeList.item(nodeIdx);
																	            if (node != null)
																	            {	
																	            	Element appElement = (Element) node;

																	            	if (appElement != null)
																	            	{
																	            		if (appElement.getElementsByTagName("appealNumber") != null && appElement.getElementsByTagName("unpendDate") != null )
																	            		{
																	            			if (appElement.getElementsByTagName("appealNumber").item(0) != null && appElement.getElementsByTagName("unpendDate").item(0) != null )
																		            		{
																	            				String appealNumber = appElement.getElementsByTagName("appealNumber").item(0).getTextContent();
																	            				String appealDate = appElement.getElementsByTagName("unpendDate").item(0).getTextContent();
																	            				if (appealNumber != null && appealNumber.length() > 0 && appealDate != null && appealDate.length() > 0)
																				            	{
																	            					// validate Date
																	            					
																				            		appealList.add(appealNumber);
																				            		appealList.add(appealDate);
																				            	}
																				            	else // empty appeal number or dates
																				            	{
																				            		theLogger.error(batchUID, "Missing appealNumber or unpendDate values in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																									
																									addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or unpendDate values in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																				            	}
																		            		}
																	            			else // null appealnumber or date values
																	            			{
																	            				theLogger.error(batchUID, "Missing appealNumber or unpendDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																								
																								addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or unpendDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																	            			}
																	            		} else // null appealnumber or date
																	            		{
																	            			theLogger.error(batchUID, "Missing appealNumber or unpendDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																							
																							addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or unpendDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																	            		}
																	            	}
																	            	else // null appeal element
																	            	{
																	            		theLogger.error(batchUID, "Invalid <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																						
																						addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Invalid <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																	            	}
																	            	
 
																	            }
																	            else
																	            {
																	            	theLogger.error(batchUID, "Found empty <appeal> node in the appealFile.xml file. Will be skipped");
																					
																	            }
																			}
																			
																			appealsInFile = appealList.size() / 2; 
																			if (appealsInFile > constantConfig.getMaxAppealsPerSettlementFile())
																			{
																				theLogger.error(batchUID, "Found too many appeals in the appealFile.xml file: " + appealsInFile + " vs. maximum number of appeals per file: " + constantConfig.getMaxAppealsPerSettlementFile());
																				
																				addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file contains: " + appealsInFile + " appeals. The maximum number of appeals per file is: " + constantConfig.getMaxAppealsPerSettlementFile());
																				
																				// UNRECOVERABLE ERROR
																				errCode = -19;
																			}
																		}
																		else
																		{
																			theLogger.error(batchUID, "Failed to parse the <appeal> nodes in the appealFile.xml file");
																			
																			addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																			
																			// UNRECOVERABLE ERROR
																			errCode = -16;
																		}
																	}
																	else
																	{
																		theLogger.error(batchUID, "Could not find any <appeal> nodes in the appealFile.xml file");
																		
																		addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																		
																		// UNRECOVERABLE ERROR
																		errCode = -15;	
																	}
																}
																else
																{
																	theLogger.error(batchUID, "Root element in appealFile.xml file is not defined");
																	
																	addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Root element in appealFile.xml file is not defined.");
																	
																	// UNRECOVERABLE ERROR
																	errCode = -14;	
																}
																	
	 
															}
															catch (Exception xmlEx)
															{
																theLogger.error(batchUID, "Exception while readng data from appealFile.xml file: ", xmlEx);
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file is not a valid XML file.");
																
																// UNRECOVERABLE ERROR
																errCode = -12;
															}
													} // end unpend	
													else
													if (functionName.compareToIgnoreCase("enact") == 0)
													{
														// Extract appeals from appealData
														
														try
														{
															DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
															DocumentBuilder builder = factory.newDocumentBuilder();
																 
															Document document = builder.parse(incomingAppealDataFile);
															
															Element root = document.getDocumentElement();
															root.normalize();
																
															if (root != null)
															{
																NodeList nodeList = document.getElementsByTagName("appeal");
																
																if (nodeList != null)
																{
																	int numAppeals = nodeList.getLength();
																	
																	if (numAppeals > 0)
																	{
																		for (int nodeIdx = 0; nodeIdx < numAppeals; nodeIdx++) 
																		{
																			int adjNodeIdx = nodeIdx + 1;
																            Node node = nodeList.item(nodeIdx);
																            if (node != null)
																            {	
																            	Element appElement = (Element) node;

																            	if (appElement != null)
																            	{
																            		if (appElement.getElementsByTagName("appealNumber") != null && appElement.getElementsByTagName("enactDate") != null )
																            		{
																            			if (appElement.getElementsByTagName("appealNumber").item(0) != null && appElement.getElementsByTagName("enactDate").item(0) != null )
																	            		{
																            				String appealNumber = appElement.getElementsByTagName("appealNumber").item(0).getTextContent();
																            				String appealDate = appElement.getElementsByTagName("enactDate").item(0).getTextContent();
																            				if (appealNumber != null && appealNumber.length() > 0 && appealDate != null && appealDate.length() > 0)
																			            	{
																            					// validate Date
																            					
																			            		appealList.add(appealNumber);
																			            		appealList.add(appealDate);
																			            	}
																			            	else // empty appeal number or dates
																			            	{
																			            		theLogger.error(batchUID, "Missing appealNumber or enactDate values in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																								
																								addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or enactDate values in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																			            	}
																	            		}
																            			else // null appealnumber or date values
																            			{
																            				theLogger.error(batchUID, "Missing appealNumber or enactDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																							
																							addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or enactDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																            			}
																            		} else // null appealnumber or date
																            		{
																            			theLogger.error(batchUID, "Missing appealNumber or enactDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																						
																						addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Missing appealNumber or enactDate in the <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																            		}
																            	}
																            	else // null appeal element
																            	{
																            		theLogger.error(batchUID, "Invalid <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal will not be processed.");
																					
																					addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Invalid <appeal> element no. " + adjNodeIdx + " in the appealFile.xml file. This appeal was not processed."); 
																            	}
																            	

																            }
																            else
																            {
																            	theLogger.error(batchUID, "Found empty <appeal> node in the appealFile.xml file. Will be skipped");
																				
																            }
																		}
																		
																		appealsInFile = appealList.size() / 2; 
																		if (appealsInFile > constantConfig.getMaxAppealsPerSettlementFile())
																		{
																			theLogger.error(batchUID, "Found too many appeals in the appealFile.xml file: " + appealsInFile + " vs. maximum number of appeals per file: " + constantConfig.getMaxAppealsPerSettlementFile());
																			
																			addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file contains: " + appealsInFile + " appeals. The maximum number of appeals per file is: " + constantConfig.getMaxAppealsPerSettlementFile());
																			
																			// UNRECOVERABLE ERROR
																			errCode = -19;
																		}
																	}
																	else
																	{
																		theLogger.error(batchUID, "Failed to parse the <appeal> nodes in the appealFile.xml file");
																		
																		addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																		
																		// UNRECOVERABLE ERROR
																		errCode = -16;
																	}
																}
																else
																{
																	theLogger.error(batchUID, "Could not find any <appeal> nodes in the appealFile.xml file");
																	
																	addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any <appeal> nodes in the appealFile.xml file.");
																	
																	// UNRECOVERABLE ERROR
																	errCode = -15;	
																}
															}
															else
															{
																theLogger.error(batchUID, "Root element in appealFile.xml file is not defined");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Root element in appealFile.xml file is not defined.");
																
																// UNRECOVERABLE ERROR
																errCode = -14;	
															}
																
 
														}
														catch (Exception xmlEx)
														{
															theLogger.error(batchUID, "Exception while readng data from appealFile.xml file: ", xmlEx);
															
															addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The appealFile.xml file is not a valid XML file.");
															
															// UNRECOVERABLE ERROR
															errCode = -12;
														}
													} // end enact	
													
													
													else
													{
														theLogger.error(batchUID, "The function " + functionName + " specified in the manifest file " + incomingManifestFile + " is not valid");
														
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The function " + functionName + " specified in the manifest file is not valid.");
														
														// UNRECOVERABLE ERROR
														errCode = -11;
													}

												}
												else
												{
													// checksum does not match
													theLogger.error(batchUID, "Provided checksum " + appealFileChecksum + " for appealFile.xml file does not match the actual checksum of the file: " + realChecksum);
													
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Provided checksum " + appealFileChecksum + " for appealFile.xml file does not match the actual checksum of the file: " + realChecksum);
													
													// UNRECOVERABLE ERROR
													errCode = -10;
												}
												
												
												if (errCode == 0)
												{
													if (appealList.size() > 0)
													{
														// Call Siebel based on function name
														processedAppeals = appealsInFile;
														
														if (functionName.compareToIgnoreCase("pend") == 0)
														{
															SettlementSiebelResponse siebelResponse = siebelService.settlementPend(consumerId,settlementIndicator, appealList, "", batchUID);
															
															siebelCalled = true;
															
															settlementFilePrefix = siebelResponse.filePrefix;
															
															// Write Siebel response to manifest file
															if (siebelResponse.status == 0)
															{
																// everything ok
																
																settlementFilePrefix = siebelResponse.filePrefix;
																
																theLogger.debug(batchUID, "All " + processedAppeals + " appeals in the " + baseFileName + " file have been pended successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "All " + processedAppeals + " appeals in the " + baseFileName + " file have been pended successfully.");
																
																errCode = 0;
															} 
															else
															{
																// some error
																
																theLogger.error(batchUID, "Some or all of the " + processedAppeals + " appeals in the " + baseFileName + " file have NOT been pended successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  siebelResponse.errCode + ": " + siebelResponse.errMsg);
																
																
																errCode = -17;
																
															}
																
														}
														else if (functionName.compareToIgnoreCase("un-enact") == 0)
														{
															SettlementSiebelResponse siebelResponse = siebelService.settlementUnenact(consumerId, appealList, "", batchUID);
															
															siebelCalled = true;
															settlementFilePrefix = siebelResponse.filePrefix;
															
															// Write Siebel response to manifest file
															if (siebelResponse.status == 0)
															{
																// everything ok
																
																settlementFilePrefix = siebelResponse.filePrefix;
																
																theLogger.debug(batchUID, "All " + processedAppeals + " appeals in the " + baseFileName + " file have been un-enacted successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "All " + processedAppeals + " appeals in the " + baseFileName + " file have been un-enacted successfully.");
																
																errCode = 0;
															} 
															else
															{
																// some error
																
																theLogger.error(batchUID, "Some or all of the " + processedAppeals + " appeals in the " + baseFileName + " file have NOT been un-enacted successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  siebelResponse.errCode + ": " + siebelResponse.errMsg);
																
																
																errCode = -17;
																
															}
																
														}
														else if (functionName.compareToIgnoreCase("un-pend") == 0)
														{
															SettlementSiebelResponse siebelResponse = siebelService.settlementUnpend(consumerId, appealList, "", batchUID);
															
															siebelCalled = true;
															
															settlementFilePrefix = siebelResponse.filePrefix;
															
															// Write Siebel response to manifest file
															if (siebelResponse.status == 0)
															{
																// everything ok
																settlementFilePrefix = siebelResponse.filePrefix;
																
																theLogger.debug(batchUID, "All " + processedAppeals + " appeals in the " + baseFileName + " file have been un-pended successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "All " + processedAppeals + " appeals in the " + baseFileName + " file have been un-pended successfully.");
																
																errCode = 0;
															} 
															else
															{
																// some error
																
																theLogger.error(batchUID, "Some or all of the " + processedAppeals + " appeals in the " + baseFileName + " file have NOT been un-pended successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  siebelResponse.errCode + ": " + siebelResponse.errMsg);
																
																
																errCode = -17;
																
															}
																
														}
														else if (functionName.compareToIgnoreCase("enact") == 0)
														{
															SettlementSiebelResponse siebelResponse = siebelService.settlementEnact(consumerId, appealList, "", batchUID);
															
															siebelCalled = true;
															settlementFilePrefix = siebelResponse.filePrefix;
															
															// Write Siebel response to manifest file
															if (siebelResponse.status == 0)
															{
																// everything ok
																
																settlementFilePrefix = siebelResponse.filePrefix;
																
																theLogger.debug(batchUID, "All " + processedAppeals + " appeals in the " + baseFileName + " file have been enacted successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  "All " + processedAppeals + " appeals in the " + baseFileName + " file have been enacted successfully.");
																
																errCode = 0;
															} 
															else
															{
																// some error
																
																theLogger.error(batchUID, "Some or all of the " + processedAppeals + " appeals in the " + baseFileName + " file have NOT been enact successfully.");
																
																addTextToManifestFile(batchUID, manifestFolder.toString(),  siebelResponse.errCode + ": " + siebelResponse.errMsg);
																
																
																errCode = -17;
																
															}
																
														} 
														
													}
													else
													{
														theLogger.error(batchUID, "Could not find any valid appeal numbers in the appealFile.xml file");
														
														addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not find any valid appeal numbers in the appealFile.xml file.");
														
														// UNRECOVERABLE ERROR
														errCode = -13;
													}
												}
												
												
												

												
												  
											} // if manifest file loaded ok...error is already logged otherwise
											
										}
										else
										{
											theLogger.error(batchUID, "Zip settlement file: " + filePath + " does not include the manifest.txt or appealFile.xml data file");
											
											addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The " + baseFileName + " settlement file does not include the manifest.txt or appealFile.xml file");
											
											
											// UNRECOVERABLE ERROR
											errCode = -4;
										}
									}
									else
									{
										theLogger.error(batchUID, "Failed to extract settlement zip file: " + filePath);
										
										addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The  " + baseFileName + " settlement file was not recognized as a valid ZIP file.");
										
										// UNRECOVERABLE ERROR
										errCode = -3;
									}
								}
								else
								{	
									theLogger.error(batchUID, "Failed to create settlement manifest file in folder: " + manifestFolder.toString());
								
									// RECOVERABLE ERROR
									errCode = 3;
								}
								
								// delete ZIP folder
								Util.deleteDirectory(settlementFolder.toString());
								
							} 
							else
							{	
								theLogger.error(batchUID, "Settlement manifest directory  could not be created: " + manifestFolder.toString());
								
								// no point to add error to manifest since it could not be created
								// addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
								// RECOVERABLE ERROR
								errCode = 3;
							}
						}
						else
						{
							theLogger.error(batchUID, "Settlement unzip directory  could not be created: " + settlementFolder.toString());
							
							addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
							// RECOVERABLE ERROR
							errCode = 2;
						}
						
						
						// CLEANUP HERE AND MOVE FILE !!!!!!!!
						
						if (errCode == 0)
						{
							// DELETE ORIGINAL FILE
							Util.deleteFile(filePath);
						}
						else
						{
							// rename file 
							if (errCode != -100) // 2 JVMs processing the same file
							{
								String originalFileName = filePath;
								originalFileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
								String errorFileName = originalFileName + "." + ProviderConstants.FAILED_EXTENSION;
								
								
								File originalFile = new File(filePath);
								File renameFile = new File(errorFileName);				
								if(originalFile.renameTo(renameFile)) 
								{
									// ok
								} 
								else
								{
									theLogger.error(batchUID, "Failed to rename settlement locked file: " + originalFileName + " to error file: " + errorFileName);
									
									// UNRECOVERABLE ERROR
								}
								
								
							} 
							else
							{
								// another JVM already processing this file
								Util.deleteFile(filePath);
								Util.deleteDirectory(manifestFolder.toString());
								
								continue;
							}
						}
						
						
						
						if ( settlementFilePrefix != null && settlementFilePrefix.length() > 0)
						{
							
							
							
							
						// create signature file for manifest file
			             
						FileOutputStream sigfos = null;
						try
						{						    
							//theLogger.debug(batchUID, "Generating settlement signature file...");
							
							
							String keyStoreFile =  constantConfig.getKeystoreName();
						    String password = constantConfig.getKeystorePassword();
						    String alias = constantConfig.getKeyAlias(); 
						    String keyPassword = constantConfig.getKeyPassword();
							
							KeyStore keystore = KeyStore.getInstance("JKS");  
				            char[] storePass = password.toCharArray();  
				            char[] keyPasswd = keyPassword.toCharArray(); 
				  
				            //load the key store from file system  
				            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
				            keystore.load(fileInputStream, storePass);  
				            fileInputStream.close();  
				  
				             
				            //read the private key  
				            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
				            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
				            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
				  
				            //initialize the signature with signature algorithm and private key  
				            Signature signature = Signature.getInstance("SHA256withRSA");  
				            signature.initSign(privateKey);  
				            
				            String manifestFilename = manifestFolder.toString() + "/manifest.txt";
				
				            FileInputStream fis = new FileInputStream(manifestFilename);
				            BufferedInputStream bufin = new BufferedInputStream(fis);
				            byte[] buffer = new byte[10000];
				            int len;
				            while ((len = bufin.read(buffer)) >= 0) {
				            	signature.update(buffer, 0, len);
				            };
				            bufin.close();

				            byte[] digitalSignature = signature.sign();

							String signatureFilename = manifestFolder.toString() + "/signature.txt";

							sigfos = new FileOutputStream(signatureFilename);
						    sigfos.write(digitalSignature);
						    sigfos.close(); 
						    
						    theLogger.debug(batchUID, "Signature file settlement generated: " + signatureFilename);
						}
						catch (Exception ioe)
						{
							Util.deleteDirectory(manifestFolder.toString());
							
							theLogger.error(batchUID, "Exception while writing settlement signature file: " + ioe.getMessage());
							
							errCode = 10;
							
							int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(batchUID, "Java settlement process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}
							
						}
						finally 
						{
							if (sigfos != null)
							{
								sigfos.close();
								sigfos = null;
							}
						}
					
						
						// ZIP and move manifest file to EFT
						
						StringBuilder compressFilePath = new StringBuilder();		
						compressFilePath.append(tempDirectoryBuilder.toString());
						compressFilePath.append(randomUniqueString);
						compressFilePath.append("_");
						compressFilePath.append(Util.getCurrentTimeStamp());
						compressFilePath.append(".zip");
						
						errCode =  Util.compressFilesInFolder(manifestFolder.toString(), compressFilePath.toString(), batchUID);
						if (errCode == 0)
						{
							theLogger.debug(batchUID, "Compressed settlement manifest file to: " + compressFilePath.toString());

							// delete manifest file and folder
							Util.deleteDirectory(manifestFolder.toString());
							
							
							StringBuilder eftFileLocation = new StringBuilder(constantConfig.getEftLocation());	
							eftFileLocation.append("/");
							
							eftFileLocation.append(constantConfig.getEftFilePrefix());
							eftFileLocation.append("#EFT.ON.");
							eftFileLocation.append(settlementFilePrefix);
							//eftFileLocation.append(".");
							//eftFileLocation.append(constantConfig.getSettlementOutFilePrefix());
							eftFileLocation.append(".");
							eftFileLocation.append(constantConfig.getEftOrgName());
							eftFileLocation.append(".D");
							
							//DYYMMDD.THHMMSST   
							
							Date rightNow = new Date();
							String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
							String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
							
							eftFileLocation.append(dateStamp);	
							eftFileLocation.append(".T");
							eftFileLocation.append(timeStamp);
							
							String destFile = eftFileLocation.toString();
							boolean fileNameAvailable = false;
							for (int fidx = 0;  fidx <= 9; fidx++)
							{
								String tryFileName = destFile + fidx;
								 
								File f = new File(tryFileName);
								if(f.exists() == false)
								{
									//destFile = tryFileName;
	
									theLogger.debug(batchUID, "Copying settlement manifest ZIP file : " + compressFilePath.toString() + " to EFT: " + tryFileName);
									
									errCode =  Util.copyFile(compressFilePath.toString(), tryFileName);
									if (errCode != 0)
									{
										theLogger.error(batchUID, "Try " + fidx + ": Error while copying settlement compressed appeal file to EFT folder: " + tryFileName);
										//return errCode;
									}
									else
									{
										theLogger.debug(batchUID, "Copied settlement compressed file to EFT folder: " + tryFileName);
										fileNameAvailable = true;
										break;
									}
	
								}
								
							}
							
							if (fileNameAvailable == true)
							{	
								// Delete compressed manifest ZIP File
								errCode =  Util.deleteFile(compressFilePath.toString());
								if (errCode == 0)
								{
									theLogger.debug(batchUID, "Deleted compressed settlement manifest file: " + compressFilePath.toString());
									
									// ALL DONE!!!!!!!!!!!!!!!
								}
								else
								{
									theLogger.error(batchUID, "Error while deleting compressed settlement manifest file: " + compressFilePath.toString() );
									
									// RECOVERABLE ERROR
									errCode = 7;
								}
							}
							else
							{
								theLogger.error(batchUID, "Could not find available file name on EFT for settlement manifest file: " + destFile);
								
								// RECOVERABLE ERROR
								errCode = 8;
								
								
								int failedAppeals = theLogger.incrementFailedAppeals();
								if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
								{
									theLogger.debug(batchUID, "Java settlement process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
								}
								
							}

						}
						else
						{
							theLogger.error(batchUID, "Error while compressing settlement manifest folder: " + manifestFolder.toString() + " to: " + compressFilePath.toString());
						
							// RECOVERABLE ERROR
							errCode = 6;
							
							int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(batchUID, "Java settlement process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}
							
						}
						}
						else
						{
							// settlementFilePrefix is null or empty
							
							theLogger.error(batchUID, "Could not get a value for the settlementFilePrefix from Siebel, so no output ZIP file was generated for the client for the received file:  " + selFileName  );
							 
							
						}


					}
					else // null file path; 
					{
						// error was already logged
						continue;
					}
				}
				else
				{
					theLogger.error(batchUID, "Found empty or null filename in the list of settlement files to be processed." );
					
					// this should never happen
				}
				
				
				// UPDATE SIEBEL WITH SUCCESS
				
				if (errCode == 0)
				{
					succesfullFiles++;
				}
				else
				{
					if (siebelCalled == true)
					{
						String errCodeStr = "J-" + errCode;
					
						siebelService.updateTransactionStatus(batchUID, "Error", errCodeStr , "Failed to deliver manifest file via EFT", null, null);
					}
				}

				
			} // end FOR loop
			
			
		} catch (Exception e) {
			theLogger.error(batchUID, "Exception while processing settlement batch: " + e.getMessage() );
			
			//errCode  = -1;
			
			//siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while closing appeal in Level3WS", null);
			
		} finally {
			theLogger.performanceStartOnly(batchUID, "Processed " + succesfullFiles  + " settlement files from the batch of " + processedFiles + " files.", startTime);

			theLogger.debug(batchUID, "Processed " + succesfullFiles  + " settlement files from the batch of " + processedFiles + " files.");
		}
		
		return succesfullFiles;
	}
	
 
	private String checkFile(long batchUID, String fileUri)
	{
		//int fileStatus = 0;
		
		try
		{
			URL url = new URL(fileUri);
			URI uri = url.toURI();
			
			File file = new File(uri);
			
			if (file.exists()) 
			{
				String fileName = file.getName();
				//String firstLetter = fileName.substring(0,1).toUpperCase();
				
				boolean filenameok = false;
				ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getSettlementInFilePrefix().split(",")));
				for (int idx = 0; idx < filePrefixList.size(); idx++)
				{
					
						if (fileName.startsWith(filePrefixList.get(idx))) 
						{
							filenameok = true;
							break;
						}
					}
							
				
				
				//if(constantConfig.getPrefixTIBCOName().contains(firstLetter)) 
				if (filenameok == true)
				{
					long fileModified = file.lastModified();
					
					long transferTimeLimit = (System.currentTimeMillis() - constantConfig.getDelayTransfer());
					
					if(fileModified < transferTimeLimit)
					{
						String extension = FilenameUtils.getExtension(fileName);
						if(extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)) 
						{
							theLogger.error(batchUID, "File already locked : " + fileUri );
							//fileStatus = -5;
						}		
						else
						{
							File renameFile = new File(file.getPath() + "." + ProviderConstants.LOCK_EXTENSION);				
							if(file.renameTo(renameFile)) 
							{
								theLogger.debug(batchUID, "Picked and renamed file for settlement: " + fileUri );
								//fileStatus = 0;
								// OK HERE return renamed file
								return renameFile.getPath();
								
							} else {
								theLogger.error(batchUID, "Failed to rename (lock) file : " + fileUri );
								//fileStatus  = -4;
							}	
						}
					} else {
						theLogger.debug(batchUID, "File is still transferring, skipping for now: " + fileUri );
						//fileStatus  = -3;
					}
				} else {
					theLogger.debug(batchUID, "File is not part of the close appeal filename schema: " + fileUri );
					//fileStatus  = -2;
				}
	
			}
			else
			{
				theLogger.error(batchUID, "File does not exist: " + fileUri );
				//fileStatus  = -2;
			}
		}
		catch (Exception ex)
		{
			theLogger.error(batchUID, "Exception while getting file information for file: " + fileUri, ex);
			//fileStatus = -1;
		}
		
		return null;
	}
	
	 
	private int addTextToManifestFile(long transactionId, String manifestFolder, String message)
	{
		int errCode = 0;
		
		FileWriter fw = null;
		try
		{
			String manifestFilename = manifestFolder + "/manifest.txt";
		    fw = new FileWriter(manifestFilename, true);  
		    fw.write(message);
		    fw.write("\r\n================================================================\r\n");
		}
		catch (Exception ioe)
		{
			theLogger.error(transactionId, "Exception while adding settlement data to manifest file: " + ioe.getMessage());
			
			// RECOVERABLE ERROR
			errCode = 4;
		}
		finally 
		{
			if (fw != null)
			{
				try
				{
					fw.close();
					fw = null;
				} catch (Exception clex)
				{
					fw = null;
				}
			}
		}
		
		return errCode;
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
}
