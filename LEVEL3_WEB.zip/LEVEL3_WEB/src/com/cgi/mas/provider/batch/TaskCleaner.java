package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.util.Util;

@Service("taskCleaner")
public class TaskCleaner {
	private CustomLogger theLogger = new CustomLogger(TaskCleaner.class);
	
	@Autowired
	private ConstantConfig constantConfig;
	
	public void cleanOldFiles()             
	{
		long batchUID = theLogger.generateUID();
		theLogger.debug(batchUID, "Running Scheduled Cleanup Task  to delete files older than " + constantConfig.getExpiredDay() + " milliseconds");
		
		List<File> fileCol = getExpiredFile(batchUID);
		
		if(fileCol.size() > 0) 
		{
			theLogger.debug(batchUID, "About to delete " + fileCol.size() + " failed validation files");
		}
		
		for (File file : fileCol){
			if (file.delete())
			{
				theLogger.debug(batchUID, "File: " + file.getName() + " --- DELETED");
			}
			else
			{
				theLogger.error(batchUID, "File: " + file.getName() + " --- FAILED TO DELETE");
			}
		}
		
		if(fileCol.size() > 0) 
		{
			theLogger.debug(batchUID, "Deleted " + fileCol.size() + " failed validation files");
		}
	}
 
	
	public List<File> getExpiredFile(long batchUID) {
		long expiredTime = constantConfig.getExpiredDay();
		
		List<File> expiredFileCol = new ArrayList<File>();
		File dir = new File(constantConfig.getIncomingEftLocation());
		
		long start = System.currentTimeMillis();
		long countDownTime = start - expiredTime;
		Calendar countDownCalendar = Calendar.getInstance();
		countDownCalendar.setTimeInMillis(countDownTime);
		
		Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		
		StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("Files before ");
			strBuilder.append(Util.convertCalendarToString(countDownCalendar, "MM/dd/yyyy HH:mm:ss"));
			strBuilder.append(" will be deleted");
			theLogger.debug(batchUID, strBuilder.toString());
			
			ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getFileprefixName().split(",")));
			
		    AndFileFilter andFileFilter = new AndFileFilter(
												new SuffixFileFilter(ProviderConstants.FAILED_VALIDATION_EXTENSION, IOCase.INSENSITIVE),
												new PrefixFileFilter(filePrefixList));		
		Collection<File>fileCol = FileUtils.listFiles(dir, andFileFilter, null);
			
		
		for (File file : fileCol) {
			String fileName = file.getName();
			Matcher mat = pat.matcher(fileName);
			if (mat.find()) {
				//String prefixName = fileName.substring(0, 1);
				//if (constantConfig.getEftClosePrefix().contains(prefixName)) {
					String timeStampVal = mat.group(0);
					timeStampVal = timeStampVal.replaceAll("[A-z]", "");
					Calendar fileCalender = Util.convertStringToCalendar(timeStampVal, "yyMMdd.HHmmssS");
					if (fileCalender.before(countDownCalendar)) {
						expiredFileCol.add(file);
					}
				//}
			}
		}
		
		return expiredFileCol;
	}

}