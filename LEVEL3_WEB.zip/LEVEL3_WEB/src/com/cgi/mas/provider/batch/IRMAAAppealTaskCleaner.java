package com.cgi.mas.provider.batch;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.SiebelService;
import com.cgi.mas.provider.util.Util;
import com.siebel.customui.GetCMLoginDetailsOutput;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.Appeal;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.EcmDocument;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfDocumentsIO;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.ListOfEcmDocuments;

@Service("irmaaTaskCleaner")
public class IRMAAAppealTaskCleaner {
	private CustomLogger theLogger = new CustomLogger(IRMAAAppealTaskCleaner.class);
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private IECMService ecmService;
	
	@Autowired
	private SiebelService siebelService;
	
	public void cleanOldIRMAAFiles()             
	{
		long batchUID = theLogger.generateUID();
		theLogger.debug(batchUID, "Running Scheduled Cleanup Task  to delete files older than " + constantConfig.getIrmaaExpiredDay() + " milliseconds");
		
		List<File> fileCol = getExpiredFile(batchUID);
		
		if(fileCol.size() > 0) 
		{
			theLogger.debug(batchUID, "About to delete " + fileCol.size() + " IRMAA Appeals");
		}
		else{
			theLogger.debug(batchUID, "No Files found to delete which are older than " + constantConfig.getIrmaaExpiredDay() + " milliseconds");	
		}
		for (File file : fileCol){
			//first delete the files in ECM	
			//get appeal Number and TransactionId from Manifest File.
			Properties manifestProps = getManifestProps(file,batchUID);
			String appealNumber = manifestProps.getProperty("AppealNumber");
			String transactionId = manifestProps.getProperty("TransactionId");
			List<String> documentList = new ArrayList<String>();
			int errCode = 0;
			String appealNum = "";
			long appealTransactionId = 0;
			int ecmIndex = 0;
			String ecmUsername = "";
			String ecmPassword = "";
			
			GetCMLoginDetailsOutput output= siebelService.getCMAppealDetails(appealNumber,new Long(transactionId));
			
			if (output != null)
			{
				ListOfDocumentsIO docsList = output.getListOfDocumentsIO();
				if (docsList != null)
				{
					
					List<Appeal> appeals = docsList.getAppeal();
					if (appeals != null && appeals.size() == 1)
					{
						Appeal appeal = appeals.get(0);
						
						if (appeal != null)
						{
							try
							{
								
								 appealNum = appeal.getAppealNumber();
								// appealTransactionId = Long.valueOf(appeal.getTransactionId()).longValue();
								 ecmIndex = Integer.valueOf(appeal.getECMIndex()).intValue(); 
								
								
								 ecmUsername =   appeal.getECMUserName();
								 ecmPassword =   appeal.getECMPassword();
								ListOfEcmDocuments ecmDocsContainer = appeal.getListOfEcmDocuments();
								if (ecmDocsContainer != null)
								{
									List<EcmDocument> ecmDocs = ecmDocsContainer.getEcmDocument();
									
									if (ecmDocs != null)
									{
										for (int ecmIdx = 0; ecmIdx < ecmDocs.size(); ecmIdx++)
										{
											EcmDocument ecmDoc = ecmDocs.get(ecmIdx);
											if (ecmDoc != null)
											{
												String ecmId = ecmDoc.getDocECMId();
												if (ecmId != null)
												{
													documentList.add(ecmId);
												}
											}
										}
									}
								}}
							catch (Exception ex)
							{
								
								theLogger.error(batchUID, "Exception while retrieving the values returned by the  Siebel web service to process the appeal documents: " + ex.getMessage() );
								
								errCode  = -1;
							}
							
						}}}
								
			//make sure the data we imported is the data we delete
			try{
				if(documentList.size()>0 && appealNumber.equals(appealNum)){
				errCode =ecmService.deleteDoc(appealNumber, new Long(transactionId), ecmUsername, ecmPassword, documentList,file);
			}}
				catch(Exception e){
					theLogger.debug(batchUID, "Exception in Deleting the ECM Doc for IRMAATaskCleaner");
					errCode=-1;
				}
				
				
			
			if(errCode<0){
				theLogger.debug(batchUID, "Exception in Deleting the ECM Doc for IRMAATaskCleaner");
				siebelService.updateTransactionStatus(new Long(transactionId),
						"Delete Failure", Integer.toString(errCode),
						"Error while Deleting IRMAA Appeal",
						null, null);
					}
			else{
				if(errCode==0){
					try{
					if (file.delete())
					{
						theLogger.debug(new Long(transactionId), "File: " + file.getName() + " --- DELETED FROM EFT IRMAA PATH");
					}
					else
					{
						theLogger.debug(new Long(transactionId), "File: " + file.getName() + " --- FAILED TO DELETE FROM EFT IRMAA PATH");
					}
					
					siebelService.updateTransactionStatus(new Long(transactionId),
							"Delete Success", Integer.toString(errCode),
							"Delete Success",
							null, null);
				
				}	
				
				catch(Exception e){
					theLogger.debug(batchUID, "Exception in Deleting the Appeal FROM EFT IRMAA PATH");
					errCode=-1;
			}
				}
				
		
		}}}
			
		}
	
 
	
	public List<File> getExpiredFile(long batchUID) {
		long expiredTime = constantConfig.getIrmaaExpiredDay();
		
		List<File> expiredFileCol = new ArrayList<File>();
		File dir = new File(constantConfig.getEftIRMAAAppealFilePath());
		
		long start = System.currentTimeMillis();
		long countDownTime = start - expiredTime;
		Calendar countDownCalendar = Calendar.getInstance();
		countDownCalendar.setTimeInMillis(countDownTime);
		
		Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		
		StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("Files before ");
			strBuilder.append(Util.convertCalendarToString(countDownCalendar, "MM/dd/yyyy HH:mm:ss"));
			strBuilder.append(" will be deleted");
			theLogger.debug(batchUID, strBuilder.toString());
			
			final String filePrefix = 	constantConfig.getEftFilePrefix()+constantConfig.getEftIRMAAAppealFilePrefix();
			
			File[] foundFiles = dir.listFiles(new FilenameFilter() {
			    public boolean accept(File dir, String name) {
			        return name.startsWith(filePrefix);
			    }
			});
		
		for (File file : foundFiles) {
			
			String fileName = file.getName();
			Matcher mat = pat.matcher(fileName);
			if (mat.find()) {
				//String prefixName = fileName.substring(0, 1);
				//if (constantConfig.getEftClosePrefix().contains(prefixName)) {
					String timeStampVal = mat.group(0);
					timeStampVal = timeStampVal.replaceAll("[A-z]", "");
					Calendar fileCalender = Util.convertStringToCalendar(timeStampVal, "yyMMdd.HHmmssS");
					if (fileCalender.before(countDownCalendar)) {
						expiredFileCol.add(file);
					}
				//}
			}
		}
		
		return expiredFileCol;
	}

	
	public Properties getManifestProps(File file,long transactionId){
		
		String randomUniqueString = UUID.randomUUID().toString();
		Properties manifestProps = new Properties();
		InputStream manifestStream = null;
		StringBuilder tempDirectoryBuilder = new StringBuilder();
		tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
		tempDirectoryBuilder.append("/");
		StringBuilder closeAppealFolder  = new StringBuilder(tempDirectoryBuilder.toString());
		closeAppealFolder.append(randomUniqueString);
		closeAppealFolder.append("_");
		closeAppealFolder.append(Util.getCurrentTimeStamp());
		theLogger.debug(transactionId, " Temp IRMAA Appeal  directory: " + closeAppealFolder.toString());
		
		boolean zipOk = Util.extractZipToFolder(file.getPath(), closeAppealFolder.toString());
		
		if (zipOk == true)
		{
			// Check that it has manifest and appeal data
			
			
			String incomingManifestFileName = new File(closeAppealFolder.toString()).listFiles()[0] + "/manifest.txt";
			
			File incomingManifestFile = new File(incomingManifestFileName);
			
			if (incomingManifestFile.exists())
			{
				// Read manifest file
				try 
				{
					manifestStream = new FileInputStream(incomingManifestFile);
					manifestProps.load(manifestStream);
				}
				catch(Exception e){
					theLogger.debug(transactionId, " Exception when zipping"+e);
				}
			}}

		return manifestProps;
		
	}
}