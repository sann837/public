package com.cgi.mas.provider.batch;


import java.util.HashMap;
import java.util.Map;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import com.cgi.mas.provider.logger.CustomLogger;


public class AppealPartitioner implements Partitioner {
	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String PARTITION_KEY = "partition";
	 
	private int totalMaxAppeals;
	private int totalSiebelAppeals;
	private long batchUID;
	
	private CustomLogger theLogger = new CustomLogger(AppealPartitioner.class);

	
	public int getTotalMaxAppeals() {
		return totalMaxAppeals;
	}

	public void setTotalMaxAppeals(int totalMaxAppeals) {
		this.totalMaxAppeals = totalMaxAppeals;
	}

	public int getTotalSiebelAppeals() {
		return totalSiebelAppeals;
	}

	public void setTotalSiebelAppeals(int totalSiebelAppeals) {
		this.totalSiebelAppeals = totalSiebelAppeals;
	}
 
	public long getbatchUID() {
		return batchUID;
	}

	public void setbatchUID(long batchUID) {
		this.batchUID = batchUID;
	}

	
	@Override
	public Map<String, ExecutionContext> partition(int gridSize){

		theLogger.debug(batchUID, "Creating partition for " + totalSiebelAppeals + "  appeals for grid size: " + gridSize);
		
		Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>();
			
		int numThreads = gridSize;		 
		if (gridSize > totalSiebelAppeals)
		{
			numThreads = totalSiebelAppeals;
		}
		//theLogger.debug(batchUID, "Number of threads to be created: " + numThreads);
		
		int maxAppealsPerThread = 1;
		if (totalSiebelAppeals > gridSize)
		{
			maxAppealsPerThread = totalSiebelAppeals / gridSize;			
			if (maxAppealsPerThread > totalMaxAppeals)
			{
				maxAppealsPerThread = totalMaxAppeals;
			}
		}
		//theLogger.debug(batchUID, "Maximum appeals per thread: " + maxAppealsPerThread);
				
		for (int index=0; index<numThreads; index++) {
 	
			ExecutionContext context = new ExecutionContext();
 
			context.putInt(MAX_APPEALS, maxAppealsPerThread);
			context.putLong(BATCH_UID, batchUID);
			context.putString(THREAD_NAME, "Thread" + index);
			
			map.put(PARTITION_KEY + index, context);	
		}	
		
		return map;
 	}

}
