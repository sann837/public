package com.cgi.mas.provider.batch;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
//import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;
//import org.apache.commons.lang.RandomStringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
 
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
 
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.CustomLogger;

import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.ClosingAppeal;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ReceivedFileDto;
import com.cgi.mas.provider.util.Util;
import com.siebel.customui.CloseAppealInput;
import com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocument;
import com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocuments;
import com.siebel.xml.mas_20l3_20svc_20close_20io.EcmDocument;
import com.siebel.xml.mas_20l3_20svc_20close_20io.EcmDocuments;
import com.siebel.xml.mas_20l3_20svc_20close_20io.ListOfMasL3SvcCloseIo;
import com.siebel.xml.mas_20l3_20svc_20ecm_20documents.Appeal;




import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventLocator;
import javax.xml.bind.util.ValidationEventCollector;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

public class AppealCloser implements Tasklet {
	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String DEFAULT_KEY_NAME = "fileName";
 
	private static CustomLogger theLogger = new CustomLogger(AppealCloser.class);
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelService siebelService;
	
	@Autowired
	private IECMService ecmService;
	
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception 
    {
    	long batchUID = 0;
    	
    	try
    	{
	    	ExecutionContext context = chunkContext.getStepContext().getStepExecution().getExecutionContext();
	    	
	    	int maxAppealsPerThread = context.getInt(MAX_APPEALS);
			batchUID = context.getLong(BATCH_UID);
			String threadId = context.getString(THREAD_NAME);
			
			
			ArrayList<String> fileList = (ArrayList<String>) context.get(DEFAULT_KEY_NAME);
			
			if (fileList != null && fileList.size() > 0)
			{
				theLogger.debug(batchUID, "Starting task " + threadId + " to close up to " + maxAppealsPerThread + " appeals");
	    	
				runDataImport(batchUID, maxAppealsPerThread, fileList);
			}
			else
			{
				theLogger.error(batchUID, "No close appeal files received by the thread for processing. This can happen if other threads allready processed the files.");
			}
    	}
    	catch (Exception ex)
    	{
    		theLogger.error(batchUID, "Exception in job scheduler.", ex);
    	}
		
		return RepeatStatus.FINISHED;
	}
    


	
	private int runDataImport(long batchUID, int maxAppealsPerThread, ArrayList<String> fileList) 
	{	
		int processedAppeals = 0;
		int closedAppeals = 0;
		
		long startTime = System.currentTimeMillis();
		
		try
		{	
			// GET THE ROOT CLOSE DIRECTORY
			
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
			tempDirectoryBuilder.append("/");
			
			//theLogger.debug(transactionId, "Root close directory: " + tempDirectoryBuilder.toString());
			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(batchUID, "Root close directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
				
				// RECOVERABLE ERROR
				return -1;
			}
			
			// Run this as long as we have files to process

			for (int fileIdx = 0; fileIdx < fileList.size(); fileIdx++)
			{
				processedAppeals++;
				
				int errCode = 0;
				String appealNumber = "";
				long transactionId = batchUID;
				
				boolean appealClosedInSiebel = false;
				boolean validatedSiebelTransaction = false;
				boolean validationPassed = false;
				boolean allDocsOk = true;
				
				boolean isPostClose = false;
				
				
				
				String selFileName = fileList.get(fileIdx);

				if (selFileName != null && selFileName.length() > 0)
				{

					String filePath = checkFile(batchUID, selFileName);
					if (filePath != null)
					{
						String postCloseIncomingPrefix = constantConfig.getEftPostCloseIncomingPrefix();
						if (postCloseIncomingPrefix != null && postCloseIncomingPrefix.length() > 0 )
						{
							URL url = new URL(selFileName);
							URI uri = url.toURI();
						 
							File file = new File(uri);
							String fileName = file.getName();
							
							if (fileName.contains(postCloseIncomingPrefix))
							{
								isPostClose = true;
							}
								 
						}
						
						if (isPostClose == true)
					    {
							theLogger.debug(transactionId, "Post-close file detected");							 
					    }
					    else
					    {
					    	theLogger.debug(transactionId, "Close file detected");
					    }
						
						// FILE IS RENAMED WITH LOCK EXTENSION NOW
						// MAKE SURE TO DELETE OR RENAME AT THE END
						
						// UNZIP AND MANIFEST FOLDER NAMES
						//String randomUniqueString = RandomStringUtils.randomAlphanumeric(20);
						String randomUniqueString = UUID.randomUUID().toString();
						
						
						StringBuilder closeAppealFolder  = new StringBuilder(tempDirectoryBuilder.toString());
						closeAppealFolder.append(randomUniqueString);
						closeAppealFolder.append("_");
						closeAppealFolder.append(Util.getCurrentTimeStamp());
						theLogger.debug(transactionId, "Appeal close directory: " + closeAppealFolder.toString());
						 
						StringBuilder manifestFolder  = new StringBuilder(closeAppealFolder.toString());
						manifestFolder.append("_OUT");
						theLogger.debug(transactionId, "Appeal manifest directory: " + manifestFolder.toString());
						 
						
						String baseFileName = FilenameUtils.getBaseName(filePath);
						
						
						// CREATE FOLDER FOR UNZIP 
						if (true == Util.directoryCheck(closeAppealFolder.toString(), true) )
						{
							// CREATE FOLDER FOR MANIFEST
							if (true == Util.directoryCheck(manifestFolder.toString(), true) )
							{
								// CREATE MANIFEST FILE

								FileWriter fw = null;
								try
								{
									String manifestFilename = manifestFolder.toString() + "/manifest.txt";
								    fw = new FileWriter(manifestFilename, true);  
								    
								    if (isPostClose == true)
								    {
								    	fw.write("Manifest file for post-close appeal file " + baseFileName +  "\r\n");
								    }
								    else
								    {
								    	fw.write("Manifest file for close appeal file " + baseFileName +  "\r\n");
								    }
								    
								    fw.write("================================================================\r\n");
								    fw.write("Processed Date: " + Util.convertCalendarToString(Calendar.getInstance(), "MM/dd/yyyy HH:mm:ss") +  "\r\n");
								    fw.write("================================================================\r\n");
								}
								catch (Exception ioe)
								{
									theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());
									
									// RECOVERABLE ERROR
									errCode = 4;
								}
								finally 
								{
									if (fw != null)
									{
										fw.close();
										fw = null;
									}
								}
								
								if (errCode == 0)
								{
									// UNZIP FILE
									
									boolean zipOk = Util.extractZipToFolder(filePath, closeAppealFolder.toString());
									
									if (zipOk == true)
									{
										// Check that it has manifest and appeal data
										
										String incomingAppealDataFileName = closeAppealFolder.toString() + "/appeal.xml";
										String incomingManifestFileName = closeAppealFolder.toString() + "/manifest.txt";
										
										File incomingAppealDataFile  =  new File(incomingAppealDataFileName);
										File incomingManifestFile = new File(incomingManifestFileName);
										
										if (incomingAppealDataFile.exists() && incomingManifestFile.exists())
										{
											// Read manifest file
											
											Properties manifestProps = new Properties();
											InputStream manifestStream = null;

											try 
											{
												manifestStream = new FileInputStream(incomingManifestFile);
												manifestProps.load(manifestStream);

												// get the property value  
												String appealNumberStr =  manifestProps.getProperty("AppealNumber");
												String transactionIdStr =  manifestProps.getProperty("TransactionId");

												if (appealNumberStr == null || appealNumberStr.length() <= 0 || 
													transactionIdStr == null || transactionIdStr.length() <= 0)
												{
													theLogger.error(batchUID, "Could not read appeal number abd transaction id from manifest file: " + incomingManifestFile);
													
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not read AppealNumber and TransactionId from the manifest.txt file.");
													
													// UNRECOVERABLE ERROR
													errCode = -7;
												}
												else
												{
													appealNumber = appealNumberStr;
													transactionId = Long.parseLong(transactionIdStr);
													
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "Requested Appeal Number: " + appealNumberStr );
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "Requested Transaction Id: " + transactionIdStr );
													
													
													
													theLogger.debug(batchUID, "Found in manifest file appeal number: " + appealNumber + " for transaction ID: " + transactionId);
												}
											} 
											catch (Exception manex) 
											{
												theLogger.error(batchUID, "Exception while readng info from manifest file: " + incomingManifestFile, manex);
												
												addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Failed to read the manifest.txt file.");
												
												// UNRECOVERABLE ERROR
												errCode = -6;
											} 
											finally 
											{
												if (manifestStream != null) 
												{
													try {
														manifestStream.close();
													} catch (Exception clex) {
														theLogger.error(batchUID, "Exception while closing manifest file stream: " + incomingManifestFile, clex);
													}
												}
											}

											if (errCode == 0)
											{
												// Extract appeal data from xml
												
												CloseAppealInput appealInput = null;
												
												ValidationEventCollector vec = new ValidationEventCollector();
												
												try
												{
													JAXBContext context = JAXBContext.newInstance(CloseAppealInput.class);
													
													Unmarshaller unmarshaller = context.createUnmarshaller();
													
													SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
													Schema schema = factory.newSchema(new StreamSource(new File(constantConfig.getCloseAppealXsdPath())));
													unmarshaller.setSchema(schema); 
													unmarshaller.setEventHandler(vec);
													
													appealInput = (CloseAppealInput) unmarshaller.unmarshal(incomingAppealDataFile);
													
												} 
												catch (Exception loadEx)
												{
													theLogger.error(transactionId, "Exception while readng appeal data file: " + incomingAppealDataFileName, loadEx);
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Could not read appeal data from the appeal.xml file. The XML data was not in the correct format.");
													
													// UNRECOVERABLE ERROR
													errCode = -6;
													
													if (vec != null && vec.hasEvents()) {
											             
											            for (ValidationEvent ve : vec.getEvents()) {
											                 
											                String valMsg = ve.getMessage();
											                ValidationEventLocator vel = ve.getLocator();
											                int lineNum = vel.getLineNumber();
											                int colNum = vel.getColumnNumber();

											                theLogger.debug(transactionId, "XSD Validation error at line " + lineNum + ", column " + colNum + " in appeal data file " + incomingAppealDataFileName + " :" + valMsg);
															addTextToManifestFile(transactionId, manifestFolder.toString(),  "Validation Error at line " + lineNum + ", column " + colNum +  ":" + valMsg); 
											            }
											        }
													
												}
									            
												int rcvdEcmFilesCount = 0;
												if (errCode == 0)
												{
													// VERIFY APPEAL NUMBER, transactionID, AND ECM FILES
													
													ListOfMasL3SvcCloseIo listofCloseIo = appealInput.getListOfMasL3SvcCloseIo();
													
													com.siebel.xml.mas_20l3_20svc_20close_20io.Appeal appealToClose = listofCloseIo.getAppeal();
													
													String appealNumberToClose = appealToClose.getAppealNum();
													
													if (appealNumberToClose != null && appealNumberToClose.compareTo(appealNumber) == 0)
													{
														String appealToCloseTransactionId = appealToClose.getTransactionId();
														
														if (appealToCloseTransactionId != null && appealToCloseTransactionId.compareTo(Long.toString(transactionId)) == 0)
														{
															EcmDocuments ecmDocs = appealToClose.getEcmDocuments();
															
															if (ecmDocs != null)
															{
																List<EcmDocument> listOfEcmDocs = ecmDocs.getEcmDocument();
																
																if (listOfEcmDocs != null)
																{
																	if (listOfEcmDocs.size() > 0)
																	{
																		rcvdEcmFilesCount = listOfEcmDocs.size();
																		for (int ecmIdx = 0; ecmIdx < listOfEcmDocs.size(); ecmIdx++)
																		{
																			EcmDocument ecmDoc = listOfEcmDocs.get(ecmIdx);
																			if (ecmDoc != null)
																			{
																				
																				String ecmDocChecksum = ecmDoc.getCheckSum();
																				String ecmDocFileName = ecmDoc.getFileName();
																				String ecmDocFilesize = ecmDoc.getFileSize(); // no need to check already covered in checksum
																				
																				if (ecmDocChecksum != null && ecmDocChecksum.length() > 0 
																					&& ecmDocFileName != null && ecmDocFileName.length() > 0
																					&& ecmDocFilesize != null && ecmDocFilesize.length() > 0)
																				{
																					
																					// VERIFY FILE EXTENSION
																					
																					String fileExtension = FilenameUtils.getExtension(ecmDocFileName);
																					
																					if (fileExtension != null && fileExtension.length() > 0)
																					{
																					
																						String mimeType = constantConfig.getMimeType().get(fileExtension.toLowerCase());
																						
																						if (mimeType != null && mimeType.length() > 0)
																						{
																							
																							// MIMETYPE OK
																							
																							// VERIFY IF FILE EXISTS
																							
																							File ecmFile = new File(closeAppealFolder.toString() + "/" + ecmDocFileName);
																							if (ecmFile.exists())
																							{
																								String realChecksum = Util.getMD5CheckSum(ecmFile);
																							
																								if (realChecksum != null && realChecksum.compareToIgnoreCase(ecmDocChecksum) == 0) 
																								{
																									// ok
					
																								}
																								else
																								{
																									// checksum does not match
																									theLogger.error(transactionId, "Provided checksum " + ecmDocChecksum + " for ECM file " + ecmDocFileName + " provided in appeal data file  " + baseFileName + " for appeal number " + appealNumber + " does not match the actual checksum of the file: " + realChecksum);
																									
																									addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Provided checksum " + ecmDocChecksum + " for document file " + ecmDocFileName + " does not match the actual checksum of the file: " + realChecksum);
																									
																									// UNRECOVERABLE ERROR
																									errCode = -8;
																									//break;
																								}
																							}
																							else
																							{
																								// ECM file does not exist
																								theLogger.error(transactionId, "ECM file " + ecmDocFileName + " not found in the appeal data file " + baseFileName + " for appeal number " + appealNumber);
																								
																								addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The " + ecmDocFileName + " file listed in the appeal.xml file could not be found.");
																								
																								// UNRECOVERABLE ERROR
																								errCode = -8;
																								//break;
																							}
																							
																							
																						}
																						else
																						{
																							String errorMessage = ErrorFieldConstant.BAD_MIME_TYPE + " - " +  getMessage(ErrorFieldConstant.BAD_MIME_TYPE, new String[]{ecmDocFileName});
																							
																							theLogger.error(transactionId, "The file extension for ECM file " + ecmDocFileName + " provided in appeal data file  " + baseFileName + " for appeal number " + appealNumber + " contains an unsupported MIME type ");
																							
																							addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: " + errorMessage );
																							
																							// UNRECOVERABLE ERROR
																							errCode = -8;
																							//break;
																							
																						}
																					} 
																					else
																					{
																						String errorMessage = ErrorFieldConstant.BAD_MIME_TYPE + " - " +  getMessage(ErrorFieldConstant.BAD_MIME_TYPE, new String[]{ecmDocFileName});
																						
																						theLogger.error(transactionId, "The file extension for ECM file " + ecmDocFileName + " provided in appeal data file  " + baseFileName + " for appeal number " + appealNumber + " contains an unsupported MIME type ");
																						
																						addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: " + errorMessage );
																						
																						// UNRECOVERABLE ERROR
																						errCode = -8;
																						//break;
																					}
																					
																				}
																				else
																				{
																					// checksum or filename not provided
																					theLogger.error(transactionId, "Checksum, File Name or File Size not provided for at least one ECM document in appeal data file " + baseFileName + " for appeal number " + appealNumber);
																					
																					addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The Checksum, FileName or FileSize where not provided for at least one document listed in the appeal.xml file.");
																					
																					// UNRECOVERABLE ERROR
																					errCode = -8;
																					//break;
																				}
																			}
																			else
																			{
																				// null ecmDoc in appeal data
																				theLogger.error(transactionId, "Null ecmDoc in appeal data file " + baseFileName + " for appeal number " + appealNumber);
																				
																				addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The appeal.xml file includes one or more NULL document files.");
																				
																				// UNRECOVERABLE ERROR
																				errCode = -8;
																				//break;
																			}
																		} // end of for loop for ECM documents
																		
																		
																	}
																}
															}
														}
														else
														{
															theLogger.error(transactionId, "Transaction Id in manifest file does not match transaction Id in appeal data file: " + baseFileName + " Transaction ID in appeal data file" + appealToCloseTransactionId  + " vs in manifest file " + transactionId);
															
															addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The TransactionId " + transactionId + " in the manifest.txt file does not match the TransactionId " + appealToCloseTransactionId +" in the appeal.xml file.");
															
															// UNRECOVERABLE ERROR
															errCode = -7;
														}
													} 
													else
													{
														theLogger.error(transactionId, "Appeal number in manifest does not match appeal number in appeal data file: " + baseFileName + " Appeal number in appeal data file" + appealNumberToClose  + " vs in manifest file " + appealNumber);
														
														addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The AppealNumber " + appealNumber + " in the manifest.txt file does not match the AppealNumber " + appealNumberToClose +" in the appeal.xml file.");
														 
														// UNRECOVERABLE ERROR
														errCode = -7;
													}
													
													// GET CLOSING APPEAL STATUS AND TRANSACTION ID FROM SIEBEL
													 
													if (errCode == 0)
													{
 
														ClosingAppeal closingAppeal = siebelService.startClosingAppeal(appealInput, batchUID);
														if (closingAppeal != null)
														{
	
															if (closingAppeal.status == 0 && closingAppeal.appeal != null)
															{
																validationPassed = true; 
																validatedSiebelTransaction  = true;
																
																// verify returned data
																String outAppealNumber = closingAppeal.appeal.getAppealNum();
																String outTransactionId = closingAppeal.appeal.getTransactionID();
																
																if (outAppealNumber != null && outAppealNumber.compareTo(appealNumber) == 0 &&
																	 outTransactionId != null && outTransactionId.compareTo(Long.toString(transactionId)) == 0)
																{
																	String ecmIndexStr = closingAppeal.appeal.getECMIndex();
																	String ecmPassword = closingAppeal.appeal.getECMPassword();
																	String ecmUsername = closingAppeal.appeal.getECMUserId();
																	
																	String appealOpenDate = closingAppeal.appeal.getAppealCreationDate();
																	String orgName = closingAppeal.appeal.getAppealOrganization();
																	
																	
																	int ecmIndex = -1;
																	try
																	{
																		ecmIndex = Integer.parseInt(ecmIndexStr);
																	} catch (Exception convEx) { }
																	
 																
																	if (ecmIndex >= 0 &&
																		ecmPassword != null && ecmPassword.length() > 0 &&
																		ecmUsername != null && ecmUsername.length() > 0 &&
																		appealOpenDate != null && appealOpenDate.length() > 0 &&
																		orgName != null && orgName.length() > 0 )
																	{
																		// verify returned files
																		
																		List<ReceivedFileDto> receivedFiles = null;
																		
																		int siebelEcmFilesCount = 0;
																		
																		com.siebel.xml.mas_20l3_20svc_20close_20io_20output.EcmDocuments outDocuments = closingAppeal.appeal.getEcmDocuments();
																		List<com.siebel.xml.mas_20l3_20svc_20close_20io_20output.EcmDocument> outDocumentsList = null;
																		
																		com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocuments ecmDocsForSiebel = new com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocuments();
																		List<ECMDocument> ecmDocsForSiebelList = ecmDocsForSiebel.getECMDocument();
																		
																		if (outDocuments != null)
																		{
																			outDocumentsList = outDocuments.getEcmDocument();
																			
																			if (outDocumentsList != null)
																			{
																				siebelEcmFilesCount = outDocumentsList.size();
																				
																				if (siebelEcmFilesCount == rcvdEcmFilesCount)
																				{
																					if (siebelEcmFilesCount > 0)
																					{
																						receivedFiles = new ArrayList<ReceivedFileDto>();
																						
																						for (int sdx=0; sdx < siebelEcmFilesCount; sdx++)
																						{
																							com.siebel.xml.mas_20l3_20svc_20close_20io_20output.EcmDocument outDocument = outDocumentsList.get(sdx);
																							
																							if (outDocument != null)
																							{
																								 
																								 
																								String siebelChecksum = outDocument.getCheckSum();
																								String siebelFileName =outDocument.getFileName();
																								String siebelFileId = outDocument.getId();
																								 
																								
																								if (siebelChecksum != null && siebelChecksum.length() > 0 && 
																									siebelFileName != null && siebelFileName.length() > 0 &&
																									siebelFileId != null && siebelFileId.length() > 0)
																								{
																									// ok
																									File ecmFile = new File(closeAppealFolder.toString() + "/" + siebelFileName);
																									if (ecmFile.exists())
																									{
																										ReceivedFileDto rcvFile = new ReceivedFileDto();
																										
																										rcvFile.setFileName(siebelFileName);
																										rcvFile.setSiebelId(siebelFileId);
																										rcvFile.setCheckSum(siebelChecksum);
																										
																										long siebelFileSize = ecmFile.length();
																										
																										rcvFile.setFileSize(siebelFileSize);

																										receivedFiles.add(rcvFile);
																										
																										
																										com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocument ecmDocForSiebel = new com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ECMDocument();
																										
																										ecmDocForSiebel.setECMId(null);
																										ecmDocForSiebel.setFileName(siebelFileName);
																										ecmDocForSiebel.setImportStatus("Failed");
																										ecmDocForSiebel.setRowId(siebelFileId);
																										
																										ecmDocsForSiebelList.add(ecmDocForSiebel);
																										
																									}
																									else
																									{
																										theLogger.error(transactionId, "Siebel returned an ECM document filename that doe snot exist in the appeal data file " + appealNumber);
																										
																										addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																										
																										// RECOVERABLE ERROR
																										errCode = 10;
																										break;
																									}
																									
																									
																									
																								}
																								else
																								{
																									theLogger.error(transactionId, "Siebel returned a null ECM document filename, checksum or fileId for appeal number " + appealNumber);
																									
																									addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																									
																									// RECOVERABLE ERROR
																									errCode = 10;
																									break;
																								}
																								 
																							}
																							else
																							{
																								theLogger.error(transactionId, "Siebel returned a null ECM document for appeal number " + appealNumber);
																								
																								addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																								
																								// RECOVERABLE ERROR
																								errCode = 10;
																								break;
																							}
																						}
																					}
																				}
																				else
																				{
																					theLogger.error(transactionId, "Siebel returned a different number of ECM documents than the input ECM documents for appeal number " + appealNumber);
																					
																					addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																					
																					// RECOVERABLE ERROR
																					errCode = 9;
																				}
																			}
																		}
																		
																		// READY TO UPLOAD DOCUMENTS TO ECM AND FINSISH CLOSING
																		if (errCode == 0)
																		{
																			if (receivedFiles != null)
																			{

																				//siebelService.updateTransactionStatus(transactionId, "Uploading to ECM", null, null, null);
																				
																				List<DocumentResultDto> importedDocs = ecmService.importFilesToAppeal(appealNumber,  appealOpenDate,  ecmUsername,  ecmPassword,  orgName, closeAppealFolder.toString(), receivedFiles,  transactionId);
				
																				if (importedDocs != null)
																				{
																						// check the status of each imported document
																					
																						boolean errorReported = false;
																						
																						for (int impIdx = 0; impIdx < importedDocs.size(); impIdx++)
																						{
																							DocumentResultDto importedDoc = importedDocs.get(impIdx);
																							
																							int importedFileStatus = importedDoc.getStatus();
																							String importedSiebelDocId = importedDoc.getSiebeldocId();
																							//String importedFileName = importedDoc.getFileName();
																							//String importedEcmItemId = importedDoc.getEcmItemId();
																							
																							if (importedSiebelDocId != null && importedSiebelDocId.length() > 0)
																							{
																							
																								for (int siebelEcmListId = 0; siebelEcmListId < ecmDocsForSiebelList.size(); siebelEcmListId++)
																								{
																									ECMDocument foundSiebelDoc = ecmDocsForSiebelList.get(siebelEcmListId);
																									if (foundSiebelDoc.getRowId().compareTo(importedSiebelDocId) == 0)
																									{
																										if (importedFileStatus == 0) // SUCCESS
																										{
																											foundSiebelDoc.setImportStatus("Completed");
																											foundSiebelDoc.setECMId(importedDoc.getEcmItemId());
																											 
																										}
																										else if (importedFileStatus > 0) // ALLREADY IN ECM
																										{
																											foundSiebelDoc.setImportStatus("Already");
																											foundSiebelDoc.setECMId(importedDoc.getEcmItemId());
																										}
																										else
																										{
																											// FAILED
																											
																											//allDocsOk = false;
																											
																											
																											
																										}
																										break;
																									}
																									
																								}
																							} 	
																							
																							
																							// THIS IS A FAILURE TO CALL ECM
																							if (importedFileStatus < 0)
																							{
																								if (errorReported == false)
																								{
																									errorReported = true;
																									
																									int failedAppeals = theLogger.incrementFailedAppeals();
																									if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																									{
																										theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																									}
																								}
																							}
																							
																						} // end for

																				}
																				else
																				{
																					//allDocsOk = false;
																					
																					theLogger.error(transactionId, "Failed to upload all documents to ECM for appeal number " + appealNumber);
																					
																					// THIS IS A FAILURE TO CALL ECM
																					int failedAppeals = theLogger.incrementFailedAppeals();
																					if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																					{
																						theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																					}
																					
																				}
																				
																				// CHECK IF WE HAVE ANY DOCS THAT WHERE NOT SUCCESFULL
																				for (int siebelEcmListId = 0; siebelEcmListId < ecmDocsForSiebelList.size(); siebelEcmListId++)
																				{
																					ECMDocument foundSiebelDoc = ecmDocsForSiebelList.get(siebelEcmListId);
																					String ecmImportStatus = foundSiebelDoc.getImportStatus();
																					if (ecmImportStatus == null || ecmImportStatus.compareTo("Failed") == 0)
																					{
																						theLogger.error(transactionId, "Found document: " + foundSiebelDoc.getFileName() + " that was not uploaded to ECM for appeal number " + appealNumber);
																						
																						//addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																						
																						// RECOVERABLE ERROR
																						errCode = 14;
																						allDocsOk = false;
																						break;
																					} 
																				}

																				
																				// UPDATE DOCUMENTS IN SIEBEL
																				int siebelDocUpdateErr = siebelService.closeEcmDocuments( transactionId, appealNumber, ecmDocsForSiebel);
																				
																				if (siebelDocUpdateErr == 0)
																				{
																					if (allDocsOk == true)
																					{
																						theLogger.debug(transactionId, "Successfully closed appeal number: " + appealNumber + " with files imported to ECM.");
																						
																						addTextToManifestFile(transactionId, manifestFolder.toString(),  "STATUS: Appeal successfully closed." );
																						
																						appealClosedInSiebel = true;
																						errCode = 0;
																					}
																					else
																					{
																						theLogger.error(transactionId, "Successfully sent ECM document Status  to Siebel for appeal number: " + appealNumber + " with  ECM upload errors.");
																						
																						addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The appeal was closed, but some of the documents could not be associated to the appeal." );
																		
																						errCode = 14;
																					}
																				}
																				else
																				{
																					theLogger.error(transactionId, "Failed to send ECM document Status  to Siebel for appeal number " + appealNumber);
																					
																					addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The appeal was closed, but some of the documents could not be associated to the appeal." );
																					
																					allDocsOk = false;
																					
																					// RECOVERABLE ERROR
																					errCode = 15;
																					
																					
																					// THIS IS A FAILURE TO CALL SIEBEL IF ERRCODE = -2
																					if (siebelDocUpdateErr == -2)
																					{
																						int failedAppeals = theLogger.incrementFailedAppeals();
																						if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																						{
																							theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																						}
																					}
																				}

																				
																			}
																			else
																			{
																				// no files to import, everything ok 
																				
																				
																				//siebelService.updateTransactionStatus(transactionId, "Uploaded", null, null, null);
																				
																				theLogger.debug(transactionId, "Suuceesfully closed appeal number: " + appealNumber + " with no files to import to ECM.");
																				
																				addTextToManifestFile(transactionId, manifestFolder.toString(),  "STATUS: APPEAL SUCCESSFULLY CLOSED" );
																				
																				appealClosedInSiebel = true;
																			}
	
																		}
																		else
																		{
																			// the error has already been logged
																		}
																	}
																	else
																	{
																		theLogger.error(transactionId, "ECM Index, ECM password, AdECM username, Org Name or Appeal Date returned by Siebel are empty for appeal number " + appealNumber);
																		
																		addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																		
																		// RECOVERABLE ERROR
																		errCode = 8;
																	}
																}
																else
																{
																	theLogger.error(transactionId, "Appeal Number and Transaction ID returned by Siebel do not match the original appeal number " + appealNumber + " and transaction Id " + transactionId);
																	
																	addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																	
																	// RECOVERABLE ERROR
																	errCode = 9;
																}

																
															}
															
															else if (closingAppeal.status == -2)
															{
																// special case for multiple JVMs
																theLogger.error(transactionId, "Siebel reported that this appeal is already closed or about to be closed. Does not means an error, as other threads / JVMs might have already closed this appeal." );
																
																errCode = -100;
															}
															/*
															else if (closingAppeal.status == -3) 
															{
																// validation passed but there was some other error
																validationPassed = true;
																
																theLogger.error(transactionId, "Siebel reported that validation passed for this appeal, but there was some other error.  Error Code: " + closingAppeal.errCode + " . Error Message: " +  closingAppeal.errMsg);
																
																//addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: " + closingAppeal.errMsg);
																addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																
																errCode = -5;
															}
															*/
															else if (closingAppeal.status == -4) 
															{
																// validation not passed 
																
																theLogger.error(transactionId, "Siebel reported that there was a validation error for this appeal.  Error Code: " + closingAppeal.errCode + " . Error Message: " +  closingAppeal.errMsg);
																
																addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The appeal could not be closed. \r\nError Code: " + closingAppeal.errCode + "\r\nError Message: " + closingAppeal.errMsg);
																
																errCode = -5;
															}
															else 
															{
																// unknown error (incorrect appeal, etc); it should not get here
																theLogger.error(transactionId, "Siebel reported that there was an error while closing this appeal.  Error Code: " + closingAppeal.errCode + " . Error Message: " +  closingAppeal.errMsg);

																addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The appeal could not be closed. \r\nError Code: " + closingAppeal.errCode + "\r\nError Message: " + closingAppeal.errMsg);
																
																errCode = -5;
															}
														}
														else
														{
															addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request.");
															
															theLogger.error(transactionId, "Error while calling the Siebel web service to close this appeal." );
										
															errCode = -6;
															
															
															// THIS IS A FAILURE TO CALL SIEBEL
															int failedAppeals = theLogger.incrementFailedAppeals();
															if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
															{
																theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
															}
															
														}
													} // else it means an error in the appeal data / ECM files, which has already been logged
												} // if appeal loaded from XML..error is already logged
											} // if manifest file loaded ok...error is already logged
										}
										else
										{
											theLogger.error(batchUID, "Zip file: " + filePath + " does not include the manifest or appeal data file");
											
											addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The " + baseFileName + " file does not include the manifest.txt or appeal.txt file");
											
											
											// UNRECOVERABLE ERROR
											errCode = -4;
										}
									}
									else
									{
										theLogger.error(batchUID, "Failed to extract zip file: " + filePath);
										
										addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The  " + baseFileName + " file was not recognized as a valid ZIP file.");
										
										// UNRECOVERABLE ERROR
										errCode = -3;
									}
								}
								else
								{	
									theLogger.error(batchUID, "Failed to create manifest file in folder: " + manifestFolder.toString());
								
									// RECOVERABLE ERROR
									errCode = 3;
								}
								
								// delete ZIP folder
								Util.deleteDirectory(closeAppealFolder.toString());
								
							} 
							else
							{	
								theLogger.error(batchUID, "Appeal manifest directory  could not be created: " + closeAppealFolder.toString());
								
								addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
								// RECOVERABLE ERROR
								errCode = 3;
							}
						}
						else
						{
							theLogger.error(batchUID, "Close appeal unzip directory  could not be created: " + closeAppealFolder.toString());
							
							addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
							// RECOVERABLE ERROR
							errCode = 2;
						}
						
						
						// CLEANUP HERE AND MOVE FILE !!!!!!!!
						
						if (errCode == 0)
						{
							// ok
							
							// DELETE ORIGINAL FILE
							Util.deleteFile(filePath);
							
							// DONE SO FAR
							
						}
						else
						{
							// rename file 
							if (errCode != -100) // 2 JVMs processing the same file
							{
								String originalFileName = filePath;
								originalFileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
								String errorFileName = "";
								
								if (validationPassed == true)
								{
									errorFileName = originalFileName + "." + ProviderConstants.FAILED_EXTENSION;
								}
								else
								{
									errorFileName = originalFileName + "." + ProviderConstants.FAILED_VALIDATION_EXTENSION;
								}
								
								File originalFile = new File(filePath);
								File renameFile = new File(errorFileName);				
								if(originalFile.renameTo(renameFile)) 
								{
								
								} 
								else
								{
									theLogger.error(batchUID, "Failed to rename locked file: " + originalFileName + " to error file: " + errorFileName);
									
									// UNRECOVERABLE ERROR
									//errCode = -2;
								}
								
								// UPDATE SIEBEL WITH ERROR
							} else
							{
								// another JVM already processing this file
								Util.deleteFile(filePath);
								Util.deleteDirectory(manifestFolder.toString());
								
								continue;
							}
						}
						
						// create signature file for manifest file
						
			            // read manifest and  sign
						FileOutputStream sigfos = null;
						try
						{						    
							theLogger.debug(transactionId, "Generating signature file...");
							
							
							String keyStoreFile =  constantConfig.getKeystoreName();
						    String password = constantConfig.getKeystorePassword();
						    String alias = constantConfig.getKeyAlias(); 
						    String keyPassword = constantConfig.getKeyPassword();
							
							KeyStore keystore = KeyStore.getInstance("JKS");  
				            char[] storePass = password.toCharArray();  
				            char[] keyPasswd = keyPassword.toCharArray(); 
				  
				            //load the key store from file system  
				            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
				            keystore.load(fileInputStream, storePass);  
				            fileInputStream.close();  
				  
				             
				            //read the private key  
				            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
				            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
				            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
				  
				            //initialize the signature with signature algorithm and private key  
				            Signature signature = Signature.getInstance("SHA256withRSA");  
				            signature.initSign(privateKey);  
				            
				            String manifestFilename = manifestFolder.toString() + "/manifest.txt";
				
				            FileInputStream fis = new FileInputStream(manifestFilename);
				            BufferedInputStream bufin = new BufferedInputStream(fis);
				            byte[] buffer = new byte[10000];
				            int len;
				            while ((len = bufin.read(buffer)) >= 0) {
				            	signature.update(buffer, 0, len);
				            };
				            bufin.close();

				            byte[] digitalSignature = signature.sign();

							String signatureFilename = manifestFolder.toString() + "/signature.txt";

							sigfos = new FileOutputStream(signatureFilename);
						    sigfos.write(digitalSignature);
						    sigfos.close(); 
						    
						    theLogger.debug(transactionId, "Signature file generated: " + signatureFilename);
						}
						catch (Exception ioe)
						{
							Util.deleteDirectory(manifestFolder.toString());
							
							theLogger.error(transactionId, "Exception while writing signature file: " + ioe.getMessage());
							
							errCode = 10;
							
							int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}
							
						}
						finally 
						{
							if (sigfos != null)
							{
								sigfos.close();
								sigfos = null;
							}
						}
					
						
						// ZIP and move manifest file to EFT
						
						StringBuilder compressFilePath = new StringBuilder();		
						compressFilePath.append(tempDirectoryBuilder.toString());
						compressFilePath.append(randomUniqueString);
						compressFilePath.append("_");
						compressFilePath.append(Util.getCurrentTimeStamp());
						compressFilePath.append(".zip");
						
						errCode =  Util.compressFilesInFolder(manifestFolder.toString(), compressFilePath.toString(), transactionId);
						if (errCode == 0)
						{
							theLogger.debug(transactionId, "Compressed manifest file to: " + compressFilePath.toString());

							// delete manifest file and folder
							Util.deleteDirectory(manifestFolder.toString());
							
							
							StringBuilder eftFileLocation = new StringBuilder(constantConfig.getEftLocation());	
							eftFileLocation.append("/");
							if (isPostClose == true)
						    {
								eftFileLocation.append(constantConfig.getEftFilePrefix());
								eftFileLocation.append(constantConfig.getEftPostCloseOutboundFilePrefix());
								eftFileLocation.append(".");
								eftFileLocation.append(constantConfig.getEftOrgName());
						    }
							else
							{
								eftFileLocation.append(constantConfig.getEftFilePrefix());
								eftFileLocation.append(constantConfig.getEftCloseOutboundFilePrefix());
								eftFileLocation.append(".");
								eftFileLocation.append(constantConfig.getEftOrgName());
							}
							
							eftFileLocation.append(".D");
							
							//DYYMMDD.THHMMSST   
							
							Date rightNow = new Date();
							String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
							String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
							
							eftFileLocation.append(dateStamp);	
							eftFileLocation.append(".T");
							eftFileLocation.append(timeStamp);
							
							String destFile = eftFileLocation.toString();
							boolean fileNameAvailable = false;
							for (int fidx = 0;  fidx <= 9; fidx++)
							{
								String tryFileName = destFile + fidx;
								 
								File f = new File(tryFileName);
								if(f.exists() == false)
								{
									destFile = tryFileName;
	
									theLogger.debug(transactionId, "Copying manifest ZIP file : " + compressFilePath.toString() + " to EFT: " + destFile);
									
									errCode =  Util.copyFile(compressFilePath.toString(), destFile);
									if (errCode != 0)
									{
										theLogger.error(transactionId, "Try " + fidx + ": Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder: " + destFile);
										//return errCode;
									}
									else
									{
										theLogger.debug(transactionId, "Copied compressed file for appeal " + appealNumber + " to EFT folder: " + destFile);
										fileNameAvailable = true;
										break;
									}
	
								}
								
							}
							
							if (fileNameAvailable == true)
							{	
								// Delete compressed manifest ZIP File
								errCode =  Util.deleteFile(compressFilePath.toString());
								if (errCode == 0)
								{
									theLogger.debug(transactionId, "Deleted compressed manifest file: " + compressFilePath.toString());
									
									// ALL DONE!!!!!!!!!!!!!!!
								}
								else
								{
									theLogger.error(transactionId, "Error while deleting compressed manifest file: " + compressFilePath.toString() );
									
									// RECOVERABLE ERROR
									errCode = 7;
								}
							}
							else
							{
								theLogger.error(transactionId, "Could not find available file name on EFT for manifest file: " + destFile);
								
								// RECOVERABLE ERROR
								errCode = 8;
								
								
								int failedAppeals = theLogger.incrementFailedAppeals();
								if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
								{
									theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
								}
								
							}
							
						 

						}
						else
						{
							theLogger.error(transactionId, "Error while compressing manifest folder: " + manifestFolder.toString() + " to: " + compressFilePath.toString());
						
							// RECOVERABLE ERROR
							errCode = 6;
							
							int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(transactionId, "Java close and post-close process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}
							
						}


						

					}
					else // null file path; 
					{
						// error was already logged
						continue;
					}
				}
				else
				{
					theLogger.error(batchUID, "Found empty or null filename in the list of files to be processed." );
					
					// this should never happen
				}
				
				
				// UPDATE SIEBEL WITH SUCCESS
				
				if (errCode == 0)
				{
					if (validatedSiebelTransaction == true)
					{
						if (allDocsOk == true)
						{
							siebelService.updateTransactionStatus(transactionId, "Completed", null, null, null, null);
							closedAppeals++;
							
							theLogger.resetFailedAppeals();
						}
						else
						{
							siebelService.updateTransactionStatus(transactionId, "Error", "-22" , "Failed to upload documents to ECM", null, null);
						}
					}
				}
				else
				{
					if (validatedSiebelTransaction == true)
					{
						if (appealClosedInSiebel == true)
						{
							
							siebelService.updateTransactionStatus(transactionId, "Completed",  Integer.toString(errCode), "Failed to send response file to EFT", null, null);
						}
						else
						{
							if (allDocsOk == true)
							{
								siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while closing appeal in Level3WS", null, null);
							}
							else
							{
								siebelService.updateTransactionStatus(transactionId, "Error", "-23" , "Failed to upload documents to ECM", null, null);
							}
						}
					}
				}

				
			} // end FOR loop
			
			
		} catch (Exception e) {
			theLogger.error(batchUID, "Exception while closing appeals: " + e.getMessage() );
			
			//errCode  = -1;
			
			//siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Exception while closing appeal in Level3WS", null);
			
		} finally {
			theLogger.performanceStartOnly(batchUID, "Closed " + closedAppeals  + " appeals in batch of " + processedAppeals + " appeals: ", startTime);

			theLogger.debug(batchUID, "Finished closing " + closedAppeals  + " appeals in batch of " + processedAppeals + " appeals.");
		}
		
		return closedAppeals;
	}
	
 
	private String checkFile(long batchUID, String fileUri)
	{
		//int fileStatus = 0;
		
		try
		{
			URL url = new URL(fileUri);
			URI uri = url.toURI();
			
			File file = new File(uri);
			
			if (file.exists()) 
			{
				String fileName = file.getName();
				//String firstLetter = fileName.substring(0,1).toUpperCase();
				
				boolean filenameok = false;
				ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getFileprefixName().split(",")));
				for (int idx = 0; idx < filePrefixList.size(); idx++)
				{
					
						if (fileName.startsWith(filePrefixList.get(idx))) 
						{
							filenameok = true;
							break;
						}
					}
							
				
				
				//if(constantConfig.getPrefixTIBCOName().contains(firstLetter)) 
				if (filenameok == true)
				{
					long fileModified = file.lastModified();
					
					long transferTimeLimit = (System.currentTimeMillis() - constantConfig.getDelayTransfer());
					
					if(fileModified < transferTimeLimit)
					{
						String extension = FilenameUtils.getExtension(fileName);
						if(extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)) 
						{
							theLogger.error(batchUID, "File already locked : " + fileUri );
							//fileStatus = -5;
						}		
						else
						{
							File renameFile = new File(file.getPath() + "." + ProviderConstants.LOCK_EXTENSION);				
							if(file.renameTo(renameFile)) 
							{
								theLogger.debug(batchUID, "Picked and renamed file for import: " + fileUri );
								//fileStatus = 0;
								// OK HERE return renamed file
								return renameFile.getPath();
								
							} else {
								theLogger.error(batchUID, "Failed to rename (lock) file : " + fileUri );
								//fileStatus  = -4;
							}	
						}
					} else {
						theLogger.debug(batchUID, "File is still transferring, skipping for now: " + fileUri );
						//fileStatus  = -3;
					}
				} else {
					theLogger.debug(batchUID, "File is not part of the close appeal filename schema: " + fileUri );
					//fileStatus  = -2;
				}
	
			}
			else
			{
				theLogger.error(batchUID, "File does not exist: " + fileUri );
				//fileStatus  = -2;
			}
		}
		catch (Exception ex)
		{
			theLogger.error(batchUID, "Exception while getting file information for file: " + fileUri, ex);
			//fileStatus = -1;
		}
		
		return null;
	}
	
	 
	private int addTextToManifestFile(long transactionId, String manifestFolder, String message)
	{
		int errCode = 0;
		
		FileWriter fw = null;
		try
		{
			String manifestFilename = manifestFolder + "/manifest.txt";
		    fw = new FileWriter(manifestFilename, true);  
		    fw.write(message);
		    fw.write("\r\n================================================================\r\n");
		}
		catch (Exception ioe)
		{
			theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());
			
			// RECOVERABLE ERROR
			errCode = 4;
		}
		finally 
		{
			if (fw != null)
			{
				try
				{
					fw.close();
					fw = null;
				} catch (Exception clex)
				{
					fw = null;
				}
			}
		}
		
		return errCode;
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
}
