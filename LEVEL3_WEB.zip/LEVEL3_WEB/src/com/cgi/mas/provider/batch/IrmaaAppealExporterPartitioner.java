package com.cgi.mas.provider.batch;


import java.util.HashMap;
import java.util.Map;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import com.cgi.mas.provider.logger.CustomLogger;


public class IrmaaAppealExporterPartitioner implements Partitioner {
	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String PARTITION_KEY = "partition";
	 
	private int totalMaxAppeals;
	private int totalIrmaaAppeals;
	private long batchUID;
	
	private CustomLogger theLogger = new CustomLogger(IrmaaAppealExporterPartitioner.class);

	
	public int getTotalMaxAppeals() {
		return totalMaxAppeals;
	}

	public void setTotalMaxAppeals(int totalMaxAppeals) {
		this.totalMaxAppeals = totalMaxAppeals;
	}
		

	public int getTotalIrmaaAppeals() {
		return totalIrmaaAppeals;
	}

	public void setTotalIrmaaAppeals(int totalIrmaaAppeals) {
		this.totalIrmaaAppeals = totalIrmaaAppeals;
	}

	public long getbatchUID() {
		return batchUID;
	}

	public void setbatchUID(long batchUID) {
		this.batchUID = batchUID;
	}

	
	@Override
	public Map<String, ExecutionContext> partition(int gridSize){

		theLogger.debug(batchUID, "Creating partition for " + totalIrmaaAppeals + "  appeals for grid size: " + gridSize);
		
		Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>();
			
		int numThreads = gridSize;		 
		if (gridSize > totalIrmaaAppeals)
		{
			numThreads = totalIrmaaAppeals;
		}
		//theLogger.debug(batchUID, "Number of threads to be created: " + numThreads);
		
		int maxAppealsPerThread = 1;
		if (totalIrmaaAppeals > gridSize)
		{
			maxAppealsPerThread = totalIrmaaAppeals / gridSize;			
			if (maxAppealsPerThread > totalMaxAppeals)
			{
				maxAppealsPerThread = totalMaxAppeals;
			}
		}
		//theLogger.debug(batchUID, "Maximum appeals per thread: " + maxAppealsPerThread);
				
		for (int index=0; index<numThreads; index++) {
 	
			ExecutionContext context = new ExecutionContext();
 
			context.putInt(MAX_APPEALS, maxAppealsPerThread);
			context.putLong(BATCH_UID, batchUID);
			context.putString(THREAD_NAME, "Thread" + index);
			
			map.put(PARTITION_KEY + index, context);	
		}	
		
		return map;
 	}

}
