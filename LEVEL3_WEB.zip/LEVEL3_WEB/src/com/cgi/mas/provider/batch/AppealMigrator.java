package com.cgi.mas.provider.batch;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.util.Util;
import com.siebel.customui.GetNextDMAppealOutput;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.Appeal;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.Correspondence;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.DocumentGeneration;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.EcmDocument;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOSupportMaterials;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfCorrespondence;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfDMDocumentsIO;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfDocumentGeneration;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfEcmDocuments;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.ListOfSupportMaterialAttachments;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.SupportMaterial;
import com.siebel.xml.mas_20l3_20svc_20dm_20ecm_20documents.SupportMaterialAttachment;

public class AppealMigrator implements Tasklet {

	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";

	private static CustomLogger theLogger = new CustomLogger(
			AppealMigrator.class);

	@Autowired
	private ConstantConfig constantConfig;

	@Autowired
	private ISiebelService siebelService;

	@Autowired
	private IECMService ecmService;

	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		ExecutionContext context = chunkContext.getStepContext()
				.getStepExecution().getExecutionContext();

		int maxAppealsPerThread = context.getInt(MAX_APPEALS);
		long batchUID = context.getLong(BATCH_UID);
		String threadId = context.getString(THREAD_NAME);

		runDataMigration(batchUID, maxAppealsPerThread);

		return RepeatStatus.FINISHED;
	}

	private int runDataMigration(long batchUID, int maxAppealsPerThread) {

		int errCode = 0;
		int processedAppeals = 0;
		String appealOp = "DM";
		String appealNumber = "";
		long transactionId = 0;
		int ecmIndex = 0;
		String ecmUsername = "";
		String ecmPassword = "";
		List<String> documentList = new ArrayList<String>();

		ListOfCorrespondence correspDocs = null;
		ListOSupportMaterials supportMat = null;
		ListOfDocumentGeneration docGen = null;
		
		long startTime = System.currentTimeMillis();

		try {
			while (processedAppeals < maxAppealsPerThread) {
				
				String uniqueId = "";
				
				GetNextDMAppealOutput migrationInfo = siebelService.getNextDMAppeal(batchUID, "DM");
				processedAppeals++;
				
				if (migrationInfo != null) {
					
					ListOfDMDocumentsIO docsList = migrationInfo.getListOfDMDocumentsIO();
					
					uniqueId = migrationInfo.getUniqueId();
					
					appealOp = migrationInfo.getTransactionOperation();
					if (docsList != null && appealOp != null) {
						List<Appeal> appeals = docsList.getAppeal();

						if (appeals != null && appeals.size() == 1) {
							Appeal appeal = appeals.get(0);

							if (appeal != null) {
								try {
									appealNumber = appeal.getAppealNumber();
									
									transactionId = Long.valueOf(appeal.getTransactionId()).longValue();
									
									ecmIndex = Integer.valueOf(appeal.getECMIndex()).intValue();
									
									ecmUsername = appeal.getECMUserName();
									ecmPassword = appeal.getECMPassword();
									
									ListOfEcmDocuments ecmDocsContainer = appeal.getListOfEcmDocuments();
									if (ecmDocsContainer != null) {
										List<EcmDocument> ecmDocs = ecmDocsContainer.getEcmDocument();

										if (ecmDocs != null) {
											for (int ecmIdx = 0; ecmIdx < ecmDocs.size(); ecmIdx++) {
												
												EcmDocument ecmDoc = ecmDocs.get(ecmIdx);
												
												if (ecmDoc != null) {
													String ecmId = ecmDoc.getDocECMId();
													
													if (ecmId != null) {
														documentList.add(ecmId);
													}
												}
											}
										}
									}
									correspDocs = appeal.getListOfCorrespondence();
									supportMat = appeal.getListOSupportMaterials();
									docGen = appeal.getListOfDocumentGeneration();
									

								} catch (Exception ex) {

									theLogger.error(batchUID,"Exception while retrieving the values returned by the  Siebel web service to process the appeal documents: "+ ex.getMessage());

									errCode = -1;
								}

							} else {
								theLogger.error(batchUID,"Null appeal received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready for data migration.");

								errCode = -1;
							}

						} else {
							theLogger.error(batchUID,"Invalid number of appeals received while calling the Siebel web service to process the appeal documents: " + appeals.size() + ". Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready for data migration.");

							errCode = -1;
						}
					} else {
						theLogger.error(batchUID,"Invalid ListOfDocumentsIO received while calling the Siebel web service to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready for data migration.");

						errCode = -1;
					}

				} else {

					theLogger.error(batchUID,"Error while calling the Siebel web service to to process the appeal documents. Does not necessarly means an error, as other threads / JVMs might have already processed all the appeals that where ready for data migration.");

					errCode = -1;
				}
				

				if (errCode == 0)
				{
					int success = migrateAppeal(appealNumber, transactionId, ecmIndex,
							documentList, ecmUsername, ecmPassword,  correspDocs,  supportMat, docGen, appealOp, uniqueId) ;
					
					if (success == 0)
					{
						// REPORT SUCCESS TO SIEBEL;
						
						 
						
						siebelService.updateTransactionStatus(transactionId, "Completed", null, null, appealNumber, uniqueId);
						
						theLogger.debug(transactionId, "Successfully migrated appeal: " + appealNumber + " for transaction Id: "  + transactionId);
						
					} 
					else 
					{
						errCode  = success;
						// REPORT TO SIEBEL, UNDO PROMOTE
						
						siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while migrating appeal (Error Code: " + errCode + ")", appealNumber, uniqueId);
						
						
						theLogger.error(transactionId, "Failed to migrate appeal: " + appealNumber + " for transaction Id: "  + transactionId + ". Error Code: " + errCode);
						
						
						break;
					}
					
				}else
				{
					// errCode was not 0
					
					// no more appeals available to promote
					// this is not a real error, as other threads or JVMs might have promoted all appeals
					// just finish this thread
					if (errCode == -5) 	
					{
						errCode = 0;
						break;
					}
					else
					{
						// the error was already logged; do nothing, let the thread try again for a new appeal
					}
				}
			}
			
			
		} catch (Exception e) {
			
			theLogger.error(batchUID,"Exception while processing Data migration: "+ e.getMessage());

			errCode = -1;
		}finally {
			theLogger.performanceStartOnly(batchUID, "Data Migration " + processedAppeals + " appeals: ", startTime);

			theLogger.debug(batchUID, "Finished Data Migration " + processedAppeals + " appeals: ");

		}
		return errCode;
	}
	
	
	
	private int migrateAppeal(String appealNumber, long transactionId, int ecmIndex,
			List<String> documentList, String ecmUsername, String ecmPassword, 
			ListOfCorrespondence correspDocs, ListOSupportMaterials supportMat, ListOfDocumentGeneration docGen, String appealOp, String uniqueId) 
		{
		int errCode = 0;
		long startTime = System.currentTimeMillis();
		
		try {
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			
			tempDirectoryBuilder.append(constantConfig.getTempFileLocation());
			tempDirectoryBuilder.append("/");
			
			theLogger.debug(transactionId, "Root data migration directory: " + tempDirectoryBuilder.toString());
			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(transactionId, "Root data migration directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
				
				errCode = 1;
				return errCode;
			}
			
			
			Random rand = new Random();
		    
			int intRand = (int) rand.nextInt(99999999);
			
			StringBuilder tempAppealFolderBuilder = new StringBuilder(tempDirectoryBuilder.toString());
			
			tempAppealFolderBuilder.append(appealNumber);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(intRand);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(Util.getCurrentTimeStamp());
			
			theLogger.debug(transactionId, "Data migration directory: " + tempAppealFolderBuilder.toString());
			 
			if (false == Util.directoryCheck(tempAppealFolderBuilder.toString(), true) )
			{
				theLogger.debug(transactionId, "Data migration directory does not exist and could not be created: " + tempAppealFolderBuilder.toString());
				
				
				errCode = 2;
				return errCode;
			}
			
			
			FileWriter fw = null;
			try
			{
				String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";
			    fw = new FileWriter(manifestFilename, true);  
			    fw.write("Manifest file for Appeal Number " + appealNumber +  "\r\n");
			    fw.write("============================================================================\r\n");
			    fw.write("Appeal  Number: " + appealNumber + "\r\n");
			    fw.write("Transaction Id: " + transactionId + "\r\n");
			    fw.write("Processed Date: " + Util.convertCalendarToString(Calendar.getInstance(), "MM/dd/yyyy HH:mm:ss") +  "\r\n");
			    //fw.write("Documents in the appeal:\r\n");
			    fw.write("============================================================================\r\n");
			    fw.write("Document Type\tDocument Id\tFile Name\tFile Size\tMD5 Checksum\r\n");
			    fw.write("============================================================================\r\n");
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while adding appeal data to manifest file while data migration: " + ioe.getMessage());
				
				errCode = -1;
				
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				return errCode;
			}
			finally 
			{
				if (fw != null)
				{
					fw.close();
					fw = null;
				}
			}
			
			// Save  Siebel attachements to tempAppealFolderBuilder
			
			if (correspDocs != null)
			{
				List<Correspondence> correspList = correspDocs.getCorrespondence();
				if (correspList != null)
				{
					for (int cdx=0; cdx < correspList.size(); cdx++)
					{
						Correspondence corresp = correspList.get(cdx);
						if (corresp != null)
						{
							String fileExt = corresp.getFileExt();
							String fileName = corresp.getFileName();
							String fileSize = corresp.getFileSize();
							String uid = corresp.getAttachmentId();
						  
							errCode = saveSiebelAttachement(transactionId, fileExt, 
									fileName, fileSize, uid,
									tempAppealFolderBuilder.toString(), "Correspondence",appealNumber);
							if (errCode != 0)
							{
								Util.deleteDirectory(tempAppealFolderBuilder.toString());
								
								return errCode;
							}
						 
						}
					}
				}
				
			}
			
			if (supportMat != null)
			{
				List<SupportMaterial> mattList = supportMat.getSupportMaterial();
				if (mattList != null)
				{
					for (int mdx=0; mdx < mattList.size(); mdx++)
					{
						SupportMaterial matt = mattList.get(mdx);
						if (matt != null)
						{
							ListOfSupportMaterialAttachments materialAttachments = matt.getListOfSupportMaterialAttachments();
							if (materialAttachments != null)
							{
								List<SupportMaterialAttachment> mattAttList = materialAttachments.getSupportMaterialAttachment();
								
								if (mattAttList != null)
								{
									for (int adx = 0; adx < mattAttList.size(); adx++)
									{
										SupportMaterialAttachment att = mattAttList.get(adx);
										if (att != null)
										{
											String fileExt = att.getFileExt();
											String fileName = att.getFileName();
											String fileSize = att.getFileSize();
											String uid = att.getAttachmentId();
										 
											errCode = saveSiebelAttachement(transactionId, fileExt, 
																			fileName, fileSize, uid,
																			tempAppealFolderBuilder.toString(), "Support Material",appealNumber);
											if (errCode != 0)
											{
												Util.deleteDirectory(tempAppealFolderBuilder.toString());
												
												return errCode;
											}
										 
										}
									}
								}
							}
						}
					}
				}
				
			}
			
			if (docGen != null)
			{
				List<DocumentGeneration> docGenList = docGen.getDocumentGeneration();
				if (docGenList != null)
				{
					for (int cdx=0; cdx < docGenList.size(); cdx++)
					{
						DocumentGeneration docGeneration = docGenList.get(cdx);
						if (docGeneration != null)
						{
							String fileExt = docGeneration.getFileExt();
							String fileName = docGeneration.getFileName();
							//String fileSize = docGeneration.getFileSize();
							String uid = docGeneration.getAttachmentId();
						  
							errCode = saveSiebelAttachement(transactionId, fileExt, 
									fileName, null, uid,
									tempAppealFolderBuilder.toString(), "DocumentGeneration",appealNumber);
							if (errCode != 0)
							{
								Util.deleteDirectory(tempAppealFolderBuilder.toString());
								
								return errCode;
							}
						 
						}
					}
				}
				
			}
			
			errCode = ecmService.exportECMContent(appealNumber, ecmUsername, ecmPassword, tempAppealFolderBuilder.toString(), documentList, transactionId);
			
			 
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while downloading ECM files: " + appealNumber + " to: " + tempAppealFolderBuilder.toString());
				return errCode;
			}
			 
			theLogger.debug(transactionId, "Downloaded ECM Files for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
			
			// Download appealData from Siebel
			
			String tempAppealFile = tempAppealFolderBuilder.toString() + "/AppealData.xml";
			
			
			errCode = siebelService.getDataMigrationAppealData(appealNumber, transactionId, tempAppealFile, uniqueId);
			
		 
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while downloading appeal data from Siebel for appeal: " + appealNumber + " to: " + tempAppealFile);
				return errCode;
			}
			
			theLogger.debug(transactionId, "Downloaded appeal data from Siebel for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
						
			// Add info to manifest file
			try
			{
				File appealFile = new File(tempAppealFile);
 
				String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";

			    fw = new FileWriter(manifestFilename, true);  
				
			    fw.write("Appeal Data\t" + appealNumber + "\tAppealData.xml\t" + appealFile.length() + "\t" + Util.getMD5CheckSum(appealFile) + "\r\n"); //appends the string to the file
			    
			}
			catch (Exception ioe)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Exception while writing to the manifest file: " + ioe.getMessage());
				
				errCode = -1;
				return errCode;
			}
			finally 
			{
				if (fw != null)
				{
					fw.close();
					fw = null;
				}
			}
		 
			
			
			// Sign manifest file
			
			FileOutputStream sigfos = null;
			try
			{
				// String keyStoreFile = "/resources/mykeystore.jks";  
			    // String password = "mypassword";  
			    //  String alias = "mycert"; 
			    
				theLogger.debug(transactionId, "Generating signature file...");
				
				
				String keyStoreFile =  constantConfig.getKeystoreName();
			    String password = constantConfig.getKeystorePassword();
			    String alias = constantConfig.getKeyAlias(); 
			    String keyPassword = constantConfig.getKeyPassword();
				
				KeyStore keystore = KeyStore.getInstance("JKS");  
	            char[] storePass = password.toCharArray();  
	            char[] keyPasswd = keyPassword.toCharArray(); 
	  
	            //load the key store from file system  
	            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
	            keystore.load(fileInputStream, storePass);  
	            fileInputStream.close();  
	  
	             
	            //read the private key  
	            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
	            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
	            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
	  
	            //initialize the signature with signature algorithm and private key  
	            Signature signature = Signature.getInstance("SHA256withRSA");  
	            signature.initSign(privateKey);  
	            
	            // read manifest and s sign
	            String manifestFilename = tempAppealFolderBuilder.toString() + "/manifest.txt";
	
	            FileInputStream fis = new FileInputStream(manifestFilename);
	            BufferedInputStream bufin = new BufferedInputStream(fis);
	            byte[] buffer = new byte[10000];
	            int len;
	            while ((len = bufin.read(buffer)) >= 0) {
	            	signature.update(buffer, 0, len);
	            };
	            bufin.close();
  
	            byte[] digitalSignature = signature.sign();
 
				String signatureFilename = tempAppealFolderBuilder.toString() + "/signature.txt";
 
				sigfos = new FileOutputStream(signatureFilename);
			    sigfos.write(digitalSignature);
			    sigfos.close(); 
			    
			    theLogger.debug(transactionId, "Signature file generated: " + signatureFilename);
			}
			catch (Exception ioe)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Exception while writing signature file: " + ioe.getMessage());
				
				errCode = -1;
				return errCode;
			}
			finally 
			{
				if (sigfos != null)
				{
					sigfos.close();
					sigfos = null;
				}
			}
 
			// Compress and move file
 
			StringBuilder compressFilePath = new StringBuilder();		
			compressFilePath.append(tempDirectoryBuilder.toString());
			// BUG FOUND
			// compressFilePath.append("/");
			compressFilePath.append(appealNumber);
			compressFilePath.append("_");
			compressFilePath.append("DM");
			compressFilePath.append("_");
			compressFilePath.append(transactionId);
			compressFilePath.append(".zip");
			
			errCode =  Util.compressContent(tempAppealFolderBuilder.toString(), compressFilePath.toString(), transactionId);
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while compressing appeal: " + appealNumber + " to: " + compressFilePath.toString());
				return errCode;
			}
			theLogger.debug(transactionId, "Compressed appeal: " + appealNumber + " to: " + compressFilePath.toString());
			
			if (errCode != 0)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				theLogger.error(transactionId, "Error while compressing appeal: " + appealNumber + " to: " + compressFilePath.toString());
				return errCode;
			}
			theLogger.debug(transactionId, "Compressed appeal: " + appealNumber + " to: " + compressFilePath.toString());
						
			Util.deleteDirectory(tempAppealFolderBuilder.toString());
			theLogger.debug(transactionId, "Removed temporary appeal folder: " + tempAppealFolderBuilder.toString());

			// Move compressFilePath ZIP file to EFT
			//T#EFT.ON.MAS.L3SVC.ORGID.DYYMMDD.THHMMSST
			 
			//File zipFile = new File(compressFilePath.toString());
			//String zipFileName = zipFile.getName();
			
			StringBuilder eftFileLocation = new StringBuilder(constantConfig.getEftLocation());	
			eftFileLocation.append("/");
			eftFileLocation.append(constantConfig.getEftDataMigrationFilePrefix());
			
			eftFileLocation.append(".D");
			
			//DYYMMDD.THHMMSST   
			
			Date rightNow = new Date();
			String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
			String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
			
			eftFileLocation.append(dateStamp);	
			eftFileLocation.append(".T");
			eftFileLocation.append(timeStamp);
			
			String destFile = eftFileLocation.toString();
			boolean fileNameAvailable = false;
			for (int fidx = 0;  fidx <= 9; fidx++)
			{
				String tryFileName = destFile + fidx;
				 
				File f = new File(tryFileName);
				if(f.exists() == false)
				{
					 
					theLogger.debug(transactionId, "Copying ZIP file : " + compressFilePath.toString() + " to EFT: " + tryFileName);
					
					errCode =  Util.copyFile(compressFilePath.toString(), tryFileName);
					if (errCode != 0)
					{
						theLogger.error(transactionId, "Try " + fidx + ": Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder: " + tryFileName);
					}
					else
					{
						theLogger.debug(transactionId, "Copied compressed file for appeal " + appealNumber + " to EFT folder: " + tryFileName);
						fileNameAvailable = true;
						break;
					}

				}
				
			}
			

			if (fileNameAvailable == false)
			{
				errCode = -1;
				// Util.deleteFile(compressFilePath.toString());
				theLogger.error(transactionId, "Could not find available file name on EFT for appeal: " + appealNumber + " for generated filename: " + destFile + ". Original ZIP file will be kept in the temp folder.");
				return errCode;
			}
			else
			{
						
				// Delete original ZIP File
				errCode =  Util.deleteFile(compressFilePath.toString());
				if (errCode != 0)
				{
					theLogger.error(transactionId, "Error while deleting compressed appeal file for appeal: " + appealNumber + " from temp folder: " + compressFilePath.toString());
					//return errCode;
					errCode = 0;
				}
				else
				{
					theLogger.debug(transactionId, "Deleted compressed file for appeal " + appealNumber + " from temp folder: " + compressFilePath.toString());
				}
		 
			}
		
			theLogger.debug(transactionId, "Successfully Data migrated appeal " + appealNumber);
			
			
		} catch (Exception e) {
			
			theLogger.error(transactionId, "Exception while migrating the appeal : " + appealNumber +  ". Exception: " + e.getMessage() );
		}


		return errCode;

	}
	
	protected int saveSiebelAttachement(long transactionId, String fileExt,	String fileName, String fileSize, String attachementId, String folderName, String docType, String appealNumber)
	{
			if(docType == "DocumentGeneration"){
				if (folderName == null || fileExt == null || fileName == null || attachementId == null )
				 {
					 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where null." );
					 return -1;
				 }
				 
				 if (folderName.length() < 1 || fileExt.length() < 1 || fileName.length() < 1 || attachementId.length() < 1)
				 {
					 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where empty." );
					 return -1;
				 }
			}else{
			 if (folderName == null || fileExt == null || fileName == null || fileSize == null || attachementId == null )
			 {
				 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where null." );
				 return -1;
			 }
			 
			 if (folderName.length() < 1 || fileExt.length() < 1 || fileName.length() < 1 || fileSize.length() < 1 || attachementId.length() < 1)
			 {
				 theLogger.error(transactionId, "Error while saving Siebel attachement: input parameters where empty." );
				 return -1;
			 }
			}
			 String siebelAttachementPath = folderName + "/" + attachementId + "_" + fileName + "." + fileExt;
			 
			 theLogger.debug(transactionId, "Saving Siebel Attachement: " + fileName + " to: " + siebelAttachementPath);
				
			 
			 FileOutputStream fos = null;
			 
			 byte[] fileContent = siebelService.getDocAttachment(attachementId, transactionId,appealNumber);
		 
			 if (fileContent == null)
			 {
				 // already logged the error message
				 return -1;
			 }
			 
		 	try
			{
				 fos = new FileOutputStream(siebelAttachementPath);
				 fos.write(fileContent);
				 fos.close();
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while writing the Siebel atatchement to file: " + ioe.getMessage());
				
				return -2;
			}
			finally 
			{
				if (fos != null)
				{
					try { fos.close(); } catch (Exception iex) {}
				}
			}
			
			
		 	FileWriter fw = null;
			try
			{
			    String manifestFilename = folderName + "/manifest.txt";
			    fw = new FileWriter(manifestFilename, true); //the true will append the new data
			    
			    File exportedFile = new File(siebelAttachementPath);
				String fName = exportedFile.getName();
				
			    fw.write(docType + "\t" + attachementId + "\t" + fName + "\t" + exportedFile.length() + "\t" + Util.getMD5CheckSum(exportedFile) + "\r\n"); //appends the string to the file
			    
			}
			catch (Exception ioe)
			{
				theLogger.error(transactionId, "Exception while writing to the manifest file: " + ioe.getMessage());
				
				return -2;
			}
			finally 
			{
				if (fw != null)
				{
					try 
					{ 
						fw.close(); 
					} catch (Exception iex) {}
				}
			}
			
			return 0;
	}
	
}
