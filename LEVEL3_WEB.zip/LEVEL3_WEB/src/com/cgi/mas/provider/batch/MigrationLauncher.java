package com.cgi.mas.provider.batch;


import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;

import org.springframework.batch.core.StepExecution;
//import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.util.Util;

 
@Service("migrationLauncher")
public class MigrationLauncher {
	
	private CustomLogger theLogger = new CustomLogger(MigrationLauncher.class); 
	
	@Autowired
	private SimpleJobLauncher jobLauncher;	
	@Autowired
	private Job migrationAppealProcessor;
	@Autowired
	private MapJobRepositoryFactoryBean jobRepository;	
	
	//@Autowired
	//private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelService siebelService;
	
	private static Map<String, JobExecution> jobHistory = new Hashtable<String, JobExecution>();


	public void migrationProcess() {
		
		long batchUID = theLogger.generateUID();
		
		try {
			String currentTime = Util.convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);

			theLogger.debug(batchUID, "Starting new batch for data migration.");
			
			getJobsStatus(batchUID);	
			
			Set<JobExecution>runningJob = getRunningJobs(batchUID);		
			
			if (runningJob.isEmpty()) {
				//theLogger.debug(batchUID, "No active running jobs from previous batch.");

				cleanUpJobs(runningJob, batchUID);
				
				
				long readyAppeals = getAppealsNumReadyInSiebel(batchUID);
				if( readyAppeals > 0 )
				{
					JobParametersBuilder jobParameterBuilder = new JobParametersBuilder();
					jobParameterBuilder.addString("currentTime", currentTime);
					jobParameterBuilder.addLong("totalMigrationAppeals", readyAppeals);
					jobParameterBuilder.addLong("batchUID", batchUID);
					
					JobExecution jobExecution = jobLauncher.run(migrationAppealProcessor,
						jobParameterBuilder.toJobParameters());	
					
					jobHistory.put(currentTime, jobExecution);
				}	
				else
				{
					theLogger.debug(batchUID, "There are no appeals ready for data migration in Siebel" );
				}
			} else {
				theLogger.debug(batchUID, "There are still running jobs from previous batch:  " + runningJob.size() );
				displayRunningJobs(runningJob, batchUID);
			} 
		} catch (Exception e) {
			theLogger.error(batchUID, "Exception while starting new job in startProcess: ", e);
		}
	}

	// ----------------------Private Method-------------
	private void getJobsStatus(long batchUID){
		try{
			//theLogger.debug(batchUID, "Checking status of previous jobs: " + jobHistory.size());
			for (String key: jobHistory.keySet()){			
				JobExecution jobEx = jobHistory.get(key);
				String exitCode = jobEx.getExitStatus().getExitCode();
				theLogger.debug(batchUID, "\t\t Previous Job: " + key + "\t Exit Code: " + exitCode + " --> " + jobEx.toString());
				if (!exitCode.equalsIgnoreCase(ExitStatus.COMPLETED.getExitCode().toString())) {
					if (exitCode.equalsIgnoreCase(ExitStatus.FAILED.getExitCode().toString())) {
						Collection<StepExecution>stepCollection = jobEx.getStepExecutions();
						for (StepExecution step: stepCollection){
							theLogger.debug(batchUID, "Child Step: " + step.toString());
						}
					}
				}
				if(!exitCode.equalsIgnoreCase(ExitStatus.UNKNOWN.toString())){
					jobHistory.remove(key);	
				}			
			}	
		}catch(Exception e){
			theLogger.error(batchUID, "Exception in getJobsStatus: ", e);
		}
	}
	
	private void displayRunningJobs(Set<JobExecution>jobList, long batchUID){
		for (JobExecution job : jobList){			
			theLogger.debug(batchUID, "\t\t Running job: " + job.getId() + "\t Exit Code: " + job.getExitStatus().getExitCode() + " --> " + job.toString());
		}
	}
	
	private Set<JobExecution> getRunningJobs(long batchUID){
		Set<JobExecution>runningJob = jobRepository.getJobExecutionDao().findRunningJobExecutions(migrationAppealProcessor.getName());
		return runningJob;
	}	
	
	private void cleanUpJobs(Set<JobExecution> runningJob, long batchUID){
		theLogger.debug(batchUID, "Cleaning previous jobs: " + runningJob.size());		
		if (runningJob.isEmpty())
		{			
			jobRepository.clear();			
		} else {
			theLogger.debug(batchUID, "Total Running jobs: " + runningJob.size());
			for (JobExecution ex : runningJob){			
				theLogger.debug(batchUID, "RunningJobDetail: "+ex.toString());
			}
		}
	}		
	
 
	private long getAppealsNumReadyInSiebel(long batchUID){
		long appealNum = 0;
		 
		int migrationAppeals = siebelService.optStatusControl("Data Migration", "Validated", batchUID);

		if (migrationAppeals > 0)
			appealNum = migrationAppeals;
		
		return appealNum;	
	}

}
