package com.cgi.mas.provider;

public class ErrorFieldConstant {
	public final static String INVALID_EXTENSION_EXCEPTION="MAS-100";
	public final static String MISS_PARAMETERS="MAS-101";
	public final static String FUTURE_DT_EXCEPTION="MAS-102";
	public final static String INVALID_PREFIX_TIBCO_EXCEPTION="MAS-103";
	//public final static String DUPLICATE_DOC_REQUEST_EXCEPTION="MAS-104";
	public final static String MISSMATCH_CHECKSUM_EXCEPTION="MAS-105";
	public final static String DUPLICATE_FILE_ID_EXCEPTION="MAS-106";
	public final static String INVALID_ORIG_FILE_NAME="MAS-107";
	public final static String MISMATCH_MIMETYPE_EXCEPTION="MAS-108";
//	public final static String CREATE_APPEAL_EXCEPTION="createAppeal.exception";
	public final static String MISMATCH_RESOURCE_EXCEPTION="mismatchResource.exception";
	
public final static String INVALID_ORG_PREFIX="MAS-109";
public final static String INVALID_APPEAL_CREATION="MAS-110";
public final static String INVALID_ORG="MAS-111";
public final static String APPEAL_FOLDER_DOESNOT_EXIST="ecm.invalid.appeal";


	
	
	//---------Error Code	
	public final static String INVALID_ORG_CODE="MAS-200";
	public final static String S_GENERAL_CODE="MAS-201";
	public final static String INVALID_TIBCO_FORMAT_EXCEPTION="MAS-202";
	public final static String INVALID_CERT_CODE="MAS-203";
	
	public final static String INVALID_SECURITY_TOKEN="MAS-301";
	
	
	
	//L2 Appeal fields
	
	public final static String MISS_PARAMETERS_L2="MAS-J-ERR-101";
	public final static String SIEBEL_ERROR="MAS-J-ERR-102";
	public final static String BAD_PARAMETERS="MAS-J-ERR-103";
	public final static String BAD_CONSUMERID="MAS-J-ERR-104";
	public final static String BAD_MIME_TYPE="MAS-J-ERR-105";
	
	
	//RAC MockService Errors
	public final static String BAD_MIME_TYPE1="MAS-J-ERR-207";
	public final static String MISS_PARAMETERS_RAC="MAS-J-ERR-101";
	public final static String MISS_CONTRACTID="BAD-CONTRACTID";
	public final static String BAD_PUBLICKEY="BAD_PUBLICKEY";
	public final static String MISS_CLAIMNUM="MISS_CLAIMNUM";
	public final static String INVALID_CLAIM="MAS-S-ERR-150";
	public final static String MISS_APPEALNUMBER="MISS_APPEALNUMBER";
	public final static String TRANSACTIONID_NULL="TRANSACTIONID_NULL";
}
