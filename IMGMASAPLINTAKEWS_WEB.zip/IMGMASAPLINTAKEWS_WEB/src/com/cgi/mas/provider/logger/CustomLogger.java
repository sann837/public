package com.cgi.mas.provider.logger;

import org.apache.log4j.Logger;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderUtils;

public class CustomLogger extends Logger {
//	private Logger logger = null;
	private Logger performanceLogger = null;
	private ConstantConfig constantConfig = null;
	private Class clazz = null;
	
	public CustomLogger(Class clazz) {
		super(clazz.getName());
		setClass(clazz);
		performanceLogger = Logger.getLogger("performance.provider");		
	}

	private void setClass(Class clazz) {
		this.clazz = clazz;
	}
	
	public void setConstantConfig(ConstantConfig constantConfig) {
		this.constantConfig = constantConfig;
	}
	
	public Logger getLogger() {
		return getLogger(clazz);
	}
	
	public Logger getOtherLogger(String className) {
		return getLogger(className);
	}

	public void performance(String msg) {
		performance(msg, -1);
	}
	
	public void performanceStartOnly(String msg, long startTime) {
		performance(msg, (System.currentTimeMillis()-startTime));
	}

	public void performance(String msg, long start_stop) {
		if(constantConfig == null || constantConfig.isPerformanceLogging()) {
			String classAndMessage = "[" + clazz.getCanonicalName() + "]:  " + msg;
			String timeMessage = "";
			if(start_stop > -1) {
				timeMessage = "\t Total Time: " + ProviderUtils.getFormattedDate(start_stop, null, "HH:mm:ss.SSS");
			}
			
			performanceLogger.info(classAndMessage + timeMessage);
			if(constantConfig != null && constantConfig.isExtraLogging()) {
				System.out.println("PERFORMANCE:: " + classAndMessage + timeMessage);
			}
		}
	}
}
