package com.cgi.mas.provider.logger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderUtils;

public class RACCFCustomLogger extends QICCustomLogger {

	//private Logger logger = null;
	private Logger racCFPerformanceLogger = null;
	private Logger racCFLogger = null;
	private ConstantConfig constantConfig = null;
	private Class clazz = null;
	
	static private int failedAppeals = 0;

	public RACCFCustomLogger(Class clazz) {
		super(clazz);
		setClass(clazz);
		racCFPerformanceLogger = Logger.getLogger("raccf.performance.provider");
		racCFLogger = Logger.getLogger("raccfLogger");
	}

	private void setClass(Class clazz) {
		this.clazz = clazz;
	}

	public void setConstantConfig(ConstantConfig constantConfig) {
		this.constantConfig = constantConfig;
	}

	public Logger getLogger() {
		return getLogger(clazz);
	}

	/*
	 * public Logger getOtherLogger(String className) { return
	 * getLogger(className); }
	 */

	public Logger getRacCFLogger() {
		return racCFLogger;
	}

	public void setRacCFLogger(Logger racCFLogger) {
		this.racCFLogger = racCFLogger;
	}

	public void performance(String msg) {
		performance(msg, -1);
	}

	public void performanceStartOnly(String msg, long startTime) {
		performance(msg, (System.currentTimeMillis() - startTime));
	}

	public void performance(String msg, long start_stop) {
		if (constantConfig == null || constantConfig.isPerformanceLogging()) {
			String classAndMessage = "[" + clazz.getCanonicalName() + "]:  "
			+ msg;
			String timeMessage = "";
			if (start_stop > -1) {
				timeMessage = "\t Total Time: "
					+ ProviderUtils.getFormattedDate(start_stop, null,
					"HH:mm:ss.SSS");
			}

			racCFPerformanceLogger.info(classAndMessage + timeMessage);
			if (constantConfig != null && constantConfig.isExtraLogging()) {
				System.out.println("PERFORMANCE:: " + classAndMessage
						+ timeMessage);
			}
		}
	}

	// RAC CF Request Webservice
	public void performance(long uid, String msg, long start_stop) {
		if (constantConfig == null || constantConfig.isPerformanceLogging()) {
			String classAndMessage = "[" + clazz.getCanonicalName() + "]:  "
			+ msg;
			String timeMessage = "";
			if (start_stop > -1) {
				timeMessage = "\t Total Time: "
					+ ProviderUtils.getFormattedDate(start_stop, null,
					"HH:mm:ss.SSS");
			}

			racCFPerformanceLogger.info(classAndMessage + timeMessage);
			if (constantConfig != null && constantConfig.isExtraLogging()) {
				System.out.println("PERFORMANCE UID: " + uid + " - "
						+ classAndMessage + timeMessage);
			}
		}
	}

	public void performanceStartOnly(long uid, String msg, long startTime) {
		performance(uid, msg, (System.currentTimeMillis() - startTime));
	}

	private long lastUidTime = 0;
	List<Long> UIDs = new ArrayList<Long>();

	public synchronized long generateUID() {
		long uid;

		try {
			long current_time = System.currentTimeMillis();

			if (current_time != lastUidTime) {
				lastUidTime = current_time;

				Random rand = new Random();

				int intRand = (int) rand.nextInt(999999);

				uid = (current_time * 1000000) + intRand;

				if (constantConfig.getTotalJVMs() > 1) {
					long remainder = uid % constantConfig.getTotalJVMs();
					long diff = constantConfig.getThisJVMid() - remainder;

					if (diff != 0) {
						uid = uid + diff;
					}
				}

				UIDs.clear();
				UIDs.add(uid);
			} else {
				boolean alreadyGenerated = false;

				do {
					Random rand = new Random();

					int intRand = (int) rand.nextInt(999999);

					uid = (current_time * 1000000) + intRand;

					if (constantConfig.getTotalJVMs() > 1) {
						long remainder = uid % constantConfig.getTotalJVMs();
						long diff = constantConfig.getThisJVMid() - remainder;

						if (diff != 0) {
							uid = uid + diff;
						}
					}

					alreadyGenerated = false;
					Iterator<Long> myListIterator = UIDs.iterator();
					while (myListIterator.hasNext()) {
						Long genUid = myListIterator.next();
						if (uid == genUid) {
							alreadyGenerated = true;
							break;
						}
					}

				} while (alreadyGenerated == true);

				UIDs.add(uid);
			}
		} catch (Exception ex) {
			long current_time = System.currentTimeMillis();

			Random rand = new Random();

			int intRand = (int) rand.nextInt(999999);

			uid = (current_time * 1000000) + intRand;
		}

		return uid;
	}

	public void trace(long uid, String msg) {
		this.getLogger().trace("UID: " + uid + " - " + msg);
	}

	public void info(long uid, String msg) {
		this.getLogger().info("UID: " + uid + " - " + msg);
	}

	public void debug(long uid, String msg) {
		// if(constantConfig == null || constantConfig.isQicLogging()) {
		String classAndMessage = " " + clazz.getCanonicalName() + "]: UID: "
		+ uid + " - " + msg;

		racCFLogger.debug(classAndMessage);

		// }

	}
	

	public void error(long uid, String msg, Exception ex) {
		String classAndMessage = " " + clazz.getCanonicalName() + "]: UID: "
		+ uid + " - " + msg;

		racCFLogger.error(classAndMessage, ex);

	}

	public void error(long uid, String msg, Error ex) {
		String classAndMessage = " " + clazz.getCanonicalName() + "]: UID: "
		+ uid + " - " + msg;

		racCFLogger.error(classAndMessage, ex);
	}

	public void error(long uid, String msg) {
		String classAndMessage = " " + clazz.getCanonicalName() + "]: UID: "
		+ uid + " - " + msg;

		racCFLogger.error(classAndMessage);
	}
	

	public void fatal(long uid, String msg, Throwable t) {
		this.getLogger().fatal("UID: " + uid + " - " + msg, t);
	}

	public int incrementFailedAppeals()
	{
		failedAppeals = failedAppeals + 1;
		return failedAppeals;
	}

}
