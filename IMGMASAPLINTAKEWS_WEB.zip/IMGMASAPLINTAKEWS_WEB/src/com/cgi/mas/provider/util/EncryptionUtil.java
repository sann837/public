/*
 * Created on Aug 15, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cgi.mas.provider.util;

import java.io.UnsupportedEncodingException;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import com.cgi.mas.provider.exceptions.CMAplIntakeWSException;

/**
 * @author dhoke
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class EncryptionUtil {
	//private static final String DESEDE_ENCRYPT_SCHEME = "DESede";
	//private final static String DES_ENCRYPT_SCHEME = "DES";
	
	private final static String DEFAULT_KEY = "0123452C4NUD1G1t0050816197850017CM$";
	
	private KeySpec keySPC;
	private SecretKeyFactory keyFctry;
	private Cipher ciph;
	
	public EncryptionUtil() throws CMAplIntakeWSException {
		initEncrypter(DEFAULT_KEY);
	}
	
	public EncryptionUtil(String encryptKey) throws CMAplIntakeWSException {
		if (encryptKey == null) {
			throw new CMAplIntakeWSException("Encryptionkey is null. Unable to instantiate object.");
		}
			
		initEncrypter(encryptKey);
	}
	
	private void initEncrypter(String encryptKey) throws CMAplIntakeWSException {
		//convert key to byte array
		try {
			byte[] keyBytes = encryptKey.getBytes("UTF-8");
			
			keySPC = new DESKeySpec(keyBytes);
			
			keyFctry = SecretKeyFactory.getInstance("DES");
			ciph = Cipher.getInstance("DES");
		} catch (Exception e) {
			throw new CMAplIntakeWSException("An error ocurred during encryption util intitialization",e);
		}		
	}
	
	public String encryptIt(String needsEncryptString) throws CMAplIntakeWSException {
		if (needsEncryptString == null || needsEncryptString.length() == 0) {
			throw new CMAplIntakeWSException("unable to encrypt null or empty string");
		}
		
		try {
			SecretKey key = keyFctry.generateSecret(keySPC);
			ciph.init(Cipher.ENCRYPT_MODE, key);
			byte[] byteNeedsEncrypt = needsEncryptString.getBytes("UTF-8");
			byte[] byteNeedsEncryptCipher = ciph.doFinal(byteNeedsEncrypt);
			
			return new BASE64Encoder().encode(byteNeedsEncryptCipher);
		} catch (Exception e) {
			throw new CMAplIntakeWSException("Unable to encrypt string",e);
		}
	}
	
	public String decryptIt(String needsUnencryptString) throws CMAplIntakeWSException {
		if (needsUnencryptString == null || needsUnencryptString.length() == 0) {
			throw new CMAplIntakeWSException("unable to decrypt null or empty string");
		}
				
		try {
			SecretKey key = keyFctry.generateSecret(keySPC);
			ciph.init(Cipher.DECRYPT_MODE, key);
			BASE64Decoder decoder = new BASE64Decoder();
			byte[] byteNeedsDecrypt = decoder.decodeBuffer(needsUnencryptString);
			byte[] byteNeedsDecryptCipher = ciph.doFinal(byteNeedsDecrypt);
	
			return new String(byteNeedsDecryptCipher);
		} catch (Exception e) {
			throw new CMAplIntakeWSException("Unable to decrypt string", e);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	static Object[] randomAlphabetArray = null;
	public static String encryptMessage(String str) {
		String encryptedString = inverseMessage(reverseMessage(str));
		
//		encryptedPassword = Base64Coder.base64Encode(encryptedPassword);
//		BASE64Encoder encoder = new BASE64Encoder();
		try {
			encryptedString  = (new BASE64Encoder()).encode(encryptedString.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return encryptedString;
	}
	
	public static String decryptMessage(String str) {
		String decryptedString = inverseMessage(reverseMessage(str));
		
		return decryptedString;
	}
	
	private static String reverseMessage(String str) {
		StringBuffer sb = new StringBuffer();
		
		for(int i=0; i<str.length(); i++)
			sb.insert(0, str.substring(i, i+1));
		
		return sb.toString();
	}
	
	private static String inverseMessage(String str) {
		StringBuffer sb = new StringBuffer();
		
		
		String[] linearAlphabetArray = {"a", "b", "c", "d", "e", "f", 
										"g", "h", "i", "j", "k", "l", 
										"m", "n", "o", "p", "q", "r", 
										"s", "t", "u", "v", "w", "x", 
										"y", "z", "A", "B", "C", "D", 
										"E", "F", "G", "H", "I", "J", 
										"K", "L", "M", "N", "O", "P", 
										"Q", "R", "S", "T", "U", "V", 
										"W", "X", "Y", "Z", "0", "1", 
										"2", "3", "4", "5", "6", "7", 
										"8", "9"};
		
		String[] qwertyAlphabetArray = {"q", "w", "e", "r", "t", "y", 
										"u", "i", "o", "p", "a", "s", 
										"d", "f", "g", "h", "j", "k", 
										"l", "z", "x", "c", "v", "b", 
										"n", "m", "Q", "W", "E", "R", 
										"T", "Y", "U", "I", "O", "P", 
										"A", "S", "D", "F", "G", "H", 
										"J", "K", "L", "z", "X", "C", 
										"V", "B", "N", "M", "0", "1", 
										"2", "3", "4", "5", "6", "7", 
										"8", "9"};
		
		if(randomAlphabetArray == null) {
			ArrayList<String> randomAplphList = new ArrayList<String>();
			randomAplphList.addAll(Arrays.asList(linearAlphabetArray));
			
			ArrayList<String> randomArray = new ArrayList<String>();
			Random ranNumGen = new Random();
			while(randomAplphList.size() > 0) {
				int randomNum = ranNumGen.nextInt(randomAplphList.size());
				String nextLetter = randomAplphList.get(randomNum);
				
				if(!randomArray.contains(nextLetter)) {
					randomArray.add(nextLetter);
					randomAplphList.remove(randomNum);
				}
			}
	
			randomAlphabetArray = randomArray.toArray();
		}
		
		
		for(int i=0; i<str.length(); i++) {
			int j=1;
			for(Object randLetter : randomAlphabetArray) {
				String strLetter = str.substring(i, (i+1));
				if(((String)randLetter).equals(strLetter)) break;
				
				j++;
			}
			
			String newLetter = (String)randomAlphabetArray[(randomAlphabetArray.length-j)];
			
			sb.insert(0, newLetter);
		}
		
		return sb.toString();
	}
}