package com.cgi.mas.provider.util;

 
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.QICCustomLogger;
 
 
public class Util {

	private static QICCustomLogger theLogger = new QICCustomLogger(Util.class);
	private static Logger logger = theLogger.getLogger();

	public static int compressFilesInFolder(String contentPath, String targetPath, long transactionId) {
		int errCode = 0;
		ZipOutputStream zip = null;
		FileOutputStream  fileWriter = null;
		//String compressFilePath = null;
		
		theLogger.debug(transactionId, "Compressing files in folder: " + contentPath + " to file: " + targetPath);
				
		try {
			fileWriter = new FileOutputStream(targetPath);
			zip = new ZipOutputStream(fileWriter);
			
			double maxSizeOfFolder = getFolderSize(contentPath);		
			if (maxSizeOfFolder <= 0)
			{
				errCode = -1;
				return errCode;
			}
			
			errCode = addFilesInFolderToZip("", contentPath, zip, 0, maxSizeOfFolder, transactionId);
			if (errCode != 0)
			{
				theLogger.error(transactionId, "Failed to compress folder: " + contentPath); 
				return errCode;
			}
			
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while compressing folder: " + e.getMessage());
			errCode = -1;
		} finally {
			theLogger.debug(transactionId, "Done compressing folder: " + contentPath);
			if (zip != null) 
			{
				// close zip
				try {
					//zip.flush();
					
					zip.closeEntry();
					
					zip.close();
					fileWriter.close();
					theLogger.debug(transactionId, "Closed zip file: " + targetPath);
				} catch (IOException e) {
					theLogger.error(transactionId,	"Exception closing the ZIP: " + e);
				}
				
				// delete folder
				try {
					theLogger.debug(transactionId, "Prepare to delete export folder: " + contentPath);
					FileUtils.deleteDirectory(new File(contentPath));
					theLogger.debug(transactionId, "Deleted export folder: " + contentPath);
				} catch (Exception ex) {
					theLogger.error(transactionId,	"Exception deleting directory: " + ex);
				}

			}
		}
		return errCode;
	}
	
	public static int compressContent(String contentPath, String targetPath, long transactionId) {
		int errCode = 0;
		ZipOutputStream zip = null;
		FileOutputStream  fileWriter = null;
		//String compressFilePath = null;
		
		theLogger.debug(transactionId, "Compressing folder: " + contentPath + " to file: " + targetPath);
				
		try {
			fileWriter = new FileOutputStream(targetPath);
			zip = new ZipOutputStream(fileWriter);
			
			double maxSizeOfFolder = getFolderSize(contentPath);		
			if (maxSizeOfFolder <= 0)
			{
				errCode = -1;
				return errCode;
			}
			
			errCode = addFolderToZip("", contentPath, zip, 0, maxSizeOfFolder, transactionId);
			if (errCode != 0)
			{
				theLogger.error(transactionId, "Failed to compress folder: " + contentPath); 
				return errCode;
			}
			
			//compressFilePath.append(targetPath);
			
			//theLogger.debug(transactionId, "Prepare to delete export folder: " + contentPath);
			//FileUtils.deleteDirectory(new File(contentPath));
			//theLogger.debug(transactionId, "Deleted export folder: " + contentPath);
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while compressing folder: " + e.getMessage());
			errCode = -1;
		} finally {
			theLogger.debug(transactionId, "Done compressing folder: " + contentPath);
			if (zip != null) 
			{
				// close zip
				try {
					//zip.flush();
					
					zip.closeEntry();
					
					zip.close();
					fileWriter.close();
					theLogger.debug(transactionId, "Closed zip file: " + targetPath);
				} catch (IOException e) {
					theLogger.error(transactionId,	"Exception closing the ZIP: " + e);
				}
				
				// delete folder
				try {
					theLogger.debug(transactionId, "Prepare to delete export folder: " + contentPath);
					FileUtils.deleteDirectory(new File(contentPath));
					theLogger.debug(transactionId, "Deleted export folder: " + contentPath);
				} catch (Exception ex) {
					theLogger.error(transactionId,	"Exception deleting directory: " + ex);
				}

			}
		}
		return errCode;
	}
	
	private static double getFolderSize(String path) {	
		File file = new File(path);
		if(file.exists()) {
			if(file.isDirectory()) {
				return FileUtils.sizeOfDirectory(file);
			} else {
				return FileUtils.sizeOfDirectory(file.getParentFile());
			}
		}		
		return -1;
	}

	private static double addFileToZip(String path, String srcFile, ZipOutputStream zip, double currentSize, double maxSize, long transactionId)
			throws Exception {

		File folder = new File(srcFile);
		if (folder.isDirectory()) {
			theLogger.debug(transactionId, "Adding sub-directory: " + srcFile + " to zip: " +  path);
			
			int errCode = addFolderToZip(path, srcFile, zip,  currentSize, maxSize, transactionId);
			if (errCode < 0)
			{
				return errCode;
			}
		} else {
			
			FileInputStream inStream = new FileInputStream(srcFile);
			
			String zentry = path + "/" + folder.getName();
			
			//String zentry = folder.getName();
			
			theLogger.debug(transactionId, "Adding file: " + srcFile + " to zip: " +  path + " as entry: " + zentry);
			
			zip.putNextEntry(new ZipEntry(zentry));
			double totalBytes = writeDataToStream(inStream, zip, currentSize, false, transactionId);
			
			zip.closeEntry();
			
			theLogger.debug(transactionId, "Added " + totalBytes + " bytes for file : " + srcFile + " to zip: " +  path);
			
			if (totalBytes < 0)
				return -1;
			else
				return totalBytes;
		}
		
		return currentSize;
	}

	private static double addFileToZipWithoutFolder(String path, String srcFile, ZipOutputStream zip, double currentSize, double maxSize, long transactionId)
	throws Exception {

	File folder = new File(srcFile);
	if (folder.isDirectory()) {
		theLogger.debug(transactionId, "Adding sub-directory: " + srcFile + " to zip: " +  path);
		
		int errCode = addFilesInFolderToZip(path, srcFile, zip,  currentSize, maxSize, transactionId);
		if (errCode < 0)
		{
			return errCode;
		}
	} else {
		
		FileInputStream inStream = new FileInputStream(srcFile);
		
		//String zentry = path + "/" + folder.getName();
		String zentry =  folder.getName();
		
		//String zentry = folder.getName();
		
		theLogger.debug(transactionId, "Adding file: " + srcFile + " to zip: " +  path + " as entry: " + zentry);
		
		zip.putNextEntry(new ZipEntry(zentry));
		double totalBytes = writeDataToStream(inStream, zip, currentSize, false, transactionId);
		
		zip.closeEntry();
		
		theLogger.debug(transactionId, "Added " + totalBytes + " bytes for file : " + srcFile + " to zip: " +  path);
		
		if (totalBytes < 0)
			return -1;
		else
			return totalBytes;
	}
	
	return currentSize;
	}
		
	private static int addFilesInFolderToZip(String path, String srcFolder, ZipOutputStream zip, double currentSize, double maxSize, long transactionId) throws Exception {
		int errCode = 0;
		
		File folder = new File(srcFolder);
		
		theLogger.debug(transactionId, "Adding files in folder to zip: " +  srcFolder);
		
		
		//zip.putNextEntry(new ZipEntry(folder.getName() + "/"));
		//theLogger.debug(transactionId, "Adding folder entry to zip: " +  folder.getName() + "/");
		//zip.closeEntry();
		
		
		for (String fileName : folder.list()) {
			if (path.equals("")) {

				currentSize = addFileToZipWithoutFolder(folder.getName(), srcFolder + "/" + fileName, zip,  currentSize, maxSize, transactionId);
			} else {

				currentSize = addFileToZipWithoutFolder(path + "/" + folder.getName(), srcFolder + "/" + fileName, zip,  currentSize, maxSize, transactionId);
			}
			
			if (currentSize < 0)
			{
				errCode = -1;
				break;
			}
		}
		
		return errCode;
	}
	
	private static int addFolderToZip(String path, String srcFolder, ZipOutputStream zip, double currentSize, double maxSize, long transactionId) throws Exception {
		int errCode = 0;
		
		File folder = new File(srcFolder);
		
		theLogger.debug(transactionId, "Adding folder to zip: " +  srcFolder);
		
		
		zip.putNextEntry(new ZipEntry(folder.getName() + "/"));
		//theLogger.debug(transactionId, "Adding folder entry to zip: " +  folder.getName() + "/");
		zip.closeEntry();
		
		
		for (String fileName : folder.list()) {
			if (path.equals("")) {

				currentSize = addFileToZip(folder.getName(), srcFolder + "/" + fileName, zip,  currentSize, maxSize, transactionId);
			} else {

				currentSize = addFileToZip(path + "/" + folder.getName(), srcFolder + "/" + fileName, zip,  currentSize, maxSize, transactionId);
			}
			
			if (currentSize < 0)
			{
				errCode = -1;
				break;
			}
		}
		
		return errCode;
	}
	
	public static double writeDataToStream(InputStream inStream, OutputStream outStream, double currentSize, boolean close, long transactionId) {
		int byteCount = 0;
 
		double totalBytes = 0;
		
		try {
			byte[] buffer = new byte[1024];
			int bytesRead = -1;
			while ((bytesRead = inStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
				byteCount += bytesRead;
			}
			
			//theLogger.debug(transactionId, "Wrote " + byteCount + " to zip stream");
				
			//outStream.flush();
			
			totalBytes = byteCount + currentSize;
			
		} catch(Exception e) {
			theLogger.error(transactionId, "An error occurred while writing to the output stream: " + e);
			return -1;
		} finally {
			
			if(close) {
				try {
					outStream.close();
				} catch (IOException ex) {
					theLogger.error(transactionId, "An error occurred while closing the outputStream.", ex);
					totalBytes = -1;
				}
			}
			
			try {
				inStream.close();
			} catch (IOException ex) {
				theLogger.error(transactionId, "An error occurred while closing the inputStream: " + ex);
				totalBytes = -1;
			}
		}

		return totalBytes;
	}
	
	public static boolean directoryCheck(String dirPath, boolean mkDir) {
		File dir = new File(dirPath);
		if(!dir.exists()) {
			if(mkDir)
				return dir.mkdir();
			else return false;
		}
		return true;
	}
	
	public static String getCurrentTimeStamp(){		
		return convertCalendarToString(Calendar.getInstance(), "MMddyyyyHHmmss");		
	}
	
	public static String convertCalendarToString(Calendar calendar, String dateFormat){
		if (calendar!=null){			
			DateFormat dateFormatObj = new SimpleDateFormat(dateFormat);
			return dateFormatObj.format(calendar.getTime());	
		} else {
			return null;
		}
	}
	
	public static boolean isStringNullOrEmpty(String value){
		return ((value==null)||(value.trim().equals("")));
	}
	
	public static String getMimeTypeExtension(Object listOfMimes, String mimeType) {
		if(listOfMimes instanceof Map) {
			Iterator mimeTypeItt = ((Map<String, String>)listOfMimes).entrySet().iterator();
			Map.Entry mimeTypeEntry;
			
			while(mimeTypeItt.hasNext()) {
				mimeTypeEntry = (Map.Entry<String, String>)mimeTypeItt.next();
				
				if(((String)mimeTypeEntry.getValue()).equalsIgnoreCase(mimeType)) {
					return (String)mimeTypeEntry.getKey();
				}
			}
/*		} else if(listOfMimes instanceof List) {
			for(String mime : (List<String>)listOfMimes) {
				if(mime.equalsIgnoreCase(mimeType))
					return mime;
			}
*/		}
		
		return null;
	}
	
	public static String getMD5CheckSum(Object fileObj) {
		InputStream fileInputStream = null;
		String md5 = null;
		try {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			char[] encodedMD5 = null;
			if(fileObj instanceof byte[]) {
				encodedMD5 = Hex.encodeHex(digest.digest((byte[]) fileObj));
			} else {
				File md5File = null;
				if(fileObj instanceof String) {
					md5File = new File((String)fileObj);
				} else if(fileObj instanceof File) {
					md5File = (File)fileObj;
				} else if(fileObj instanceof InputStream) {
					fileInputStream = (InputStream)fileObj;
				}
				
				if(md5File != null)
					fileInputStream = new FileInputStream(md5File);
				
				byte[] buffer = new byte[1024];
				int read = fileInputStream.read(buffer, 0, 1024);
				while (read > -1) {
					digest.update(buffer, 0, read);
					read = fileInputStream.read(buffer, 0, 1024);
				}
				
				encodedMD5 = Hex.encodeHex(digest.digest());
			}
			
			md5 = new String(encodedMD5);
		} catch (FileNotFoundException e) {             
			logger.error("Unable to checkSum when file doesn't exist.", e);
		} catch (OutOfMemoryError e) {
			logger.error("Out of memory Error occurred when trying to get the checksum.",e);			
		} catch (Exception e) {             
			logger.error("Exception occurred when trying to get the checksum.",e);			
		} catch (Error e) {             
			logger.error("Error occurred when trying to get the checksum.",e);			
		} finally{
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
					fileInputStream = null;
				} catch (IOException e) {
					logger.error("IOException occured when trying to close the fileInputStream.",e);
				}
			}
		}
		
		return md5;
	}
	
	public static boolean validateFileName(String fileName){
		List<Character> inputCharacters = new Vector<Character>();
		for (int i = 0; i < fileName.length(); ++i) {
			inputCharacters.add(new Character(fileName.charAt(i)));
		}
		//Set<Character>test = ProviderConstants.INVALID_CHARACTERS;
		for (Character inputCharacter: inputCharacters){
			// if any of the characters do NOT belong to list of acceptable characters
			if (ProviderConstants.INVALID_CHARACTERS.contains(inputCharacter)){
				logger.error("Improper character [" + inputCharacter + "] in [" + fileName + "] field");
				return true;
				
			}
		}
		return false;
	}
	
	public static int deleteFile(String inputFilePath) {
		int errCode = 0;
		
		try
		{
			FileUtils.forceDelete(new File(inputFilePath));
		} catch (Exception ex)
		{
			errCode = -1;
		}
		
		return errCode;
	}
	
	public static int copyFile(String inputFilePath, String targetFilePath) {
		int errCode = 0;
		
		try
		{
			File inputFile = new java.io.File(inputFilePath);
			File targetFile = new java.io.File(targetFilePath);
			
			if (copyFile(inputFile, targetFile) == false)
				errCode = -1;
		} catch (Exception ex)
		{
			errCode = -1;
		}
		
		return errCode;
	}
	
	public static boolean copyFile(File inputFile, File targetFile) throws IOException{
		boolean ok = true;

	      
        FileChannel source = null;
        FileChannel destination = null;
        try {
              
              if (!targetFile.exists()) 
              {
                    boolean fileIsNew = targetFile.createNewFile();
                    
                    if (fileIsNew == false)
                    {
                          ok = false;
                    }
              }
              
              if (ok == true)
              {
                    source = new FileInputStream(inputFile).getChannel();
                    destination = new FileOutputStream(targetFile).getChannel();
                    
                    
                    final long blockSize = Math.min(268435456, source.size());
                    
                    long position = 0;
                    long transferred = 0;
                    long transferredNow = 0;
                    do
                    {
                          transferredNow = destination.transferFrom(source, position, blockSize);
                          transferred += transferredNow;
                          position += transferredNow;
                          
                    } while (transferredNow > 0);
                    

                    
                    if (transferred != source.size())
                    {
                          ok = false;
                    }
              
              }
        } 
        catch (Exception ex)
        {
              ok = false;
        } 
        finally 
        {
              if(source != null) 
                    source.close();
              
              if(destination != null) 
                    destination.close();
        }

        return ok;

	}
	
	public static String getFormattedDate(Object dateObj, String currentDateFormatPattern, String newDateFormatPattern){
		DateFormat dateFormat = new SimpleDateFormat(newDateFormatPattern);
		
		Date date = null;
		if(dateObj != null && dateObj instanceof Date) {
			date = (Date)dateObj;
		} else if(dateObj != null && dateObj instanceof Calendar) {
			date = ((Calendar)dateObj).getTime();
		} else if(dateObj != null && dateObj instanceof String) {
			String dateStr = (String)dateObj;
			try {
//				logger.debug("Get current Date Format "+currentDateFormatPattern);
				date = (new SimpleDateFormat(currentDateFormatPattern)).parse(dateStr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if(dateObj != null && dateObj instanceof Long) {
			date = new Date((Long)dateObj);
			dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		} else {
			Calendar currentCalendar = Calendar.getInstance();
			date = currentCalendar.getTime();
		}
		
		String formattedDate = dateFormat.format(date);
//		logger.debug("Date: "+formattedDate);
		return formattedDate;
	}
	
	public static void copyFolder(String sourceFolder, String targetFolder, int count) {

		try {
			// fInputStream = new FileInputStream(new File(sourceFolder));
			File sourceFolderFile = new File(sourceFolder);
			File sourceFile[] = sourceFolderFile.listFiles();
			int index = 0;
			for (File file : sourceFile) {
				if (index >= count) {
					return;
				}
				FileInputStream fInputStream = null;
				FileOutputStream fOutputStream = null;
				FileChannel fInchannel = null, fOutChannel = null;
				MappedByteBuffer mapByteBuffer = null;
				try {
					fInputStream = new FileInputStream(file);
					fOutputStream = new FileOutputStream(new File(targetFolder
							+ "/" + file.getName()));
					fInchannel = fInputStream.getChannel();
					fOutChannel = fOutputStream.getChannel();
					long size = fInchannel.size();
					mapByteBuffer = fInchannel.map(
							FileChannel.MapMode.READ_ONLY, 0, size);
					fOutChannel.write(mapByteBuffer);
					fInchannel.close();
					fOutChannel.close();
					fInputStream.close();
					fOutputStream.close();
				} catch (Exception e) {

				}
				index++;
			}

		} catch (Exception e) {

		}
	}
	
	public static void deleteDirectory(String targetDirectory) {
		try {
			File targetFile = new File(targetDirectory);
			File fileList[] = targetFile.listFiles();
			for (File file : fileList) {
				file.delete();
			}
			
			targetFile.delete();
		}
		catch (Exception ex)
		{
			//theLogger.error("Failed to delete directory: " + targetDirectory);
		}
	}
	
	
	static public boolean extractZipToFolder(String zipFile, String destFolder) 
	{		
		if (zipFile == null || zipFile.length() <= 0 || destFolder == null || destFolder.length() <= 0)
			return false;
		
		boolean success = true;
 
		
	    int BUFFER = 2048;
	    File file = new File(zipFile);

	    ZipFile zip = null;
	    
	    try
	    {
	    	zip = new ZipFile(file);
	    	
		    //String newPath = zipFile.substring(0, zipFile.length() - 4);

		    new File(destFolder).mkdir();
		    
		    Enumeration zipFileEntries = zip.entries();
	
		    // Process each entry
		    while (zipFileEntries.hasMoreElements())
		    {
		        // grab a zip file entry
		        ZipEntry entry = (ZipEntry) zipFileEntries.nextElement();
		        String currentEntry = entry.getName();
		        File destFile = new File(destFolder, currentEntry);
		        //destFile = new File(newPath, destFile.getName());
		        File destinationParent = destFile.getParentFile();
	
		        // create the parent directory structure if needed		        
		        // might not work in windows ???
		        destinationParent.mkdirs();
	
		        if (!entry.isDirectory())
		        {
		            BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
		            int currentByte;
		            // establish buffer for writing file
		            byte data[] = new byte[BUFFER];
	
		            // write the current file to disk
		            FileOutputStream fos = new FileOutputStream(destFile);
		            BufferedOutputStream dest = new BufferedOutputStream(fos,
		            BUFFER);
	
		            // read and write until last byte is encountered
		            while ((currentByte = is.read(data, 0, BUFFER)) != -1) 
		            {
		                dest.write(data, 0, currentByte);
		            }
		            dest.flush();
		            dest.close();
		            is.close();
		        }
	
		        // NO NEED TO EXTRACT ZIP FILES WITHIN ZIP FILES
		        /*
		        if (currentEntry.endsWith(".zip") || currentEntry.endsWith(".ZIP"))
		        {
		        	success = extractFolder(destFile.getAbsolutePath());
		        	if (success == false)
		        	{
		        		break;
		        	}
		        }
		        */
		    }
	    }
	    catch (Exception ex)
	    {
	    	success = false;
	    }
	    finally 
	    {
	    	if (zip != null)
	    	{
	    		try {
	    			zip.close();
	    		} catch(Exception closeEx) {}
	    	}
	    }
	    
	    return success;
	    
	}
	
	
	public static Calendar convertStringToCalendar(String calendarValue, String dateFormatPattern){
		DateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(dateFormat.parse(calendarValue));
		} catch (ParseException e) {			
			return null;
		}
		return calendar;
	}
}
