package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.logger.CustomLogger;

/**
 * @author buppala
 *
 */
@Service("batchLauncher")
public class BatchLauncher {
	
	private CustomLogger theLogger = new CustomLogger(BatchLauncher.class);
	private Logger logger = theLogger.getLogger();
	
	@Autowired
	private JobLauncher jobLauncher;	
	@Autowired
	private Job webserviceUploader;
	@Autowired
	private MapJobRepositoryFactoryBean jobRepository;	
	@Autowired
	private ConstantConfig constantConfig;
	
	
	private static Map<String, JobExecution> jobHistory = new Hashtable<String, JobExecution>();


	public void startProcess() {
		try {
			String currentTime = ProviderUtils.convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);
			logger.debug("Current Time; "+currentTime);
			getJobHistory();			
			Set<JobExecution>runningJob = getRunningJob();			
			if (runningJob.isEmpty()) {
				logger.debug("No running job. Prepare to clean up job repository");
				//jobRepository.clear();
				cleanUpJob(runningJob);
				JobParametersBuilder jobParameterBuilder = new JobParametersBuilder();
				jobParameterBuilder.addString("currentTime", currentTime);
				if(doesFolderhasFiles()){
				JobExecution jobExecution = jobLauncher.run(webserviceUploader,
						jobParameterBuilder.toJobParameters());				
				jobHistory.put(currentTime, jobExecution);}		
				//currentTime = ProviderUtils.convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);
			} else {
				//logger.debug("Still waiting for other job to finish "+runningJob.size());
				logger.debug("Detect another job is running "+runningJob.size());
				//currentTime = ProviderUtils.convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);
				//getJobHistory();
				displayRunningJobDetail(runningJob);
				
			} 
		} catch (Exception e) {
			logger.error("", e);
		}
//		logger.debug("-----Done Start Process-------");
	}

	// ----------------------Private Method-------------
	private void getJobHistory(){
		try{
			logger.debug("---GetJobHistory------ Size: "+jobHistory.size());
			for (String key: jobHistory.keySet()){			
				JobExecution jobEx = jobHistory.get(key);
				String exitCode = jobEx.getExitStatus().getExitCode();
				logger.debug("Job: "+key+"\tEC: "+exitCode+" --> "+jobEx.toString());
				if (!exitCode.equalsIgnoreCase(ExitStatus.COMPLETED.getExitCode().toString())) {
					if (exitCode.equalsIgnoreCase(ExitStatus.FAILED.getExitCode().toString())) {
						Collection<StepExecution>stepCollection = jobEx.getStepExecutions();
						for (StepExecution step: stepCollection){
							logger.debug("Child Step: "+step.toString());
						}
					}
				}
				if(!exitCode.equalsIgnoreCase(ExitStatus.UNKNOWN.toString())){
					jobHistory.remove(key);	
				}			
			}	
		}catch(Exception e){
			logger.error(e);
		}
		
	logger.debug("------End of GetJobHistory-----");
	}
	private void displayRunningJobDetail(Set<JobExecution>jobList){
		logger.debug("-->Get running job");
		for (JobExecution job : jobList){			
			logger.debug(job.getId()+"-->Exit Code: "+job.getExitStatus().getExitCode()+"-->"+job.toString());
		}
	}
	private Set<JobExecution> getRunningJob(){
		Set<JobExecution>runningJob = jobRepository.getJobExecutionDao().findRunningJobExecutions(webserviceUploader.getName());
		return runningJob;
	}	
	private void cleanUpJob(Set<JobExecution> runningJob){
		logger.debug("-------cleanUpJob: "+runningJob.size());		
		if (runningJob.isEmpty()){
			logger.debug("There aren't any jobs to run");			
			jobRepository.clear();			
		}else{
			logger.debug("Total Running job: "+runningJob.size());
			for (JobExecution ex : runningJob){			
				logger.debug("RunningJobDetail: "+ex.toString());
			}
		}
		logger.debug("---------Done cleanUpJob");
	}		
	
	/**  Checks the directory if it has any files.
	 * @return boolean
	 */
	private boolean doesFolderhasFiles(){
		boolean folderHasFiles = false;
		File fileDir = new File(constantConfig.getTempFileLocation());
		File[] fileList =fileDir.listFiles();
		for(File file: fileList){
			if(file.isFile()){
				folderHasFiles = true;
				break;
			}
		}		
		return folderHasFiles;
			
	}

}
