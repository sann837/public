package com.cgi.mas.provider.batch;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.RACCFCustomLogger;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelRACService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ReceivedFileDto;
import com.cgi.mas.provider.util.Util;
import com.siebel.racappealvalidation.ValidateTransctnId1Input;
import com.siebel.racappealvalidation.ValidateTransctnId1Output;
import com.siebel.xml.masassociatedocsio.ListOfMasBcAssociateDocuments;
import com.siebel.xml.masassociatedocsio.MasBcAssociateDocuments;

public class RACCFImport implements Tasklet{

	private static final String MAX_APPEALS = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String DEFAULT_KEY_NAME = "fileName";
 
	private RACCFCustomLogger theLogger = new RACCFCustomLogger(RACCFImport.class);
	private Logger logger = theLogger.getRacCFLogger();
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelRACService siebelService;
	
	
	@Autowired
	private IECMService ecmService;
	
    public RepeatStatus execute(StepContribution contribution,
            ChunkContext chunkContext) throws Exception 
    {
    	long batchUID = 0;
    	
    	try
    	{
	    	ExecutionContext context = chunkContext.getStepContext().getStepExecution().getExecutionContext();
	    	
	    	int maxAppealsPerThread = context.getInt(MAX_APPEALS);
			batchUID = context.getLong(BATCH_UID);
			String threadId = context.getString(THREAD_NAME);
			
			
			ArrayList<String> fileList = (ArrayList<String>) context.get(DEFAULT_KEY_NAME);
			
			if (fileList != null && fileList.size() > 0)
			{
				theLogger.debug(batchUID, "Starting task " + threadId + " to import RAC casefiles for appeals up to " + maxAppealsPerThread + " appeals");
	    	
				runDataImport(batchUID, maxAppealsPerThread, fileList);
			}
			else
			{
				theLogger.error(batchUID, "No  RAC Csefiles  received by the thread for processing. This can happen if other threads allready processed the files.");
			}
    	}
    	catch (Exception ex)
    	{
    		theLogger.error(batchUID, "Exception in job scheduler.", ex);
    	}
		
		return RepeatStatus.FINISHED;
	}
    


	
	private int runDataImport(long batchUID, int maxAppealsPerThread, ArrayList<String> fileList) 
	{	
		int processedRACCFAppeals = 0;
		int raccfAppeals = 0;
		
		long startTime = System.currentTimeMillis();
		
		try
		{	
			// GET THE ROOT CLOSE DIRECTORY
			
			StringBuilder tempDirectoryBuilder = new StringBuilder();
			tempDirectoryBuilder.append(constantConfig.getRaccfTempLocation());
			tempDirectoryBuilder.append("/");
			
			//theLogger.debug(transactionId, "Root close directory: " + tempDirectoryBuilder.toString());
			
			if (false == Util.directoryCheck(tempDirectoryBuilder.toString(), true) )
			{
				theLogger.debug(batchUID, "Root RACCF directory does not exist and could not be created: " + tempDirectoryBuilder.toString());
				
				// RECOVERABLE ERROR
				return -1;
			}
			
			// Run this as long as we have files to process

			for (int fileIdx = 0; fileIdx < fileList.size(); fileIdx++)
			{
				processedRACCFAppeals++;
				
				int errCode = 0;
				String appealNumber = "";
				long transactionId = batchUID;
			
				List<String> checksumsList = null;
				List<String> fileNamesList = null;
				List<ReceivedFileDto> validRACDocsList = null;
				
				boolean appealClosedInSiebel = false;
				boolean validatedSiebelTransaction = false;
				boolean validationPassed = false;
				boolean allDocsOk = true;
				
				
				
				
				
				String selFileName = fileList.get(fileIdx);

				if (selFileName != null && selFileName.length() > 0)
				{

					String filePath = checkFile(batchUID, selFileName);
					if (filePath != null)
					{
						
						
						// FILE IS RENAMED WITH LOCK EXTENSION NOW
						// MAKE SURE TO DELETE OR RENAME AT THE END
						
						// UNZIP AND MANIFEST FOLDER NAMES
						//String randomUniqueString = RandomStringUtils.randomAlphanumeric(20);
						String randomUniqueString = UUID.randomUUID().toString();
						
						
						StringBuilder raccfFolder  = new StringBuilder(tempDirectoryBuilder.toString());
						raccfFolder.append(randomUniqueString);
						raccfFolder.append("_");
						raccfFolder.append(Util.getCurrentTimeStamp());
						raccfFolder.append("_RACCF");
						theLogger.debug(transactionId, "RAC Casefiles directory: " + raccfFolder.toString());
						 
						StringBuilder manifestFolder  = new StringBuilder(raccfFolder.toString());
						manifestFolder.append("_OUT");
						
						theLogger.debug(transactionId, "RAC Casefiles manifest directory: " + manifestFolder.toString());
						 
						
						String baseFileName = FilenameUtils.getBaseName(filePath);
						
						
						// CREATE FOLDER FOR UNZIP 
						if (true == Util.directoryCheck(raccfFolder.toString(), true) )
						{
							// CREATE FOLDER FOR MANIFEST
							if (true == Util.directoryCheck(manifestFolder.toString(), true) )
							{
								// CREATE MANIFEST FILE

								FileWriter fw = null;
								try
								{
									String manifestFilename = manifestFolder.toString() + "/manifest.txt";
								    fw = new FileWriter(manifestFilename, true);  
								   	fw.write("Manifest file for RAC Casefiles " + baseFileName +  "\r\n");								   							    
								    fw.write("================================================================\r\n");
								    fw.write("Processed Date: " + Util.convertCalendarToString(Calendar.getInstance(), "MM/dd/yyyy HH:mm:ss") +  "\r\n");
								    fw.write("================================================================\r\n");
								}
								catch (Exception ioe)
								{
									theLogger.error(transactionId, "Exception while adding RACCF data to manifest file: " + ioe.getMessage());
									
									// RECOVERABLE ERROR
									errCode = 4;
								}
								finally 
								{
									if (fw != null)
									{
										fw.close();
										fw = null;
									}
								}
								
								if (errCode == 0)
								{
									// UNZIP FILE
									
									boolean zipOk = Util.extractZipToFolder(filePath, raccfFolder.toString());
									 
									
									if (zipOk == true)
									{
										File folder = new File(raccfFolder.toString());
										List<File> files = null;
										if(folder != null && folder.exists()){
									    files = Arrays.asList(folder.listFiles());
										}
										
										
										
										// Check that it has manifest and signature files and atleast one RAC casefile
										
										/*String incomingSignatureFileName = raccfFolder.toString() + "/appeal.xml";*/
										String incomingManifestFileName = raccfFolder.toString() + "/manifest.txt";
										
										/*File incomingSignatureFile  =  new File(incomingSignatureFileName);*/
										File incomingManifestFile = new File(incomingManifestFileName);
										
										if (incomingManifestFile.exists())
										{
											if(files.contains(incomingManifestFile) && files.size() > 1){
											// Read manifest file
											
											Properties manifestProps = new Properties();
											InputStream manifestStream = null;

											try 
											{
												manifestStream = new FileInputStream(incomingManifestFile);
												manifestProps.load(manifestStream);

												// get the property value  
												String appealNumberStr =  manifestProps.getProperty("AppealNumber");
												String transactionIdStr =  manifestProps.getProperty("TransactionId");
												String fileNames = manifestProps.getProperty("Filenames");
												String checksums = manifestProps.getProperty("Checksums");
												
												if(fileNames !=null && checksums != null){
													fileNamesList = Arrays.asList(fileNames.split(","));
													checksumsList =  Arrays.asList(checksums.split(","));
													
												}
												else{
													
													theLogger.debug(batchUID, "manifest file does not have Filenames or Checksums property");
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: manifest file does not have Filenames or Checksums property.");
													errCode = -7;
												}
							
												

												if (appealNumberStr == null || appealNumberStr.length() <= 0 || 
													transactionIdStr == null || transactionIdStr.length() <= 0 || checksumsList == null || checksumsList.size() <= 0 || fileNamesList == null || fileNamesList.size() <= 0)
												{
													theLogger.error(batchUID, "Could not read appeal number and transaction id or checksums and filenames from manifest file: " + incomingManifestFile);
													
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Could not read AppealNumber and TransactionId or checksums and filenames from the manifest.txt file.");
													
													// UNRECOVERABLE ERROR
													errCode = -7;
												}
												else if(checksumsList.size() != fileNamesList.size()){
													theLogger.error(batchUID, "Number of Checksums does not match with number of filenames provided.Number of filenames: "+fileNamesList.size()+"and Number of Checksums: "+checksumsList.size());
													addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Number of Checksums does not match with number of filenames provided.Number of filenames: "+fileNamesList.size()+"and Number of Checksums: "+checksumsList.size());
													// UNRECOVERABLE ERROR
													errCode = -7;
												}
												else
												{
													appealNumber = appealNumberStr;
													transactionId = Long.parseLong(transactionIdStr);
													
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "Requested Appeal Number: " + appealNumberStr );
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "Requested Transaction Id: " + transactionIdStr );
													
													
													
													theLogger.debug(batchUID, "Found in manifest file appeal number: " + appealNumber + " for transaction ID: " + transactionId);
												}
												
												/*if(incomingSignatureFile.exists()){
													
													//ok
													
												}
												else{
													
													addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: We are unable to process the received file for the Transaction ID "+transactionId+" as the file format is invalid/corrupt( signature file) , please resubmit the file" );
													theLogger.debug(batchUID,"Zip file: " + filePath + " does not include the sugnature  file");
													// UNRECOVERABLE ERROR
													errCode = -4;
													
												}*/
												
												
												
											} 
											catch (Exception manex) 
											{
												theLogger.error(batchUID, "Exception while readng info from manifest file: " + incomingManifestFile, manex);
												
												addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Failed to read the manifest.txt file.");
												
												// UNRECOVERABLE ERROR
												errCode = -6;
											} 
											finally 
											{
												if (manifestStream != null) 
												{
													try {
														manifestStream.close();
													} catch (Exception clex) {
														theLogger.error(batchUID, "Exception while closing manifest file stream: " + incomingManifestFile, clex);
													}
												}}
											
											
											if (errCode == 0)
											{
												
												validRACDocsList = new ArrayList<ReceivedFileDto>();
												Iterator<String> fileNamesItr = fileNamesList.iterator();
												while(fileNamesItr.hasNext()){
													
													String fileName =  fileNamesItr.next();
													// VERIFY FILE EXTENSION
													String fileExtension = FilenameUtils.getExtension(fileName);
													
													
													
													if (fileExtension != null && fileExtension.length() > 0)
													{
													
														String mimeType = constantConfig.getMimeType().get(fileExtension.toLowerCase());
														
														if (mimeType != null && mimeType.length() > 0)
														{
															
															// MIMETYPE OK
															// VERIFY IF FILE EXISTS
															File racCaseFile = new File(raccfFolder.toString() + "/" + fileName);
															if (racCaseFile.exists()){
																
																String realChecksum = Util.getMD5CheckSum(racCaseFile).toLowerCase();
																
																ListIterator<String> listItr = checksumsList.listIterator();
																while(listItr.hasNext()){
																	
																	listItr.set(listItr.next().toLowerCase());
																}
																/*String providedChecksum = fileInfo.get(fileName);*/
																
																	
																	if (realChecksum != null && checksumsList.contains(realChecksum))
																	{
																		
																		long fileSize = racCaseFile.length();
																		
																		ReceivedFileDto rcvFile = new ReceivedFileDto();
																		
																		rcvFile.setFileName(fileName);
																		rcvFile.setCheckSum(realChecksum);
																		rcvFile.setFileSize(fileSize);
																		validRACDocsList.add(rcvFile);	

																	}
																	
																
																	else
																	{
																		// checksum does not match
																		theLogger.error(transactionId, "Provided checksum  for RAC Casefile " + fileName + " provided in manifest file  " + baseFileName + " for appeal number " + appealNumber + " does not match the actual checksum of the file: " + realChecksum);
																		
																		addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Provided checksum  for document file " + fileName + " does not match the actual checksum of the file: " + realChecksum);
																		
																		// UNRECOVERABLE ERROR
																		errCode = -8;
																		//break;
																	}
																	
																
																
														
															
																
															}
															else
															{
																// ECM file does not exist
																theLogger.error(transactionId, "RAC Casefile " + fileName + " not found in the  data file " + baseFileName + " for appeal number " + appealNumber);
																
																addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: The " + fileName + " file listed in the manifest file could not be found.");
																
																// UNRECOVERABLE ERROR
																errCode = -8;
																//break;
															}
															
															
														}
														else
														{
															String errorMessage = ErrorFieldConstant.BAD_MIME_TYPE1 + " - " +  getMessage(ErrorFieldConstant.BAD_MIME_TYPE1, new String[]{fileName});
															
															theLogger.error(transactionId, "The file extension for RAC Case file " + fileName + " provided in manifest file  " + baseFileName + " for appeal number " + appealNumber + " contains an unsupported MIME type ");
															
															addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: " + errorMessage );
															
															// UNRECOVERABLE ERROR
															errCode = -8;
															//break;
															
														}
														
													}
													else
													{
														String errorMessage = ErrorFieldConstant.BAD_MIME_TYPE1 + " - " +  getMessage(ErrorFieldConstant.BAD_MIME_TYPE1, new String[]{fileName});
														
														theLogger.error(transactionId, "The file extension for RAC Case file " + fileName + " provided in appeal data file  " + baseFileName + " for appeal number " + appealNumber + " contains an unsupported MIME type ");
														
														addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: " + errorMessage );
														
														// UNRECOVERABLE ERROR
														errCode = -8;
														//break;
													}
													
													
												
												}	
												

													if (errCode == 0) 
													{ 
														
														ValidateTransctnId1Input input = new ValidateTransctnId1Input() ;
														input.setAppealNum(appealNumber);
														input.setTransId(String.valueOf(transactionId));
														
														ValidateTransctnId1Output response = siebelService.validateRACAppeal(input);
														
													 if (response != null)
													{
														 String successOrNot = response.getStatus();
														    String errorCode = null;
															String errMsg = null;
														 theLogger.debug(transactionId, "siebel validateTransctnId1 webservice call response status "+response.getStatus());
														 
														 if (successOrNot != null && successOrNot.compareToIgnoreCase("Success") == 0)
															{
															 
																// verify returned data
																String outAppealNumber = response.getAppealNum();
																String outTransactionId = response.getTransId();
																
																 theLogger.debug(transactionId, "Found in siebel validateTransctnId1 webservice call response appealNumber: "+outAppealNumber+" and transactionId: "+outTransactionId );
																
																if (outAppealNumber != null && outAppealNumber.compareTo(appealNumber) == 0 &&
																	 outTransactionId != null && outTransactionId.compareTo(Long.toString(transactionId)) == 0)
																{
																	
																	
																	String ecmPassword = response.getEcmUserPassword();
																	String ecmUsername = response.getEcmUserId();
																	String appealOpenDate = response.getRequestReceived();
														
																	
																	
																	
																	if (ecmPassword != null && ecmPassword.length() > 0 &&
																		ecmUsername != null && ecmUsername.length() > 0)
																	{
																		// verify returned files
																		
																		
																		
																		int siebelEcmFilesCount = 0;
																		
																	
																		
																		ListOfMasBcAssociateDocuments ecmDocsForSiebel = new ListOfMasBcAssociateDocuments();
																		List<MasBcAssociateDocuments> ecmDocsForSiebelList = ecmDocsForSiebel.getMasBcAssociateDocuments();
																		
																		MasBcAssociateDocuments ecmDocForSiebel = new MasBcAssociateDocuments();
																		
																		Iterator<ReceivedFileDto> fileItr = validRACDocsList.iterator();
																		
																		while(fileItr.hasNext()){
																			
																			ReceivedFileDto rcvFile = fileItr.next();
																			
																			ecmDocForSiebel.setDocECMId(null);
																			ecmDocForSiebel.setFileName(rcvFile.getFileName());
																			ecmDocForSiebel.setImportStatus("Failed");
																			ecmDocForSiebel.setCheckSum(rcvFile.getCheckSum());
																			ecmDocForSiebel.setFileSize(String.valueOf(rcvFile.getFileSize()));
																			ecmDocForSiebel.setType(null);
																			ecmDocsForSiebelList.add(ecmDocForSiebel);
																			
																		}
																		
																		
																		
																
																																							
																		
																		
																		// READY TO UPLOAD DOCUMENTS TO ECM AND FINSISH CLOSING
																		if (errCode == 0)
																		{
																			if ( validRACDocsList!= null)
																			{																		
																				
																				List<DocumentResultDto> importedDocs = ecmService.importFilesToAppeal(ecmUsername,  ecmPassword, appealNumber,  appealOpenDate,  null, raccfFolder.toString(), validRACDocsList,  transactionId,constantConfig.getLevel1());
				
																				if (importedDocs != null)
																				{
																						// check the status of each imported document
																					
																						boolean errorReported = false;
																						
																						for (int impIdx = 0; impIdx < importedDocs.size(); impIdx++)
																						{
																							DocumentResultDto importedDoc = importedDocs.get(impIdx);
																							
																							int importedFileStatus = importedDoc.getStatus();
																							String importedFileName = importedDoc.getFileName();																						
																							String importedChecksum = importedDoc.getCheckSum();
																							
																							
																								for (int siebelEcmListId = 0; siebelEcmListId < ecmDocsForSiebelList.size(); siebelEcmListId++)
																								{
																									MasBcAssociateDocuments foundSiebelDoc = ecmDocsForSiebelList.get(siebelEcmListId);
																									if (foundSiebelDoc.getFileName().compareTo(importedFileName) == 0 && foundSiebelDoc.getCheckSum().compareTo(importedChecksum) == 0)
																									{
																										if (importedFileStatus == 0) // SUCCESS
																										{
																											
																											foundSiebelDoc.setImportStatus("Completed");
																											foundSiebelDoc.setDocECMId(importedDoc.getEcmItemId());
																											 
																										}
																										else if (importedFileStatus > 0) // ALLREADY IN ECM
																										{
																										foundSiebelDoc.setImportStatus("Already");
																										foundSiebelDoc.setDocECMId(importedDoc.getEcmItemId());
																										}
																										else
																										{
																											// FAILED
																											
																											//allDocsOk = false;
																											
																											
																											
																										}
																										break;
																									}
																									
																								}
																							 	
																							
																							
																							// THIS IS A FAILURE TO CALL ECM
																							if (importedFileStatus < 0)
																							{
																								if (errorReported == false)
																								{
																									errorReported = true;
																									
																									int failedAppeals = theLogger.incrementFailedAppeals();
																									if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																									{
																										theLogger.debug(transactionId, "Java QIC Appeal process  will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																									}
																								}
																							}
																							
																						} // end for

																				}
																				else
																				{
																					//allDocsOk = false;
																					
																					theLogger.error(transactionId, "Failed to upload all documents to ECM for appeal number " + appealNumber);
																					
																					// THIS IS A FAILURE TO CALL ECM
																					int failedAppeals = theLogger.incrementFailedAppeals();
																					if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																					{
																						theLogger.debug(transactionId, "Java QIC Appeal process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																					}
																					
																				}
								 												
																			// CHECK IF WE HAVE ANY DOCS THAT WHERE NOT SUCCESFULL
																				for (int siebelEcmListId = 0; siebelEcmListId < ecmDocsForSiebelList.size(); siebelEcmListId++)
																				{
																					//ECMDocument
																					MasBcAssociateDocuments foundSiebelDoc = ecmDocsForSiebelList.get(siebelEcmListId);
																					String ecmImportStatus = foundSiebelDoc.getImportStatus();
																					if (ecmImportStatus == null || ecmImportStatus.compareTo("Failed") == 0)
																					{
																						theLogger.error(transactionId, "Found document: " + foundSiebelDoc.getFileName() + " that was not uploaded to ECM for appeal number " + appealNumber);
																						
																						//addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																						
																						// RECOVERABLE ERROR
																						errCode = 14;
																						allDocsOk = false;
																						break;
																					} 
																				}

																				
																		/*		// UPDATE DOCUMENTS IN SIEBEL
																				int siebelDocUpdateErr = siebelService.associateDocuments( transactionId, appealNumber, ecmDocsForSiebel);
																				
																				if (siebelDocUpdateErr == 0)
																				{
																					if (allDocsOk == true)
																					{
																						theLogger.debug(transactionId, "Successfully associated Documents for appeal number: " + appealNumber + " with files imported to ECM.");
																						
																						addTextToManifestFile(transactionId, manifestFolder.toString(),  "STATUS: Files successfully associated with Claim." );
																						
																						appealClosedInSiebel = true;
																						errCode = 0;
																					}
																					else
																					{
																						theLogger.error(transactionId, "Successfully sent ECM document Status  to Siebel for appeal number: " + appealNumber + " with  ECM upload errors.");
																						
																						addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Some of the documents could not be associated to the appeal." );
																		
																						errCode = 14;
																					}
																				}
																				else
																				{
																					theLogger.error(transactionId, "Failed to send ECM document Status  to Siebel for appeal number " + appealNumber);
																					
																					addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Some of the documents could not be associated to the appeal." );
																					
																					allDocsOk = false;
																					
																					// RECOVERABLE ERROR
																					errCode = 15;
																					
																					
																					// THIS IS A FAILURE TO CALL SIEBEL IF ERRCODE = -2
																					if (siebelDocUpdateErr == -2)
																					{
																						int failedAppeals = theLogger.incrementFailedAppeals();
																						if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
																						{
																							theLogger.debug(transactionId, "Java QIC Appeal process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
																						}
																					}
																				}*/

																				
																			}
																			else
																			{
																				// no files to import, everything ok 
																				
																				
																				
																				
																				theLogger.debug(transactionId, "No Files to import for "+ appealNumber + " to ECM.");
																				
																				addTextToManifestFile(transactionId, manifestFolder.toString(),  "STATUS: APPEAL SUCCESSFULLY UPDATED" );
																				
																				appealClosedInSiebel = true;
																			}

																		}
																		else
																		{
																			// the error has already been logged
																		}
																	}
																	else
																	{
																		theLogger.error(transactionId, "ECM Index, ECM password, AdECM username, Org Name or Appeal Date returned by Siebel are empty for appeal number " + appealNumber);
																		
																		addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																		
																		// RECOVERABLE ERROR
																		errCode = 8;
																	}
																}
																else
																{
																	theLogger.error(transactionId, "Appeal Number and Transaction ID returned by Siebel do not match the original appeal number " + appealNumber + " and transaction Id " + transactionId);
																	
																	addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request." );
																	
																	// RECOVERABLE ERROR
																	errCode = 9;
																}
															 
															}
														 else{
															 
															    errorCode = response.getErrorSpcCode();
																 errMsg = response.getErrorSpcMessage();
																
																
																if (errMsg == null)
																	errMsg = "NULL"; 
																if (errorCode == null)
																	errorCode = "NULL"; 
																
																	
																	theLogger.error(transactionId, "Siebel reported that there was a validation error for this appeal.. Error Code: " + errorCode + ". Error Message: " + errMsg);
																	addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request . \r\nError Code: " + errorCode + "\r\nError Message: " + errMsg);
																	
														
																errCode = -5;
														 }
														
														
													}
													else
													{
														addTextToManifestFile(transactionId, manifestFolder.toString(),  "ERROR: Unable to process request.");
														
														theLogger.error(transactionId, "validateTransctnId1 - Received null response from Siebel." );
									
														errCode = -6;
														
														
														// THIS IS A FAILURE TO CALL SIEBEL
														/*int failedAppeals = theLogger.incrementFailedAppeals();
														if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
														{
															theLogger.debug(transactionId, "Java QIC Appeal process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
														}*/
														
													}
												
													
											//*******************		
												
												}
												}
										}
										else
										{
											theLogger.error(batchUID, "Zip file: " + filePath + " does not have any RAC case files to Process except manifest  file");
											
											addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The " + baseFileName + " file does not have any RAC case files to Process.We are unable to process the received file  , please resubmit the file");
											
											
											// UNRECOVERABLE ERROR
											errCode = -4;
										}
										
										}
										
										else
										{
											theLogger.error(batchUID, "Zip file: " + filePath + " does not include the manifest  file");
											
											addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: We are unable to process the received file " + baseFileName + " as the manifest file format is missing or invalid/corrupt, please resubmit the file");
											
											
											// UNRECOVERABLE ERROR
											errCode = -4;
										}
									
							}
									else
									{
										theLogger.error(batchUID, "Failed to extract zip file: " + filePath);
										
										addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: The  " + baseFileName + " file was not recognized as a valid ZIP file.");
										
										// UNRECOVERABLE ERROR
										errCode = -3;
									}
									}	
								else
								{	
									theLogger.error(batchUID, "Failed to create manifest file in folder: " + manifestFolder.toString());
								
									// RECOVERABLE ERROR
									errCode = 3;
								}
								
								// delete ZIP folder
								//Util.deleteDirectory(qicAppealFolder.toString());
								
						}
							else
							{	
								theLogger.error(batchUID, "RAC casefile manifest directory  could not be created: " + raccfFolder.toString());
								
								addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
								// RECOVERABLE ERROR
								errCode = 3;
							} }
						
						else
						{
							theLogger.error(batchUID, "RAC Casefile unzip directory  could not be created: " + manifestFolder.toString());
							
							addTextToManifestFile(batchUID, manifestFolder.toString(),  "ERROR: Unable to process request.");
							
							// RECOVERABLE ERROR
							errCode = 2;
						}
						
						
						// CLEANUP HERE AND MOVE FILE !!!!!!!!
						
						if (errCode == 0)
						{
							// ok
							
							// DELETE ORIGINAL FILE
							Util.deleteFile(filePath);
							
							// DONE SO FAR
							
						}
						else
						{
							// rename file 
							if (errCode != -100) // 2 JVMs processing the same file
							{
								String originalFileName = filePath;
								originalFileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
								String errorFileName = "";
								
								if (validationPassed == true)
								{
									errorFileName = originalFileName + "." + ProviderConstants.FAILED_EXTENSION;
								}
								else
								{
									errorFileName = originalFileName + "." + ProviderConstants.FAILED_VALIDATION_EXTENSION;
								}
								
								File originalFile = new File(filePath);
								
								File renameFile = new File(errorFileName);		
								
								if(originalFile.renameTo(renameFile)) 
								{
								
								} 
								else
								{
									theLogger.error(batchUID, "Failed to rename locked file: " + originalFileName + " to error file: " + errorFileName);
									
									// UNRECOVERABLE ERROR
									//errCode = -2;
								}
								
								// UPDATE SIEBEL WITH ERROR
							} else
							{
								// another JVM already processing this file
								Util.deleteFile(filePath);
								Util.deleteDirectory(manifestFolder.toString());
								
								continue;
							}
						}
						
						// create signature file for manifest file
						
			            // read manifest and  sign
						FileOutputStream sigfos = null;
						try
						{						    
							theLogger.debug(transactionId, "Generating signature file...");
							
							
							String keyStoreFile =  constantConfig.getKeystoreName();
						    String password = constantConfig.getKeystorePassword();
						    String alias = constantConfig.getKeyAlias(); 
						    String keyPassword = constantConfig.getKeyPassword();
							
							KeyStore keystore = KeyStore.getInstance("JKS");  
				            char[] storePass = password.toCharArray();  
				            char[] keyPasswd = keyPassword.toCharArray(); 
				  
				            //load the key store from file system  
				            FileInputStream fileInputStream = new FileInputStream(keyStoreFile);  
				            keystore.load(fileInputStream, storePass);  
				            fileInputStream.close();  
				  
				             
				            //read the private key  
				            KeyStore.ProtectionParameter keyPass = new KeyStore.PasswordProtection(keyPasswd);  
				            KeyStore.PrivateKeyEntry privKeyEntry = (KeyStore.PrivateKeyEntry) keystore.getEntry(alias, keyPass);  
				            PrivateKey privateKey = privKeyEntry.getPrivateKey();  
				  
				            //initialize the signature with signature algorithm and private key  
				            Signature signature = Signature.getInstance("SHA256withRSA");  
				            signature.initSign(privateKey);  
				            
				            String manifestFilename = manifestFolder.toString() + "/manifest.txt";
				
				            FileInputStream fis = new FileInputStream(manifestFilename);
				            BufferedInputStream bufin = new BufferedInputStream(fis);
				            byte[] buffer = new byte[10000];
				            int len;
				            while ((len = bufin.read(buffer)) >= 0) {
				            	signature.update(buffer, 0, len);
				            };
				            bufin.close();

				            byte[] digitalSignature = signature.sign();

							String signatureFilename = manifestFolder.toString() + "/signature.txt";

							sigfos = new FileOutputStream(signatureFilename);
						    sigfos.write(digitalSignature);
						    sigfos.close(); 
						    
						    theLogger.debug(transactionId, "Signature file generated: " + signatureFilename);
						}
						catch (Exception ioe)
						{
							Util.deleteDirectory(manifestFolder.toString());
							
							theLogger.error(transactionId, "Exception while writing signature file: " + ioe.getMessage());
							
							errCode = 10;
							
							/*int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(transactionId, "Java QIC Appeal Process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}*/
							
						}
						finally 
						{
							if (sigfos != null)
							{
								sigfos.close();
								sigfos = null;
							}
						}
					
						
						// ZIP and move manifest file to EFT
						
						StringBuilder compressFilePath = new StringBuilder();		
						compressFilePath.append(tempDirectoryBuilder.toString());
						compressFilePath.append(randomUniqueString);
						compressFilePath.append("_");
						compressFilePath.append(Util.getCurrentTimeStamp());						
						compressFilePath.append(".zip");
						
						errCode =  Util.compressFilesInFolder(manifestFolder.toString(), compressFilePath.toString(), transactionId);
						if (errCode == 0)
						{
							theLogger.debug(transactionId, "Compressed manifest file to: " + compressFilePath.toString());

							// delete manifest file and folder
							Util.deleteDirectory(manifestFolder.toString());
							
							
							StringBuilder eftFileLocation = new StringBuilder(constantConfig.getRaccfOutEftLocation());	
							eftFileLocation.append("/");
							eftFileLocation.append(constantConfig.getRacCaseFileprefixName());
							eftFileLocation.append(".D");
							
							//DYYMMDD.THHMMSST   
							
							Date rightNow = new Date();
							String dateStamp = new SimpleDateFormat("yyMMdd").format(rightNow);
							String timeStamp = new SimpleDateFormat("HHmmss").format(rightNow);
							
							eftFileLocation.append(dateStamp);	
							eftFileLocation.append(".T");
							eftFileLocation.append(timeStamp);
							eftFileLocation.append("_RACCF");
							String destFile = eftFileLocation.toString();
							boolean fileNameAvailable = false;
							for (int fidx = 0;  fidx <= 9; fidx++)
							{
								String tryFileName = destFile + fidx;
								 
								File f = new File(tryFileName);
								if(f.exists() == false)
								{
									//destFile = tryFileName;
	
									theLogger.debug(transactionId, "Copying manifest ZIP file : " + compressFilePath.toString() + " to EFT: " + tryFileName);
									
									errCode =  Util.copyFile(compressFilePath.toString(), tryFileName);
									if (errCode != 0)
									{
										theLogger.error(transactionId, "Try " + fidx + ": Error while copying compressed appeal file for appeal: " + appealNumber + " to EFT folder: " + tryFileName);
										//return errCode;
									}
									else
									{
										theLogger.debug(transactionId, "Copied compressed file for appeal " + appealNumber + " to EFT folder: " + tryFileName);
										fileNameAvailable = true;
										break;
									}
	
								}
								
							}
							
							if (fileNameAvailable == true)
							{	
								// Delete compressed manifest ZIP File
								errCode =  Util.deleteFile(compressFilePath.toString());
								if (errCode == 0)
								{
									theLogger.debug(transactionId, "Deleted compressed manifest file: " + compressFilePath.toString());
									
									// ALL DONE!!!!!!!!!!!!!!!
								}
								else
								{
									theLogger.error(transactionId, "Error while deleting compressed manifest file: " + compressFilePath.toString() );
									
									// RECOVERABLE ERROR
									errCode = 7;
								}
							}
							else
							{
								theLogger.error(transactionId, "Could not find available file name on EFT for manifest file: " + destFile);
								
								// RECOVERABLE ERROR
								errCode = 8;
								
								
								/*int failedAppeals = theLogger.incrementFailedAppeals();
								if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
								{
									theLogger.debug(transactionId, "QIC Appeal process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
								}*/
								
							}
							
						 

						}
						else
						{
							theLogger.error(transactionId, "Error while compressing manifest folder: " + manifestFolder.toString() + " to: " + compressFilePath.toString());
						
							// RECOVERABLE ERROR
							errCode = 6;
							
							/*int failedAppeals = theLogger.incrementFailedAppeals();
							if (failedAppeals >= constantConfig.getStopAfterFailedAppeals() )
							{
								theLogger.debug(transactionId, "Java QIC Appeal process will be stoppped because the maximum number of consecutive failures has been reached: " + failedAppeals);
							}*/
							
						}


						

					}
					else // null file path; 
					{
						// error was already logged
						continue;
					}
				}
				else
				{
					theLogger.error(batchUID, "Found empty or null filename in the list of files to be processed." );
					
					// this should never happen
				}
				
				
				// UPDATE SIEBEL WITH SUCCESS
				
				/*if (errCode == 0)
				{
					if (validatedSiebelTransaction == true)
					{
						if (allDocsOk == true)
						{
							siebelService.updateTransactionStatus(transactionId, "Completed", null, null, null, null);
							raccfAppeals++;
							
							theLogger.resetFailedAppeals();
						}
						else
						{
							siebelService.updateTransactionStatus(transactionId, "Error", "-22" , "Failed to upload documents to ECM", null, null);
						}
					}
				}
				else
				{
					if (validatedSiebelTransaction == true)
					{
						if (appealClosedInSiebel == true)
						{
							
							siebelService.updateTransactionStatus(transactionId, "Completed",  Integer.toString(errCode), "Failed to send response file to EFT", null, null);
						}
						else
						{
							if (allDocsOk == true)
							{
								siebelService.updateTransactionStatus(transactionId, "Error",  Integer.toString(errCode), "Error while processing the QIC Appeal process", null, null);
							}
							else
							{
								siebelService.updateTransactionStatus(transactionId, "Error", "-23" , "Failed to upload documents to ECM", null, null);
							}
						}
					}
				}*/
			}
				
			} // end FOR loop
		
		 catch (Exception e) {
			theLogger.error(batchUID, "Exception while process RAC Casefile appeals: " + e.getMessage() );
			
			
			
		} finally {
			theLogger.performanceStartOnly(batchUID, "Processed " + raccfAppeals  + " appeals in batch of " + processedRACCFAppeals + " appeals: ", startTime);

			theLogger.debug(batchUID, "Finished processing " + raccfAppeals  + " appeals in batch of " + processedRACCFAppeals + " appeals.");
		}
		
												return raccfAppeals;
	}
									
	
 
	private String checkFile(long batchUID, String fileUri)
	{
		//int fileStatus = 0;
		
		try
		{
			URL url = new URL(fileUri);
			URI uri = url.toURI();
			
			File file = new File(uri);
			
			if (file.exists()) 
			{
				String fileName = file.getName();
				//String firstLetter = fileName.substring(0,1).toUpperCase();
				
				boolean filenameok = false;
				ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getRacCaseFileprefixName().split(",")));
				for (int idx = 0; idx < filePrefixList.size(); idx++)
				{
					
						if (fileName.startsWith(filePrefixList.get(idx))) 
						{
							filenameok = true;
							break;
						}
					}
							
				
				
				//if(constantConfig.getPrefixTIBCOName().contains(firstLetter)) 
				if (filenameok == true)
				{
					long fileModified = file.lastModified();
					
					long transferTimeLimit = (System.currentTimeMillis() - constantConfig.getDelayTransfer());
					
					if(fileModified < transferTimeLimit)
					{
						String extension = FilenameUtils.getExtension(fileName);
						if(extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)) 
						{
							theLogger.error(batchUID, "File already locked : " + fileUri );
							//fileStatus = -5;
						}		
						else
						{
							File renameFile = new File(file.getPath() + "." + ProviderConstants.LOCK_EXTENSION);				
							if(file.renameTo(renameFile)) 
							{
								theLogger.debug(batchUID, "Picked and renamed file for import: " + fileUri );
								//fileStatus = 0;
								// OK HERE return renamed file
								return renameFile.getPath();
								
							} else {
								theLogger.error(batchUID, "Failed to rename (lock) file : " + fileUri );
								//fileStatus  = -4;
							}	
						}
					} else {
						theLogger.debug(batchUID, "File is still transferring, skipping for now: " + fileUri );
						//fileStatus  = -3;
					}
				} else {
					theLogger.debug(batchUID, "File is not part of the RACCF appeal filename schema: " + fileUri );
					//fileStatus  = -2;
				}
	
			}
			else
			{
				theLogger.error(batchUID, "File does not exist: " + fileUri );
				//fileStatus  = -2;
			}
		}
		catch (Exception ex)
		{
			theLogger.error(batchUID, "Exception while getting file information for file: " + fileUri, ex);
			//fileStatus = -1;
		}
		
		return null;
	}
	
	 
	private int addTextToManifestFile(long transactionId, String manifestFolder, String message)
	{
		int errCode = 0;
		
		FileWriter fw = null;
		try
		{
			String manifestFilename = manifestFolder + "/manifest.txt";
		    fw = new FileWriter(manifestFilename, true);  
		    fw.write(message);
		    fw.write("\r\n================================================================\r\n");
		}
		catch (Exception ioe)
		{
			theLogger.error(transactionId, "Exception while adding appeal data to manifest file: " + ioe.getMessage());
			
			// RECOVERABLE ERROR
			errCode = 4;
		}
		finally 
		{
			if (fw != null)
			{
				try
				{
					fw.close();
					fw = null;
				} catch (Exception clex)
				{
					fw = null;
				}
			}
		}
		
		return errCode;
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
}

