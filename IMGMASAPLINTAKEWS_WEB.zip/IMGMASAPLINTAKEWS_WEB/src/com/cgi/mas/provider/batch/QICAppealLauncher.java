package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.util.Util;
 
@Service("qicAppealLauncher")
public class QICAppealLauncher {

	private QICCustomLogger theLogger = new QICCustomLogger(QICAppealLauncher.class); 
	
	@Autowired
	private SimpleJobLauncher jobLauncher;	
	@Autowired
	private Job qicAppealProcessor;
	@Autowired
	private MapJobRepositoryFactoryBean jobRepository;	
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private ISiebelService siebelService;
	
	private static Map<String, JobExecution> jobHistory = new Hashtable<String, JobExecution>();


	public void startProcess() {
		
		long batchUID = theLogger.generateUID();
		
		try {
			String currentTime = Util.convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);

			theLogger.debug(batchUID, "Starting new process to qic appeals.");
			
			getJobsStatus(batchUID);	
			
			Set<JobExecution>runningJob = getRunningJobs(batchUID);		
			
			if (runningJob.isEmpty()) {
				//theLogger.debug(batchUID, "No active running jobs from previous batch.");

				cleanUpJobs(runningJob, batchUID);
				
				long readyFiles = getFilesReady(batchUID);
				
				if( readyFiles > 0 )
				{
					theLogger.debug(batchUID, "There are " + readyFiles + " files ready for processing in the incoming EFT Folder." );
					
					JobParametersBuilder jobParameterBuilder = new JobParametersBuilder();
					jobParameterBuilder.addString("currentTime", currentTime);
					jobParameterBuilder.addLong("totalFilesAvailable", readyFiles);
					jobParameterBuilder.addLong("batchUID", batchUID);
					
					JobExecution jobExecution = jobLauncher.run(qicAppealProcessor,
						jobParameterBuilder.toJobParameters());	
					
					jobHistory.put(currentTime, jobExecution);
				}	
				else
				{
					theLogger.debug(batchUID, "There are no files ready for processing in the incoming EFT Folder." );
				}
			} else {
				theLogger.debug(batchUID, "There are still running qic appeal jobs from previous batch:  " + runningJob.size() );
				displayRunningJobs(runningJob, batchUID);
			} 
		} catch (Exception e) {
			theLogger.error(batchUID, "Exception while starting new job to qic appeals in startProcess: ", e);
		}
	}

	// ----------------------Private Method-------------
	private void getJobsStatus(long batchUID){
		try{
			//theLogger.debug(batchUID, "Checking status of previous jobs: " + jobHistory.size());
			for (String key: jobHistory.keySet()){			
				JobExecution jobEx = jobHistory.get(key);
				String exitCode = jobEx.getExitStatus().getExitCode();
				theLogger.debug(batchUID, "\t\t Previous Job: " + key + "\t Exit Code: " + exitCode + " --> " + jobEx.toString());
				if (!exitCode.equalsIgnoreCase(ExitStatus.COMPLETED.getExitCode().toString())) {
					if (exitCode.equalsIgnoreCase(ExitStatus.FAILED.getExitCode().toString())) {
						Collection<StepExecution>stepCollection = jobEx.getStepExecutions();
						for (StepExecution step: stepCollection){
							theLogger.debug(batchUID, "Child Step: " + step.toString());
						}
					}
				}
				if(!exitCode.equalsIgnoreCase(ExitStatus.UNKNOWN.toString())){
					jobHistory.remove(key);	
				}			
			}	
		}catch(Exception e){
			theLogger.error(batchUID, "Exception in getJobsStatus: ", e);
		}
	}
	
	private void displayRunningJobs(Set<JobExecution>jobList, long batchUID){
		for (JobExecution job : jobList){			
			theLogger.debug(batchUID, "\t\t Running qic appeal job: " + job.getId() + "\t Exit Code: " + job.getExitStatus().getExitCode() + " --> " + job.toString());
		}
	}
	
	private Set<JobExecution> getRunningJobs(long batchUID){
		Set<JobExecution>runningJob = jobRepository.getJobExecutionDao().findRunningJobExecutions(qicAppealProcessor.getName());
		return runningJob;
	}	
	
	private void cleanUpJobs(Set<JobExecution> runningJob, long batchUID){
		//theLogger.debug(batchUID, "Cleaning previous close appeal jobs: " + runningJob.size());		
		if (runningJob.isEmpty())
		{			
			jobRepository.clear();			
		} else {
			theLogger.debug(batchUID, "Total qic appeal running jobs: " + runningJob.size());
			for (JobExecution ex : runningJob){			
				theLogger.debug(batchUID, "RunningJobDetail: "+ex.toString());
			}
		}
	}		
	
 

	
	private long getFilesReady(long batchUID)
	{
		//theLogger.debug(batchUID, "Finding the number of available files in the EFT incoming directory: " + directory);
		
		theLogger.debug(batchUID, "About to scan for appeal files. Failed Appeals: " + theLogger.getFailedAppeals() + " Failed Interface Appeals: " + theLogger.getFailedMBDAppeals());
		
		if (theLogger.getFailedAppeals() >= constantConfig.getStopAfterFailedAppeals() ||
				theLogger.getFailedMBDAppeals() >= constantConfig.getStopAfterFailedInterfaceCalls() )
		{
			theLogger.error(batchUID, "Java QIC Appeal process is paused. Failed Appeals: " + theLogger.getFailedAppeals() + " Failed Interface Appeals: " + theLogger.getFailedMBDAppeals());
			
			// stop processing
			
			// check Siebel if reset
			boolean shouldRestart = true;//siebelService.getJavaRestartFlag(batchUID);
			
			if (shouldRestart == true)
			{
				theLogger.debug(batchUID, "Received signal from Siebel to re-start the Qic Appeal processing");
				theLogger.resetFailedAppeals();
				theLogger.resetFailedMBDAppeals();
			}
			
			return 0;
		}
		else	
		{
			// process as usual
			long filesReady = 0;
	 
			String directory = constantConfig.getQicIncomingEftLocation();
			if (directory == null || directory.length() <= 0)
			{
				theLogger.error(batchUID, "The incoming EFT directory was not set");
				return -1;
			}
			
			//theLogger.debug(batchUID, "Finding the number of available files in the EFT incoming directory: " + directory);
			ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getQicFileprefixName().split(",")));
			File fileDir = new File(directory);
			AndFileFilter andFileFilter = new AndFileFilter(
												new SuffixFileFilter("zip", IOCase.INSENSITIVE),
												new PrefixFileFilter(filePrefixList));		
			Collection<File>fileCol = FileUtils.listFiles(fileDir, andFileFilter, null);
			
			if (fileCol != null)
			{
				filesReady = fileCol.size();
			}
	 
			return filesReady;	
		}
	}
 
	

	
	
}

