package com.cgi.mas.provider.batch;

import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.logger.CustomLogger;

public class FilePartitioner implements Partitioner{
	private static final String DEFAULT_KEY_NAME = "fileName";

	private static final String PARTITION_KEY = "partition";
	private String directory;
	private int totalMaxFiles;
	private CustomLogger theLogger = new CustomLogger(FilePartitioner.class);
	private Logger logger = theLogger.getLogger();
	@Autowired
	private  ConstantConfig constantConfig;
	
	
	public int getTotalMaxFiles() {
		return totalMaxFiles;
	}

	public void setTotalMaxFiles(int totalMaxFiles) {
		this.totalMaxFiles = totalMaxFiles;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}
	@Override
	public Map<String, ExecutionContext> partition(int gridSize){
		long startTime = System.currentTimeMillis();
		logger.debug("Prepare to partition..GroupSize: "+gridSize);
		int startRecord = 0;
		Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>();
		Assert.notNull(directory, "File directory need to be provided");
		File fileDir = new File(directory);
		Set<String>fileExtensionSet = constantConfig.getMimeType().keySet();
		Iterator<String>iteratorExtension = fileExtensionSet.iterator();
		List<String>fileExensionList = new ArrayList<String>();
		while(iteratorExtension.hasNext()){
			fileExensionList.add(iteratorExtension.next());
		}
		
		AndFileFilter andFileFilter = new AndFileFilter(new SuffixFileFilter(fileExensionList,IOCase.INSENSITIVE),new PrefixFileFilter(constantConfig.getPrefixTIBCOName()));		
		Collection<File>fileCol = FileUtils.listFiles(fileDir, andFileFilter, null);
				
		theLogger.performanceStartOnly("Collect all of the files", startTime);
		if (!fileCol.isEmpty()) {
			int totalReadFile = 0;
			if (totalMaxFiles > -1) {
				totalReadFile = totalMaxFiles;
			} else {
				totalReadFile = fileCol.size();
			}			
			File[]fileArray = convertCollectionToList(fileCol);
			Arrays.sort(fileArray,comparator);
    		int fileColSize = fileArray.length;
			long startGetFileTime = System.currentTimeMillis();
			int totalRecordsPerBatch = totalReadFile/gridSize;	
			int partitionloop=gridSize;
			if(gridSize> fileColSize)
				partitionloop = fileColSize;
			for (int index=0;index<partitionloop;index++){
				List<String>groupList = new ArrayList<String>();	
				ExecutionContext context = new ExecutionContext();
				for (int record=0;record<=totalRecordsPerBatch;record++){
					if(startRecord<fileColSize){
						
						try {
							groupList.add(fileArray[startRecord].toURI().toURL().toString());
						} catch (MalformedURLException e) {							
							e.printStackTrace();
						}
						startRecord++;	
					}else{
						break;
					}
						
				}
				context.put(DEFAULT_KEY_NAME, groupList);
				map.put(PARTITION_KEY+index, context);	
				
			}	
		}
		theLogger.performanceStartOnly("Total records for partition:  "+startRecord, startTime);
		//logger.debug("Finish partition....MaxFilePerBatch: "+totalMaxFiles);
		return map;
		
	
	}
	

	/**
	 * @param fileCol
	 * @return
	 */
	private File[] convertCollectionToList(Collection<File>fileCol){
		File[]fileArray = new File[(fileCol.size())];
		Iterator<File>fileIterator = fileCol.iterator();
		int i =0;
		Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		while(fileIterator.hasNext()){
			fileArray[i] = fileIterator.next();
			File file = (File)fileArray[i];
			i++;
		}
		return fileArray;
	}
	
	/**
	 * Files Process on first come first basis
	 */
	private final Comparator<File> comparator = new Comparator<File>() {
		@Override
		public int compare(File o1, File o2) {
			Pattern pat = Pattern.compile(constantConfig
					.getTibcoTimeStampRegEx());
			Matcher mat1 = pat.matcher(o1.getName());
			Matcher mat2 = pat.matcher(o2.getName());
			String timeStampVal1 = null;
			Calendar fileCalender1 = null;
			String timeStampVal2 = null;
			Calendar fileCalender2 = null;
			if (mat1.find()) {
				timeStampVal1 = mat1.group(0);
				timeStampVal1 = timeStampVal1.replaceAll("[A-z]", "");
				fileCalender1 = ProviderUtils.convertStringToCalendar(
						timeStampVal1, "yyMMdd.HHmmssS");
			}
			if (mat2.find()) {
				timeStampVal2 = mat2.group(0);
				timeStampVal2 = timeStampVal2.replaceAll("[A-z]", "");
				fileCalender2 = ProviderUtils.convertStringToCalendar(
						timeStampVal2, "yyMMdd.HHmmssS");
			}
			return fileCalender1 == fileCalender2 ? 0 : (fileCalender1
					.compareTo(fileCalender2) > 0 ? 1 : -1);
		}
	};
	
	
}
