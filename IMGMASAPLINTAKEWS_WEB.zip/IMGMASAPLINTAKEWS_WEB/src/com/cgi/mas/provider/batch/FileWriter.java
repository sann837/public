package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ECMDocumentDto;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.cgi.mas.provider.services.dto.UserDto;

public class FileWriter implements ItemWriter<ResourceSiebelDto> {

	private static CustomLogger theLogger = new CustomLogger(FileWriter.class);
	private static Logger logger = theLogger.getLogger();
	
	@Autowired
	private IECMService ecmService;
	
	@Autowired
	private ISiebelService siebelService;

	@Autowired
	private ConstantConfig constantConfig;

	@Override
	public void write(List<? extends ResourceSiebelDto> items) throws Exception {
		logger.debug("Size: "+items.size());
		for (ResourceSiebelDto resourceSDto : items){
			File file = resourceSDto.getResource().getFile();

			
			if (file.exists()){
				//boolean isSuccess = false;
 
				try {
					
//					ibmSession = getTransactionConnection(resourceSDto);
					
					//DocumentResultDto ecmResult = uploadToECM(ibmSession, resourceSDto);
					
					DocumentResultDto ecmResult = uploadToECM(resourceSDto);
					
					if(ecmResult!= null) {
						boolean status = siebelService.updateSiebelDocId(ecmResult);						
						//logger.debug("Update Siebel success : "+status);
						if (status)
						{
							//isSuccess = true;
							//ibmSession.commit();
							//logger.debug("Prepare to delete file: "+file.getPath()+"-->"+file.delete());
							
							logger.debug("File Import: BATCH IMPORT --- File Name: " + resourceSDto.getResource().getFilename() + " --- File Id: " + resourceSDto.getFileId() + " --- ECM Id: " + resourceSDto.getEcmId() + " --- Siebel Id: " + resourceSDto.getSiebelId() +  " --- Appeal Number: " + resourceSDto.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: SUCCESFULL ");
							
							file.delete();
						}
						else
						{
							logger.error("File Import: BATCH IMPORT --- File Name: " + resourceSDto.getResource().getFilename() + " --- File Id: " + resourceSDto.getFileId() + " --- ECM Id: " + resourceSDto.getEcmId() + " --- Siebel Id: " + resourceSDto.getSiebelId() +  " --- Appeal Number: " + resourceSDto.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: FAILED --- Error Message: FAILED TO UPDATE SIEBEL (will try again later)");
						}
						
					} else {
						/*
						StringBuilder strBuilder = new StringBuilder();
						strBuilder.append("Unable to import doc into ECM --> We will try again later ");
						strBuilder.append(resourceSDto.getFileId());
						strBuilder.append(" --> AppealNumber: ");
						strBuilder.append(resourceSDto.getAppealNumber());
						strBuilder.append(" --> ");
						strBuilder.append(resourceSDto.getOriginalName());						
						logger.debug(strBuilder.toString());	
						*/
						logger.error("File Import: BATCH IMPORT --- File Name: " + resourceSDto.getResource().getFilename() + " --- File Id: " + resourceSDto.getFileId() + " --- ECM Id: " + resourceSDto.getEcmId() + " --- Siebel Id: " + resourceSDto.getSiebelId() +  " --- Appeal Number: " + resourceSDto.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: FAILED --- Error Message: FAILED TO UPLOAD TO ECM");
						
					}	
				} catch(Error e) {
					//logger.error("", e);
					
					logger.error("File Import: BATCH IMPORT --- File Name: " + resourceSDto.getResource().getFilename() + " --- File Id: " + resourceSDto.getFileId() + " --- ECM Id: " + resourceSDto.getEcmId() + " --- Siebel Id: " + resourceSDto.getSiebelId() +  " --- Appeal Number: " + resourceSDto.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: ERROR --- Error Message: " + e);
					
				} catch(Exception e) {
					//logger.error("", e);
					
					logger.error("File Import: BATCH IMPORT --- File Name: " + resourceSDto.getResource().getFilename() + " --- File Id: " + resourceSDto.getFileId() + " --- ECM Id: " + resourceSDto.getEcmId() + " --- Siebel Id: " + resourceSDto.getSiebelId() +  " --- Appeal Number: " + resourceSDto.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: EXCEPTION --- Error Message: " + e);
					
				} finally {
					/*if (!isSuccess){
						rollBackTransaction(ibmSession);
					}*/
//					ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
				}
			}
		}
	}
	
/*
	private void rollBackTransaction(CMBConnection session){	
		try {
			if (session != null) {
				logger.debug("Prepare to roll back transaction");
				session.rollback();	
				logger.debug("Done rolling back transaction");
			}
		} catch (Error e) {
			logger.error("", e);
		} catch (Exception e) {
			logger.error("", e);
		}		
		
	}
*/
	
	/*
	private CMBConnection getTransactionConnection(ResourceSiebelDto resourceDto){
		CMBConnection session = null;
		try{
			UserDto userAccount = resourceDto.getUserAccount();
			session = ecmConnectionService.getIBMConnectionFromPool(userAccount.getEcmUserName(), userAccount.getEcmPassword(), constantConfig.getEcmServerName(), constantConfig.getEcmServerType());
			//session.startTransaction();
			return session;
		} catch(Error e) {
			logger.error("Unable to get connection ", e);
			return null;
		} catch(Exception e) {
			logger.error("Unable to get connection ", e);
			return null;
		}
		
	}
	*/
	
	private DocumentResultDto uploadToECM(ResourceSiebelDto resourceDto) {
		String appealNumber = resourceDto.getAppealNumber();
		UserDto userAccount = resourceDto.getUserAccount();		
		
		 
		
		try {
			Resource resource = resourceDto.getResource();
			String fileName = resourceDto.getOriginalName();
			String fileExtension = FilenameUtils.getExtension(fileName);		
		
			ECMDocumentDto ecmDoc = new ECMDocumentDto();			
			ecmDoc.setContentInputStream(resource.getInputStream());
			ecmDoc.setAppealNumber(appealNumber);
			ecmDoc.setEntityName(constantConfig.getLevel1ItemType());
			ecmDoc.setAttributeMap(setupECMDocumentAttributeMap(appealNumber,resourceDto.getSiebelId(),userAccount.getOrg(),resourceDto.getFileId(),resourceDto.getChecksum(),resourceDto.getAppealLevel()));							
			ecmDoc.setFileExtension(fileExtension);
			ecmDoc.setMimeType(getMimeType(fileExtension));
			ecmDoc.setFileName(fileName);
			ecmDoc.setFileSize(resource.getFile().length());			
			List<ECMDocumentDto> documentList = new ArrayList<ECMDocumentDto>();
			documentList.add(ecmDoc);
			
			/*
			CMBItem[] items = ecmService.getItemByDescription(session, appealNumber, (resourceDto.getFileId()+"-"+resourceDto.getChecksum()));
			if(items == null || items.length < 1) {
				List<DocumentResultDto>ecmDocResultList = ecmService.importDocumentIntoAppeal(session, appealNumber, documentList);	
				if (!ecmDocResultList.isEmpty()){
					return ecmDocResultList.get(0);
				}
			}
			*/
			
			String foundItem = ecmService.getItemByDescription(userAccount.getEcmUserName(), userAccount.getEcmPassword(), appealNumber, (resourceDto.getFileId()+"-"+resourceDto.getChecksum()));
			boolean itemInECM = false;
			
			if (foundItem != null)
			{
				if  (foundItem.length() > 0)
				{
					itemInECM = true;
				}
			}
			
			
			if (itemInECM == false)
			{
				// item is not in ECM, import it!
				List<DocumentResultDto> ecmDocResultList = ecmService.importDocumentIntoAppeal(userAccount.getEcmUserName(), userAccount.getEcmPassword(), appealNumber, documentList);	
				if (!ecmDocResultList.isEmpty()){
					return ecmDocResultList.get(0);
				}
			}
			
		} catch (Error e) {
			logger.error("uploadToECM Error", e);			
		} catch (Exception e) {
			logger.error("uploadToECM Exception", e);			
		}
		
		return null;
	}
	
	private String getMimeType(String fileExtension) {
		return constantConfig.getMimeType().get(fileExtension.toLowerCase());
	}
	
	private Map<String,String> setupECMDocumentAttributeMap(String appealNumber,String siebelId,String org,String fileId, String md5,String appealLevel){
		HashMap<String,String> ecmAttrMap = new HashMap<String,String>();
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel2DocCategory());
		}
		if(appealLevel.contains(constantConfig.getLevel1())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel1DocCategory());
		}
		if(appealLevel.contains(constantConfig.getLevel3())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel3DocCategory());
		}
		ecmAttrMap.put(ProviderConstants.ECM_RECEIVED_DT, ProviderUtils.convertCalendarToString(Calendar.getInstance(), ProviderConstants.ECM_DT_FORMAT));
		
		ecmAttrMap.put(ProviderConstants.ECM_AUDT_CD, constantConfig.getDocAuditCode().get(org));
		
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel2Code());
		}
		if(appealLevel.contains(constantConfig.getLevel1())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel1Code());
		}
		
		if(appealLevel.contains(constantConfig.getLevel3())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel3Code());
		}
			
		ecmAttrMap.put(ProviderConstants.ECM_DESCRIPTION, fileId+"-"+md5);
		ecmAttrMap.put(ProviderConstants.ECM_APPEAL_NUM, appealNumber);
		if (StringUtils.hasText(siebelId)){
			ecmAttrMap.put(ProviderConstants.ECM_SIEBEL_LVL_1_ID, siebelId);	
		}
		
		return ecmAttrMap;
	}
	

	/*
	private void displayMessage(String message) {
		logger.debug(message);
	}
	*/
}
