package com.cgi.mas.provider.batch;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ECMDocumentDto;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.cgi.mas.provider.services.dto.UserDto;

 
public class ValidateECM implements ItemProcessor<ResourceSiebelDto,ResourceSiebelDto>{

	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private IECMService ecmService;
	
	@Autowired
	private ISiebelService siebelService;
	
	private Logger logger = Logger.getLogger(ValidateECM.class);
	
	@Override
	public ResourceSiebelDto process(ResourceSiebelDto item) throws Exception {
		
		Resource docResource = item.getResource();
		String transferFileName = docResource.getFilename();	
		
		String ecmId = item.getEcmId();
		String fileId = item.getFileId();
		
		try{
			logger.debug("Validate item if exist in ECM");
			File file = docResource.getFile();
			StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("FileId: ");
			strBuilder.append(fileId);
			strBuilder.append("-->ECMId:");
			strBuilder.append(ecmId);
			String infor = strBuilder.toString();
			logger.debug(infor);
			UserDto userAccount = item.getUserAccount();
//			ibmSession = ecmConnectionService.getIBMConnectionFromPool(userAccount.getEcmUserName(), userAccount.getEcmPassword(), constantConfig.getEcmServerName(), constantConfig.getEcmServerType());
			if((ecmId == null) || (ecmId.length() != 26)) {
				//invalid id because siebel always has id when client initially call webservice
				logger.debug("Verify ECM document by searching description-->"+infor);
				String description = fileId+"-"+item.getChecksum();
				//CMBItem[] docItems = ecmService.getItemByDescription(ibmSession, item.getAppealNumber(), description);
				
				String docItem = ecmService.getItemByDescription(userAccount.getEcmUserName(), userAccount.getEcmPassword(), item.getAppealNumber(), description);
				
				
				if(docItem != null && docItem.length() > 0) {
					//for(CMBItem theDocItem : docItems) {					
						DocumentResultDto ecmDto = new DocumentResultDto();		
						ecmDto.setSiebeldocId(item.getSiebelId());
						//ecmDto.setEcmItemId(theDocItem.getDDO().getPidObject().getPrimaryId());
						ecmDto.setEcmItemId(docItem);
						ECMDocumentDto docDto = new ECMDocumentDto();
						String extension = FilenameUtils.getExtension(item.getOriginalName());
						docDto.setMimeType(constantConfig.getMimeType().get(extension!= null ? extension.toLowerCase(): extension));					
						docDto.setContentInputStream(docResource.getInputStream());
						ecmDto.setPageCount(ecmService.getPageCount(docDto));					
						ecmDto.setSizeInKB(file.length()/FileUtils.ONE_KB);
						ecmDto.setFileName(item.getOriginalName());
						boolean status = siebelService.updateSiebelDocId(ecmDto);
						
						if(status) 
						{
							logger.debug("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + ecmId + " --- Siebel Id: " + item.getSiebelId() + " --- Appeal Number: " + item.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: SUCCESFULL ");

							file.delete();
							//logger.debug("validateECM: Done update Siebel..need to delete : "+file.getPath()+"-->"+file.delete());						
						} else {				
							logger.error("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + ecmId + " --- Siebel Id: " + item.getSiebelId() + " --- Appeal Number: " + item.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: FAILED --- Error Message: ERROR WHILE UPDATING SIEBEL (will try again later)");
							
							//logger.debug("There are something wrong..Will try again later "+infor);
						}
					//}
					
					return null;
				} else return item;
			} else {
				//Check ECM if it is exist.				
				// docItem = ecmService.searchItemById(ibmSession, ecmId);
				String docItem = ecmService.searchItemById(userAccount.getEcmUserName(), userAccount.getEcmPassword(), ecmId);
				if(docItem!= null) {
					//logger.debug("Doc Already import into ECM-->"+infor);					
					//logger.debug("validateECM: Prepare to delete file: "+file.getPath()+"-->"+file.delete());
					
					logger.debug("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + ecmId + " --- Siebel Id: " + item.getSiebelId() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: DUPLICATE --- Error Message: FILE ALREADY IMPORTED INTO ECM");
					file.delete();
					
					return null;
				} else {
					logger.debug("Could not find the ECM-->"+infor);
					return item;
				}
			}
		} catch(Exception e) {
			
			logger.error("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + ecmId + " --- Siebel Id: " + item.getSiebelId() +  " --- Import Status: EXCEPTION --- Error Message: " + e);
			
			//logger.error("", e);
			return null;
		} finally {
//			ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
		}
	}
	

}
