package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.util.Util;

public class QICPartitioner implements Partitioner {
	
	@Autowired
	private ConstantConfig constantConfig;
	
	private static final String MAX_FILES = "MaxAppeals";
	private static final String BATCH_UID = "BatchUID";
	private static final String THREAD_NAME = "ThreadName";
	private static final String PARTITION_KEY = "partition";
	private static final String DEFAULT_KEY_NAME = "fileName";
	 
	private int totalMaxFiles;
	private int totalFilesAvailable;
	private long batchUID;
	
	private QICCustomLogger theLogger = new QICCustomLogger(QICPartitioner.class);

	
	public int getTotalMaxFiles() {
		return totalMaxFiles;
	}

	public void setTotalMaxFiles(int totalMaxFiles) {
		this.totalMaxFiles = totalMaxFiles;
	}

	public int getTotalFilesAvailable() {
		return totalFilesAvailable;
	}

	public void setTotalFilesAvailable(int totalFilesAvailable) {
		this.totalFilesAvailable = totalFilesAvailable;
	}
 
	public long getbatchUID() {
		return batchUID;
	}

	public void setbatchUID(long batchUID) {
		this.batchUID = batchUID;
	}

	
	@Override
	public Map<String, ExecutionContext> partition(int gridSize){

		theLogger.debug(batchUID, "Creating partition for " + totalFilesAvailable + "  close appeal files for grid size: " + gridSize);
		
		Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>();
			
		int numThreads = gridSize;		 
		if (gridSize > totalFilesAvailable)
		{
			numThreads = totalFilesAvailable;
		}
		//theLogger.debug(batchUID, "Number of threads to be created: " + numThreads);
		
		int maxFilesPerThread = 1;
		if (totalFilesAvailable > gridSize)
		{
			maxFilesPerThread = totalFilesAvailable / gridSize;			
			if (maxFilesPerThread > totalMaxFiles)
			{
				maxFilesPerThread = totalMaxFiles;
			}
		}
		//theLogger.debug(batchUID, "Maximum files per thread: " + maxFilesPerThread);
		

		String directory = constantConfig.getQicIncomingEftLocation();
		//theLogger.debug(batchUID, "Reading all available files in the EFT incoming directory: " + directory);
		ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getQicFileprefixName().split(",")));
		File fileDir = new File(directory);
		AndFileFilter andFileFilter = new AndFileFilter(
											new SuffixFileFilter("zip", IOCase.INSENSITIVE),
											new PrefixFileFilter(filePrefixList));		
		Collection<File>fileCol = FileUtils.listFiles(fileDir, andFileFilter, null);
		
 		
		int startRecord = 0;
		if (fileCol != null && fileCol.size() > 0) 
		{
			File[] fileArray = convertCollectionToList(fileCol, batchUID);
			if (fileArray != null)
			{
				Arrays.sort(fileArray,comparator);
				
				for (int index=0; index<numThreads; index++) 
				{
					ExecutionContext context = new ExecutionContext();
		 
					List<String> groupList = new ArrayList<String>();
					
					for (int record=0; record<maxFilesPerThread; record++)
					{
						if(startRecord < fileArray.length)
						{
							try {
								groupList.add(fileArray[startRecord].toURI().toURL().toString());
							} catch (Exception urlEx) {							
								theLogger.error(batchUID, "Exception while setting file URI for processing: ", urlEx);
							}
							startRecord++;	
						}else{
							break;
						}	
					}
					
					context.putInt(MAX_FILES, maxFilesPerThread);
					context.putLong(BATCH_UID, batchUID);
					context.putString(THREAD_NAME, "Thread" + index);
					context.put(DEFAULT_KEY_NAME, groupList);
					
					map.put(PARTITION_KEY + index, context);	
				}	
			}
		}
		
		return map;
 	}
	
	
	private final Comparator<File> comparator = new Comparator<File>() {
		@Override
		public int compare(File o1, File o2) 
		{
			try
			{
				Pattern pat = Pattern.compile(constantConfig
						.getTibcoTimeStampRegEx());
				Matcher mat1 = pat.matcher(o1.getName());
				Matcher mat2 = pat.matcher(o2.getName());
				String timeStampVal1 = null;
				Calendar fileCalender1 = null;
				String timeStampVal2 = null;
				Calendar fileCalender2 = null;
				if (mat1.find()) {
					timeStampVal1 = mat1.group(0);
					timeStampVal1 = timeStampVal1.replaceAll("[A-z]", "");
					fileCalender1 = Util.convertStringToCalendar(
							timeStampVal1, "yyMMdd.HHmmssS");
				}
				if (mat2.find()) {
					timeStampVal2 = mat2.group(0);
					timeStampVal2 = timeStampVal2.replaceAll("[A-z]", "");
					fileCalender2 = Util.convertStringToCalendar(
							timeStampVal2, "yyMMdd.HHmmssS");
				}
				return fileCalender1 == fileCalender2 ? 0 : (fileCalender1
						.compareTo(fileCalender2) > 0 ? 1 : -1);
			} catch (Exception ex)
			{
				return 0;
			}
		}
	};
	
	private boolean checkFileName(File fileToCheck, long transactionId) 
	{
		boolean fileOk = true;
		try
		{
			Pattern pat = Pattern.compile(constantConfig
					.getTibcoTimeStampRegEx());
			Matcher mat1 = pat.matcher(fileToCheck.getName());
			 
			
			if (mat1.find()) {
				String timeStampVal1 = mat1.group(0);
				timeStampVal1 = timeStampVal1.replaceAll("[A-z]", "");
				Util.convertStringToCalendar( timeStampVal1, "yyMMdd.HHmmssS");
			}
			else
			{
				fileOk = false;
			}

		} 
		catch (Exception ex)
		{
			fileOk = false;
		}
		
		return fileOk;
	}
	
	private File[] convertCollectionToList(Collection<File>fileCol, long transactionId)
	{
		File[] initialFileArray = new File[(fileCol.size())];
		
		Iterator<File> fileIterator = fileCol.iterator();
		int i =0;
		//Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		
		int numberOfOkFiles = 0;
		while (fileIterator.hasNext())
		{
			File fileToCheck  = fileIterator.next();
			 
			// check for bad filenames
			boolean fileOk = checkFileName(fileToCheck, transactionId) ; 
			
			if (fileOk == true)
			{
				numberOfOkFiles++;
				initialFileArray[i] = fileToCheck;		
			}
			else
			{
				initialFileArray[i] = null;
				
				String originalFileName = fileToCheck.getPath();
				originalFileName = originalFileName.substring(0, originalFileName.lastIndexOf('.'));
				String errorFileName = originalFileName + "." + ProviderConstants.FAILED_VALIDATION_EXTENSION;
			 
				File renameFile = new File(errorFileName);				
				if(fileToCheck.renameTo(renameFile)) 
				{
					theLogger.error(transactionId, "The filename " + fileToCheck.getName() + " does not have a correct date / time format and was renamed.");
				}
				else
				{
					theLogger.error(transactionId, "The filename " + fileToCheck.getName() + " does not have a correct date / time format and could not be renamed!");
				}
			}
			i++;
		}
		
		if (numberOfOkFiles > 0)
		{
			File[] fileArray = new File[numberOfOkFiles];
			
			int fdx = 0;
			for (i = 0; i < fileCol.size(); i++) 
			{
				if (initialFileArray[i] != null)
				{
					fileArray[fdx] = initialFileArray[i];
					fdx++;
				}
			}
			
			return fileArray;
		}
		else
		{
			return null;
		}
	}
	
	
	private long getFilesReady(long batchUID)
	{
		long filesReady = 0;
	 
		String directory = constantConfig.getQicIncomingEftLocation();
		if (directory == null || directory.length() <= 0)
		{
			theLogger.error(batchUID, "The incoming EFT directory was not set");
			return -1;
		}
		
		//theLogger.debug(batchUID, "Reading all available files in the EFT incoming directory: " + directory);
		ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getQicFileprefixName().split(",")));
		File fileDir = new File(directory);
		AndFileFilter andFileFilter = new AndFileFilter(
											new SuffixFileFilter("zip", IOCase.INSENSITIVE),
											new PrefixFileFilter(filePrefixList));		
		Collection<File>fileCol = FileUtils.listFiles(fileDir, andFileFilter, null);
		
		if (fileCol != null)
		{
			filesReady = fileCol.size();
		}
 
		return filesReady;	
	}

}
