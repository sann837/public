package com.cgi.mas.provider.batch;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.CustomLogger;

public class FileReader implements ResourceAwareItemReaderItemStream<Resource>{
	private Resource resource = null;	
	private boolean isDoneProcess = false;
	
	@Override
	public void setResource(Resource resource) {		
		this.resource = resource;		
	}

	@Override
	public void close() throws ItemStreamException {
		if(this.resource!= null) {
			displayMessage(this.resource.toString()+"--Closing");
			File file = null;
			try {
				file = this.resource.getFile();
				
				/*if (file.exists()){
					File renameFile = new File(file.getPath()+".old");
					displayMessage("Delete file: "+file.renameTo(renameFile));	
				}*/
				
			} catch(IOException e) {
				logger.error("", e);
			}
		} //else displayMessage("Not thing to close");
	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		displayMessage(this.resource.toString()+"--open");		
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		if(this.resource!= null) {
			displayMessage(this.resource.toString()+"--updating");	
		} else {
			//displayMessage("Just calling update");
		}
	}
	
	public Resource readgood() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException{
		displayMessage("Read ---> " + resource.toString() + " --> " + this.hashCode());
		if(!isDoneProcess) {
			isDoneProcess = true;			
			return resource;
		} else {
			isDoneProcess = false;
			return null;
		}
	}
	
	@Override
	public Resource read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {		

		if (resource == null) {
			displayMessage("Detect Null");
			//isDoneProcess = true;
			return null;
		}
		
		//displayMessage("Before Read: "+resource.toString());
		
		if (!resource.exists()){
			//displayMessage("File doesn't exist: "+resource.getFilename());
			
			logger.debug("File Import: BATCH IMPORT --- File Name: " + resource.getFilename() + " --- Import Status: FILE DOES NOT EXIST");
			
			return null;
		}
		
		File file = resource.getFile();
		String fileName = file.getName();
		String firstLetter = fileName.substring(0,1).toUpperCase();
		
		if(constantConfig.getPrefixTIBCOName().contains(firstLetter)) {
			long fileModified = file.lastModified();
			
			long transferTimeLimit = (System.currentTimeMillis() - constantConfig.getDelayTransfer());
			
			if(fileModified < transferTimeLimit){
				String extension = FilenameUtils.getExtension(fileName);
				if(extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)) {
					return null;
				}				
				File renameFile = new File(file.getPath() + "." + ProviderConstants.LOCK_EXTENSION);				
				if(file.renameTo(renameFile)) {
					//displayMessage("Rename suscccessful: " + fileName);
					
					logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- Import Status: RENAMED");
					
					Resource fileSystemResource = new FileSystemResource(renameFile);
					this.setResource(null);
					return fileSystemResource;
				} else {
					/*
					StringBuilder errorMessage = new StringBuilder();
					errorMessage.append("Can not rename from ");
					errorMessage.append(file.getPath());
					errorMessage.append(" --To--");
					errorMessage.append(renameFile.getPath());
					displayMessage(errorMessage.toString());	
					*/
					
					logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- File Path: " + file.getPath() + " --- Import Status: FAILED TO RENAME");
					
					return null;
				}	
			} else {
				//logger.debug("Still transferring file: "+fileName);
				
				logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- Import Status: STILL TRANSFERRING");
				
				return null;
			}
		} else {
//			if(constantConfig.isExtraLogging())
//				logger.debug("File " + fileName + " is not a part of the CreateAutoAppeal Web Services.");
			
			return null;
		}
	}
	
	public Resource readeeee() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		if(!isDoneProcess) {
			if(resource == null) {
				return null;
			}
			
			File file = resource.getFile();
			
			RandomAccessFile randomFile = null;
			FileChannel fileChannel = null;
			try {
				//skip if it has lockextension
				String extension = FilenameUtils.getExtension(file.getName());
				/*if (extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)){
					isDoneProcess = true;
					return null;
				}*/
				randomFile = new RandomAccessFile(file,"rw");
				//fileChannel = fileInputStream.getChannel();
				fileChannel = randomFile.getChannel();
				//logger.debug(resource.toString()+"-->got channel");
				FileLock fileLock = fileChannel.tryLock();				
				isDoneProcess = true;
				if(fileLock != null) {					
					File renameFile = new File(file.getPath()+"."+ ProviderConstants.LOCK_EXTENSION);
					
					file.renameTo(renameFile);
					
					//displayMessage(resource.toString() + " --> got lock --> rename: " + file.renameTo(renameFile));
					//fileLock.release();	
					
					logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- File Path: " + file.getPath() + " --- Import Status: LOCKED");
					
					return resource;
				} else {
					//displayMessage(resource.toString() + " --> could not obtain the lock");
					
					logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- File Path: " + file.getPath() + " --- Import Status: FAILED TO OBTAIN LOCK");
					
					return null;
				}	
				
			} catch(Error e) {
				//logger.error("", e);
				
				logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- File Path: " + file.getPath() + " --- Import Status: ERROR --- Error Message: " + e);
				
				return null;
			} catch(Exception e) {
				//logger.error("", e);
				
				logger.debug("File Import: BATCH IMPORT --- File Name: " + file.getName() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- File Path: " + file.getPath() + " --- Import Status: EXCEPTION --- Error Message: " + e);
				
				return null;
			} finally {
				if (fileChannel!= null){
					fileChannel.close();	
				}
				if (randomFile!= null){
					randomFile.close();	
				}
			}
			
			/*isDoneProcess = true;
			if (file.exists()){
				displayMessage(resource.toString()+"-->exist::::");
				return resource;	
			}else{
				return null;
			}*/
			
		} else {			
			isDoneProcess = false;
			return null;
		}
				
		
		
		
		/*if (!isDoneProcess){
			if (resource==null){
				return null;
			}
			File file = resource.getFile();						
			isDoneProcess = true;
			if (file.exists()){
				displayMessage(resource.toString()+"-->exist::::");
				return resource;	
			}else{
				return null;
			}
			
		}else{			
			isDoneProcess = false;
			return null;
		}
				*/
		
	}
	
	private static CustomLogger theLogger = new CustomLogger(FileReader.class);
	private static Logger logger = theLogger.getLogger();
	
	@Autowired
	private ConstantConfig constantConfig;
	
	private void displayMessage(String message){
		logger.debug(message);
	}
	
	//private final int TRANSFER_LIMIT = (1000*10);
}
