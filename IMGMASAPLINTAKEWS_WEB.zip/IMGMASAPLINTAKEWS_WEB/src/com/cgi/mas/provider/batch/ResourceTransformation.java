package com.cgi.mas.provider.batch;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;

public class ResourceTransformation implements ItemProcessor<Resource,ResourceSiebelDto>{

	@Override
	public ResourceSiebelDto process(Resource item) throws Exception {	
		String fileId = getFileId(item.getFilename());
		File file = item.getFile();
		logger.debug("Trying to retrieve siebel information for file id: "+fileId+"-->"+file.getName());
		if (!file.exists()){
			// The reason while the file does not exist is that another thread processed it, so thi sis not an error
			// We still need to check if there are other reasons while the file no longer exists
			
			logger.debug("File doesn't exist: "+item.toString());

			//logger.error("File Import: BATCH IMPORT --- File Name: " + fileId +  " --- Import Status: ERROR --- Error Message: FILE DOES NOT EXIST");
			
			return null;
		}
		String prefixName = item.getFilename().substring(0,1).toUpperCase();
		ResourceSiebelDto dto = siebelService.getDocInforFromFileId(fileId);
		if (dto!= null){
			String siebelId = dto.getSiebelId();
			//checking for Invalid Prefix for Organization
			// Giving the ability to ADQIC user to transfer files for Level 2 and Level 3 
			if (dto.getUserAccount().getEcmUserName().equalsIgnoreCase(constantConfig.getAdQICEcmUserName()) || (constantConfig.getOrgPrefix().get(dto.getUserAccount().getOrg())!=null && ((constantConfig.getOrgPrefix().get(dto.getUserAccount().getOrg()).contains(prefixName)) || !constantConfig.getOrgPrefix().get(dto.getUserAccount().getOrg()).equalsIgnoreCase("InValid")))){
				if(StringUtils.hasText(siebelId)){			
				dto.setResource(item);
				return dto;
			}
				else
					return null;
				}else{
				//Siebel has not populate this data yet. Transferring file too earlier				
				return null;
			}
			
		}else{
			return null;
		}
		
		
	}
	private String getFileId(String fileName){
		String[] fileNameSpl = fileName.split("\\.");
		return fileNameSpl[0];
	}
	@Autowired
	private ISiebelService siebelService;
	@Autowired
	private ConstantConfig constantConfig;
	private Logger logger = Logger.getLogger(ResourceTransformation.class);
}
