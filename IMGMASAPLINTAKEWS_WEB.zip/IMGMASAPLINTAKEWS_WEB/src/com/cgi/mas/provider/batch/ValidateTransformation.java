package com.cgi.mas.provider.batch;

import java.io.File;
import java.util.Locale;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.Resource;

import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.siebel.customui.CreateDocErrorLogInput;

public class ValidateTransformation implements ItemProcessor<ResourceSiebelDto,ResourceSiebelDto>{

	@Override
	public ResourceSiebelDto process(ResourceSiebelDto item) throws Exception {
		//logger.debug("Trying to validate mimetype/checksum to verify that submitted file match transferring file");
		Resource resource = item.getResource();
		String fileName = item.getOriginalName();
		
		String fileExtension = FilenameUtils.getExtension(fileName);
		//test.pdf.lock
		String transferFileName = resource.getFilename();
		//test.pdf
		String transferBaseName = FilenameUtils.getBaseName(transferFileName);
		//String transferExtension = FilenameUtils.getExtension(transferFileName);
		String lockExtension  = FilenameUtils.getExtension(transferFileName);
		String transferExtension = null;
		if(lockExtension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)){
			transferExtension = FilenameUtils.getExtension(transferBaseName);
		}else{
			transferExtension = lockExtension;
		}
		
		/*
		 File Import: Batch Import --- File Name: filename --- File Size: filesize --- Import Status: status --- Appeal Number: appealNumber --- Siebel ID: siebelId --- ECM Id: ecmId --- Error Message: error
		 */
		
		 
		logger.debug("Request File: "+fileName+"-->Transfer: "+transferFileName);
		File file = resource.getFile();
		String eftCheckSum = ProviderUtils.getMD5CheckSum(file);
		String requestCheckSum = item.getChecksum();
		boolean isSame = requestCheckSum.equalsIgnoreCase(eftCheckSum);
		//logger.debug("Request CheckSum: "+requestCheckSum+"-->"+eftCheckSum+"-->Same:"+isSame);
		if((fileExtension.equalsIgnoreCase(transferExtension))&&(isSame)) {
			return item;
		} else {
			String errorCode = null;
			String errorMessage = null;
			String fileId = item.getFileId();
			if (!isSame){
				errorMessage = messageSource.getMessage(ErrorFieldConstant.MISSMATCH_CHECKSUM_EXCEPTION, new String[]{eftCheckSum, requestCheckSum, fileId}, Locale.US);
				logger.error("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + item.getEcmId() + " --- Siebel Id: " + item.getSiebelId() + " --- Appeal Number: " + item.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: FAILED --- Error Message: CHECKSUM DOES NOT MATCH (" + eftCheckSum + " vs. " + requestCheckSum + ")");
				errorCode = ErrorFieldConstant.MISSMATCH_CHECKSUM_EXCEPTION;				
			}else{
				errorMessage = messageSource.getMessage(ErrorFieldConstant.MISMATCH_MIMETYPE_EXCEPTION, new String[]{fileExtension, transferExtension, fileId}, Locale.US);
				logger.error("File Import: BATCH IMPORT --- File Name: " + transferFileName + " --- File Id: " + fileId + " --- ECM Id: " + item.getEcmId() + " --- Siebel Id: " + item.getSiebelId() + " --- Appeal Number: " + item.getAppealNumber() + " --- File Size: " + file.length()/FileUtils.ONE_KB + " --- Import Status: FAILED --- Error Message: MIMETYPE DOES NOT MATCH (" + fileExtension + " vs. " + transferExtension + ")");
				errorCode = ErrorFieldConstant.MISMATCH_MIMETYPE_EXCEPTION;
			}			
			//logger.error(errorMessage+"-->"+item.getFileId());
			
			
			logger.debug("Trying to rename the document since we can not recover");
			boolean isRenameWork = renameUnRecoverFile(file);
			if (isRenameWork){
				CreateDocErrorLogInput input = new CreateDocErrorLogInput();
				input.setErrorCode(errorCode);
				input.setErrorMsg(errorMessage);
				input.setAppealNumber(item.getAppealNumber());
				siebelService.createSiebelDocError(input, false);
				logger.debug("---Done detect and report error to siebel");	
			}else{
				//logger.debug(""+renameUnRecoverFile(file));	
			}			
			return null;	
		}
		
		
		
	}
	@Autowired
	private ISiebelService siebelService;
	@Autowired
	private MessageSource messageSource;
	private Logger logger = Logger.getLogger(ValidateTransformation.class);
	private boolean renameUnRecoverFile(File file){
		File renameFile = new File(file.getPath() + "." + ProviderConstants.NON_RECOVER_EXTENSION);
		boolean isSuccess = file.renameTo(renameFile);
		if(isSuccess) {
			logger.debug("Rename suscccessful: " + renameFile.getPath());		
		}else{
			StringBuilder errorMessage = new StringBuilder();
			errorMessage.append("Can not rename from ");
			errorMessage.append(file.getPath());
			errorMessage.append(" --To--");
			errorMessage.append(renameFile.getPath());
			logger.error(errorMessage.toString());
		}
		return isSuccess;
		
	}

}
