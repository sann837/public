package com.cgi.mas.provider;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConstantConfig {
	private String ecmServerName;
	private String ecmServerType;
	private String level1ItemType;
	private String siebelDocCategory;
	private String siebelDocType;	
	private HashMap<String,String> mimeType;
	private String tempFileLocation;
	private String tibcoTimeStampRegEx;
	private List<String> prefixTIBCOName;
	private String siebelWSAddress;	
	private String siebelUserName;
	private String siebelPassWord;	
	private Map<String,String> docAuditCode;
	private long expiredDay;
	private List<String> certList;
	
	private boolean extraLogging = false;
	private boolean performanceLogging = true;
	private int delayTransfer;
	private String siebelLevel1DocCategory;
	private String siebelLevel2DocCategory;
	private String siebelLevel3DocCategory;
	private String level1;
	private String level2;
	private String level3;
	private String ecmDocTypeLevel1Code;
	private String ecmDocTypeLevel2Code;
	private String ecmDocTypeLevel3Code;	
	private Map<String,String>  orgPrefix;
	private List<String> level2OrgList;
	private List<String> level1OrgList;
	private String adQICEcmUserName;
	
	//QIC Webservice
	private long totalJVMs;
	private long thisJVMid;
	
	private long siebelWsConnectTimeout;
	private long siebelWsRespondTimeout;
	private int httpWsConnectTimeout;
	private int httpWsRespondTimeout;
	private String qicFileprefixName;
	
	private String qicAppealXsdPath;
	
	private String keystorePassword;
	private String keyAlias;
	private String keystoreName;
	private String keyPassword;
	
	private String validateDocumentInputXsdPath;
	private String qicTempLocation;
	private String qicEftLocation;
	private String qicIncomingEftLocation; 
	private long l2ExpiredDay;
		
	private int stopAfterFailedAppeals;
	private int stopAfterFailedInterfaceCalls;
	private int resetFailedInterfaceCallsAfter;
	
	
	//RACCF
	private String raccfTempLocation;
	private String raccfIncomingEftLocation;
	private String raccfOutEftLocation;
	private String racCaseFileprefixName;
	private String racWSAddress;
	private String siebelRacUsername;
	
	private HashMap<String,String> claimContrctNum;
 
	

	public HashMap<String, String> getClaimContrctNum() {
		return claimContrctNum;
	}
	public void setClaimContrctNum(HashMap<String, String> claimContrctNum) {
		this.claimContrctNum = claimContrctNum;
	}
	public String getQicEftLocation() {
		return qicEftLocation;
	}
	public void setQicEftLocation(String qicEftLocation) {
		this.qicEftLocation = qicEftLocation;
	}
	public String getQicFileprefixName() {
		return qicFileprefixName;
	}
	public void setQicFileprefixName(String qicFileprefixName) {
		this.qicFileprefixName = qicFileprefixName;
	}
	public int getDelayTransfer() {
		return delayTransfer;
	}
	public void setDelayTransfer(int delayTransfer) {
		this.delayTransfer = delayTransfer;
	}
	public long getExpiredDay() {
		return expiredDay;
	}
	public void setExpiredDay(long expiredDay) {
		this.expiredDay = expiredDay;
	}
	public Map<String, String> getDocAuditCode() {
		return docAuditCode;
	}
	public void setDocAuditCode(Map<String, String> docAuditCode) {
		this.docAuditCode = docAuditCode;
	}
	public String getSiebelUserName() {
		return siebelUserName;
	}
	public void setSiebelUserName(String siebelUserName) {
		this.siebelUserName = siebelUserName;
	}
	public String getSiebelPassWord() {
		return siebelPassWord;
	}
	public void setSiebelPassWord(String siebelPassWord) {
		this.siebelPassWord = siebelPassWord;
	}
	public String getSiebelWSAddress() {
		return siebelWSAddress;
	}
	public void setSiebelWSAddress(String siebelWSAddress) {
		this.siebelWSAddress = siebelWSAddress;
	}
	public List<String> getPrefixTIBCOName() {
		return prefixTIBCOName;
	}
	public void setPrefixTIBCOName(List<String> prefixTIBCOName) {
		this.prefixTIBCOName = prefixTIBCOName;
	}
	public void setCertList(List<String> certList) {
		this.certList = certList;
	}
	public List<String> getCertList() {
		return certList;
	}
	public String getTibcoTimeStampRegEx() {
		return tibcoTimeStampRegEx;
	}
	public void setTibcoTimeStampRegEx(String tibcoTimeStampRegEx) {
		this.tibcoTimeStampRegEx = tibcoTimeStampRegEx;
	}
	public String getTempFileLocation() {
		return tempFileLocation;
	}
	public void setTempFileLocation(String tempFileLocation) {
		this.tempFileLocation = tempFileLocation;
	}
	public HashMap<String, String> getMimeType() {
		return mimeType;
	}
	public void setMimeType(HashMap<String, String> mimeType) {
		this.mimeType = mimeType;
	}
	public String getSiebelDocCategory() {
		return siebelDocCategory;
	}
	public void setSiebelDocCategory(String siebelDocCategory) {
		this.siebelDocCategory = siebelDocCategory;
	}
	public String getSiebelDocType() {
		return siebelDocType;
	}
	public void setSiebelDocType(String siebelDocType) {
		this.siebelDocType = siebelDocType;
	}
	public String getLevel1ItemType() {
		return level1ItemType;
	}
	public void setLevel1ItemType(String level1ItemType) {
		this.level1ItemType = level1ItemType;
	}
	public String getEcmServerName() {
		return ecmServerName;
	}
	public void setEcmServerName(String ecmServerName) {
		this.ecmServerName = ecmServerName;
	}
	public String getEcmServerType() {
		return ecmServerType;
	}
	public void setEcmServerType(String ecmServerType) {
		this.ecmServerType = ecmServerType;
	}
	public void setExtraLogging(boolean extraLogging) {
		this.extraLogging = extraLogging;
	}
	public boolean isExtraLogging() {
		return extraLogging;
	}
	public void setPerformanceLogging(boolean performanceLogging) {
		this.performanceLogging = performanceLogging;
	}
	public boolean isPerformanceLogging() {
		return performanceLogging;
	}
	public String getSiebelLevel1DocCategory() {
		return siebelLevel1DocCategory;
	}
	public void setSiebelLevel1DocCategory(String siebelLevel1DocCategory) {
		this.siebelLevel1DocCategory = siebelLevel1DocCategory;
	}
	public String getSiebelLevel2DocCategory() {
		return siebelLevel2DocCategory;
	}
	public void setSiebelLevel2DocCategory(String siebelLevel2DocCategory) {
		this.siebelLevel2DocCategory = siebelLevel2DocCategory;
	}	
	public String getSiebelLevel3DocCategory() {
		return siebelLevel3DocCategory;
	}
	public void setSiebelLevel3DocCategory(String siebelLevel3DocCategory) {
		this.siebelLevel3DocCategory = siebelLevel3DocCategory;
	}
	public String getLevel1() {
		return level1;
	}
	public void setLevel1(String level1) {
		this.level1 = level1;
	}
	public String getLevel2() {
		return level2;
	}
	public void setLevel2(String level2) {
		this.level2 = level2;
	}	
	public String getLevel3() {
		return level3;
	}
	public void setLevel3(String level3) {
		this.level3 = level3;
	}
	public String getEcmDocTypeLevel1Code() {
		return ecmDocTypeLevel1Code;
	}
	public void setEcmDocTypeLevel1Code(String ecmDocTypeLevel1Code) {
		this.ecmDocTypeLevel1Code = ecmDocTypeLevel1Code;
	}
	public String getEcmDocTypeLevel2Code() {
		return ecmDocTypeLevel2Code;
	}
	public void setEcmDocTypeLevel2Code(String ecmDocTypeLevel2Code) {
		this.ecmDocTypeLevel2Code = ecmDocTypeLevel2Code;
	}	
	public String getEcmDocTypeLevel3Code() {
		return ecmDocTypeLevel3Code;
	}
	public void setEcmDocTypeLevel3Code(String ecmDocTypeLevel3Code) {
		this.ecmDocTypeLevel3Code = ecmDocTypeLevel3Code;
	}
	public Map<String, String> getOrgPrefix() {
		return orgPrefix;
	}
	public void setOrgPrefix(Map<String, String> orgPrefix) {
		this.orgPrefix = orgPrefix;
	}
	public List<String> getLevel2OrgList() {
		return level2OrgList;
	}
	public void setLevel2OrgList(List<String> level2OrgList) {
		this.level2OrgList = level2OrgList;
	}
	public List<String> getLevel1OrgList() {
		return level1OrgList;
	}
	public void setLevel1OrgList(List<String> level1OrgList) {
		this.level1OrgList = level1OrgList;
	}
	public String getAdQICEcmUserName() {
		return adQICEcmUserName;
	}
	public void setAdQICEcmUserName(String adQICEcmUserName) {
		this.adQICEcmUserName = adQICEcmUserName;
	}
	
	//QIC Services
	public long getTotalJVMs() {
		return totalJVMs;
	}
	public void setTotalJVMs(long totalJVMs) {
		this.totalJVMs = totalJVMs;
	}
	public long getThisJVMid() {
		return thisJVMid;
	}
	public void setThisJVMid(long thisJVMid) {
		this.thisJVMid = thisJVMid;
	}
	public long getSiebelWsConnectTimeout() {
		return siebelWsConnectTimeout;
	}
	public void setSiebelWsConnectTimeout(long siebelWsConnectTimeout) {
		this.siebelWsConnectTimeout = siebelWsConnectTimeout;
	}
	public long getSiebelWsRespondTimeout() {
		return siebelWsRespondTimeout;
	}
	public void setSiebelWsRespondTimeout(long siebelWsRespondTimeout) {
		this.siebelWsRespondTimeout = siebelWsRespondTimeout;
	}
	public int getHttpWsConnectTimeout() {
		return httpWsConnectTimeout;
	}
	public void setHttpWsConnectTimeout(int httpWsConnectTimeout) {
		this.httpWsConnectTimeout = httpWsConnectTimeout;
	}
	public int getHttpWsRespondTimeout() {
		return httpWsRespondTimeout;
	}
	public void setHttpWsRespondTimeout(int httpWsRespondTimeout) {
		this.httpWsRespondTimeout = httpWsRespondTimeout;
	}
	public String getQicAppealXsdPath() {
		return qicAppealXsdPath;
	}
	public void setQicAppealXsdPath(String qicAppealXsdPath) {
		this.qicAppealXsdPath = qicAppealXsdPath;
	}
	public String getKeystorePassword() {
		return keystorePassword;
	}
	public void setKeystorePassword(String keystorePassword) {
		this.keystorePassword = keystorePassword;
	}
	public String getKeyAlias() {
		return keyAlias;
	}
	public void setKeyAlias(String keyAlias) {
		this.keyAlias = keyAlias;
	}
	public String getKeystoreName() {
		return keystoreName;
	}
	public void setKeystoreName(String keystoreName) {
		this.keystoreName = keystoreName;
	}
	public String getKeyPassword() {
		return keyPassword;
	}
	public void setKeyPassword(String keyPassword) {
		this.keyPassword = keyPassword;
	}
	public String getValidateDocumentInputXsdPath() {
		return validateDocumentInputXsdPath;
	}
	public void setValidateDocumentInputXsdPath(String validateDocumentInputXsdPath) {
		this.validateDocumentInputXsdPath = validateDocumentInputXsdPath;
	}
	public String getQicTempLocation() {
		return qicTempLocation;
	}
	public void setQicTempLocation(String qicTempLocation) {
		this.qicTempLocation = qicTempLocation;
	}
	public int getStopAfterFailedAppeals() {
		return stopAfterFailedAppeals;
	}
	public void setStopAfterFailedAppeals(int stopAfterFailedAppeals) {
		this.stopAfterFailedAppeals = stopAfterFailedAppeals;
	}
	public int getStopAfterFailedInterfaceCalls() {
		return stopAfterFailedInterfaceCalls;
	}
	public void setStopAfterFailedInterfaceCalls(int stopAfterFailedInterfaceCalls) {
		this.stopAfterFailedInterfaceCalls = stopAfterFailedInterfaceCalls;
	}
	public int getResetFailedInterfaceCallsAfter() {
		return resetFailedInterfaceCallsAfter;
	}
	public void setResetFailedInterfaceCallsAfter(int resetFailedInterfaceCallsAfter) {
		this.resetFailedInterfaceCallsAfter = resetFailedInterfaceCallsAfter;
	}
	public String getQicIncomingEftLocation() {
		return qicIncomingEftLocation;
	}
	public void setQicIncomingEftLocation(String qicIncomingEftLocation) {
		this.qicIncomingEftLocation = qicIncomingEftLocation;
	}
	public long getL2ExpiredDay() {
		return l2ExpiredDay;
	}
	public void setL2ExpiredDay(long expiredDay) {
		l2ExpiredDay = expiredDay;
	}
	public String getRaccfTempLocation() {
		return raccfTempLocation;
	}
	public void setRaccfTempLocation(String raccfTempLocation) {
		this.raccfTempLocation = raccfTempLocation;
	}
	public String getRaccfIncomingEftLocation() {
		return raccfIncomingEftLocation;
	}
	public void setRaccfIncomingEftLocation(String raccfIncomingEftLocation) {
		this.raccfIncomingEftLocation = raccfIncomingEftLocation;
	}
	public String getRacCaseFileprefixName() {
		return racCaseFileprefixName;
	}
	public void setRacCaseFileprefixName(String racCaseFileprefixName) {
		this.racCaseFileprefixName = racCaseFileprefixName;
	}
	public String getRaccfOutEftLocation() {
		return raccfOutEftLocation;
	}
	public void setRaccfOutEftLocation(String raccfOutgoingEftLocation) {
		this.raccfOutEftLocation = raccfOutgoingEftLocation;
	}
	public String getRacWSAddress() {
		return racWSAddress;
	}
	public void setRacWSAddress(String racWSAddress) {
		this.racWSAddress = racWSAddress;
	}
	public String getSiebelRacUsername() {
		return siebelRacUsername;
	}
	public void setSiebelRacUsername(String siebelRacUsername) {
		this.siebelRacUsername = siebelRacUsername;
	}
	
	
}
