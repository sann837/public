package com.cgi.mas.provider;

import java.util.concurrent.Callable;

import org.apache.log4j.Logger;

public class SiebelServiceCallable implements Callable{
	private Logger logger = Logger.getLogger(SiebelServiceCallable.class.getName());
	/*private MASL1AutoAppealWebService port = null;
	private CreateAutoAppeal1Input input = null;
	public SiebelServiceCallable(MASL1AutoAppealWebService port, CreateAutoAppeal1Input input){
		this.port= port;
		this.input = input;
		
	}*/
	
	@Override
	public Object call() throws Exception {
		return null;/*
		logger.debug("**********Invoking Siebel createAppeal");
		if (true){
			return "1-42606601";
		}
		String appealNumber = null; //A1001001A13B24B55741F25026 test
		CreateAutoAppeal1Output output = null;
		try{			
			 output = port.createAutoAppeal1(input);
			 appealNumber = output.getAppealNumber();
			 String errorMessage = output.getErrorMsg();
			 if (StringUtils.hasText(errorMessage)){
				 logger.debug("Error message: "+errorMessage);
			 }
			 String status = output.getStatus();
			 //if (("N").equalsIgnoreCase(string))
			 logger.debug("Appeal number: "+appealNumber);
			 
			 
		}catch(Exception e){
			logger.error(e);
		}
		
		return appealNumber;
		
	*/}

}
