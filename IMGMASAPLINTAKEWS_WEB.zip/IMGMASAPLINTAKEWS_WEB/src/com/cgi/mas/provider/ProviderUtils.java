package com.cgi.mas.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import java.util.Vector;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.cgi.mas.provider.logger.CustomLogger;


public class ProviderUtils {
	private static CustomLogger theLogger = new CustomLogger(ProviderUtils.class);
	private static Logger logger = theLogger.getLogger();
	
	public static boolean validateFileName(String fileName){
		List<Character> inputCharacters = new Vector<Character>();
		for (int i = 0; i < fileName.length(); ++i) {
			inputCharacters.add(new Character(fileName.charAt(i)));
		}
		Set<Character>test = ProviderConstants.INVALID_CHARACTERS;
		for (Character inputCharacter: inputCharacters){
			// if any of the characters do NOT belong to list of acceptable characters
			if (ProviderConstants.INVALID_CHARACTERS.contains(inputCharacter)){
				logger.error("Improper character [" + inputCharacter + "] in [" + fileName + "] field");
				return true;
				
			}
		}
		return false;
	}
	public static String getMD5CheckSum(Object fileObj) {
		InputStream fileInputStream = null;
		String md5 = null;
		try {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			char[] encodedMD5 = null;
			if(fileObj instanceof byte[]) {
				encodedMD5 = Hex.encodeHex(digest.digest((byte[]) fileObj));
			} else {
				File md5File = null;
				if(fileObj instanceof String) {
					md5File = new File((String)fileObj);
				} else if(fileObj instanceof File) {
					md5File = (File)fileObj;
				} else if(fileObj instanceof InputStream) {
					fileInputStream = (InputStream)fileObj;
				}
				
				if(md5File != null)
					fileInputStream = new FileInputStream(md5File);
				
				byte[] buffer = new byte[1024];
				int read = fileInputStream.read(buffer, 0, 1024);
				while (read > -1) {
					digest.update(buffer, 0, read);
					read = fileInputStream.read(buffer, 0, 1024);
				}
				
				encodedMD5 = Hex.encodeHex(digest.digest());
			}
			
			md5 = new String(encodedMD5);
		} catch (FileNotFoundException e) {             
			logger.error("Unable to checkSum when file doesn't exist.", e);
		} catch (OutOfMemoryError e) {
			logger.error("Out of memory Error occurred when trying to get the checksum.",e);			
		} catch (Exception e) {             
			logger.error("Exception occurred when trying to get the checksum.",e);			
		} catch (Error e) {             
			logger.error("Error occurred when trying to get the checksum.",e);			
		} finally{
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
					fileInputStream = null;
				} catch (IOException e) {
					logger.error("IOException occured when trying to close the fileInputStream.",e);
				}
			}
		}
		
		return md5;
	}
	
	public static Calendar convertStringToCalendar(String calendarValue, String dateFormatPattern){
		DateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(dateFormat.parse(calendarValue));
		} catch (ParseException e) {			
			return null;
		}
		return calendar;
	}
	
	public static String getFormattedDate(Object dateObj, String currentDateFormatPattern, String newDateFormatPattern){
		DateFormat dateFormat = new SimpleDateFormat(newDateFormatPattern);
		
		Date date = null;
		if(dateObj != null && dateObj instanceof Date) {
			date = (Date)dateObj;
		} else if(dateObj != null && dateObj instanceof Calendar) {
			date = ((Calendar)dateObj).getTime();
		} else if(dateObj != null && dateObj instanceof String) {
			String dateStr = (String)dateObj;
			try {
//				logger.debug("Get current Date Format "+currentDateFormatPattern);
				date = (new SimpleDateFormat(currentDateFormatPattern)).parse(dateStr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		} else if(dateObj != null && dateObj instanceof Long) {
			date = new Date((Long)dateObj);
			dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		} else {
			Calendar currentCalendar = Calendar.getInstance();
			date = currentCalendar.getTime();
		}
		
		String formattedDate = dateFormat.format(date);
//		logger.debug("Date: "+formattedDate);
		return formattedDate;
	}
	
	/**
	 * Convert Calendar from specific date format into String value
	 * @param calendar calendar
	 * @param dateFormat date format that need to be converted
	 * @return Calendar in String format.  Otherwise, return null.
	 */
	public static String convertCalendarToString(Calendar calendar, String dateFormat){
		if (calendar!=null){			
			DateFormat dateFormatObj = new SimpleDateFormat(dateFormat);
			return dateFormatObj.format(calendar.getTime());	
		} else {
			return null;
		}
	}
	//Create temp location with timestamp ie: c:/mm_dd_yy_hh_MM_SS
	public static String createTempLocationWithTimeStamp(String tempLocation){
		String currentTime = convertCalendarToString(Calendar.getInstance(), ProviderConstants.DT_FORMAT);
		String location= tempLocation+"/"+currentTime+"/";
		try {
			logger.debug(tempLocation+"-->Location: "+location);
			FileUtils.forceMkdir(new File(location));
		} catch (IOException e) {
			logger.error(e);
			
		}
		return location;
		
	}
	public static boolean copyFile(InputStream inputStream, File targetFile) throws IOException{
		long startTime = System.currentTimeMillis();

		if(!targetFile.exists()) {
			targetFile.createNewFile();
		}

		FileChannel source = null;
		FileChannel destination = null;
		try {
			//source = new FileInputStream(inputStream).getChannel();
			destination = new FileOutputStream(targetFile).getChannel();
			destination.transferFrom(source, 0, source.size());
		} finally {
			if(source != null) source.close();
			
			if(destination != null) destination.close();
		}

		theLogger.performanceStartOnly("copyFile", startTime);
		
		return false;
	}
}
