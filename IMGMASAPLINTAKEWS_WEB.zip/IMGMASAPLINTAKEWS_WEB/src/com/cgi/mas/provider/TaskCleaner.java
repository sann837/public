package com.cgi.mas.provider;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.batch.QICAppealLauncher;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.util.Util;

@Service("taskCleaner")
public class TaskCleaner {
	private Logger logger = Logger.getLogger(this.getClass().getName());
	private QICCustomLogger theLogger = new QICCustomLogger(QICAppealLauncher.class); 
	public void cleanTempFolderTask() {
		logger.info("Running Scheduled Cleanup Task!");
		List<File> fileCol = getExpiredFile();
		
		if(fileCol.size() > 0) logger.info("Start to run clean up task");
		
		for (File file : fileCol){
			//String fileName = file.getName();
			if (file.delete())
			{
				logger.debug("File Import: CLEANUP TASK --- File Name: " + file.getName() + " --- DELETED");
			}
			else
			{
				logger.error("File Import: CLEANUP TASK  --- File Name: " + file.getName() + " --- FAILED TO DELETE");
			}
		}
		
		if(fileCol.size() > 0) logger.info("Done Scheduled Cleanup Task!");
	}
	public void removeLockFile() {
		logger.debug("-------Remove the lock file--------");
		File directoryFile = new File(constantConfig.getTempFileLocation());
		Collection<File> fileCol = FileUtils.listFiles(directoryFile, new String[] { ProviderConstants.LOCK_EXTENSION }, false);
		
		//if(fileCol.size() > 0) logger.debug("*****Remove Lock File");
		
		for (File file : fileCol) {
			String path = file.getPath();
			String originialName = path.substring(0,path.indexOf(ProviderConstants.LOCK_EXTENSION)-1);
			File renameFile = new File(originialName);
			if (file.renameTo(renameFile))
			{
				logger.debug("File Import: UNLOCK TASK --- File Name: " + file.getName() + " --- Succesfully renamed to : " + renameFile.getName());
			}
			else
			{
				logger.error("File Import: UNLOCK TASK --- File Name: " + file.getName() + " --- Failed to renam to : " + renameFile.getName());
			}
			//logger.debug(path+" --> rename to : " + originialName + " --> " + isSuccesful);
		}
		
		if(fileCol.size() > 0) logger.debug("*****Done Lock File");
	}
	
	public List<File> getExpiredFile() {
		//long expiredTime = constantConfig.getExpiredDay()* (24 * 60 * 60 * 1000);
		long expiredTime = constantConfig.getExpiredDay();
		logger.debug("Expired Time: " + expiredTime);
		
		List<File> expiredFileCol = new ArrayList<File>();
		File dir = new File(constantConfig.getTempFileLocation());
		
		File[] fileCol = dir.listFiles();
		Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		long start = System.currentTimeMillis();
		long countDownTime = start - expiredTime;
		Calendar countDownCalendar = Calendar.getInstance();
		countDownCalendar.setTimeInMillis(countDownTime);
		
		StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("Before this date:  ");
			strBuilder.append(ProviderUtils.convertCalendarToString(countDownCalendar, ProviderConstants.DT_FORMAT));
			strBuilder.append(" will consider expired");
		logger.debug(strBuilder.toString());
		
		for (File file : fileCol) {
			String fileName = file.getName();
			Matcher mat = pat.matcher(fileName);
			if (mat.find()) {
				String prefixName = fileName.substring(0, 1);
				if (constantConfig.getPrefixTIBCOName().contains(prefixName)) {
					String timeStampVal = mat.group(0);
					timeStampVal = timeStampVal.replaceAll("[A-z]", "");
					Calendar fileCalender = ProviderUtils.convertStringToCalendar(timeStampVal, "yyMMdd.HHmmssS");
					if (fileCalender.before(countDownCalendar)) {
						expiredFileCol.add(file);
					}
				}
			}
		}
		
		return expiredFileCol;
	}
	
	public void cleanL2NotValidFiles()             
	{
		long batchUID = theLogger.generateUID();
		theLogger.debug(batchUID, "Running Scheduled Cleanup Task  to delete  L2 files for  older than " + constantConfig.getL2ExpiredDay() + " milliseconds");
		
		List<File> fileCol = getL2ExpiredFile(batchUID);
		
		if(fileCol.size() > 0) 
		{
			theLogger.debug(batchUID, "About to delete " + fileCol.size() + " failed validation L2 files");
		}
		
		for (File file : fileCol){
			if (file.delete())
			{
				theLogger.debug(batchUID, "File: " + file.getName() + " --- DELETED");
			}
			else
			{
				theLogger.error(batchUID, "File: " + file.getName() + " --- FAILED TO DELETE");
			}
		}
		
		if(fileCol.size() > 0) 
		{
			theLogger.debug(batchUID, "Deleted " + fileCol.size() + " failed validation L2 files");
		}
	}
 
	
	public List<File> getL2ExpiredFile(long batchUID) {
		long expiredTime = constantConfig.getL2ExpiredDay();
		
		List<File> expiredFileCol = new ArrayList<File>();
		File dir = new File(constantConfig.getQicIncomingEftLocation());
		
		long start = System.currentTimeMillis();
		long countDownTime = start - expiredTime;
		Calendar countDownCalendar = Calendar.getInstance();
		countDownCalendar.setTimeInMillis(countDownTime);
		
		Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
		
		StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("Files before ");
			strBuilder.append(Util.convertCalendarToString(countDownCalendar, "MM/dd/yyyy HH:mm:ss"));
			strBuilder.append(" will be deleted");
			theLogger.debug(batchUID, strBuilder.toString());
			
			ArrayList<String> filePrefixList = 	new ArrayList<String>(Arrays.asList(constantConfig.getQicFileprefixName().split(",")));
			
		    AndFileFilter andFileFilter = new AndFileFilter(
												new SuffixFileFilter(ProviderConstants.FAILED_VALIDATION_EXTENSION, IOCase.INSENSITIVE),
												new PrefixFileFilter(filePrefixList));		
		Collection<File>fileCol = FileUtils.listFiles(dir, andFileFilter, null);
			
		
		for (File file : fileCol) {
			String fileName = file.getName();
			Matcher mat = pat.matcher(fileName);
			if (mat.find()) {
				//String prefixName = fileName.substring(0, 1);
				//if (constantConfig.getEftClosePrefix().contains(prefixName)) {
					String timeStampVal = mat.group(0);
					timeStampVal = timeStampVal.replaceAll("[A-z]", "");
					Calendar fileCalender = Util.convertStringToCalendar(timeStampVal, "yyMMdd.HHmmssS");
					if (fileCalender.before(countDownCalendar)) {
						expiredFileCol.add(file);
					}
				//}
			}
		}
		
		return expiredFileCol;
	}

	
	
	
	@Autowired
	private ConstantConfig constantConfig;
}