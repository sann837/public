package com.cgi.mas.provider.exceptions;

public class ECMServiceException extends Exception {

	public ECMServiceException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ECMServiceException(String message) {
		super(message);
		
	}

}
