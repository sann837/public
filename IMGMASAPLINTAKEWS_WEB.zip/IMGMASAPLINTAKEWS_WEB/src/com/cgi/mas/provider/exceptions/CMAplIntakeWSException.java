package com.cgi.mas.provider.exceptions;

public class CMAplIntakeWSException extends Exception {
	
	public CMAplIntakeWSException(String message, Throwable cause) {
		super(message, cause);
	}

	public CMAplIntakeWSException(String message) {
		super(message);
	}
}
