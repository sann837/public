package com.cgi.mas.provider.exceptions;

public class SiebelAuthenticationException extends Exception{

	public SiebelAuthenticationException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public SiebelAuthenticationException(String message) {
		super(message);
		
	}

}
