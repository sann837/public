package com.cgi.mas.provider.exceptions;

public class SiebelServiceException extends Exception{

	public SiebelServiceException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public SiebelServiceException(String message) {
		super(message);
		
	}

	
}
