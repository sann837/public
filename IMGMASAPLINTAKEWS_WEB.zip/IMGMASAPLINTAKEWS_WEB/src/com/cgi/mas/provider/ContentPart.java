package com.cgi.mas.provider;


public enum ContentPart {
	ICMBASE, ICMANNOTATION, ICMNOTELOG, BookMarkPart;
	public String value() {
		return name();
	}

	public static ContentPart fromValue(String v) {
		return valueOf(v);
	}
}
