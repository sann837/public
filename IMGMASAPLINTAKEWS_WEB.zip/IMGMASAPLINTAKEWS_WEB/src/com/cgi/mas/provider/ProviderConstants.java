package com.cgi.mas.provider;

import java.util.Set;
import java.util.TreeSet;

public class ProviderConstants {
	public final static String VERSION="13.9.0.2013.10.23 version 11";
	public final static String WS_HTTP="http";
	//public final static String WSDL_suffix= "eai_enu/start.swe?SWEExtSource=WebService&SWEExtCmd=Execute&UserName=MKAPOOR&Password=MKAPOOR";
	public static final String DT_FORMAT="MM_dd_yyyy_HH_mm_ss_SSS";
	public static final String LOCK_EXTENSION="lock2";
	public static final String NON_RECOVER_EXTENSION="nonrecover";
	
	//public static final String[] INVALID_CHARACTERS= new String[]{"\\","/",":","*","?","<",">","|"};
	public static Set<Character> INVALID_CHARACTERS = new TreeSet<Character>();
	//-----------Siebel Related-----------------------
	public final static String S_USER_NAME="UserName";
	public final static String S_PASSWORD="Password";
	public final static String S_WSDL_NAME="MASL1AppealCreation.WSDL";
	public final static String S_L2_WSDL_NAME="MASL2AutoAppealWS.WSDL";
	public final static String S_RAC_WSDL_NAME="MASTransactionValidationv7.WSDL";
	
	public final static String S_DT_FORMAT="MM/dd/yyyy";	
	
	//------------ECM related--------------
	public final static String ECM_CATEGORY="MAS_DOC_CTGRY_NAME";
	public final static String ECM_RECEIVED_DT="DOC_RCV_DT";
	public final static String ECM_AUDT_CD="DOC_AUDT_CD";
	public final static String ECM_DOCTYPE="DOC_TYPE_CD";
	public final static String ECM_DT_FORMAT="yyyy-MM-dd";
	public final static String ECM_DESCRIPTION="DOC_DESC";
	public final static String ECM_APPEAL_NUM="MDCR_APL_NUM";
	public static final String EMC_APPEAL_FOLDER = "MDCR_APL";
	public static final String ECM_SIEBEL_LVL_1_ID="MAS_LVL_2_ID";
	//QIC Webservice
	public final static int MAX_CONSUMERID_LENGTH=30;
	public final static int MAX_APPEAL_NUMBER_LENGTH=30;
	public final static String FAILED_EXTENSION="failed";
	public final static String FAILED_VALIDATION_EXTENSION="notvalid";
	public final static String ECM_APPEAL_OPENDATE="MDCR_APL_OPEN_DT";
	//RACCF 
	public final static String J_RAC_WSDL_NAME="RACCFRequestMockWebService.wsdl";
	static{
		String specialCharacters = "?:/*\\|\"<>";
		for (int i = 0; i < specialCharacters.length(); i++){
			INVALID_CHARACTERS.add(new Character(specialCharacters.charAt(i)));
		}
	}
}
