package com.cgi.mas.provider.validations;

import java.util.Locale;

import org.apache.cxf.common.util.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cgi.cms.l2services.schema.mas.CreateL2AppealRequest;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.QICCustomLogger;

public class CreateL2AppealValidator implements Validator {
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ConstantConfig constantConfig;
	
	private QICCustomLogger theLogger = new QICCustomLogger(CreateL2AppealValidator.class);
	private Logger logger = theLogger.getQicLogger();

	
	@Override
	public boolean supports(Class<?> arg0) {
		return CreateL2AppealValidator.class.equals(arg0);
	}

	
	public void validate(Object obj,String pk,long transID, Errors errors) {		
		CreateL2AppealRequest request = (CreateL2AppealRequest) obj;
		
		
		//check for empty or null <cert>
		String requestReceivedDate = request.getAppeal().getRequestReceivedDate();
		String requestDescription = request.getAppeal().getRequestDescription();
		String planContract = request.getAppeal().getPlanContractNum();
		String hicn = request.getAppeal().getBeneficiaryIdentifier();
		String jurisdiction = request.getJurisdiction();
		String consumerId = request.getConsumerId();
		boolean consumerIdMatch = validatePk(pk, consumerId, transID);
		
		
		if(consumerId == null || StringUtils.isEmpty(consumerId)){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"Consumer Id"}));
		}
		else{
			if (consumerIdMatch == false)
			{
				
				
				errors.reject(ErrorFieldConstant.BAD_CONSUMERID, 
						getMessage(ErrorFieldConstant.BAD_CONSUMERID, new String[]{"ConsumerId"}));
						
					
			}
		}
		if(jurisdiction == null || StringUtils.isEmpty(jurisdiction)){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"Jurisdiction"}));
		}
		
		if((planContract==null || StringUtils.isEmpty(planContract))){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"Plan Contract Number"}));		
		} 
		
		if((requestReceivedDate==null || StringUtils.isEmpty(requestReceivedDate))){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"Request Received Date"}));		
		} 
		
		if(requestDescription == null || StringUtils.isEmpty(requestDescription)){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"Request Description"}));
		}
				
		if((hicn==null || StringUtils.isEmpty(hicn))){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_L2, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_L2, new String[]{"HICN"}));		
		} 
		
		
	}
	
	
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
	
	private boolean validatePk(String pk, String consumerId, long transactionId) 
	{
		boolean okValues = false;
		
		if (pk != null && pk.length() > 0 )
		{
			if (consumerId != null && consumerId.length() > 0)
			{
				if((consumerId.length() > ProviderConstants.MAX_CONSUMERID_LENGTH))
				{
					theLogger.error(transactionId,"ConsumerId exceeds maximum length: " + consumerId);
				}
				else
				{
					okValues = true;
				}
			}
			else
			{
				theLogger.error(transactionId, "ConsumerId not found in the request");
				
			}
		}
		else
		{
			theLogger.error(transactionId, "Public key  not found in the request");
		}
			
		return okValues;
	}


	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}
}
