package com.cgi.mas.provider.validations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cgi.cms.services.schema.mas.DocumentDetail;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.cms.services.schema.mas.ReceiveAdditionalInfoRequest;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderUtils;

public class RequestAdditionalInfoValidator implements Validator {
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ConstantConfig constantConfig;
	@Autowired
	private DocumentValidator documentValidator;

	@Override
	public boolean supports(Class<?> arg0) {
		return RequestAdditionalInfoValidator.class.equals(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {		
		ReceiveAdditionalInfoRequest request = (ReceiveAdditionalInfoRequest) obj;
		boolean isLevel2User= false;
		boolean isLevel1User=false;
		
		//check for empty or null <cert>
		String certificate = request.getCert();
		if(certificate == null || certificate.isEmpty()){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Certificate"}));
		}
		else {
			if(!constantConfig.getCertList().contains(certificate))
				errors.reject(ErrorFieldConstant.INVALID_CERT_CODE, getMessage(ErrorFieldConstant.INVALID_CERT_CODE, new String[]{request.getOrg().getMac()}));
		} 
		//check for empty or null MAC
		if(request.getOrg()!=null){
			if(constantConfig.getLevel2OrgList().contains(request.getOrg().getMac())){
				isLevel2User= true;
			}
			else if(constantConfig.getLevel1OrgList().contains(request.getOrg().getMac())){
				isLevel1User =true;
			}
		if((request.getOrg().getMac()==null || request.getOrg().getMac().isEmpty())){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org Contractor Name"}));		
		} else if(isLevel2User==false && isLevel1User==false){
			errors.reject(ErrorFieldConstant.INVALID_ORG, getMessage(ErrorFieldConstant.INVALID_ORG, new String[]{request.getOrg().getMac()}));
		}
		//check to make jurisdication required only when its level 1 user or mac is empty or null
		if(isLevel1User==true || ((request.getOrg().getMac()==null || request.getOrg().getMac().isEmpty())) ){
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "org.jurisdiction", ErrorFieldConstant.MISS_PARAMETERS, 
				getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org Jurisdiction"}));}		
		}
		else{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org"}));
		}
		//check for appealNumber 
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "appealNumber", ErrorFieldConstant.MISS_PARAMETERS,getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Appeal Number"}));
		
		
		//validate_docs(obj, errors);
		documentValidator.validateDocDetail(request.getOrg(),request.getDocumentList(), errors);
	}
	
	public void validate_docs(Object obj, Errors errors) {
		
		/*
		ReceiveAdditionalInfoRequest request = (ReceiveAdditionalInfoRequest) obj;		
		DocumentList documentList = request.getDocumentList();
		documentValidator.validateDocDetail(documentList, errors);
		if(documentList!= null) {
			List<DocumentDetail> docList = documentList.getDocument();
			if(!docList.isEmpty()){				
				HashMap<String,String>validMimeTypeMap = constantConfig.getMimeType();
				Collections.sort(docList,new DocumentDetailComparator());
				int index = 0;
				for(DocumentDetail doc : docList) {				
					boolean detectError = false;
					StringBuilder fieldBuilder = new StringBuilder();
					String checkSum = doc.getChecksum();
					String fileId = doc.getFileId();
					String fileName = doc.getFileName();
					String extension= FilenameUtils.getExtension(fileName);
					if(!StringUtils.hasText(checkSum)) {					
						fieldBuilder.append("checksum");
						detectError = true;
					}
					if(!StringUtils.hasText(fileId)) {					
						fieldBuilder.append(detectError==true ? ", fileId" : "fileId" );
						detectError = true;
					} else {
						String prefixName = fileId.substring(0,1).toUpperCase();
						if (!constantConfig.getPrefixTIBCOName().contains(prefixName)){
							errors.reject(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION,getMessage(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION, new String[]{prefixName, fileId}));
							break;
						}
					}
					if(!StringUtils.hasText(fileName)) {					
						fieldBuilder.append(detectError==true ? ", fileName" : "fileName" );
						detectError = true;					
					} else {
						if(ProviderUtils.validateFileName(fileName)){						
							errors.reject(ErrorFieldConstant.INVALID_ORIG_FILE_NAME, getMessage(ErrorFieldConstant.INVALID_ORIG_FILE_NAME, null));
							break;
						}
						if (!validMimeTypeMap.containsKey(extension.toLowerCase())){
							errors.reject(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, getMessage(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, new String[]{extension}));
							break;
						}
					}			
					
					if(detectError) {
						errors.reject(ErrorFieldConstant.MISS_PARAMETERS, getMessage(
								ErrorFieldConstant.MISS_PARAMETERS, new String[]{fieldBuilder.toString()}));
						break;
					}
					
					index++;
					List<DocumentDetail> subList = docList.subList(index, docList.size());
					for (DocumentDetail subDoc : subList){
						if (fileId.equals(subDoc.getFileId())){
							errors.reject(ErrorFieldConstant.DUPLICATE_FILE_ID_EXCEPTION, getMessage(
									ErrorFieldConstant.DUPLICATE_FILE_ID_EXCEPTION, new String[]{doc.getFileId()}));
							break;
						}
					}
				
				}
			
			}else{
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS, getMessage(
						ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Document"}));	

			}
			
		}else{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, getMessage(
					ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Documents"}));
		}
	*/}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
}
