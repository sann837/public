package com.cgi.mas.provider.validations;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;

import com.cgi.cms.services.schema.mas.DocumentDetail;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.cms.services.schema.mas.Org;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderUtils;

public class DocumentValidator {
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ConstantConfig constantConfig;

	public void validateDocDetail(Org org,DocumentList documentList, Errors errors) {
		String jurisdicationOrgValidation = "";
		if(org!=null && org.getJurisdiction()!=null && !org.getJurisdiction().isEmpty()){
			jurisdicationOrgValidation = " - "+ org.getJurisdiction();
		}
		if (documentList != null) {
			List<DocumentDetail> docList = documentList.getDocument();
			if (!docList.isEmpty()) {
				HashMap<String, String> validMimeTypeMap = constantConfig
						.getMimeType();
				Collections.sort(docList, new DocumentDetailComparator());
				int index = 0;
				for (DocumentDetail doc : docList) {
					boolean detectError = false;
					StringBuilder fieldBuilder = new StringBuilder();
					String checkSum = doc.getChecksum();
					String fileId = doc.getFileId();
					String fileName = doc.getFileName();
					String type= doc.getType();
					//Triming for the empty spaces
					if(type!=null && type.matches("^\\s*$")){
						doc.setType(type.trim());
					}
					String extension = FilenameUtils.getExtension(fileName);
					if (!StringUtils.hasText(checkSum)) {
						fieldBuilder.append("checksum");
						detectError = true;
					}
					if (!StringUtils.hasText(fileId)) {
						fieldBuilder.append(detectError == true ? ", fileId"
								: "fileId");
						detectError = true;
					} else {
						String prefixName = fileId.substring(0, 1)
								.toUpperCase();
						if (!constantConfig.getPrefixTIBCOName().contains(
								prefixName)) {
							errors
									.reject(
											ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION,
											getMessage(
													ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION,
													new String[] { prefixName,
															fileId }));
							break;
						}
						else if(org!=null && (constantConfig.getOrgPrefix().get(org.getMac()+jurisdicationOrgValidation)!=null && ((!constantConfig.getOrgPrefix().get(org.getMac()+jurisdicationOrgValidation).contains(prefixName)) || constantConfig.getOrgPrefix().get(org.getMac()+jurisdicationOrgValidation).equalsIgnoreCase("InValid")))){
							errors
							.reject(
									ErrorFieldConstant.INVALID_ORG_PREFIX,
									getMessage(
											ErrorFieldConstant.INVALID_ORG_PREFIX,
											new String[] { prefixName,
													fileId }));
					break;
						}
					}
					if (!StringUtils.hasText(fileName)) {
						fieldBuilder.append(detectError == true ? ", fileName"
								: "fileName");
						detectError = true;
					} else {
						if (ProviderUtils.validateFileName(fileName)) {
							errors
									.reject(
											ErrorFieldConstant.INVALID_ORIG_FILE_NAME,
											getMessage(
													ErrorFieldConstant.INVALID_ORIG_FILE_NAME,
													null));
							break;
						}
						if (!validMimeTypeMap.containsKey(extension
								.toLowerCase())) {
							errors
									.reject(
											ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION,
											getMessage(
													ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION,
													new String[] { extension }));
							break;
						}
					}

					if (detectError) {
						errors
								.reject(
										ErrorFieldConstant.MISS_PARAMETERS,
										getMessage(
												ErrorFieldConstant.MISS_PARAMETERS,
												new String[] { fieldBuilder
														.toString() }));
						break;
					}

					index++;
					List<DocumentDetail> subList = docList.subList(index,
							docList.size());
					for (DocumentDetail subDoc : subList) {
						if (fileId.equals(subDoc.getFileId())) {
							errors
									.reject(
											ErrorFieldConstant.DUPLICATE_FILE_ID_EXCEPTION,
											getMessage(
													ErrorFieldConstant.DUPLICATE_FILE_ID_EXCEPTION,
													new String[] { doc
															.getFileId() }));
							break;
						}
					}

				}

			} else {
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS, getMessage(
						ErrorFieldConstant.MISS_PARAMETERS,
						new String[] { "Document" }));

			}

		} else {
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, getMessage(
					ErrorFieldConstant.MISS_PARAMETERS,
					new String[] { "Documents" }));
		}

	}

	private String getMessage(String fieldId, String[] fieldValues) {
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}

}
