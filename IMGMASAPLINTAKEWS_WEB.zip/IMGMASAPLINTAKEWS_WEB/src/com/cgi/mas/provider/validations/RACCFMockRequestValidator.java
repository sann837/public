package com.cgi.mas.provider.validations;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cgi.cms.services.schema.mas.RACCFMockRequest;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;

public class RACCFMockRequestValidator implements Validator {
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ConstantConfig constantConfig;

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object obj, Errors errors) {

		RACCFMockRequest request  = (RACCFMockRequest)obj;


		if((request.getClaimNumber()  == null || request.getClaimNumber().isEmpty()))
		{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"ClaimNumber"}));
		}
		else
			if((request.getContractNumber() == null || request.getContractNumber().isEmpty()))
			{
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
						getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"ContractID"}));
			}
			else if(String.valueOf(request.getTransactionId()) == null){
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
						getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"TransactionId"}));
			}
			else if(!request.getContractNumber().equals(constantConfig.getClaimContrctNum().get(request.getClaimNumber()))){
			
				errors.reject(ErrorFieldConstant.INVALID_CLAIM,
						getMessage(ErrorFieldConstant.INVALID_CLAIM, new String[]{request.getClaimNumber()}));
				
			}
	}

	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}

} 


