package com.cgi.mas.provider.validations;

import java.util.Comparator;

import com.cgi.cms.services.schema.mas.DocumentDetail;

public class DocumentDetailComparator implements Comparator<DocumentDetail> {
	@Override
	public int compare(DocumentDetail object1, DocumentDetail object2) {
		String fileId1 = object1.getFileId();
		String fileId2 = object2.getFileId();
		if((fileId1 != null)&&(fileId2 != null)) {
			return fileId1.compareTo(fileId2);
		} else return -1;
	}
}
