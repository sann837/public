package com.cgi.mas.provider.validations;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cgi.cms.services.schema.mas.CreateAppealRequest;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;

public class CreateAppealDocValidator implements Validator {
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ConstantConfig constantConfig;
	@Autowired
	private DocumentValidator documentValidator;

	@Override
	public boolean supports(Class<?> arg0) {
		return CreateAppealDocValidator.class.equals(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {		
		CreateAppealRequest request = (CreateAppealRequest) obj;
		boolean isLevel2User= false;
		boolean isLevel1User=false;
		
		//check for empty or null <cert>		
		String certificate = request.getCert();
		if(certificate == null || certificate.isEmpty()){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Certificate"}));
		}
		else if(certificate != null || !certificate.isEmpty()) {
			if(!constantConfig.getCertList().contains(certificate))
				errors.reject(ErrorFieldConstant.INVALID_CERT_CODE, getMessage(ErrorFieldConstant.INVALID_CERT_CODE, new String[]{request.getOrg().getMac()}));
		} 
		if(request.getOrg()!=null){
			if(constantConfig.getLevel2OrgList().contains(request.getOrg().getMac())){
				isLevel2User= true;
			}
			else if(constantConfig.getLevel1OrgList().contains(request.getOrg().getMac())){
				isLevel1User =true;
			}
		//check for empty or null MAC
		if((request.getOrg().getMac()==null || request.getOrg().getMac().isEmpty())){
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org Contractor Name"}));		
		} else if(isLevel2User==false && isLevel1User==false){
			errors.reject(ErrorFieldConstant.INVALID_ORG, getMessage(ErrorFieldConstant.INVALID_ORG, new String[]{request.getOrg().getMac()}));
		}
		
		//check for Level2 cannot create appeals 
		if(request.getOrg().getMac() != null) {
			if(isLevel2User==true){
				errors.reject(ErrorFieldConstant.INVALID_APPEAL_CREATION, getMessage(ErrorFieldConstant.INVALID_APPEAL_CREATION, new String[]{request.getOrg().getMac()}));
			}
		}		
		
		//check to make jurisdication required only when its level 1 user or mac is empty or null
		if(isLevel1User==true || ((request.getOrg().getMac()==null || request.getOrg().getMac().isEmpty())) ){
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "org.jurisdiction", ErrorFieldConstant.MISS_PARAMETERS, 
				getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org Jurisdiction"}));}		
			
		}
		else{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Org"}));
		}
		Calendar requestCalendar = request.getRequestDate();
		if(requestCalendar != null) {
			Date todayDate = Calendar.getInstance().getTime();
			if(requestCalendar.getTime().after(todayDate)) {
				errors.reject(ErrorFieldConstant.FUTURE_DT_EXCEPTION,
						getMessage(ErrorFieldConstant.FUTURE_DT_EXCEPTION, null));
			}
		} else {
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
				getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"Request Date"}));
		}
		
		validate_docs(obj, errors);
	}
	
	public void validate_docs(Object obj, Errors errors) {
		CreateAppealRequest request = (CreateAppealRequest) obj;
		
		DocumentList documentList = request.getDocumentList();
		if(documentList!= null && request.getOrg()!=null) {
			documentValidator.validateDocDetail(request.getOrg(),documentList, errors);
			
}
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
}
