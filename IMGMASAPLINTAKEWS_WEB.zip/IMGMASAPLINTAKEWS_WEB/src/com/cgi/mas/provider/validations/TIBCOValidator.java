package com.cgi.mas.provider.validations;

import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.Resource;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;

public class TIBCOValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return true;		
	}

	@Override
	public void validate(Object target, Errors errors) {
		if (target instanceof Resource){
			logger.debug("Check file TIBCO format 1");
			Resource resource = (Resource)target;
			String fileName = resource.getFilename();	
			logger.debug("FileName: "+fileName+"-->"+resource.toString());
			Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
			Matcher mat = pat.matcher(fileName);
			String errorMessage = null;
			
			if (mat.find()) {
				//Check to see if we support those extension
				//filename = test.pdf.lock
				String lockExtension = FilenameUtils.getExtension(fileName);				
				String baseName = FilenameUtils.getBaseName(fileName); //test.pdf
				String extension = null;
				
				if(lockExtension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)) {
					extension = FilenameUtils.getExtension(baseName);
				} else {
					extension = lockExtension;
				}
				
				HashMap<String,String>validMimeTypeMap = constantConfig.getMimeType();
				if (!validMimeTypeMap.containsKey(extension.toLowerCase())){					
					errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, new String[]{extension});
					errors.reject(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, errorMessage);
				}
				//check if they have correct prefix for webservice. It should start with predefine letter: E, F, or G
				String prefixName = fileName.substring(0,1).toUpperCase();
				if (!constantConfig.getPrefixTIBCOName().contains(prefixName)){				
					errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION, new String[]{prefixName, fileName});
					errors.reject(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION,errorMessage);
				}
			} else {
				errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_TIBCO_FORMAT_EXCEPTION, new String[]{fileName});
				errors.reject(ErrorFieldConstant.INVALID_TIBCO_FORMAT_EXCEPTION, errorMessage);
			}
		} else {
			errors.reject(ErrorFieldConstant.MISMATCH_RESOURCE_EXCEPTION,
				messageSource.getMessage(ErrorFieldConstant.MISMATCH_RESOURCE_EXCEPTION, null, Locale.US));
		}
	}
	
	public void validategood(Object target, Errors errors) {
		if(target instanceof Resource) {
			logger.debug("Check file TIBCO format");
			Resource resource = (Resource)target;
			String fileName = resource.getFilename();	
			logger.debug("FileName: "+fileName+"-->"+resource.toString());
			Pattern pat = Pattern.compile(constantConfig.getTibcoTimeStampRegEx());
			Matcher mat = pat.matcher(fileName);
			String errorMessage = null;
			if(mat.find()) {
				//Check to see if we support those extension
				String extension = FilenameUtils.getExtension(fileName);
				HashMap<String,String>validMimeTypeMap = constantConfig.getMimeType();
				if (!validMimeTypeMap.containsKey(extension.toLowerCase())){					
					errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, new String[]{extension});
					errors.reject(ErrorFieldConstant.INVALID_EXTENSION_EXCEPTION, errorMessage);
				}
				//check if they have correct prefix for webservice. It should start with predefine letter: B,C,D
				String prefixName = fileName.substring(0,1).toUpperCase();
				if(!constantConfig.getPrefixTIBCOName().contains(prefixName)) {				
					errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION, new String[]{prefixName, fileName});
					errors.reject(ErrorFieldConstant.INVALID_PREFIX_TIBCO_EXCEPTION,errorMessage);
				}
				
				
			} else {
				errorMessage = getErrroMessage(ErrorFieldConstant.INVALID_TIBCO_FORMAT_EXCEPTION, new String[]{fileName});
				errors.reject(ErrorFieldConstant.INVALID_TIBCO_FORMAT_EXCEPTION, errorMessage);
			}
		} else {
			errors.reject(ErrorFieldConstant.MISMATCH_RESOURCE_EXCEPTION,
				messageSource.getMessage(ErrorFieldConstant.MISMATCH_RESOURCE_EXCEPTION, null, Locale.US));
		}
	}
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ConstantConfig constantConfig;
	private Logger logger = Logger.getLogger(TIBCOValidator.class);
	private String getErrroMessage(String errorCode, String[]errorValue){
		String message = messageSource.getMessage(errorCode, errorValue, Locale.US);
		logger.error(message);
		return message;
	}

}
