package com.cgi.mas.provider.validations;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cgi.cms.l2services.schema.mas.TestAppealRequest;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;

public class TestAppealValidator implements Validator {
	@Autowired
	private MessageSource messageSource;

	
	@Override
	public boolean supports(Class<?> arg0) {
		return TestAppealValidator.class.equals(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		TestAppealRequest request = (TestAppealRequest) obj;
			
		if((request.getAppealNumber()  == null || request.getAppealNumber().isEmpty()))
		{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS, new String[]{"AppealNumber"}));
		}
		else
			if((request.getAppealNumber().length() > ProviderConstants.MAX_APPEAL_NUMBER_LENGTH))
			{
				errors.reject(ErrorFieldConstant.BAD_PARAMETERS, 
							getMessage(ErrorFieldConstant.BAD_PARAMETERS, new String[]{"AppealNumber"}));
			}
		 
		
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
	
}
