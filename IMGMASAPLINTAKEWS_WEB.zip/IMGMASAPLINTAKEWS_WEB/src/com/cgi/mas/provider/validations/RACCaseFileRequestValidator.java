package com.cgi.mas.provider.validations;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cgi.cms.services.schema.mas.RACCaseFileRequest;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.logger.RACCFCustomLogger;
import com.cgi.mas.provider.services.RACCaseFileServiceProvider;

public class RACCaseFileRequestValidator implements Validator {

	private RACCFCustomLogger theLogger = new RACCFCustomLogger(
			RACCaseFileServiceProvider.class);
	private Logger logger = theLogger.getRacCFLogger();
	
	@Autowired
	private MessageSource messageSource;
	
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public void validate(Object obj, long trannsactionId,Errors errors) {
		
		RACCaseFileRequest request  = (RACCaseFileRequest)obj;


		if((request.getClaimNumber()  == null || request.getClaimNumber().isEmpty()))
		{
			errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
					getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"ClaimNumber"}));
		}
		else
			if((request.getContractNumber() == null || request.getContractNumber().isEmpty()))
			{
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
						getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"ContractID"}));
			}
			else if(request.getAppealNumber() == null || request.getAppealNumber().isEmpty()){
			
				errors.reject(ErrorFieldConstant.MISS_PARAMETERS_RAC, 
						getMessage(ErrorFieldConstant.MISS_PARAMETERS_RAC, new String[]{"AppealNumber"}));
				
			}
	}

	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}

		
	
	
	@Override
	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		
	}

}
