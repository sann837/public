package com.cgi.mas.provider.services.dto;

public class RACValidDocDto {

	private String fileName;
	private String checkSum;
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}
	
	
	
	
}
