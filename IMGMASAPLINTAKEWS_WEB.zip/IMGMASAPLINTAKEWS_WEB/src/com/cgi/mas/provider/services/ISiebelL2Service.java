package com.cgi.mas.provider.services;

import com.cgi.cms.l2services.schema.mas.CreateL2AppealResponse;
import com.cgi.mas.provider.services.dto.QicAppeal;
import com.cgi.mas.provider.services.dto.UserDto;
import com.siebel.masl2autoappeal.CreateL2AutoAppealInput;
import com.siebel.masl2autoappeal.GetL2AppealDocumentsOutput;
import com.siebel.masl2autoappeal.L2UserAuthenticationInput;
import com.siebel.masl2autoappeal.L2UserAuthenticationOutput;
import com.siebel.masl2autoappeal.ValidateDocumentsInput;
import com.siebel.xml.masassociatedocsio.ListOfMasBcAssociateDocuments;

public interface ISiebelL2Service {

	L2UserAuthenticationOutput getUserL2Account(
			L2UserAuthenticationInput siebelRequest);

	CreateL2AppealResponse createL2Appeal(CreateL2AutoAppealInput input,
			long transactionId, UserDto userAccount);

	QicAppeal validateDocs(ValidateDocumentsInput input, long transactionId);

	String updateTransactionStatus(long transactionId, String transStatus,
			String errCode, String errMsg, String extAppealNum, String uniqueId);

	int associateDocuments(long transactionId, String appealNumber,
			ListOfMasBcAssociateDocuments ecmDocs);

	GetL2AppealDocumentsOutput testAppeal(String appealNumber, long transUID,
			String consumerId, String pk);
}
