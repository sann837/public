package com.cgi.mas.provider.services;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ContentPart;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.exceptions.ECMServiceException;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.logger.RACCFCustomLogger;
import com.cgi.mas.provider.services.IECMConnectionService;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ECMDocumentDto;
import com.cgi.mas.provider.services.dto.ECMDocumentL1L2Dto;
import com.cgi.mas.provider.services.dto.ReceivedFileDto;
import com.cgi.mas.provider.util.Util;
import com.ibm.mm.beans.CMBAttribute;
import com.ibm.mm.beans.CMBBaseConstant;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBDataManagement;
import com.ibm.mm.beans.CMBDocumentServices;
import com.ibm.mm.beans.CMBEntity;
import com.ibm.mm.beans.CMBException;
import com.ibm.mm.beans.CMBItem;
import com.ibm.mm.beans.CMBItemNotExistException;
import com.ibm.mm.beans.CMBItemNotSetException;
import com.ibm.mm.beans.CMBNoConnectionException;
import com.ibm.mm.beans.CMBObject;
import com.ibm.mm.beans.CMBQueryService;
import com.ibm.mm.beans.CMBSearchResults;
import com.ibm.mm.sdk.server.DKDatastoreICM;
import com.ibm.mm.viewer.CMBDocument;
import com.ibm.mm.viewer.CMBStreamingDocServices;

@Service
public class ECMService implements IECMService {
	private Logger logger = Logger.getLogger(ECMService.class);
	private QICCustomLogger theLogger = new QICCustomLogger(this.getClass());
	private RACCFCustomLogger racLogger = new RACCFCustomLogger(this.getClass());
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private ConstantConfig constantConfig;
	
	@Autowired
	private IECMConnectionService ecmConnectionService;
	
         
	@Override
	public boolean appealFolderExists(String ecmUsername, String ecmPassword, String appealNumber)
	{
		boolean appealExists = false;
		CMBConnection ibmSession = null;
		
		try
		{
			ibmSession = getConnection(ecmUsername, ecmPassword);
		
			if (ibmSession != null)
			{	
				CMBItem appealFolder = getAppeal(ibmSession, appealNumber);
				
				if (appealFolder != null)
				{
					appealExists = true;
				}
			}
		}
		catch (Exception ex)
		{
			logger.error("IException while getting the appeal folder ", ex);
		}
		finally
		{
			if (ibmSession != null)
			{
				ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
			}
		}
		
		return appealExists;
	}
	
	@Override
	public String getItemByDescription(String ecmUsername, String ecmPassword, String appealNumber, String desc) {

		CMBConnection ibmSession = null;
		String foundItem = null;
		
		logger.debug("EcmService - getItemByDescription for Appeal Number: "+appealNumber);
		
		try {
			ibmSession = getConnection(ecmUsername, ecmPassword);
			
			if (ibmSession != null)
			{
				StringBuilder queryBuilder = new StringBuilder();
				queryBuilder.append("/'");
				queryBuilder.append(constantConfig.getLevel1ItemType());
				queryBuilder.append("'");
				queryBuilder.append("[./" + ProviderConstants.ECM_APPEAL_NUM + "_LVL_2/@");
				queryBuilder.append(ProviderConstants.ECM_APPEAL_NUM);
				queryBuilder.append("=\"");
				queryBuilder.append(appealNumber);
				queryBuilder.append("\" AND @");
				queryBuilder.append(ProviderConstants.ECM_DESCRIPTION);
				queryBuilder.append(" LIKE \"%");
				queryBuilder.append(desc);
				queryBuilder.append("%\"");
				queryBuilder.append("]");
				logger.debug("EcmService - getItemByDescription Query Search: " + queryBuilder.toString());
				CMBItem[] resultItems = runQuery(ibmSession, queryBuilder.toString());
				logger.debug("EcmService - getItemByDescription Number of document(s) Found: " + resultItems.length);
	
				//It should only have 1 item
				if(resultItems != null  ) 
				{
					if (resultItems.length == 1) 
					{
						for(CMBItem theDocItem : resultItems) 
						{					
							foundItem = theDocItem.getDDO().getPidObject().getPrimaryId();
						}
					} else if (resultItems.length <= 0) 
					{
						logger.error("EcmService - getItemByDescription - No items could be found.");
					}	
					else
					{
						logger.error("EcmService - getItemByDescription - There are more than 1 documents that match the criteria. This usually indicates something went wrong!");
					}
				}
				else
				{
					logger.error("EcmService - getItemByDescription - No items could be found.");
				}
			}
		} catch(Error e) {
			logger.error("EcmService - getItemByDescription - Unable to find document: " + desc + " within appeal: "+appealNumber, e);
			return null;
		} catch(Exception e) {
			logger.error("EcmService - getItemByDescription - Unable to find document: " + desc + " within appeal: "+appealNumber, e);
			return null;
		}
		finally
		{
			if (ibmSession != null)
			{
				ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
			}
		}
		
		return foundItem;
	}
	
	@Override
	public String searchItemById(String ecmUsername, String ecmPassword, String docId) {
		
		CMBItem[] resultItems = null;
		CMBConnection ibmSession = null;
		String foundItem = null;
		
		logger.debug("EcmService - searchItemById for Doc ID: "+docId);
		
		try 
		{
			ibmSession = getConnection(ecmUsername, ecmPassword);
			
			if (ibmSession != null)
			{
				logger.debug("EcmService - searchItemById  : "+((DKDatastoreICM)ibmSession.getDatastore()).getLSSessionId());
				String queryString = "/'*'[ @ITEMID = \"" + docId + "\"]";
				logger.debug("Query Search: " + queryString);
				resultItems = runQuery(ibmSession, queryString);
				
				if (resultItems == null || resultItems.length != 1)
				{
					logger.debug("EcmService - searchItemById - Prepare to go to sleep and run the query again");
					Thread.sleep(200);
					resultItems = runQuery(ibmSession, queryString);
				}
				
				//It should only have 1 item
				if (resultItems != null)
				{
					if (resultItems.length == 1)
					{
						//return resultItems[0];
						foundItem = resultItems[0].getDDO().getPidObject().getPrimaryId();
					} else if (resultItems.length > 1){
						logger.error("EcmService - searchItemById - Found multiple items based on the id: "+docId);
					}
					else
					{
						logger.error("EcmService - searchItemById - Could not find any items based on the id: "+docId);
					}
				}
				else
				{
					logger.error("EcmService - searchItemById - Could not find any items based on the id: "+docId);
				}
				
			}
			
		} catch(Error e) {
			logger.error("EcmService - searchItemById error", e);
			return null;
		} catch(Exception e) {
			logger.error("EcmService - searchItemById exception", e);
			return null;
		}
		finally
		{
			if (ibmSession != null)
			{
				ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
			}
		}
		

		return foundItem;
	}
	
	@Override
	public List<DocumentResultDto> importDocumentIntoAppeal(
			String ecmUsername, String ecmPassword, String appealNumber,
			List<ECMDocumentDto> documentList) throws ECMServiceException {
		
		logger.debug("EcmService - importDocumentIntoAppeal for appealNumber " + appealNumber);
		
		List<DocumentResultDto> docResultList = new ArrayList<DocumentResultDto>();	
		
		//CMBConnection ibmSession = null;
		
		//try 
		//{
		CMBConnection ibmSession = getConnection(ecmUsername, ecmPassword);
			
		if (ibmSession != null)
		{
				CMBItem appealFolder = getAppeal(ibmSession, appealNumber);
				
				if (appealFolder != null) 
				{
					int index = 1;
					for (ECMDocumentDto dto : documentList) 
					{
						InputStream fileContentStream = null;
						boolean isSuccess = false;	
						
						try {
							fileContentStream = dto.getContentInputStream();
							
							ibmSession.startTransaction();
							DocumentResultDto importDoc = new DocumentResultDto();
							CMBItem correspondDoc = createDocumentItem(ibmSession, dto, fileContentStream);
							
							if (correspondDoc != null) {
								appealFolder.addFolderItem(correspondDoc);
								importDoc.setPageCount(getPageCount(dto));
								importDoc.setEcmItemId(correspondDoc.getDDO().getPidObject().getPrimaryId());
								importDoc.setSizeInKB(dto.getFileSize()/FileUtils.ONE_KB);
								importDoc.setFileName(dto.getFileName());	
								String siebelId = dto.getAttributeMap().get(ProviderConstants.ECM_SIEBEL_LVL_1_ID);
								importDoc.setSiebeldocId(siebelId);
								logger.debug("Newly import Doc Id: "+ importDoc.getEcmItemId() +" --> siebelId: "+ siebelId);
								docResultList.add(importDoc);
							} else {
								logger.error(index + " EcmService - importDocumentIntoAppeal: Unable to create document in ecm");						
							}
							
							index++;
							isSuccess = true;					
						} catch (Error e) {
							logger.error("", e);
						} catch (Exception e) {
							logger.error("", e);
						} finally {
							if(fileContentStream!= null){
								try {
									fileContentStream.close();
								} catch(IOException e) {							
									logger.error("EcmService - importDocumentIntoAppeal: Unable to close the stream " + dto.getFileName(), e);
								}
							}
							try {
								if(isSuccess) {							
									ibmSession.commit();
								} else {
									ibmSession.rollback();
								}
							} catch(Exception e) {
								try {
									ibmSession.rollback();
								} catch (CMBException e1) {
									logger.error("EcmService - importDocumentIntoAppeal: rollback failed", e);
								}
								logger.error("EcmService - importDocumentIntoAppeal: commit failed", e);
							}
						}
						
					} // end for loop
					
					ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
					
				} else {
					
					logger.error("EcmService - importDocumentIntoAppeal: Could not find appeal folder for appealNumber " + appealNumber);
					
					ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
					
					throw new ECMServiceException(messageSource.getMessage(
							"ecm.invalid.appeal", new String[] { appealNumber }, Locale.US));
				}
 
		}
		
		return docResultList;
	}
	
	
	@Override
	public String getPageCount(ECMDocumentDto docDto) {

		int numberOfParts = 1;
		CMBDocument doc = null;
		CMBStreamingDocServices cmbStreamingDocServices = null;
		String pageCount = "N/A";
		try {
			String docMimeType = docDto.getMimeType();
			boolean isTiffOrPdf = (docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("pdf"))
					|| docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("tiff")) 
					|| docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("tif")));

			if (isTiffOrPdf) {
				InputStream contentByteArray = docDto.getContentInputStream();
				CMBDocumentServices cmbDocumentServices = new CMBDocumentServices();
				Properties engineProperty = new Properties();
				engineProperty.setProperty("ENGINE1_CLASSNAME",
						"com.ibm.mm.viewer.CMBSnowboundEngine");
				engineProperty.setProperty("ENGINE1_DELAYINIT", "true");
				engineProperty.setProperty("ENGINES", "1");
				cmbDocumentServices.setEngineProperties(engineProperty);
				cmbStreamingDocServices = cmbDocumentServices.getStreamingDocServices();
				doc = cmbStreamingDocServices.loadDocument(contentByteArray,
						numberOfParts, docMimeType, docMimeType, null, null);

				if (doc.getCanPaginate()) {
					logger.debug("Number of Page: " + doc.getPageCount());
					return String.valueOf(doc.getPageCount());

				}
			}
		} catch(Error ex) {
			logger.error("Unable to get page count of a document. " + ex.getMessage(), ex);
		} catch(Exception ex) {
			logger.error("Unable to get page count of a document. " + ex.getMessage(), ex);
		} finally {
			if (cmbStreamingDocServices != null) {
				cmbStreamingDocServices.dropDocument(doc);
			}
		}
		
		return pageCount;
	}
	
	@Override
	public List<DocumentResultDto> importFilesToAppeal(String ecmUsername, String ecmPassword, String appealNumber, String appealOpenDate,  String orgName, String appealDirectory, List<ReceivedFileDto> receivedFiles, long transactionId,String level)
	{
		if(level== constantConfig.getLevel1()){
			theLogger = racLogger;
		}
		
		if (receivedFiles == null || receivedFiles.size() <= 0)
		{
			theLogger.error(transactionId, "The list of received files is empty or null.");
			return null;
		}
		
		theLogger.debug(transactionId, "Starting to import documents into ECM for appeal number: " + appealNumber);

		
		String ecmServerName = constantConfig.getEcmServerName();
		String ecmServerType = constantConfig.getEcmServerType();
		
		CMBConnection ibmSession = ecmConnectionService.getIBMConnectionFromPool(ecmUsername, ecmPassword, ecmServerName, ecmServerType, transactionId);	
		if (ibmSession == null)
		{
			
			theLogger.error(transactionId, "Failed to obtain CMBConnection from pool");
			return null;
		}
		
		
		List<DocumentResultDto> resultList = null;
		
		try {			
			// Create or obtain the appeal folder
			CMBItem appealFolder = createAppealFolder(ibmSession, appealNumber, appealOpenDate, transactionId);
			if (appealFolder == null)
			{
				appealFolder = getAppeal(ibmSession, appealNumber, transactionId);
				if (appealFolder == null)
				{
					//logger.error("Could not create appeal folder, and no existing appeal folder was found");
					
					ecmConnectionService.releaseIBMConnectionToPool(ibmSession, transactionId);
					ibmSession = null;
					
					return resultList;	
				}
			}
			
			resultList = new ArrayList<DocumentResultDto>();
			
			for (int idx = 0; idx < receivedFiles.size(); idx++)
			{
				ReceivedFileDto receivedFile = receivedFiles.get(idx);
				
				if (receivedFile != null)
				{
					String fileExtension = FilenameUtils.getExtension(receivedFile.getFileName());	

					ECMDocumentL1L2Dto ecmDoc = new ECMDocumentL1L2Dto();		
					ecmDoc.setAppealNumber(appealNumber);
					ecmDoc.setEntityName(constantConfig.getLevel1ItemType());
					ecmDoc.setFileExtension(fileExtension);
					ecmDoc.setMimeType(getMimeType(fileExtension));
					ecmDoc.setFileName(receivedFile.getFileName());
					ecmDoc.setFileFolder(appealDirectory);			
					ecmDoc.setFileSize(receivedFile.getFileSize());
					ecmDoc.setCheckSum(receivedFile.getCheckSum());				
					//ecmDoc.setSiebelId(receivedFile.getSiebelId());
					
					String fileID = receivedFile.getFileName() + "-" + receivedFile.getCheckSum();
					
					ecmDoc.setAttributeMap(setupECMDocumentAttributeMap(appealNumber,
							null,
							orgName,
							fileID,
							receivedFile.getCheckSum(),
							level));							

								
					
					CMBItem[] items = getItemByDescription(ibmSession,  appealNumber, fileID, transactionId);
					if (items == null || items.length < 1) 
					{
						DocumentResultDto ecmDocResult  = importDocumentIntoAppeal(ibmSession, appealFolder, appealNumber, ecmDoc, transactionId);	
						if (ecmDocResult != null )
						{
							 // OK -> add as ok to result
							resultList.add(ecmDocResult);
						}
						else
						{
							// FAILED -> add as failed to result
							
							ecmDocResult = new DocumentResultDto();
							
							ecmDocResult.setSiebeldocId(ecmDoc.getSiebelId());
							ecmDocResult.setPageCount(getPageCount(ecmDoc, transactionId));
							ecmDocResult.setSizeInKB(ecmDoc.getFileSize()/FileUtils.ONE_KB);
							ecmDocResult.setFileName(ecmDoc.getFileName());
							ecmDocResult.setStatus(-10); // failed
							ecmDocResult.setCheckSum(ecmDoc.getCheckSum());	
							resultList.add(ecmDocResult);
							
						}
					}
					else if (items.length == 1)
					{
						// one document already in ECM ?? maybe from a prior import that did not finish ??
						
						theLogger.debug(transactionId, "Found one document for file: " + ecmDoc.getFileName() + " already imported ECM for appeal number: " + appealNumber);
								
						DocumentResultDto ecmDocResult = new DocumentResultDto();
							
						ecmDocResult.setSiebeldocId(ecmDoc.getSiebelId());
						ecmDocResult.setPageCount(getPageCount(ecmDoc, transactionId));
						ecmDocResult.setSizeInKB(ecmDoc.getFileSize()/FileUtils.ONE_KB);
						ecmDocResult.setFileName(ecmDoc.getFileName());
						ecmDocResult.setStatus(1); // allredy in ECM
						ecmDocResult.setCheckSum(ecmDoc.getCheckSum());	
						resultList.add(ecmDocResult);
					}
					else if (items.length >  1)
					{
						// multiple documents already in ECM ?? how ??
						
						theLogger.debug(transactionId, "Found multiple documents for file : " + ecmDoc.getFileName() + " already imported ECM for appeal number: " + appealNumber);
						
						DocumentResultDto ecmDocResult = new DocumentResultDto();
						
						ecmDocResult.setSiebeldocId(ecmDoc.getSiebelId());
						ecmDocResult.setPageCount(getPageCount(ecmDoc, transactionId));
						ecmDocResult.setSizeInKB(ecmDoc.getFileSize()/FileUtils.ONE_KB);
						ecmDocResult.setFileName(ecmDoc.getFileName());
						ecmDocResult.setStatus(1); // allredy in ECM
						ecmDocResult.setCheckSum(ecmDoc.getCheckSum());		
						resultList.add(ecmDocResult);
					}
				}
				else
				{
					theLogger.error(transactionId, "Received file in the list was found empty or null.");
					break;
				}
			}
		} catch (Error e) {
			theLogger.error(transactionId, "Error while importing document to ECM: ", e);	

		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while importing document to ECM: ", e);	
		}
		finally {
			if (ibmSession != null)
			{
				ecmConnectionService.releaseIBMConnectionToPool(ibmSession, transactionId);
			}
		}
		
		return resultList;
	}
	
	private CMBItem getAppeal(CMBConnection ibmSession, String appealNumber, long transactionId) throws Exception 
	{
		theLogger.debug(transactionId, "Retrieving ECM appeal folder for appeal number: " + appealNumber);
		
		try {
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("/");
			queryBuilder.append(ProviderConstants.EMC_APPEAL_FOLDER);
			queryBuilder.append("[@");
			queryBuilder.append(ProviderConstants.ECM_APPEAL_NUM);
			queryBuilder.append("=\"");
			queryBuilder.append(appealNumber);
			queryBuilder.append("\"]");
			CMBItem[] resultItems = runQuery(ibmSession, queryBuilder.toString(), transactionId);

			// It should only have 1 item
			if (resultItems.length == 1) {
				return resultItems[0];
			} else if (resultItems.length <= 0) {
				theLogger.error(transactionId, "No ECM appeal folders have been found for the appeal number: : " + appealNumber);
				return null;
			} else {
				theLogger.error(transactionId, "Multiple ECM appeal folders found for the same appeal number: : " + appealNumber);
				throw new Exception("Multiple ECM appeal folders found for the same appeal number: " + appealNumber);
			}

		} catch (Error e) {
			theLogger.error(transactionId, "Error while retrieving ECM appeal folder for appeal number: " + appealNumber, e);
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while retrieving ECM appeal folder for appeal number: " + appealNumber, e);
		}
		return null;

	}
	
	private CMBItem createAppealFolder(CMBConnection ibmSession, String appealNumber, String appealOpenDate, long transactionId) throws Exception 
	{
		try 
		{
			theLogger.debug(transactionId, "Appeal folder is already in ECM for appeal number: " + appealNumber);
			CMBItem appealFolder = searchItemByAppealNumber(ibmSession, appealNumber, transactionId);
			
			if(appealFolder == null) 
			{
				HashMap<String, String> caseAttrMap = new HashMap<String, String>();
				caseAttrMap.put(ProviderConstants.ECM_APPEAL_NUM, appealNumber);
				caseAttrMap.put(ProviderConstants.ECM_APPEAL_OPENDATE, appealOpenDate);	
				
				appealFolder =  createFolderItem(ibmSession, ProviderConstants.EMC_APPEAL_FOLDER, caseAttrMap, transactionId);	
			} 
			else 
			{
				theLogger.debug(transactionId, "Appeal folder is already in ECM for appeal number: " + appealNumber);
			}
			
			return appealFolder;
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while searching for appeal number: " + appealNumber, e);
			throw new Exception(e);
		}
	}
	
	private CMBItem searchItemByAppealNumber(CMBConnection ibmSession, String appealNumber, long transactionId) throws Exception{
		try {
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("/");
			queryBuilder.append(ProviderConstants.EMC_APPEAL_FOLDER);
			queryBuilder.append("[@");
			queryBuilder.append(ProviderConstants.ECM_APPEAL_NUM);
			queryBuilder.append("=\"");
			queryBuilder.append(appealNumber);
			queryBuilder.append("\"]");
			
			CMBItem[] resultList = runQuery(ibmSession, queryBuilder.toString(), 1, "searchItemByAppealNumber", transactionId);
			
			//logger.debug("Total Count: "+resultList.length);
			
			if(resultList.length == 0) {
				return null;
			} else if (resultList.length > 1) {
				theLogger.error(transactionId, "Multiple appeal folder exists in ECM for appeal number: " + appealNumber);
				throw new Exception("Multiple appeal folders exists in ECM for the appeal number: " + appealNumber);
			} else return resultList[0];
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while searching for appeal number: " + appealNumber, e);
			throw new Exception(e);
		}
	}
	
	public CMBItem createFolderItem(CMBConnection ibmSession, String entityName, HashMap<String, String> attrMap, long transactionId ) throws  Exception 
	{
		try 
		{
			theLogger.debug(transactionId, "Creating ECM folder for entity: " + entityName);
				
			CMBDataManagement dataManagement = ibmSession.getDataManagement();
			// Construct a CMBItem object to represent the new item
			CMBItem item = new CMBItem();
			item.setConnection(dataManagement.getConnection());
			item.setServerType(ibmSession.getDsType());
			item.setServerName(ibmSession.getServerName());
			item.setEntityName(entityName);
			item.setItemType(CMBBaseConstant.CMB_TYPE_FOLDER);

			// Set the attributes from the string arrays.
			CMBEntity entity = ibmSession.getSchemaManagement().getEntity(entityName);

			for (String attrName : attrMap.keySet()) 
			{
				//theLogger.debug(transactionId, "Attribute Name: " + attrName + "-->" + attrMap.get(attrName));
				CMBAttribute attrObj = entity.getAttribute(attrName);

				if (attrObj != null)
					item.addAttr(attrName, attrMap.get(attrName), attrObj.getType());
				else
					throw new Exception(attrName + " is invalid for item type: " + entityName);
			}

			dataManagement.setDataObject(item);
			dataManagement.createItem(entityName);

			return item;
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while creating ECM folder for entity: " + entityName, e);
			throw new Exception(e.getMessage(), e.fillInStackTrace());
		}
	}
	
	
	
	private DocumentResultDto importDocumentIntoAppeal(
			CMBConnection ibmSession, CMBItem appealFolder, String appealNumber,
			ECMDocumentL1L2Dto dto, long transactionId) throws Exception 
	{
		DocumentResultDto importDoc = new DocumentResultDto();
		importDoc.setSiebeldocId(dto.getSiebelId());
		importDoc.setPageCount(getPageCount(dto, transactionId));
		importDoc.setSizeInKB(dto.getFileSize()/FileUtils.ONE_KB);
		importDoc.setFileName(dto.getFileName());
		importDoc.setCheckSum(dto.getCheckSum());
		
		importDoc.setStatus(-1); // import not attempted
		
		theLogger.debug(transactionId, "Importing document: " + dto.getFileName() + " into ECM for appeal number: " + appealNumber);
 
		String fullFilePath = dto.getFileFolder() + "/" + dto.getFileName();
 	
		InputStream fileContentStream = null;		
		boolean isSuccess = false;		
		 
		 
		try {
			
			 fileContentStream = new FileInputStream(fullFilePath);
			
			 if (fileContentStream != null)
			 {
				ibmSession.startTransaction();
				
				CMBItem correspondDoc = createDocumentItem(ibmSession, dto, fileContentStream, transactionId);
						
				if (correspondDoc != null) 
				{
					appealFolder.addFolderItem(correspondDoc);
					
					importDoc.setEcmItemId(correspondDoc.getDDO().getPidObject().getPrimaryId());
						

					fileContentStream.close();
					fileContentStream  = null;
	 
					ibmSession.commit();
							
					theLogger.debug(transactionId, "Finished mporting document: " + dto.getFileName() + " into ECM for appeal number: " + appealNumber + " . The ECM ID is: " + importDoc.getEcmItemId());
					isSuccess = true;
					
					importDoc.setStatus(0); // successfull
				} else {	
					theLogger.error(transactionId, "Failed to import document: " + dto.getFileName()+ " into ECM for appeal number: " + appealNumber );
					importDoc.setStatus(-2); // failed
				}
			 } else
			 {
				 theLogger.error(transactionId, "Failed to open file: " + fullFilePath + " for importing into ECM for appeal number: " + appealNumber );
				 importDoc.setStatus(-3); // failed
			 }
											
		} catch (Error e) {
			theLogger.error(transactionId, "Error while uploading document: " + dto.getFileName() + " into ECM for appeal number: " + appealNumber, e);
			importDoc.setStatus(-4); // failed
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while uploading document: " + dto.getFileName() + " into ECM for appeal number: " + appealNumber, e);
			importDoc.setStatus(-5); // failed
		} finally 
		{
			if (fileContentStream!= null)
			{
				try {
					fileContentStream.close();
				} catch(IOException e) {							
					theLogger.error(transactionId, "Unable to close the stream after importing document to ECM for file: " + dto.getFileName(), e);
				}
			}
					
			if (isSuccess == false) {	
				try {
					ibmSession.rollback();
				} catch(Exception e) {
					try {
						ibmSession.rollback();
					} catch (CMBException e1) {
						theLogger.error(transactionId, "ECM rollback failed: ", e);
					}
					theLogger.error(transactionId, "ECM commit failed: ", e);
				}
			}
		}
		
		return importDoc;
	}
	
	private CMBItem createDocumentItem(CMBConnection ibmSession, ECMDocumentL1L2Dto dto, InputStream contentStream, long transactionId) 
	{
		theLogger.debug(transactionId, "Creating document in ECM for document: " + dto.getFileName() + " for appeal number: " + dto.getAppealNumber());
		
		CMBItem newDocument = new CMBItem();
		try {
			CMBDataManagement dataManager = ibmSession.getDataManagement();
			String entityName = dto.getEntityName();
			String fileName = dto.getFileName();
			String fileExtension = dto.getFileExtension();
			long contentSize = dto.getFileSize();
			Map<String, String> docAttrMap = dto.getAttributeMap();
			
			//logger.debug("Entity Name: " + entityName);
			//logger.debug("File size: "+contentSize);
			newDocument.setConnection(ibmSession);			
			newDocument.setServerType(ibmSession.getDsType());
			newDocument.setServerName(ibmSession.getServerName());
			newDocument.setEntityName(entityName);
			newDocument.setItemType(CMBBaseConstant.CMB_TYPE_DOCUMENT);

			// Set the attributes from the string arrays.
			CMBEntity entity = ibmSession.getSchemaManagement().getEntity(entityName);
			CMBAttribute[] attributes = entity.getAttributes();
			for (CMBAttribute attrObj : attributes) {
				String name = attrObj.getName();
				if (docAttrMap.containsKey(name)) {
					short type = attrObj.getType();
					String value = docAttrMap.get(name);
					//logger.debug("Attribute Name: " + name + "-->" + value);
					newDocument.addAttr(name, value, type);
				}
			}

			if (entity.hasSubEntities()) {
				//logger.debug("Has sub entity ");
				CMBEntity subEntityList[] = entity.getSubEntities();
				for (CMBEntity subEntity : subEntityList) {
					String childComponentName = subEntity.getName();
					if (subEntity.getDisplayName().contains("Medicare Appeal Number")) {
						//logger.debug("Child component Name: " + childComponentName);
						//logger.debug("Prepare to add child components");
						CMBItem[] collection = new CMBItem[1];
						collection[0] = new CMBItem();
						collection[0].setServerName(ibmSession.getServerName());
						collection[0].setServerType(ibmSession.getDsType());
						collection[0].setEntityName(childComponentName);
						collection[0].addAttr(ProviderConstants.ECM_APPEAL_NUM,
								docAttrMap.get(ProviderConstants.ECM_APPEAL_NUM),
								CMBBaseConstant.CMB_DATATYPE_VSTRING);
						newDocument.addAttr(childComponentName, collection,
								CMBBaseConstant.CMB_DATATYPE_ITEM_COLLECTION);
					}
				}
				//logger.debug("End of processing sub Entity");
			}

			dataManager.setDataObject(newDocument);
			String mimeType = constantConfig.getMimeType().get(fileExtension.toLowerCase());
			
			// Add Content
			CMBObject documentContent = new CMBObject();
			documentContent.setMimeType(mimeType);
			documentContent.setPartType("ICMBASE");
			documentContent.setOriginalFileName(fileName);
			documentContent.setDataStream(contentStream, contentSize);

			dataManager.addContent(documentContent);
			dataManager.createItem(entityName);

			return newDocument;
		} catch (Error e) {
			theLogger.error(transactionId, "Error while creating document in ECM for document: " + dto.getFileName() + " for appeal number: " + dto.getAppealNumber(), e);
		} catch (Exception e) {
			theLogger.error(transactionId, "Exception while creating document in ECM for document: " + dto.getFileName() + " for appeal number: " + dto.getAppealNumber(), e);
		}
		
		return null;
	}
	
	
	private CMBItem[] getItemByDescription(CMBConnection ibmSession, String appealNumber, String desc, long transactionId) {

		try{
			//logger.debug("Appeal Number: "+appealNumber);
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("/'");
			queryBuilder.append(constantConfig.getLevel1ItemType());
			queryBuilder.append("'");
			queryBuilder.append("[./" + ProviderConstants.ECM_APPEAL_NUM + "_LVL_2/@");
			queryBuilder.append(ProviderConstants.ECM_APPEAL_NUM);
			queryBuilder.append("=\"");
			queryBuilder.append(appealNumber);
			queryBuilder.append("\" AND @");
			queryBuilder.append(ProviderConstants.ECM_DESCRIPTION);
			queryBuilder.append(" LIKE \"%");
			queryBuilder.append(desc);
			queryBuilder.append("%\"");
			queryBuilder.append("]");
			//logger.debug("Query Search: " + queryBuilder.toString());
			CMBItem[] resultItems = runQuery(ibmSession, queryBuilder.toString(), transactionId);
			//logger.debug("Number of document(s) Found: " + resultItems.length);

			//It should only have 1 item
			if (resultItems.length == 1) {
				return resultItems;
			} else if (resultItems.length <= 0) {
				return null;
			} else {
				theLogger.error(transactionId, "There are more than 1 documents matching " + desc + " within appeal: " + appealNumber);
				return resultItems;
			}
		} catch(Error e) {
			theLogger.error(transactionId, "Unable to find document: " + desc + " within appeal: " + appealNumber, e);
			return null;
		} catch(Exception e) {
			theLogger.error(transactionId, "Unable to find document: " + desc + " within appeal: " + appealNumber, e);
			return null;
		}
	}
	
	public CMBItem[] runQuery(CMBConnection con, String queryString, String methodName, long transactionId) throws Exception {
		return runQuery(con, queryString, -1, methodName, transactionId);		
	}

	public CMBItem[] runQuery(CMBConnection con, String queryString, int maxResults, String methodName, long transactionId) throws Exception {
		long startTime = System.currentTimeMillis();
			
		try {
			if(!con.isConnected()) con.connect();

			CMBQueryService queryService = con.getQueryService();
			CMBSearchResults resultBean = new CMBSearchResults();
			resultBean.setConnection(con);
				
			queryService.clearQuery();
			queryService.setMaxResults(maxResults);
			queryService.setAsynchSearch(false);
			//CMBBaseConstant.CMB_LATEST_VERSION  - supported CM V8 only
			//The default value is CMB_ALL_VERSIONS
			queryService.setVersion(CMBBaseConstant.CMB_LATEST_VERSION);
			
			queryService.setQueryString(queryString, CMBBaseConstant.CMB_QS_TYPE_XPATH);

			theLogger.debug(transactionId, "[" + methodName + "]: Query String: " + queryString);

			queryService.runQuery();
			resultBean.newResults(queryService.getResults());
			
			theLogger.performanceStartOnly(transactionId, methodName, startTime);
			
			return resultBean.getItems();
		} catch (CMBException e) {
			theLogger.error(transactionId, "Unable to run query: ", e);
			throw new Exception("Unable to run query: ", e);
		} catch (Error e) {
			theLogger.error(transactionId, "Unable to run query: ", e);
			throw new Exception("Unable to run query: ", e);
		} catch (Exception e) {
			theLogger.error(transactionId, "Unable to run query: ", e);
			throw new Exception("Unable to run query: ", e);
		}
	}
	
	private CMBItem[] runQuery(CMBConnection con, String queryString, long transactionId) throws Exception {
		try {
			if (!con.isConnected())
				con.connect();

			CMBQueryService queryService = con.getQueryService();
			CMBSearchResults resultBean = new CMBSearchResults();
			resultBean.setConnection(con);
			
			queryService.clearQuery();
			queryService.setMaxResults(-1);
			queryService.setAsynchSearch(false);
			queryService.setVersion(CMBBaseConstant.CMB_LATEST_VERSION);
			
			queryService.setQueryString(queryString,
					CMBBaseConstant.CMB_QS_TYPE_XPATH);

			queryService.runQuery();
			resultBean.newResults(queryService.getResults());
			return resultBean.getItems();
		} catch (CMBException e) {
			theLogger.error(transactionId, "Exception while executing ECM query: " + queryString, e);
			throw new Exception(e.getMessage(), e.fillInStackTrace());
		}

	}
	
	
	private Map<String,String> setupECMDocumentAttributeMap(String appealNumber,String siebelId,String org,String fileId, String md5,String appealLevel){
		HashMap<String,String> ecmAttrMap = new HashMap<String,String>();
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel2DocCategory());
		}
		if(appealLevel.contains(constantConfig.getLevel1())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel1DocCategory());
		}
		if(appealLevel.contains(constantConfig.getLevel3())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel3DocCategory());
		}
		ecmAttrMap.put(ProviderConstants.ECM_RECEIVED_DT, Util.convertCalendarToString(Calendar.getInstance(), ProviderConstants.ECM_DT_FORMAT));
		
		ecmAttrMap.put(ProviderConstants.ECM_AUDT_CD, constantConfig.getDocAuditCode().get(org));
		
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel2Code());
		}
		if(appealLevel.contains(constantConfig.getLevel1())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel1Code());
		}
		
		if(appealLevel.contains(constantConfig.getLevel3())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel3Code());
		}
			
		ecmAttrMap.put(ProviderConstants.ECM_DESCRIPTION, fileId);
		ecmAttrMap.put(ProviderConstants.ECM_APPEAL_NUM, appealNumber);
		if (siebelId != null && siebelId.length() > 0)
		{
			ecmAttrMap.put(ProviderConstants.ECM_SIEBEL_LVL_1_ID, siebelId);	
		}
		
		return ecmAttrMap;
	}
	
	
	private String getPageCount(ECMDocumentL1L2Dto docDto, long transactionId) 
	{
		theLogger.debug(transactionId, "Getting page count for document: " + docDto.getFileName() + " for appeal number: " + docDto.getAppealNumber());
		
		int numberOfParts = 1;
		CMBDocument doc = null;
		CMBStreamingDocServices cmbStreamingDocServices = null;
		String pageCount = "N/A";
		InputStream contentByteArray = null;
		try {
			String docMimeType = docDto.getMimeType();
			boolean isTiffOrPdf = (docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("pdf"))
					|| docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("tiff")) 
					|| docMimeType.equalsIgnoreCase(constantConfig.getMimeType().get("tif")));

			if (isTiffOrPdf) 
			{
				 
				
				String fullFilePath = docDto.getFileFolder() + "/" + docDto.getFileName();
				contentByteArray = new FileInputStream(fullFilePath);
				
				CMBDocumentServices cmbDocumentServices = new CMBDocumentServices();
				Properties engineProperty = new Properties();
				engineProperty.setProperty("ENGINE1_CLASSNAME",
						"com.ibm.mm.viewer.CMBSnowboundEngine");
				engineProperty.setProperty("ENGINE1_DELAYINIT", "true");
				engineProperty.setProperty("ENGINES", "1");
				cmbDocumentServices.setEngineProperties(engineProperty);
				cmbStreamingDocServices = cmbDocumentServices.getStreamingDocServices();
				doc = cmbStreamingDocServices.loadDocument(contentByteArray,
						numberOfParts, docMimeType, docMimeType, null, null);

				if (doc.getCanPaginate()) {
					//logger.debug("Number of Page: " + doc.getPageCount());
					return String.valueOf(doc.getPageCount());

				}
			}
		} catch(Error ex) {
			theLogger.error(transactionId, "Error while getting page count for document: " + docDto.getFileName() + " for appeal number: " + docDto.getAppealNumber(), ex);
		} catch(Exception ex) {
			theLogger.error(transactionId, "Exception while getting page count for document: " + docDto.getFileName() + " for appeal number: " + docDto.getAppealNumber(), ex);
		} finally {
			if (cmbStreamingDocServices != null) {
				cmbStreamingDocServices.dropDocument(doc);
			}
			
			if (contentByteArray!= null)
			{
				try {
					contentByteArray.close();
				} catch(IOException e) {							
					theLogger.error(transactionId, "Unable to close the stream after getting the page count ECM for file: " + docDto.getFileName(), e);
				}
			}
		}
		
		return pageCount;
	}
	
	private String getMimeType(String fileExtension) {
		return constantConfig.getMimeType().get(fileExtension.toLowerCase());
	}
	

	

	
	public CMBItem searchItemByPrimaryId(CMBConnection ibmSession, String itemID) throws Exception {
		logger.debug("Search Session: "+((DKDatastoreICM)ibmSession.getDatastore()).getLSSessionId());
		String queryString = "/'*'[ @ITEMID = \"" + itemID + "\"]";
		logger.debug("Query Search: " + queryString);
		CMBItem[] resultItems = null;
		try{
			resultItems = runQuery(ibmSession, queryString);
			if (resultItems.length!=1){
				logger.debug("Prepare to go to sleep");
				Thread.sleep(200);
				resultItems = runQuery(ibmSession, queryString);
			}
		} catch(Error e) {
			logger.error("Issue occured when trying to search for an item by item id: " + itemID, e);
		} catch(Exception e) {
			logger.error("Issue occured when trying to search for an item by item id: " + itemID, e);
		}
		
		//It should only have 1 item
		if (resultItems.length==1){
			return resultItems[0];
		} else {
			throw new Exception("Unable to find CMBItem based on: "+itemID);
		}
	}
	

	private CMBItem createDocumentItem(CMBConnection ibmSession, ECMDocumentDto dto, InputStream contentStream) {
		CMBItem newDocument = new CMBItem();
		try {
			CMBDataManagement dataManager = ibmSession.getDataManagement();
			String entityName = dto.getEntityName();
			String fileName = dto.getFileName();
			String fileExtension = dto.getFileExtension();
			long contentSize = dto.getFileSize();
			Map<String, String> docAttrMap = dto.getAttributeMap();
			
			logger.debug("Entity Name: " + entityName);
			logger.debug("File size: "+contentSize);
			newDocument.setConnection(ibmSession);			
			newDocument.setServerType(ibmSession.getDsType());
			newDocument.setServerName(ibmSession.getServerName());
			newDocument.setEntityName(entityName);
			newDocument.setItemType(CMBBaseConstant.CMB_TYPE_DOCUMENT);

			// Set the attributes from the string arrays.
			CMBEntity entity = ibmSession.getSchemaManagement().getEntity(entityName);
			CMBAttribute[] attributes = entity.getAttributes();
			for (CMBAttribute attrObj : attributes) {
				String name = attrObj.getName();
				if (docAttrMap.containsKey(name)) {
					short type = attrObj.getType();
					String value = docAttrMap.get(name);
					logger.debug("Attribute Name: " + name + "-->" + value);
					newDocument.addAttr(name, value, type);
				}
			}

			if (entity.hasSubEntities()) {
				logger.debug("Has sub entity ");
				CMBEntity subEntityList[] = entity.getSubEntities();
				for (CMBEntity subEntity : subEntityList) {
					String childComponentName = subEntity.getName();
					if (subEntity.getDisplayName().contains("Medicare Appeal Number")) {
						logger.debug("Child component Name: " + childComponentName);
						logger.debug("Prepare to add child components");
						CMBItem[] collection = new CMBItem[1];
						collection[0] = new CMBItem();
						collection[0].setServerName(ibmSession.getServerName());
						collection[0].setServerType(ibmSession.getDsType());
						collection[0].setEntityName(childComponentName);
						collection[0].addAttr(ProviderConstants.ECM_APPEAL_NUM,
								docAttrMap.get(ProviderConstants.ECM_APPEAL_NUM),
								CMBBaseConstant.CMB_DATATYPE_VSTRING);
						newDocument.addAttr(childComponentName, collection,
								CMBBaseConstant.CMB_DATATYPE_ITEM_COLLECTION);
					}
				}
				logger.debug("End of processing sub Entity");
			}

			dataManager.setDataObject(newDocument);
			String mimeType = constantConfig.getMimeType().get(fileExtension.toLowerCase());
			
			// Add Content
			CMBObject documentContent = new CMBObject();
			documentContent.setMimeType(mimeType);
			documentContent.setPartType("ICMBASE");
			documentContent.setOriginalFileName(fileName);
			documentContent.setDataStream(contentStream, contentSize);

			dataManager.addContent(documentContent);
			dataManager.createItem(entityName);

			return newDocument;
		} catch (Error e) {
			logger.error("Create Document Failed", e);
		} catch (Exception e) {
			logger.error("Create Document Failed", e);
		}
		
		return null;
	}
	
	
	private CMBItem getAppeal(CMBConnection ibmSession, String appealNumber) {
		try {
			logger.debug("Call SearchAppealFolderNumber");
			logger.debug("Appeal Number: " + appealNumber);
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("/");
			queryBuilder.append(ProviderConstants.EMC_APPEAL_FOLDER);
			queryBuilder.append("[@");
			queryBuilder.append(ProviderConstants.ECM_APPEAL_NUM);
			queryBuilder.append("=\"");
			queryBuilder.append(appealNumber);
			queryBuilder.append("\"]");
			logger.debug("Query Search: " + queryBuilder.toString());
			CMBItem[] resultItems = runQuery(ibmSession, queryBuilder.toString());
			logger.debug("Number of appeal Case Found: " + resultItems.length);

			// It should only have 1 item
			if (resultItems.length == 1) {
				return resultItems[0];
			} else if (resultItems.length <= 0) {
				return null;
			} else {
				logger.error("There have more appeal case exist with the selected appeal number: " + appealNumber);
				throw new ECMServiceException("Unable to find appeal Folder: " + appealNumber);
			}

		} catch (Error e) {
			logger.error("", e);
		} catch (Exception e) {
			logger.error("", e);
		}
		return null;

	}
	
	private CMBItem[] runQuery(CMBConnection con, String queryString) throws ECMServiceException {
		try {
			if (!con.isConnected())
				con.connect();

			CMBQueryService queryService = con.getQueryService();
			CMBSearchResults resultBean = new CMBSearchResults();
			resultBean.setConnection(con);
			
			queryService.clearQuery();
			queryService.setMaxResults(-1);
			queryService.setAsynchSearch(false);
			queryService.setVersion(CMBBaseConstant.CMB_LATEST_VERSION);
			
			queryService.setQueryString(queryString,
					CMBBaseConstant.CMB_QS_TYPE_XPATH);

			queryService.runQuery();
			resultBean.newResults(queryService.getResults());
			return resultBean.getItems();
		} catch (CMBException e) {
			logger.error("Unable to run query: " + e.getMessage(), e.fillInStackTrace());
			throw new ECMServiceException(e.getMessage(), e.fillInStackTrace());
		}

	}

	

	private CMBConnection getConnection(String ecmUsername, String ecmPassword){
		CMBConnection session = null;
		try{			
			session = ecmConnectionService.getIBMConnectionFromPool(ecmUsername, ecmPassword, constantConfig.getEcmServerName(), constantConfig.getEcmServerType());
			//session.startTransaction();
			return session;
		} catch(Error e) {
			logger.error("Unable to get ECM connection ", e);
			return null;
		} catch(Exception e) {
			logger.error("Unable to get ECM connection ", e);
			return null;
		}
		
	}
	
	public String exportTestDoc( String tempAppealFolder, String documentEcmId, 
			String ecmUsername, String ecmPassword, long transactionId ) 
	{
		String errMsg = null; 
 
		if (documentEcmId != null) 
		{
			String ecmServerName = constantConfig.getEcmServerName();
			String ecmServerType = constantConfig.getEcmServerType();
			
			CMBConnection ibmSession = ecmConnectionService.getIBMConnectionFromPool(ecmUsername, ecmPassword, ecmServerName, ecmServerType, transactionId);	
			if (ibmSession == null)
			{
				return "Failed to obtain CMBConnection from pool for exporting docuemnt from ECM";
			}
			
 
					try
					{
						CMBItem document = getDocument(ibmSession, documentEcmId, transactionId);				
						

						if (document!=null)
						{
							theLogger.debug(transactionId, "Exporting document content for ECM ID: " + documentEcmId);
							
							String exportDocumentPath = exportContent(null, ibmSession,
										document, ContentPart.ICMBASE,
										tempAppealFolder, transactionId, documentEcmId);
							  
							
							if (exportDocumentPath != null)
							{
								 theLogger.debug(transactionId, "Successfully exported ECM document to: " + exportDocumentPath );
							} else {
								errMsg = "Error when exporting document from ECM for ECM document Id:" + documentEcmId ;
							}
						} else {
							errMsg = "Document with ECM Id: " + documentEcmId+ " does not exist in ECM";
						}
					} 
					catch(Exception e) 
					{
						theLogger.error(transactionId, "Exception while exporting document fom ECM: " + e.getMessage() );
						errMsg = "Error when exporting document from ECM for ECM document Id:" + documentEcmId ;
					}

			 
			if (ibmSession != null)
			{
				ecmConnectionService.releaseIBMConnectionToPool(ibmSession, transactionId);
			}
			
		}
		else
		{
			errMsg = "No ECM document Id was specified in the input.";
		}
		
 
		return errMsg;
	} 

	private CMBItem getDocument(CMBConnection con, String ecmItemId, long transactionId){
		CMBItem item = null; 
		try{
			item = searchItemByPrimaryId(con, ecmItemId, transactionId);
		}catch(Exception e){	
			theLogger.error(transactionId, "Exception while findind ECM document: " + e.getMessage() + e.fillInStackTrace());
		}
		return item;
	}
	
	public String exportContent(String orgFileName, CMBConnection con, CMBItem documentItem,
			ContentPart partType, String targetFilePath, long transactionId, String ecmDocId) {		
		String exportFileName = null;
		CMBDataManagement dataManager = null;
		try {
			theLogger.debug(transactionId, "Export Content for ECM ID " +  documentItem.getDDO().getPidObject().getPrimaryId() + " on Target Directory: " + targetFilePath);
			 
			
			dataManager = con.getDataManagement();
			dataManager.setDataObject(documentItem);
			dataManager.retrieveItem();
			CMBObject[] contentList = dataManager.getContent();
			
			/*
			logger.debug("Content List: " + contentList.length);			
			logger.debug("Annotation count: "
					+ dataManager.getAnnotationCount());
			logger.debug("NoteLog count: " + dataManager.getNoteLogCount());	
			*/
			
			/*String fileName = "";*/
			switch (partType) {
			
			case ICMBASE: {
				double currentSize = 0;
				for (CMBObject content : contentList) {
					//theLogger.debug(transactionId, "Part Type: " + content.getPartType());
					if (content.getPartType().equalsIgnoreCase( ContentPart.ICMBASE.value())) 
					{
						//String fileExt = FilenameUtils.getExtension(content.getOriginalFileName());						
						//logger.debug("File extension for export: "+fileExt);				
						
						Object[] obj = writeContentToFileShaun(content, targetFilePath, currentSize, content.getSize(), transactionId, ecmDocId);
						
						if (obj != null)
						{
							exportFileName = (String)obj[0].toString().trim();
							currentSize = (Double)obj[1];
						}
								
						break;
					}
				}
				break;
			}

			
			default:
				theLogger.error(transactionId, "Unable to determine content type");
				break;
			}
			
		} catch (CMBItemNotSetException e) {
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getMessage() + " " + e.getCause());
		} catch (CMBItemNotExistException e) {
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getMessage() + " " + e.getCause());
		} catch (CMBNoConnectionException e) {
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getClass() + " " + e.getMessage() + e.getCause());
		} catch (CMBException e) {
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getMessage() + " " + e.getCause());
		} catch (ArrayIndexOutOfBoundsException e) {
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getMessage() + " " + e.getCause());
		} catch (Exception e) {	
			theLogger.error(transactionId, "Exception while getting content from ECM: " + e.getClass() + " "+ e.getMessage() + " " +  e.fillInStackTrace());
		} finally {
			theLogger.debug(transactionId, "Done Export ECM Content");
			/*objectManagement.releaseItem(documentItem);*/			
		}
		return exportFileName;

	}

	private Object[] writeContentToFileShaun(CMBObject content, String targetDirectory, double currentSize, double estimatedSize, long transactionId, String ecmDocId) throws CMBException, FileNotFoundException {
	 	
		String fileName = content.getOriginalFileName();
		String mimeType = content.getMimeType();
		
		theLogger.debug(transactionId, "File Name: " + fileName + " Mime Type: " + mimeType);
		
		if (Util.isStringNullOrEmpty(fileName)){
			fileName = content.getXDO().getPidObject().getPrimaryId();			
			fileName+="." + Util.getMimeTypeExtension(constantConfig.getMimeType(), mimeType);		
		}
		
		//when append pdf to tiff, tiff convert to pdf but the filename never change
		//if (mimeType.equalsIgnoreCase("application/pdf"))
		//	fileName = FilenameUtils.getBaseName(fileName)+".pdf";
		
		
		String targetFile = targetDirectory + "/" + ecmDocId + "_" + fileName;
		//targetFile = Util.generateNewFileName(targetFile);
		FileOutputStream fileOutStream = new FileOutputStream(targetFile);
		
		currentSize = Util.writeDataToStream(content.getDataStream(), fileOutStream, currentSize, true, transactionId);
		
		if (currentSize > 0 )
		{
			return new Object[]{targetFile, currentSize};
		}
		
		return null;
	}
	
	private CMBItem searchItemByPrimaryId(CMBConnection con, String itemID, long transactionId) throws Exception {
		theLogger.debug(transactionId, "Search Session: "+((DKDatastoreICM)con.getDatastore()).getLSSessionId());
		String queryString = "/'*'[ @ITEMID = \"" + itemID + "\"]";

		CMBItem[] resultItems = null;
		try
		{
			resultItems = runQuery(con, queryString, "searchItemByPrimaryId", transactionId);
			if (resultItems.length != 1)
			{
				// try one more time
				Thread.sleep(200);
				resultItems = runQuery(con, queryString, "searchItemByPrimaryId", transactionId);
			}
		} catch(Exception e) {
			theLogger.error(transactionId, "Issue occured when trying to search for an item by item id: " + itemID, e);
		}

		//It should only have 1 item
		if (resultItems.length==1){
			return resultItems[0];
		} else {
			theLogger.error(transactionId, "Could not find only one CMBItem for item ID : " + itemID );
			throw new Exception("Unable to find CMBItem: "+itemID);
		}	

	}
}
