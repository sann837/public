package com.cgi.mas.provider.services.dto;

public class DocumentResultDto {
	private String ecmItemId;
	private String pageCount;
	private long sizeInKB;
	private String fileName;
	private String siebeldocId;
	
	
	//QIC Webservice
	private int status; // 1 = in ECM; -ERRCODE = FAILED; 0 = SUCCESS;
	private String checkSum ;
	
	public String getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}
	public String getSiebeldocId() {
		return siebeldocId;
	}
	public void setSiebeldocId(String siebeldocId) {
		this.siebeldocId = siebeldocId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getEcmItemId() {
		return ecmItemId;
	}
	public void setEcmItemId(String ecmItemId) {
		this.ecmItemId = ecmItemId;
	}
	public String getPageCount() {
		return pageCount;
	}
	public void setPageCount(String pageCount) {
		this.pageCount = pageCount;
	}	

	public long getSizeInKB() {
		return sizeInKB;
	}
	public void setSizeInKB(long sizeInKB) {
		this.sizeInKB = sizeInKB;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(this.siebeldocId);
		strBuilder.append("-->ECM Id:");
		strBuilder.append(this.ecmItemId);
		strBuilder.append("-->");
		strBuilder.append("PageCount:");
		strBuilder.append(this.pageCount);
		strBuilder.append("-->");
		strBuilder.append("File Size:");
		strBuilder.append(this.sizeInKB);
		strBuilder.append("-->");
		strBuilder.append("FileName:");
		strBuilder.append(this.fileName);
		return strBuilder.toString();
	}
	
}
