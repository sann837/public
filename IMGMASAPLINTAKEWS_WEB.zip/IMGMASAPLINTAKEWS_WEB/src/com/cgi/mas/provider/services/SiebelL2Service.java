package com.cgi.mas.provider.services;

import java.io.File;
import java.net.URL;
import java.util.Locale;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import com.cgi.cms.l2services.schema.mas.CreateL2AppealResponse;
import com.cgi.cms.l2services.schema.mas.MessageDetail;
import com.cgi.cms.l2services.schema.mas.MessageList;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.exceptions.CMAplIntakeWSException;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.services.dto.QicAppeal;
import com.cgi.mas.provider.services.dto.UserDto;
import com.cgi.mas.provider.util.EncryptionUtil;
import com.siebel.masl2autoappeal.AssociateDocumentsInput;
import com.siebel.masl2autoappeal.AssociateDocumentsOutput;
import com.siebel.masl2autoappeal.CreateL2AutoAppealInput;
import com.siebel.masl2autoappeal.CreateL2AutoAppealOutput;
import com.siebel.masl2autoappeal.GetL2AppealDocumentsInput;
import com.siebel.masl2autoappeal.GetL2AppealDocumentsOutput;
import com.siebel.masl2autoappeal.L2UserAuthenticationInput;
import com.siebel.masl2autoappeal.L2UserAuthenticationOutput;
import com.siebel.masl2autoappeal.MASL2AutoAppealWS;
import com.siebel.masl2autoappeal.MASL2AutoAppealWS_Service;
import com.siebel.masl2autoappeal.UpdateL2TransctnIdInput;
import com.siebel.masl2autoappeal.UpdateL2TransctnIdOutput;
import com.siebel.masl2autoappeal.ValidateDocumentsInput;
import com.siebel.masl2autoappeal.ValidateDocumentsOutput;
import com.siebel.xml.mas_20validate_20documents_20response_20io.Appeal;
import com.siebel.xml.mas_20validate_20documents_20response_20io.ListOfResponseDocsIO;
import com.siebel.xml.masassociatedocsio.ListOfMasBcAssociateDocuments;
import com.siebel.xml.masassociatedocsio.ListOfMasassociatedocsio;
import com.siebel.xml.masassociatedocsio.MasBcValidateDocumentsAppeal;

@Service
public class SiebelL2Service implements ISiebelL2Service {
	
	//---------------Private Methods
	private QICCustomLogger theLogger = new QICCustomLogger( SiebelL2Service.class);
	
	private static final QName SERVICE_NAME = new QName("http://siebel.com/MASL2AutoAppeal", "MASL2AutoAppealWS");
	private static boolean isTest = false;	
	@Autowired
	private ConstantConfig constantConfig;
	@Autowired
	private MessageSource messageSource;



	public SiebelL2Service() {
		super();
		//theLogger.debug("",ProviderConstants.VERSION);
	}

		
	@Override
	public CreateL2AppealResponse createL2Appeal(CreateL2AutoAppealInput input, long transactionId,UserDto userdto) {
		long startTime = System.currentTimeMillis();
		theLogger.debug(transactionId,"**********Invoking Siebel createAppeal");
		//CreateAutoAppeal1Output appealNumber = null; //A1001001A13B24B55741F25026 test
	
		CreateL2AppealResponse response = new CreateL2AppealResponse();
		CreateL2AutoAppealOutput output = new CreateL2AutoAppealOutput();
		try {			
			MASL2AutoAppealWS port = getSiebelL2WSClient(transactionId,true,userdto);			
			output = port.createL2AutoAppeal(input);				
			if (output != null)
			{			
				String successOrNot = output.getStatus();
				
				if (successOrNot != null && successOrNot.compareToIgnoreCase("Success") == 0)
				{
					response.setAppealNumber(output.getAppealNumber());

					response.setStatus(true);
				} 
				else
				{
					String errCode = output.getErrCode();
					String errMessage = output.getErrMsg();
					
 
					theLogger.error(transactionId,"Error received from Siebel: " + errCode + " Message: " + errMessage);
					
					MessageList messageList = new MessageList();
					MessageDetail errorMessageDetail = new MessageDetail();							
					errorMessageDetail.setErrorCode(errCode);
					errorMessageDetail.setErrorMessage(errMessage);
					messageList.getErrorMessage().add(errorMessageDetail);
					
					response.setAppealNumber(output.getAppealNumber());
					response.setStatus(false);
					response.setMessageList(messageList);
				}
			}
			else
			{
				theLogger.error(transactionId, "Received null output from Siebel");
					
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();							
				errorMessageDetail.setErrorCode(ErrorFieldConstant.SIEBEL_ERROR);
				errorMessageDetail.setErrorMessage(messageSource.getMessage(ErrorFieldConstant.SIEBEL_ERROR, null, Locale.US));					
				messageList.getErrorMessage().add(errorMessageDetail);
					
				response.setStatus(false);
				response.setMessageList(messageList);
			}
			 
		} catch(Error er) {
			theLogger.error(transactionId, "Error while calling the Siebel createL2Appeal web service: ", er);

			MessageList messageList = new MessageList();
			MessageDetail errorMessageDetail = new MessageDetail();							
			errorMessageDetail.setErrorCode(ErrorFieldConstant.SIEBEL_ERROR);
			errorMessageDetail.setErrorMessage(messageSource.getMessage(ErrorFieldConstant.SIEBEL_ERROR, null, Locale.US));
			

			messageList.getErrorMessage().add(errorMessageDetail);
			
			response.setStatus(false);
			response.setMessageList(messageList);			
		} catch(Exception ex) {
			theLogger.error(transactionId, "Exception while calling the Siebel createL2Appeal web service: ", ex);

			MessageList messageList = new MessageList();
			MessageDetail errorMessageDetail = new MessageDetail();							
			errorMessageDetail.setErrorCode(ErrorFieldConstant.SIEBEL_ERROR);
			errorMessageDetail.setErrorMessage(messageSource.getMessage(ErrorFieldConstant.SIEBEL_ERROR, null, Locale.US));
			messageList.getErrorMessage().add(errorMessageDetail);
			
			response.setStatus(false);
			response.setMessageList(messageList);
			
		}

		theLogger.error(transactionId, "createL2Appeal - Siebel createL2Appeal web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel createL2Appeal Web Service", startTime);
		
		return response;
	}



	
	
	

	private String getSiebelAddress(UserDto userDto,long transactionId) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(constantConfig.getSiebelWSAddress());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_USER_NAME);
		strBuilder.append("=");
		strBuilder.append(userDto != null ? userDto.getSiebelUserId() : constantConfig.getSiebelUserName());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_PASSWORD);
		strBuilder.append("=");
		
		String password = userDto != null ? userDto.getSiebelPassWord() : constantConfig.getSiebelPassWord();
		
		try {
			EncryptionUtil encryptionUtil = new EncryptionUtil();
			
			theLogger.debug(transactionId,"--Siebel EndPoint: " + strBuilder.toString() + encryptionUtil.encryptIt(password));
		} catch (CMAplIntakeWSException e) {
			theLogger.error(transactionId, e);
		} catch (Error e) {
			theLogger.error(transactionId, e);
		} catch (Exception e) {
			theLogger.error(transactionId, e);
		}
		
		strBuilder.append(password);
		
		return strBuilder.toString();
	}

	private String getTestCheckSum(String fileId){
		File directory = new File(constantConfig.getTempFileLocation());
		File fileCol [] = directory.listFiles();
		for (File file : fileCol){
			String fileName = file.getName();
			int index = fileName.indexOf(fileId);
			if (index>-1){
				return ProviderUtils.getMD5CheckSum(file.getPath());
			}
		}
		
		return null;
	}
	
	@Override
	public L2UserAuthenticationOutput getUserL2Account(L2UserAuthenticationInput siebelRequest) {
		Long transId = new Long(siebelRequest.getTransId());
		long startTime = System.currentTimeMillis();
		theLogger.debug(transId,"************getUserAccount");
		theLogger.debug(transId,"Jurisdiction: "+siebelRequest.getJurisdiction());
		theLogger.debug(transId,"MAC: "+siebelRequest.getConsumerId());
		L2UserAuthenticationOutput output = null;
		
		try {
		
			if(isTest) {
				output = new L2UserAuthenticationOutput();				
				output.setUserId("testSiebelId");
				output.setUserPassword("testPassword");
				
			} else {
				MASL2AutoAppealWS port = getSiebelL2WSClient(transId,true,null);
				output = port.l2UserAuthentication(siebelRequest);
			}
			
			
			theLogger.performanceStartOnly("Done Invoking Siebel getUserAccount", startTime);
			theLogger.debug(transId,"************Done-getUserAccount");
		} catch(Error e) {
			if(output != null) {
				theLogger.error(transId,"UserAuthenticationOutput: \n" + output, e);
			} else theLogger.error(transId,"UserAuthenticationOutput: \n" +  e);
		} catch(Exception e) {
			if(output != null) {
				theLogger.error(transId,"UserAuthenticationOutput: \n" + output, e);
			} else 
				theLogger.error(transId,"UserAuthenticationOutput: \n" +  e);
		}
		
		return output;
	}
	
	private MASL2AutoAppealWS getSiebelL2WSClient(long transactionId, boolean setTimeout,UserDto userdto) {
		MASL2AutoAppealWS port = null;
		//theLogger.debug(transactionId, "Initializing Siebel Web Service");
		
		try
		{
			ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
			URL wsdlURL = classLoader.getResource(ProviderConstants.S_L2_WSDL_NAME);
			if (wsdlURL == null){
				//theLogger.debug(transactionId, "Siebel Web Service WSDL location for default Class Loader was null; Using this Class Loader instead");
				wsdlURL = this.getClass().getClassLoader().getResource(ProviderConstants.S_L2_WSDL_NAME);					
			}
			theLogger.debug(transactionId, "Initializing Siebel Web Service URL: "+wsdlURL.toString());
			
			MASL2AutoAppealWS_Service ss = new MASL2AutoAppealWS_Service(wsdlURL, SERVICE_NAME);				
			port = ss.getMASL2AutoAppealWS();		
				
			Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
	
			// Set Siebel Endpoint
			requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getSiebelAddress(userdto,transactionId));
			
			// Set Siebel Timeouts
			long connectTimeout = 300000;   // 300 seconds for internal calls between Java and Siebel
			long respondTimeout = 300000;
			if (setTimeout == true)
			{
				 connectTimeout = constantConfig.getSiebelWsConnectTimeout();
				 
				 respondTimeout = constantConfig.getSiebelWsRespondTimeout();
				
			}
			 
			
			requestContext.put("javax.xml.ws.client.receiveTimeout", respondTimeout); // Timeout in millis - BindingProviderProperties.REQUEST_TIMEOUT
			requestContext.put("javax.xml.ws.client.connectionTimeout", connectTimeout); // Timeout in millis
			
			// Set Siebel Username / Password
			/*
			final String SECURITY_NAMESPACE =
	                "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
	
	        SOAPFactory soapFactory = SOAPFactory.newInstance();
	        QName securityQName = new QName(SECURITY_NAMESPACE, "Security");
	        SOAPElement security = soapFactory.createElement(securityQName);
	        QName tokenQName = new QName(SECURITY_NAMESPACE, "UsernameToken");
	        SOAPElement token = soapFactory.createElement(tokenQName);
	        QName userQName = new QName(SECURITY_NAMESPACE, "Username");
	        SOAPElement soapUsername = soapFactory.createElement(userQName);
	        soapUsername.addTextNode(constantConfig.getSiebelUserName());
	        QName passwordQName = new QName(SECURITY_NAMESPACE, "Password");
	        SOAPElement soapPassword = soapFactory.createElement(passwordQName);
	        soapPassword.addTextNode(constantConfig.getSiebelPassWord());
	        token.addChildElement(soapUsername);
	        token.addChildElement(soapPassword);
	        security.addChildElement(token);
	              
	        List<Header> headersList = new ArrayList<Header>();
	        
	        SoapHeader securityHeader = new SoapHeader( new QName(null, "Security"), security);
          
	        headersList.add(securityHeader);

	        requestContext.put(Header.HEADER_LIST, headersList);
	        */
     
			theLogger.debug(transactionId, "Siebel Web Service initilized from URL: "+wsdlURL.toString());
		}
		catch (Exception ex)
		{
			theLogger.error(transactionId, "Failed to instantiate Siebel Web Service: ", ex);
		}
		
		return port;
	}
	
	@Override
	public QicAppeal validateDocs(ValidateDocumentsInput input, long transactionId)
	{
long startTime = System.currentTimeMillis();
		
		theLogger.debug(transactionId, "ValidateDocuments - Calling Siebel closeAppeal web service");
 
		QicAppeal appeal = null;
	 
		try {

			MASL2AutoAppealWS port = getSiebelL2WSClient(transactionId, true, null);
 
			ValidateDocumentsOutput output = port.validateDocuments(input);
 
			if (output != null)
			{			
				String successOrNot = output.getStatus();

				if (successOrNot != null && successOrNot.compareToIgnoreCase("Success") == 0)
				{
					ListOfResponseDocsIO appealList = output.getListOfResponseDocsIO();
					 
					if (appealList != null)
					{
						Appeal appealData = appealList.getAppeal();
						 
						if (appealData != null)
						{
							appeal= new QicAppeal();
							appeal.appeal = appealData;
							appeal.status = 0;
							
							theLogger.debug(transactionId, "ValidateDocuments - successfully got the Validate Documents  data");
							
							
							
		    				
						}
						else	
						{
							theLogger.error(transactionId, "Received empty appeal from Siebel for ValidateDocuments method");
						}
					}
					else
					{
						theLogger.error(transactionId, "Received empty appeal list from Siebel for ValidateDocuments method");
					}
				} 
				else
				{
					String errCode = output.getErrCode();
					String errMsg = output.getErrMsg();
					
					appeal= new QicAppeal();
					appeal.appeal = null;
					
					
					if (errCode != null)
					{
						// validation error
						appeal.status = -4;
					}
					else
					{
						appeal.status = -1;
					}
					
					if (errMsg == null)
						errMsg = "NULL";
						
					
					 
					appeal.errCode = errCode;
					appeal.errMsg = errMsg;
					
					theLogger.error(transactionId, "ValidateDocuments - Received error from Siebel. Error Code: " + errCode + ". Error Message: " + errMsg);
				}
			}
			else
			{
				theLogger.error(transactionId, "ValidateDocuments - Received null output from Siebel");
			}
			 
		} catch(Error er) 
		{
			theLogger.error(transactionId, "ValidateDocuments - Error while calling the Siebel ValidateDocuments web service: ", er);	 			
		} catch(Exception ex) 
		{
			theLogger.error(transactionId, "ValidateDocuments - Exception while calling the Siebel ValidateDocuments web service: ", ex);
		}

		theLogger.debug(transactionId, "ValidateDocuments - Siebel ValidateDocuments web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel ValidateDocuments Web Service", startTime);
		
		return appeal;
	}
	
	
	@Override
	public String updateTransactionStatus(long transactionId, String transStatus, String errCode, String errMsg, String extAppealNum, String uniqueId)
	{
		
		/*
		Operation	Status
		Promote		Received
		Promote		Validated
		Promote		Retrieving ECM Data
		Promote		Retrieving Appeal Data
		Promote		Completed
		Promote		Error
		RFH			Received
		RFH			Completed
		RFH			Error

		 */
		String newStatus = null;
		
		long startTime = System.currentTimeMillis();
		
		theLogger.debug(transactionId, "updateTransactionStatus - Calling Siebel updateTransaction web service");
		
 
		
		try {

			MASL2AutoAppealWS port = getSiebelL2WSClient(transactionId, false, null);
				 
			UpdateL2TransctnIdInput input = new UpdateL2TransctnIdInput();
		
			input.setTransId(String.valueOf(transactionId));
			input.setTranStatus(transStatus);
			
			if (uniqueId != null)
				input.setTransId(uniqueId);
			
			if (errCode != null)
				input.setErrCode(errCode);
			if (errMsg != null)
				input.setErrMsg(errMsg);
			
			
			 
			
			UpdateL2TransctnIdOutput output = port.updateL2TransctnId(input);
			
			
			if (output != null)
			{			
				newStatus = output.getStatus();			
			}
			else
			{
				theLogger.error(transactionId, "Received null output from Siebel");
			}
			 
		} catch(Error er) {
			theLogger.error(transactionId, "Error while calling the Siebel updateTransaction web service: ", er);		
		} catch(Exception ex) {
			theLogger.error(transactionId, "Exception while calling the Siebel updateTransaction web service: ", ex);
		}

		theLogger.debug(transactionId, "updateTransactionStatus - Siebel updateTransaction web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel updateTransactionStatus Web Service", startTime);
		
		return newStatus;
	}
	
	
	@Override
	public int associateDocuments(long transactionId, String appealNumber, ListOfMasBcAssociateDocuments ecmDocs)
	{
		int errCode = -1;

		long startTime = System.currentTimeMillis();
		
		theLogger.debug(transactionId, "associateDocuments - Calling Siebel associateDocuments web service");
 
		try {

			MASL2AutoAppealWS port = getSiebelL2WSClient(transactionId, true, null);
			
			AssociateDocumentsInput input = new AssociateDocumentsInput();
			
			//com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ListOfMasL3SvcCloseEcmIo closeEcmIo = input.getListOfMasL3SvcCloseEcmIo();
			
			
			ListOfMasassociatedocsio associateEcmIo = new ListOfMasassociatedocsio();
			
			MasBcValidateDocumentsAppeal ap = new MasBcValidateDocumentsAppeal();
			
			ap.setAppealNum(appealNumber);
			ap.setTransactionID(Long.toString(transactionId));
			
			ap.setListOfMasBcAssociateDocuments(ecmDocs);
			 
			associateEcmIo.setMasBcValidateDocumentsAppeal(ap);
			input.setListOfMasassociatedocsio(associateEcmIo);
			
			AssociateDocumentsOutput output = port.associateDocuments(input);
			
			//com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ps.ECMDocument ecmDocForSiebel = new com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ps.ECMDocument();
			//com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ps.ECMDocument ecmDocForSiebel = new com.siebel.xml.mas_20bo_20l3_20close_20ecm_20io.ps.ECMDocument();
			
			if (output != null)
			{	
				
				String successOrNot =  output.getStatus(); 
				
				if (successOrNot != null && successOrNot.compareToIgnoreCase("Success") == 0)
				{
					errCode = 0;
				}
				else
				{
					theLogger.error(transactionId, "The Siebel web service associateDocuments returned error code: " + output.getErrCode() + " and error message: " + output.getErrMsg());
				}
				 
			}
			else
			{
				theLogger.error(transactionId, "Received null output from Siebel associateDocuments");
				errCode = -2;
			}
			 
		} catch(Error er) {
			theLogger.error(transactionId, "Error while calling the Siebel associateDocuments web service: ", er);
			errCode = -2;
			 
		} catch(Exception ex) {
			theLogger.error(transactionId, "Exception while calling the Siebel associateDocuments web service: ", ex);
			
			errCode = -2;
		}

		theLogger.debug(transactionId, "associateDocuments - Siebel associateDocuments web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel associateDocuments Web Service", startTime);
		
		return errCode;
	}
	@Override
	public GetL2AppealDocumentsOutput testAppeal(String appealNumber, long transactionId, String consumerId, String publicKey)
	{
		long startTime = System.currentTimeMillis();
		
		theLogger.debug(transactionId, "testAppeal - Calling Siebel getAppealDocuments web service");
		
		GetL2AppealDocumentsOutput response = null;
		//response.setTransactionId(transactionId);
		
		try {
			
			MASL2AutoAppealWS port = getSiebelL2WSClient(transactionId, true, null);
						
			GetL2AppealDocumentsInput input = new GetL2AppealDocumentsInput();
			
			input.setAppealNumber(appealNumber);
			input.setTransId(String.valueOf(transactionId));
			
			response = port.getL2AppealDocuments(input);
			
		} catch(Error er) {
			theLogger.error(transactionId, "Error while calling the Siebel getAppealDocuments web service: ", er);

			response = null;	
		} catch(Exception ex) {
			theLogger.error(transactionId, "Exception while calling the Siebel getAppealDocuments web service: ", ex);

			response = null;
		}

		theLogger.debug(transactionId, "testAppeal - Siebel getAppealDocuments web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel testAppeal Web Service", startTime);
		
		return response;
	}


}
