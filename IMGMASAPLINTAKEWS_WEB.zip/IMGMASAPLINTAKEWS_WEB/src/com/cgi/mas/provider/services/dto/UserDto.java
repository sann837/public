package com.cgi.mas.provider.services.dto;

import org.springframework.util.StringUtils;



public class UserDto{
	private String siebelUserId;
	private String siebelPassWord;
	private String ecmUserName;
	private String ecmPassword;
	private String mac;
	private String jurisdiction;
	private String org;
	private String loginUserId;
	
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getOrg() {
		if (this.org != null){
			return org;
		}else{
			
			boolean hasMac = StringUtils.hasText(this.mac);
			boolean hasJurisdiction = StringUtils.hasText(this.jurisdiction);
			if (hasMac & hasJurisdiction){
				StringBuilder strbuilder = new StringBuilder();
				strbuilder.append(mac);
				strbuilder.append(" - ");
				strbuilder.append(jurisdiction);
				this.org = strbuilder.toString();				
				return this.org;
			}else if (hasJurisdiction==false){
				this.org = this.mac;
				return this.org;				
			}else{
				return this.org;
			}			
		}
		
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public String getSiebelUserId() {
		return siebelUserId;
	}
	public void setSiebelUserId(String siebelUserId) {
		this.siebelUserId = siebelUserId;
	}
	public String getSiebelPassWord() {
		return siebelPassWord;
	}
	public void setSiebelPassWord(String siebelPassWord) {
		this.siebelPassWord = siebelPassWord;
	}
	public String getEcmUserName() {
		return ecmUserName;
	}
	public void setEcmUserName(String ecmUserName) {
		this.ecmUserName = ecmUserName;
	}
	public String getEcmPassword() {
		return ecmPassword;
	}
	public void setEcmPassword(String ecmPassword) {
		this.ecmPassword = ecmPassword;
	}
	public String getLoginUserId() {
		return loginUserId;
	}
	public void setLoginUserId(String loginUserId) {
		this.loginUserId = loginUserId;
	}
	
}
