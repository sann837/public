package com.cgi.mas.provider.services.dto;

import org.springframework.core.io.Resource;

public class ResourceSiebelDto {
	private Resource resource;
	private String siebelId;
	private String ecmId;
	private String checksum;
	private String originalName;
	private String fileId;
	private UserDto userAccount;
	private String appealNumber;
	private String appealLevel;
	private String docType;
	private String docCategory;
	
	public String getAppealNumber() {
		return appealNumber;
	}
	public void setAppealNumber(String appealNumber) {
		this.appealNumber = appealNumber;
	}
	public UserDto getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(UserDto userAccount) {
		this.userAccount = userAccount;
	}
	public Resource getResource() {
		return resource;
	}
	public void setResource(Resource resource) {
		this.resource = resource;
	}
	public String getSiebelId() {
		return siebelId;
	}
	public void setSiebelId(String siebelId) {
		this.siebelId = siebelId;
	}
	public String getEcmId() {
		return ecmId;
	}
	public void setEcmId(String ecmId) {
		this.ecmId = ecmId;
	}
	public String getChecksum() {
		return checksum;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	public String getOriginalName() {
		return originalName;
	}
	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getAppealLevel() {
		return appealLevel;
	}
	public void setAppealLevel(String appealLevel) {
		this.appealLevel = appealLevel;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocCategory() {
		return docCategory;
	}
	public void setDocCategory(String docCategory) {
		this.docCategory = docCategory;
	}
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(this.siebelId);
		strBuilder.append("-->File Id:");
		strBuilder.append(this.fileId);
		strBuilder.append("-->ECMId: ");		
		strBuilder.append(this.ecmId);
		strBuilder.append("-->originalFileName:");		
		strBuilder.append(this.originalName);
		
		return strBuilder.toString();
	}
	

}
