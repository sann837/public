package com.cgi.mas.provider.services;

import java.util.List;

import com.cgi.mas.provider.exceptions.ECMServiceException;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ECMDocumentDto;
import com.cgi.mas.provider.services.dto.ReceivedFileDto;


public interface IECMService {
	
	public boolean appealFolderExists(String ecmUsername, String ecmPassword, String appealNumber);

	public String getItemByDescription(String ecmUsername, String ecmPassword, String appealNumber, String desc);
	
	public String searchItemById(String ecmUsername, String ecmPassword, String docId);
 
	public List<DocumentResultDto> importDocumentIntoAppeal(String ecmUsername, String ecmPassword,
			String appealNumber, List<ECMDocumentDto> documentList)
			throws ECMServiceException;
	

	public List<DocumentResultDto> importFilesToAppeal(String ecmUsername, String ecmPassword, 
			String appealNumber, String appealOpenDate,  String orgName, String appealDirectory, 
			List<ReceivedFileDto> receivedFiles, long transactionId,String level);

	public String getPageCount(ECMDocumentDto docDto);

	public String exportTestDoc(String string, String ecmDocId,
			String ecmUsername, String ecmPassword, long transUID);
}
