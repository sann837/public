package com.cgi.mas.provider.services;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
 
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
 
import org.apache.ws.security.WSPasswordCallback;

 
/**
 * Really callback for key passwords.  Configure it with a map
 * of key-alias-to-password mappings.  Obviously this could
 * be extended to encrypt or obfuscate these passwords if desired.
 */
public class KeystorePasswordCallback implements CallbackHandler
{
 
    private Map<String, String> passwords = new HashMap<String, String>();
 
    /**
     * {@inheritDoc}
     * 
     * @see javax.security.auth.callback.CallbackHandler#handle(javax.security.auth.callback.Callback[])
     */
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException
    {
        for (Callback callback : callbacks)
        {
            if (callback instanceof WSPasswordCallback)
            {
                WSPasswordCallback pc = (WSPasswordCallback)callback;
     
                String identifier = pc.getIdentifier();
                if (identifier != null)
                {
	                String pass = passwords.get(identifier);
	                if (pass != null)
	                {
	                    pc.setPassword(pass);
	                    return;
	                }
                }
            }
        }
    }
 
    /**
     * @return the passwords
     */
    public Map<String, String> getPasswords()
    {
        return passwords;
    }
 
    /**
     * @param passwords the passwords to set
     */
    public void setPasswords(Map<String, String> passwords)
    {
        this.passwords = passwords;
    }
     
}
