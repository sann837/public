package com.cgi.mas.provider.services;

import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.cgi.mas.provider.services.dto.UserDto;
import com.siebel.customui.CreateAddlnDocumentInput;
import com.siebel.customui.CreateAddlnDocumentOutput;
import com.siebel.customui.CreateAutoAppealInput;
import com.siebel.customui.CreateAutoAppealOutput;
import com.siebel.customui.UserAuthenticationInput;
import com.siebel.customui.UserAuthenticationOutput;


public interface ISiebelService {
	CreateAutoAppealOutput createAppeal(CreateAutoAppealInput siebelRequest, UserDto userDto);	
	
	ResourceSiebelDto getDocInforFromFileId(String fileId);
	
	boolean createSiebelDocError(Object input, boolean shouldReturn);
	
	boolean updateSiebelDocId(DocumentResultDto ecmDto);
	
	UserAuthenticationOutput getUserAccount(UserAuthenticationInput siebelRequest);
	
	CreateAddlnDocumentOutput requestAdditionalInfo(CreateAddlnDocumentInput siebelRequest, UserDto userDto);
}
