package com.cgi.mas.provider.services.dto;

import java.util.Map;

public class ReceivedFileDto {
 
 
	private String fileName;
	private String siebelType;
	private String checkSum;
	private long fileSize;
	private String docTypeExists;
 
	public String getDocTypeExists() {
		return docTypeExists;
	}
	public void setDocTypeExists(String docTypeExists) {
		this.docTypeExists = docTypeExists;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getCheckSum() {
		return checkSum;
	}
	public String getSiebelType() {
		return siebelType;
	}
	public void setSiebelType(String siebelType) {
		this.siebelType = siebelType;
	}
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
}
