package com.cgi.mas.provider.services;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBConnectionPool;
import com.ibm.mm.beans.CMBException;
import com.ibm.mm.beans.CMBNoConnectionException;
import com.ibm.mm.sdk.server.DKDatastoreICM;

@Service
public class ECMConnectionService implements IECMConnectionService {
	private CustomLogger theLogger = new CustomLogger(ECMConnectionService.class);
	private Logger logger = theLogger.getLogger();
	private QICCustomLogger qicLogger = new QICCustomLogger(ECMConnectionService.class);
	private CMBConnectionPool connectionPool = null;
	private String serverName = null;
	private String dsType = null;
	
	private int usedConnections = 0;
	
	@Override
	public CMBConnectionPool createNewConnectionPool(String serverName, String dsType) {
		if(this.serverName == null) {
			if(serverName == null || serverName.length() == 0) {
				serverName = "";
			} else this.serverName = serverName;
		} else {
			serverName = this.serverName;
		}
		
		if(this.dsType == null) {
			if(dsType == null || dsType.length() == 0) {
				dsType = "";
			} else this.dsType = dsType;
		} else {
			dsType = this.dsType;
		}
		
		if(connectionPool != null) {
			logger.debug("Invalidating all old connections.");
			connectionPool.invalidatePool();
			logger.debug("Setting connection pool to null.");
			connectionPool = null;
		}
		
		if (connectionPool == null) {
			logger.debug("initialize Connection Pool from properties in IMGMASAPLINTAKEWS APP");
			try {
				Properties masConnectionProp  = new Properties();			
				InputStream inputStream = ClassUtils.getDefaultClassLoader().getResourceAsStream("MASConnectionPool.properties");
				masConnectionProp.load(inputStream);
				connectionPool = CMBConnectionPool.create(masConnectionProp);
//				connectionPool.setServerName(serverName);
				usedConnections = 0;
				logger.debug("ConnectionPool created from \"MASConnectionPool.properties\" file");
			} catch (Error e) {
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("Unable to create connection pool from properties. Reason: ");
				strBuilder.append(e.getMessage());
				logger.error(strBuilder.toString(), e);
				connectionPool = new CMBConnectionPool();
				connectionPool.setDsType(dsType);
//				connectionPool.setServerName(serverName);
				connectionPool.setMaxConnectionBehavior(CMBConnectionPool.CMB_MAX_CONNECTIONS_QUEUE);
			} catch (Exception e) {
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("Unable to create connection pool from properties. Reason: ");
				strBuilder.append(e.getMessage());
				logger.error(strBuilder.toString(), e);
				connectionPool = new CMBConnectionPool();
				connectionPool.setDsType(dsType);
//				connectionPool.setServerName(serverName);
				connectionPool.setMaxConnectionBehavior(CMBConnectionPool.CMB_MAX_CONNECTIONS_QUEUE);
			} 
		}
		
		return connectionPool;
	}
	
	@Override
	public CMBConnection getIBMConnectionFromPool(String userName, String password, String serverName, String dsType) {
		CMBConnection connection = null;
		long startTime = System.currentTimeMillis();
		
		int maxRetries = 2;
		for(int i=0; i<maxRetries; i++) {
			try {
				logger.debug("Call getIBMConnectionFromPool");
				
				if(connectionPool == null) createNewConnectionPool(serverName, dsType);
				
				connection = connectionPool.getConnection(serverName,userName, password);			
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("SessionId from pool: ");
				strBuilder.append(((DKDatastoreICM)connection.getDatastore()).getLSSessionId());
				strBuilder.append("-->UserName: ");
				strBuilder.append(userName);
				logger.debug(strBuilder.toString());
				theLogger.performanceStartOnly("getIBMConnectionFromPool", startTime);
				
				break;
			} catch (Error e) {			
	//			logger.error("ERROR Occured: " + e.getMessage(),e);
				if(connection != null)
					releaseIBMConnectionToPool(connection);
				
				if((i+1)<maxRetries) {
					logger.debug("+++++++ RECREATING THE CONNECTION POOL +++++++");
					createNewConnectionPool(null, null);
				} else
					logger.error("Unable to create connection to Content Manager Server. Please check all properties in WEB-INF directory; class loader for Application Server; user credentials", e);
			} catch (Exception e) {			
	//			logger.error("EXCEPTION Occured: " + e.getMessage(),e);
				if(connection != null)
					releaseIBMConnectionToPool(connection);
				
				if((i+1)<maxRetries) {
					logger.debug("+++++++ RECREATING THE CONNECTION POOL +++++++");
					createNewConnectionPool(null, null);
				} else
					logger.error("Unable to create connection to Content Manager Server. Please check all properties in WEB-INF directory; class loader for Application Server; user credentials", e);
			}
		}
		
		if (connection!= null){
			logger.debug("getConnectionFromPool id: "+connection.hashCode());
			usedConnections = usedConnections + 1;
			displayConnectionMonitor("getIBMConnectionFromPool");
			return (connection.isConnected()? connection : null);
		
		} else {
			logger.error("It should never come here");
			return null;
		}
	}

	@Override
	public CMBConnection releaseIBMConnectionToPool(CMBConnection con) {		
		logger.debug("Release connection to Pool");
		if(con != null) {
			connectionPool.freeConnection(con);	
			usedConnections = usedConnections - 1;
			displayConnectionMonitor("releaseIBMConnectionPool");
		} else {
			logger.error("Detect release empty connection to the pool");
		}
		
		return con;
	}
	
//	@Override
	public CMBConnection connectIBM(String userName, String password, String serverName, String dsType) {
		CMBConnection connection = null;
		try {
			logger.debug("UserName: "+userName);			
			connection = new CMBConnection();
			connection.setUserid(userName);
			connection.setPassword(password);
			connection.setServerName(serverName);
			connection.setDsType(dsType);
			connection.connect();			
		} catch (Error e) {
			logger.error("", e);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		if (connection.isConnected()){
			StringBuilder strBuilder = new StringBuilder ();
			strBuilder.append("Session Id: ");
			strBuilder.append(((DKDatastoreICM)connection.getDatastore()).getLSSessionId());
			logger.debug(strBuilder.toString());
			return connection;	
		} else {
			return null;
		}
	
	}

//	@Override
	public CMBConnection releaseIBMConnection(CMBConnection con) {
		logger.debug("Prepare to release IBM connection session");
		if ((con!=null)&&(con.isConnected())){
			try {
				StringBuilder strBuilder = new StringBuilder ();
				strBuilder.append("Session Id: ");
				strBuilder.append(((DKDatastoreICM)con.getDatastore()).getLSSessionId());
				con.disconnect();
				strBuilder.append("--Release successful");
				logger.debug(strBuilder.toString());
			} catch (CMBNoConnectionException e) {
				logger.error("", e.fillInStackTrace());				
			} catch (CMBException e) {
				logger.error("", e.fillInStackTrace());
			} catch (Error e) {
				logger.error("", e);
			} catch (Exception e) {
				logger.error("", e);
			}
		}
		con = null;
		return con;
	}
	
	
	private void displayConnectionMonitor(String message){
		logger.debug(message + " --> IntakeWS --> Connections in Pool: " + usedConnections);		
	}
	@Override
	public CMBConnectionPool createNewConnectionPool(String serverName, String dsType, long transactionId) {
		if(this.serverName == null) {
			if(serverName == null || serverName.length() == 0) {
				serverName = "";
			} else this.serverName = serverName;
		} else {
			serverName = this.serverName;
		}
		
		if(this.dsType == null) {
			if(dsType == null || dsType.length() == 0) {
				dsType = "";
			} else this.dsType = dsType;
		} else {
			dsType = this.dsType;
		}
		
		if(connectionPool != null) {
			qicLogger.debug(transactionId, "Invalidating all old connections.");
			connectionPool.invalidatePool();
			qicLogger.debug(transactionId, "Setting connection pool to null.");
			connectionPool = null;
		}
		
		if (connectionPool == null) {
 
			try {
				Properties masConnectionProp  = new Properties();		
				InputStream inputStream = ClassUtils.getDefaultClassLoader().getResourceAsStream("MASConnectionPool.properties");
				masConnectionProp.load(inputStream);
				connectionPool = CMBConnectionPool.create(masConnectionProp);
//				connectionPool.setServerName(serverName);
				usedConnections = 0;
				qicLogger.debug(transactionId, "ConnectionPool created from \"MASConnectionPool.properties\" file");
			} catch (Error e) {
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("Unable to create connection pool from properties. Reason: ");
				strBuilder.append(e.getMessage());
				qicLogger.error(transactionId, strBuilder.toString(), e);
				connectionPool = new CMBConnectionPool();
				connectionPool.setDsType(dsType);
				connectionPool.setServerName(serverName);
				connectionPool.setMaxConnectionBehavior(CMBConnectionPool.CMB_MAX_CONNECTIONS_QUEUE);
			} catch (Exception e) {
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("Unable to create connection pool from properties. Reason: ");
				strBuilder.append(e.getMessage());
				qicLogger.error(transactionId, strBuilder.toString(), e);
				connectionPool = new CMBConnectionPool();
				connectionPool.setDsType(dsType);
				connectionPool.setServerName(serverName);
				connectionPool.setMaxConnectionBehavior(CMBConnectionPool.CMB_MAX_CONNECTIONS_QUEUE);
			} 
		}
		
		return connectionPool;
	}
	
	@Override
	public CMBConnection getIBMConnectionFromPool(String userName, String password, String serverName, String dsType, long transactionId) {
		CMBConnection connection = null;
		long startTime = System.currentTimeMillis();
		
		int maxRetries = 2;
		for(int i=0; i<maxRetries; i++) {
			try {
				//logger.debug("Call getIBMConnectionFromPool");
				
				if(connectionPool == null) createNewConnectionPool(serverName, dsType, transactionId);
				
				connection = connectionPool.getConnection(serverName,userName, password);			
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("Retrieving ECM Conenction from pool for session ID: ");
				strBuilder.append(((DKDatastoreICM)connection.getDatastore()).getLSSessionId());
				strBuilder.append(" and UserName: ");
				strBuilder.append(userName);
				qicLogger.debug(transactionId, strBuilder.toString());
				qicLogger.performanceStartOnly(transactionId, "getIBMConnectionFromPool", startTime);
				
				break;
			} catch (Error e) {			
				qicLogger.error(transactionId, "Erro while getting connection from pool: " + e.getMessage(),e);
				if(connection != null)
					releaseIBMConnectionToPool(connection, transactionId);
				
				if((i+1)<maxRetries) {
					qicLogger.debug(transactionId, "Recreating the connection pool");
					createNewConnectionPool(null, null, transactionId);
				} else
				{
					qicLogger.error(transactionId, "Unable to create connection to Content Manager Server. Please check all properties in WEB-INF directory; class loader for Application Server; user credentials", e);
				}
			} catch (Exception e) {			
				qicLogger.error(transactionId, "Exception while getting ECM connection from pool: " + e.getMessage() );
				if(connection != null)
					releaseIBMConnectionToPool(connection, transactionId);
				
				if((i+1)<maxRetries) {
					qicLogger.debug(transactionId, "Recreating the connection pool");
					createNewConnectionPool(null, null, transactionId);
				} else
				{
					qicLogger.error(transactionId, "Unable to create connection to Content Manager Server. Please check all properties in WEB-INF directory; class loader for Application Server; user credentials", e);
				}
			}
		}
		
		if (connection!= null){
			qicLogger.debug(transactionId, "getConnectionFromPool id: "+connection.hashCode());
			usedConnections = usedConnections + 1;
			logConnectionPoolStatus("getIBMConnectionFromPool", transactionId);
			return (connection.isConnected()? connection : null);
		
		} else {
			qicLogger.error(transactionId, "Connection should never be NULL");
			return null;
		}
	}

	@Override
	public CMBConnection releaseIBMConnectionToPool(CMBConnection con, long transactionId) {		
		qicLogger.debug(transactionId, "Release connection to Pool");
		if(con != null) {
			connectionPool.freeConnection(con);	
			usedConnections = usedConnections - 1;
			logConnectionPoolStatus("releaseIBMConnectionPool", transactionId);
		} else {
			qicLogger.error(transactionId, "Detect release empty connection to the pool");
		}
		
		return con;
	}
	
//	@Override
	public CMBConnection connectIBM(String userName, String password, String serverName, String dsType, long transactionId) {
		CMBConnection connection = null;
		try {
			qicLogger.debug(transactionId, "Connecting to ECM for Username: "+userName);			
			connection = new CMBConnection();
			connection.setUserid(userName);
			connection.setPassword(password);
			connection.setServerName(serverName);
			connection.setDsType(dsType);
			connection.connect();			
		} catch (Error e) {
			qicLogger.error(transactionId, "Error while connecting to ECM", e);
		} catch (Exception e) {
			qicLogger.error(transactionId, "Exception while connecting to ECM", e);
		}
		
		if (connection.isConnected()){
			StringBuilder strBuilder = new StringBuilder ();
			strBuilder.append("Got ECM Connection Session Id: ");
			strBuilder.append(((DKDatastoreICM)connection.getDatastore()).getLSSessionId());
			qicLogger.debug(transactionId, strBuilder.toString());
			return connection;	
		} else {
			return null;
		}
	
	}

//	@Override
	public CMBConnection releaseIBMConnection(CMBConnection con, long transactionId) {
		qicLogger.debug(transactionId, "Prepare to release IBM connection session");
		if ((con!=null)&&(con.isConnected())){
			try {
				StringBuilder strBuilder = new StringBuilder ();
				strBuilder.append("Session Id: ");
				strBuilder.append(((DKDatastoreICM)con.getDatastore()).getLSSessionId());
				con.disconnect();
				strBuilder.append("--Release successful");
				qicLogger.debug(transactionId, strBuilder.toString());
			} catch (CMBNoConnectionException e) {
				qicLogger.error(transactionId, "releaseIBMConnection Exception", e );				
			} catch (CMBException e) {
				qicLogger.error(transactionId, "releaseIBMConnection Exception", e );
			} catch (Error e) {
				qicLogger.error(transactionId, "releaseIBMConnection Error", e);
			} catch (Exception e) {
				qicLogger.error(transactionId, "releaseIBMConnection Exception", e);
			}
		}
		con = null;
		return con;
	}
	
	
	private void logConnectionPoolStatus(String message, long transactionId){
		qicLogger.debug(transactionId, message + " --> Level3WS --> Connections in Pool: " + usedConnections);		
	}


	}
