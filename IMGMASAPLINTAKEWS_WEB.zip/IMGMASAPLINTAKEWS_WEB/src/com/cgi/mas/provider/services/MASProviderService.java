package com.cgi.mas.provider.services;

import java.util.List;
import java.util.Locale;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import com.cgi.cms.services.schema.mas.Claim;
import com.cgi.cms.services.schema.mas.ClaimList;
import com.cgi.cms.services.schema.mas.CreateAppealRequest;
import com.cgi.cms.services.schema.mas.CreateAppealResponse;
import com.cgi.cms.services.schema.mas.DocumentDetail;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.cms.services.schema.mas.MessageDetail;
import com.cgi.cms.services.schema.mas.MessageList;
import com.cgi.cms.services.schema.mas.Org;
import com.cgi.cms.services.schema.mas.ReceiveAdditionalInfoRequest;
import com.cgi.cms.services.schema.mas.ReceiveAdditionalInfoResponse;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.dto.UserDto;
import com.cgi.mas.provider.validations.CreateAppealDocValidator;
import com.cgi.mas.provider.validations.RequestAdditionalInfoValidator;
import com.cgi.services.mas.AppealIntakeWebServiceImpl;
import com.cgi.services.mas.CreateAppealException;
import com.cgi.services.mas.ReceiveAdditionalInfoException;
import com.siebel.customui.CreateAddlnDocumentInput;
import com.siebel.customui.CreateAddlnDocumentOutput;
import com.siebel.customui.CreateAutoAppealInput;
import com.siebel.customui.CreateAutoAppealOutput;
import com.siebel.customui.CreateDocErrorLogInput;
import com.siebel.customui.UserAuthenticationInput;
import com.siebel.customui.UserAuthenticationOutput;
import com.siebel.xml.mas_20bc_20bip_20claim_20bene.L1ClaimLists;
import com.siebel.xml.mas_20bc_20bip_20claim_20bene.ListOfL1ClaimList;
import com.siebel.xml.mas_20l1_20ecm_20bc.ClaimNumberList;
import com.siebel.xml.mas_20l1_20ecm_20bc.HICNumberList;
import com.siebel.xml.mas_20l1_20ecm_20bc.L1DocumentList;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfClaimNumbers;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfHICNumbers;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfL1Documentlist;

@Service
public class MASProviderService extends AppealIntakeWebServiceImpl {	
	public MASProviderService() {
		theLogger.setConstantConfig(constantConfig);
		logger.debug("Version: " + ProviderConstants.VERSION);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cgi.services.mas.AppealIntakeWebServiceImpl#createAppeal(com.cgi.cms.services.schema.mas.CreateAppealRequest)
	 * This is the implementation of the web service method to create a new appeal in MAS
	 */
	@Override
	public CreateAppealResponse createAppeal(CreateAppealRequest request) throws CreateAppealException {		
		long startTime = System.currentTimeMillis();
		logger.debug("********Invoking CreateAppeal "+ ProviderConstants.VERSION);	
		CreateAppealResponse response = new CreateAppealResponse();
		Vector<CreateDocErrorLogInput> docErrorLogsVect = null;
		logger.debug("*********createAppealFolder****");
		
		BindException bindingException = new BindException(request, "CreateAppealRequest");
		createAppealValidator.validate(request, bindingException);		
		if (bindingException.hasErrors()){					
			MessageList messageList = new MessageList();
			List<ObjectError> errorList = bindingException.getAllErrors();
			StringBuilder errorStrBuilder = new StringBuilder();						
			for (ObjectError error: errorList){
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorStrBuilder.append(error.getDefaultMessage());
				errorStrBuilder.append("\n");				
				errorMessageDetail.setErrorCode(error.getCode());
				errorMessageDetail.setErrorMessage(error.getDefaultMessage());
				messageList.getErrorMessage().add(errorMessageDetail);
			}
			logger.error("Detect request problem: "+errorStrBuilder.toString());			
			response.setAppealNumber(null);
			response.setStatus(false);
			response.setMessageList(messageList);			
			return response;
		}
		
		try {
			MessageList messageList = new MessageList();	
			Org org = request.getOrg();		
			UserDto userAccount = getSiebelUserAccount(org);
			String siebelAppealFolder = null;
			
			if(userAccount!= null) { //Validate user information
				
				String securityToken = request.getToken();
				String siebelPwd = userAccount.getSiebelPassWord();
				
				// validate the security token only if it was provided
				// this should be made mandatory in a future release
				if (securityToken != null)
				{
					if (securityToken.length() > 0)
					{
						if (securityToken.compareTo(siebelPwd) != 0)
						{
							// password does not match -> throw exception
							logger.debug("Security token for org " + userAccount.getOrg() + " was provided but does not match the Siebel token. User has provided this value: "+ securityToken);
				
							MessageDetail errorMessageDetail = new MessageDetail();				
							errorMessageDetail.setErrorCode(ErrorFieldConstant.INVALID_SECURITY_TOKEN);
							errorMessageDetail.setErrorMessage("Data validation failed.");
							
							messageList.getErrorMessage().add(errorMessageDetail);
							
							response.setAppealNumber(null);
							response.setStatus(false);
							response.setMessageList(messageList);			
							return response;
						}
					}
				}
				
				Object[] returnedItems = setupCreateAutoAppealSiebelRequest(request, bindingException);
				CreateAutoAppealInput createAutoAppealInput = (CreateAutoAppealInput)returnedItems[0];
				docErrorLogsVect = (Vector<CreateDocErrorLogInput>)returnedItems[1];
				CreateAutoAppealOutput siebelWSResponse = siebelService.createAppeal(createAutoAppealInput, userAccount);

				siebelAppealFolder = siebelWSResponse.getAppealNumber();
				String siebelStatus = siebelWSResponse.getStatus();
				String siebelErrorMessage = siebelWSResponse.getErrorMsg();
				logger.debug("Siebel Error Message: "+siebelErrorMessage);
				logger.debug("Siebel status: "+siebelStatus);
				String siebelErrorMessageLogging = "";
				if(StringUtils.hasText(siebelErrorMessage)) {
					MessageDetail errorMessageDetail = new MessageDetail();
					errorMessageDetail.setErrorCode(ErrorFieldConstant.S_GENERAL_CODE);
					errorMessageDetail.setErrorMessage(siebelErrorMessage);
					messageList.getErrorMessage().add(errorMessageDetail);
					
					CreateDocErrorLogInput docErrorLogInput = new CreateDocErrorLogInput();
					docErrorLogInput.setAppealNumber(siebelAppealFolder);
					docErrorLogInput.setErrorCode(ErrorFieldConstant.S_GENERAL_CODE);
					docErrorLogInput.setErrorMsg(siebelErrorMessage);
					
					docErrorLogsVect.add(docErrorLogInput);
					siebelErrorMessageLogging = " -->"+siebelErrorMessage;
				}
				
				if(bindingException.hasErrors()){
					List<ObjectError> errorList = bindingException.getAllErrors();
					StringBuilder errorStrBuilder = new StringBuilder();						
					for(ObjectError error: errorList) {
						MessageDetail errorMessageDetail = new MessageDetail();				
						errorStrBuilder.append(error.getDefaultMessage());
						errorStrBuilder.append("\n");				
						errorMessageDetail.setErrorCode(error.getCode());
						errorMessageDetail.setErrorMessage(error.getDefaultMessage());
						messageList.getErrorMessage().add(errorMessageDetail);
					}
					
					logger.error("Detect create auto appeal request problem: "+errorStrBuilder.toString());
				}
				
				logger.debug("Appeal number: "+siebelAppealFolder+" -->"+siebelStatus + "--Siebel error: "+siebelErrorMessageLogging);
			} else {
				MessageDetail errorMessageDetail = new MessageDetail();
				String errorMessage = messageSource.getMessage(ErrorFieldConstant.INVALID_ORG_CODE, new String[] {org.getMac(), org.getJurisdiction() },  Locale.US);
				errorMessageDetail.setErrorCode(ErrorFieldConstant.INVALID_ORG_CODE);
				errorMessageDetail.setErrorMessage(errorMessage);

				messageList.getErrorMessage().add(errorMessageDetail);
			}
			
			if(docErrorLogsVect != null && docErrorLogsVect.size() > 0) {
				for(CreateDocErrorLogInput errors : docErrorLogsVect) {
					errors.setAppealNumber(siebelAppealFolder);
				}
				
				siebelService.createSiebelDocError(docErrorLogsVect, false);
			}
			response.setAppealNumber(siebelAppealFolder);			
			response.setMessageList(messageList);
			response.setStatus(StringUtils.hasText(siebelAppealFolder));
			
			theLogger.performanceStartOnly("createAppeal", startTime);
			
			return response;
		} catch(Error e) {
			logger.error("--CreateAppealError ", e);
			throw new CreateAppealException(e.getMessage(), e);
		} catch(Exception e) {
			logger.error("--CreateAppealException ", e);
			throw new CreateAppealException(e.getMessage(), e);
		}
	}
	
	
	@Override
	public ReceiveAdditionalInfoResponse receiveAdditionalInfo(ReceiveAdditionalInfoRequest request) 
		throws ReceiveAdditionalInfoException {		
		long startTime = System.currentTimeMillis();
		//CMBConnection ibmSession=null;
		logger.debug("********Invoking ReceiveAdditionalInfo " + ProviderConstants.VERSION);	
		ReceiveAdditionalInfoResponse response = new ReceiveAdditionalInfoResponse();
		Vector<CreateDocErrorLogInput> docErrorLogsVect = null;
		String appealNumber = request.getAppealNumber();
		boolean status = false;
		UserDto userAccount = null;
		BindException bindingException = new BindException(request, "ReceiveAdditionalInfoRequest");
		requestAdditionalInfoValidator.validate(request, bindingException);		
		if (bindingException.hasErrors()){					
			MessageList messageList = new MessageList();
			List<ObjectError> errorList = bindingException.getAllErrors();
			StringBuilder errorStrBuilder = new StringBuilder();						
			for (ObjectError error: errorList){
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorStrBuilder.append(error.getDefaultMessage());
				errorStrBuilder.append("\n");				
				errorMessageDetail.setErrorCode(error.getCode());
				errorMessageDetail.setErrorMessage(error.getDefaultMessage());
				messageList.getErrorMessage().add(errorMessageDetail);
			}

			logger.error("Detect problem in the request: " + errorStrBuilder.toString());
			response.setAppealNumber(appealNumber);
			response.setStatus(status);
			response.setMessageList(messageList);			
			return response;
		}
			
		try {									
			MessageList messageList = new MessageList();	
			Org org = request.getOrg();			
			userAccount = getSiebelUserAccount(request.getOrg());
			//UserDto userAccount = resourceDto.getUserAccount();
			//ibmSession= getConnection(userAccount);
					
			
			if(userAccount!= null){ //Validate user information
				
				String securityToken = request.getToken();
				String siebelPwd = userAccount.getSiebelPassWord();
				
				// validate the security token only if it was provided
				// this should be made mandatory in a future release
				if (securityToken != null)
				{
					if (securityToken.length() > 0)
					{
						if (securityToken.compareTo(siebelPwd) != 0)
						{
							// password does not match -> throw exception
							logger.debug("Security token for org " + userAccount.getOrg() + " was provided but does not match the Siebel token. User has provided this value: "+ securityToken);
				
							MessageDetail errorMessageDetail = new MessageDetail();				
							errorMessageDetail.setErrorCode(ErrorFieldConstant.INVALID_SECURITY_TOKEN);
							errorMessageDetail.setErrorMessage("Data validation failed.");
							
							messageList.getErrorMessage().add(errorMessageDetail);
							
							response.setAppealNumber(null);
							response.setStatus(false);
							response.setMessageList(messageList);			
							return response;
						}
					}
				}
				
				Object[] returnedItems = setupRequestAddiInfoSiebelRequest(request, bindingException);
				CreateAddlnDocumentInput createAddlnDocumentInput = (CreateAddlnDocumentInput)returnedItems[0];
				docErrorLogsVect = (Vector<CreateDocErrorLogInput>)returnedItems[1];
				CreateAddlnDocumentOutput siebelWSResponse = siebelService.requestAdditionalInfo(createAddlnDocumentInput, userAccount);
				
				String siebelStatus = siebelWSResponse.getStatus();
				String siebelErrorMessage = siebelWSResponse.getErrorMsg();
				if (StringUtils.hasText(siebelErrorMessage)){
					MessageDetail errorMessageDetail = new MessageDetail();
					errorMessageDetail.setErrorCode(ErrorFieldConstant.S_GENERAL_CODE);
					errorMessageDetail.setErrorMessage(siebelErrorMessage);
					messageList.getErrorMessage().add(errorMessageDetail);					
					if(!siebelErrorMessage.contains("invalid document type")){
					CreateDocErrorLogInput docErrorLogInput = new CreateDocErrorLogInput();
					docErrorLogInput.setAppealNumber(appealNumber);
					docErrorLogInput.setErrorCode(ErrorFieldConstant.S_GENERAL_CODE);
					docErrorLogInput.setErrorMsg(siebelErrorMessage);										
					docErrorLogsVect.add(docErrorLogInput);
					}
				}
				
				if (bindingException.hasErrors()){
					List<ObjectError> errorList = bindingException.getAllErrors();
					StringBuilder errorStrBuilder = new StringBuilder();						
					for (ObjectError error: errorList){
						MessageDetail errorMessageDetail = new MessageDetail();				
						errorStrBuilder.append(error.getDefaultMessage());
						errorStrBuilder.append("\n");				
						errorMessageDetail.setErrorCode(error.getCode());
						errorMessageDetail.setErrorMessage(error.getDefaultMessage());
						messageList.getErrorMessage().add(errorMessageDetail);
					}
					logger.error("Detect receive additional information request problem: "+errorStrBuilder.toString());
				}
				logger.debug("Appeal number: "+appealNumber+" --> "+siebelStatus+" --> "+siebelErrorMessage);
			} else {
				MessageDetail errorMessageDetail = new MessageDetail();
				String errorMessage = messageSource.getMessage(ErrorFieldConstant.INVALID_ORG_CODE, new String[] {org.getMac(), org.getJurisdiction() },  Locale.US);
				errorMessageDetail.setErrorCode(ErrorFieldConstant.INVALID_ORG_CODE);
				errorMessageDetail.setErrorMessage(errorMessage);
				messageList.getErrorMessage().add(errorMessageDetail);
			}
			
			if(docErrorLogsVect != null && docErrorLogsVect.size() > 0) {
				for(CreateDocErrorLogInput errors : docErrorLogsVect) {
					errors.setAppealNumber(appealNumber);
				}
				
				siebelService.createSiebelDocError(docErrorLogsVect, false);
			}
			
			if (messageList.getErrorMessage().size() == 0) {
				//Validation to see if ECM folder exists or not
				//CMBItem appealFolder = ecmService.getAppeal(ibmSession, request.getAppealNumber());
				boolean folderExists = ecmService.appealFolderExists(userAccount.getEcmUserName(), userAccount.getEcmPassword(), request.getAppealNumber() );
				
				if (folderExists == false) {
					MessageList messageList1 = new MessageList();
					MessageDetail errorMessageDetail = new MessageDetail();
					errorMessageDetail
							.setErrorCode(ErrorFieldConstant.APPEAL_FOLDER_DOESNOT_EXIST);
					errorMessageDetail.setErrorMessage(messageSource
							.getMessage("ecm.invalid.appeal",
									new String[] { appealNumber }, Locale.US));
					messageList1.getErrorMessage().add(errorMessageDetail);
					response.setAppealNumber(appealNumber);
					response.setStatus(status);
					response.setMessageList(messageList1);
					return response;
				}
			}
			response.setAppealNumber(appealNumber);			
			response.setMessageList(messageList);			
			response.setStatus(messageList.getErrorMessage().isEmpty());
			
			theLogger.performanceStartOnly("receiveAdditionalInfo", startTime);			
			return response;
		} catch(Error e) {
			logger.error("--ReceiveAdditionalInfoError ", e);
			throw new ReceiveAdditionalInfoException(e.getMessage(), e);
		} catch(Exception e) {
			logger.error("--ReceiveAdditionalInfoException ", e);
			throw new ReceiveAdditionalInfoException(e.getMessage(), e);
		}
		finally{
			//ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
		}
	}


	//*********************Private Method
	private CustomLogger theLogger = new CustomLogger(MASProviderService.class);
	private Logger logger = theLogger.getLogger();
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ISiebelService siebelService;
	
	@Autowired
	private ConstantConfig constantConfig;
	
	//@Autowired
	//private IECMConnectionService ecmConnectionService;
	
	//@Autowired
	//private BatchLauncher batchLauncher;
	
	@Autowired
	private CreateAppealDocValidator createAppealValidator;
	
	//@Autowired
	//private TaskCleaner taskCleaner; 
	
	@Autowired
	private RequestAdditionalInfoValidator requestAdditionalInfoValidator;
	
	@Autowired
	private IECMService ecmService;
	
	/*private CreateAppealDocRecord1Input setupSiebelCreateDocRequest(String appealNumber,List<DocumentResultDto> docList){
		CreateAppealDocRecord1Input request = new CreateAppealDocRecord1Input();
		ImportL1DocAppealRequest l1Request = new ImportL1DocAppealRequest();
		l1Request.setAppealNumber(appealNumber);
		for (DocumentResultDto ecmDoc : docList){
			DocumentList siebelDoc = new DocumentList();
			siebelDoc.setFileName(ecmDoc.getFileName());
			siebelDoc.setItemId(ecmDoc.getEcmItemId());
			siebelDoc.setFileSize(String.valueOf(ecmDoc.getSize()/1024)); //in KB
			siebelDoc.setPageCount(ecmDoc.getPageCount());			
			l1Request.getDocumentList().add(siebelDoc);
		}
		
		
		
		request.setImportL1DocAppealRequest(l1Request);
		return request;
	}
	
	private CreateAutoAppealOutput setupSiebelCreateDocRequest(String appealNumber,List<DocumentResultDto> docList){
		CreateAutoAppealOutput request = new CreateAutoAppealOutput();	
		
		
		return request;
	}
	*/
	
	private Object[] setupCreateAutoAppealSiebelRequest(CreateAppealRequest request, BindException bindingException){
		CreateAutoAppealInput input = new CreateAutoAppealInput();
		Vector<CreateDocErrorLogInput> errorLogsVector = new Vector<CreateDocErrorLogInput>();
		
		input.setRequestDate(ProviderUtils.convertCalendarToString(request.getRequestDate(),ProviderConstants.S_DT_FORMAT));
		
		DocumentList requestDocList = request.getDocumentList();
		
		createAppealValidator.validate_docs(request, bindingException);
		
		ListOfL1Documentlist documentList = setupDocumentList(requestDocList, errorLogsVector, bindingException);

		input.setListOfL1Documentlist(documentList);
		
		String contractNumber = request.getContractNumber();
		if(contractNumber != null) input.setContractNumber(contractNumber);
		
		ClaimList requestClaimList = request.getClaimList();
		ListOfL1ClaimList claimList = setupClaimsList(requestClaimList, errorLogsVector);
		
		input.setListOfL1ClaimList(claimList);
		
		Object[] returnItems = new Object[2];
		returnItems[0] = input;
		returnItems[1] = errorLogsVector;
		
		return returnItems;
	}
	
	private Object[] setupRequestAddiInfoSiebelRequest(ReceiveAdditionalInfoRequest request, BindException bindingException){
		CreateAddlnDocumentInput input = new CreateAddlnDocumentInput();
		Vector<CreateDocErrorLogInput> errorLogsVector = new Vector<CreateDocErrorLogInput>();
		
		input.setAppealNumber(request.getAppealNumber());
		
		DocumentList requestDocList = request.getDocumentList();
		
		//requestAdditionalInfoValidator.validate_docs(request, bindingException);
		
		ListOfL1Documentlist documentList = setupDocumentList(requestDocList, errorLogsVector, bindingException);
		
		input.setListOfL1Documentlist(documentList);
		
		Object[] returnItems = new Object[2];
		returnItems[0] = input;
		returnItems[1] = errorLogsVector;
		
		return returnItems;
	}
	
	private ListOfL1ClaimList setupClaimsList(ClaimList requestClaimList, Vector<CreateDocErrorLogInput> errorLogsVector) {
		ListOfL1ClaimList claimList = new ListOfL1ClaimList();
		
		if(requestClaimList != null) {
			List<Claim> requestClaimArray = requestClaimList.getClaim();
			
			for(Claim claim : requestClaimArray) {
				L1ClaimLists l1Claim = new L1ClaimLists();
				l1Claim.setClaimNumber(claim.getClaimNumber());
				l1Claim.setHICNumber(claim.getHicNumber());
				
				claimList.getL1ClaimLists().add(l1Claim);
			}
//			String contractNumber = request.getContractNumber();
//			if(contractNumber != null) input.setContractNumber(contractNumber);
		}
		
		return claimList;
	}
	
	private ListOfL1Documentlist setupDocumentList(DocumentList requestDocList, Vector<CreateDocErrorLogInput> errorLogsVector, BindException bindingException) {
		ListOfL1Documentlist documentList = new ListOfL1Documentlist();
		
		if(requestDocList != null) {
			List<DocumentDetail> requestDocArray = requestDocList.getDocument();
			int totalDoc = requestDocArray.size();
			logger.debug("Total Number of Docs: " + totalDoc);
			Vector<String> multiFileIds = new Vector<String>();
			ConcurrentHashMap<String, Integer> fileIdsCheckList = new ConcurrentHashMap<String, Integer>();
			for (DocumentDetail requestDoc : requestDocArray){					
				L1DocumentList doc = new L1DocumentList();
				String fileId = requestDoc.getFileId();				
				doc.setFileId(fileId);
				doc.setChecksum(requestDoc.getChecksum());
				doc.setType(requestDoc.getType());		
				

				
				if(requestDoc.getListOfClaimNumbers() != null) {
				ListOfClaimNumbers claimNumberList = new ListOfClaimNumbers();
					List<String> requestClaimArray = requestDoc.getListOfClaimNumbers().getClaimNumber();
					
					for(String  claimNumber : requestClaimArray) {
						ClaimNumberList l1Claim = new ClaimNumberList();
						l1Claim.setClaimNumber(claimNumber);						
						claimNumberList.getClaimNumberList().add(l1Claim);
					}					
					doc.setListOfClaimNumbers(claimNumberList);
					
				}
				if(requestDoc.getListOfHICNumbers() != null) {
								ListOfHICNumbers hicNumberList = new ListOfHICNumbers();
					List<String> requestHICArray = requestDoc.getListOfHICNumbers().getHicNumber();
					
					for(String  hicNumber : requestHICArray) {
						HICNumberList l1hic = new HICNumberList();
						l1hic.setHICNumber(hicNumber);						
						hicNumberList.getHICNumberList().add(l1hic);
					}
					doc.setListOfHICNumbers(hicNumberList);
				}
				
				String originalFileName = requestDoc.getFileName();
				StringBuilder origFileNameSb = new StringBuilder();
				for(int ind=0; ind<originalFileName.length(); ind++) {
					String origChar = originalFileName.substring(ind, ind+1);
					if(origChar.matches("[A-z0-9\\.\\s]")) origFileNameSb.append(origChar);
				}
				
				originalFileName = origFileNameSb.toString();
				doc.setFileName(originalFileName);
						
				documentList.getL1DocumentList().add(doc);
				StringBuilder strBuilder = new StringBuilder();
				strBuilder.append("FileId: ");
				strBuilder.append(doc.getFileId());
				strBuilder.append("-->FileName:");
				strBuilder.append(doc.getFileName());
				strBuilder.append("-->CheckSum:");
				strBuilder.append(doc.getChecksum());
				strBuilder.append("-->Type:");
				strBuilder.append(doc.getType());
				logger.debug("Doc: "+strBuilder.toString());
			
		}}
		
		return documentList;
	}
	
	
	/**
	 * Retrieve siebel and ecm user account base on org. 
	 * @param org
	 * @return {@link UserDto}. Return null if detect any errors
	 */
	private UserDto getSiebelUserAccount(Org org){
		UserAuthenticationInput input = new UserAuthenticationInput();
		UserDto userAccount = new UserDto();
		logger.debug("---Calling GetUserAccount: ");
		logger.debug("MAC: "+org.getMac());
		logger.debug("Jurisdiciton: "+org.getJurisdiction());
		input.setJurisdiction(org.getJurisdiction());
		input.setMac(org.getMac());
		UserAuthenticationOutput output = siebelService.getUserAccount(input);
		String errorMessage = output.getErrorMsg();
		if(StringUtils.hasText(errorMessage)) {
			logger.error("--Got Error while trying to retrieve user account: " + errorMessage);
			return null;
		} else {
			userAccount.setEcmUserName(output.getEcmUserId());
			userAccount.setEcmPassword(output.getEcmUserPassword());
			userAccount.setSiebelPassWord(output.getUserPassword());
			userAccount.setSiebelUserId(output.getUserId());
			userAccount.setMac(org.getMac());
			userAccount.setJurisdiction(org.getJurisdiction());
			userAccount.setLoginUserId(output.getLoginUserId());
			return userAccount;			
		}
		
		
	}
	


/*
	
	private CMBConnection getConnection(UserDto userAccount){
		CMBConnection session = null;
		try{			
			session = ecmConnectionService.getIBMConnectionFromPool(userAccount.getEcmUserName(), userAccount.getEcmPassword(), constantConfig.getEcmServerName(), constantConfig.getEcmServerType());
			//session.startTransaction();
			return session;
		} catch(Error e) {
			logger.error("Unable to get connection ", e);
			return null;
		} catch(Exception e) {
			logger.error("Unable to get connection ", e);
			return null;
		}
		
	}
*/
	
}
