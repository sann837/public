package com.cgi.mas.provider.services.dto;

import com.siebel.xml.mas_20validate_20documents_20response_20io.Appeal;

public class QicAppeal {
	public Appeal appeal = null;
	public int status = 0;
	public String errCode = "";
	public String errMsg = "";
}
