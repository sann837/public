package com.cgi.mas.provider.services;

import com.siebel.racappealvalidation.ValidateTransctnId1Input;
import com.siebel.racappealvalidation.ValidateTransctnId1Output;

public interface ISiebelRACService {

	
	ValidateTransctnId1Output validateRACAppeal(ValidateTransctnId1Input input);
}
