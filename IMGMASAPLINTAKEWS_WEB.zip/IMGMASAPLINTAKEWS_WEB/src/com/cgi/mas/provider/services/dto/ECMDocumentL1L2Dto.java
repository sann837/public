package com.cgi.mas.provider.services.dto;

//import java.io.InputStream;
import java.util.Map;

public class ECMDocumentL1L2Dto {	
	private String appealNumber;
	private String entityName;
	private Map<String,String>attributeMap;
	private String fileFolder;
	private String fileName;
	private String fileExtension;
	private String mimeType;
	private long fileSize;
	private String siebelId;
	private String checkSum;
	
	public String getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getFileFolder() {
		return fileFolder;
	}
	public void setFileFolder(String fileFolder) {
		this.fileFolder = fileFolder;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileExtension() {
		return fileExtension;
	}
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
	public String getAppealNumber() {
		return appealNumber;
	}
	public void setAppealNumber(String appealNumber) {
		this.appealNumber = appealNumber;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public Map<String, String> getAttributeMap() {
		return attributeMap;
	}
	public void setAttributeMap(Map<String, String> attributeMap) {
		this.attributeMap = attributeMap;
	}
	public String getSiebelId() {
		return siebelId;
	}
	public void setSiebelId(String siebelId) {
		this.siebelId = siebelId;
	}
}
