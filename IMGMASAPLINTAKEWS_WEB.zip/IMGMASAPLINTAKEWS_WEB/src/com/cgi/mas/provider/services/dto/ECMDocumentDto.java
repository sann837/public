package com.cgi.mas.provider.services.dto;

import java.io.InputStream;
import java.util.Map;

public class ECMDocumentDto {	
	private String appealNumber;
	/**
	 * Document Type level1
	 */
	private String entityName;
	private Map<String,String>attributeMap;
	private InputStream contentInputStream;
	private String contentLocation;
	private String fileName;
	private String fileExtension;
	private String mimeType;
	private long fileSize;
	
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	public String getContentLocation() {
		return contentLocation;
	}
	public void setContentLocation(String contentLocation) {
		this.contentLocation = contentLocation;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileExtension() {
		return fileExtension;
	}
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
	public String getAppealNumber() {
		return appealNumber;
	}
	public void setAppealNumber(String appealNumber) {
		this.appealNumber = appealNumber;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public Map<String, String> getAttributeMap() {
		return attributeMap;
	}
	public void setAttributeMap(Map<String, String> attributeMap) {
		this.attributeMap = attributeMap;
	}
	public InputStream getContentInputStream() {
		return contentInputStream;
	}
	public void setContentInputStream(InputStream contentInputStream) {
		this.contentInputStream = contentInputStream;
	}
	
}
