package com.cgi.mas.provider.services;


import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.apache.log4j.Logger;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;
import org.apache.ws.security.util.WSSecurityUtil;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import com.cgi.cms.l2services.schema.mas.CreateL2AppealRequest;
import com.cgi.cms.l2services.schema.mas.CreateL2AppealResponse;
import com.cgi.cms.l2services.schema.mas.MessageDetail;
import com.cgi.cms.l2services.schema.mas.MessageList;
import com.cgi.services.mas.TestAppealException;
import com.cgi.cms.l2services.schema.mas.TestAppealRequest;
import com.cgi.cms.l2services.schema.mas.TestAppealResponse;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.QICCustomLogger;
import com.cgi.mas.provider.services.dto.UserDto;
import com.cgi.mas.provider.util.Util;
import com.cgi.mas.provider.validations.CreateL2AppealValidator;
import com.cgi.mas.provider.validations.TestAppealValidator;
import com.cgi.services.mas.CreateL2AppealException;
import com.cgi.services.mas.QICL2WebserviceImpl;
import com.siebel.masl2autoappeal.CreateL2AutoAppealInput;
import com.siebel.masl2autoappeal.GetL2AppealDocumentsOutput;
import com.siebel.masl2autoappeal.L2UserAuthenticationInput;
import com.siebel.masl2autoappeal.L2UserAuthenticationOutput;
import com.siebel.xml.mas_20l2_20appeal_20partcd_20io.Appeal;
import com.siebel.xml.mas_20l2_20appeal_20partcd_20io.ListOfMasL2AppealPartcdIo;
 

 
@Service
public class QICServiceProvider extends QICL2WebserviceImpl 
{	
	//*********************Private Method
	private QICCustomLogger theLogger = new QICCustomLogger(QICServiceProvider.class);
	private Logger logger = theLogger.getQicLogger();

	@Autowired
	private ISiebelL2Service siebelService;
	@Autowired
	private ConstantConfig constantConfig;	
	 
	
	@Autowired
	private CreateL2AppealValidator createL2AppealValidator;
	
	@Autowired
	private TestAppealValidator testAppealValidator;
	
	@Autowired
	private MessageSource messageSource;
	
	@Resource
    private WebServiceContext context;
	
	@Autowired
	private IECMService ecmService;
	
	private String errorCode ;
	private String errorMsg;
	
	public QICServiceProvider() {
		theLogger.setConstantConfig(constantConfig);
		//logger.debug("Version: " + ProviderConstants.VERSION);
	}
	
		
		@SuppressWarnings("unchecked")
		private String getPublicKey(WebServiceContext context)
	{
		String stringPk = null;
		
		try
		{
		MessageContext msgCtx = context.getMessageContext(); 
		HttpServletRequest httpSR = (HttpServletRequest)msgCtx.get(MessageContext. SERVLET_REQUEST ); 
		
		if (httpSR != null)
		{
			List<WSHandlerResult> handlerResults = (List<WSHandlerResult>) msgCtx.get(WSHandlerConstants.RECV_RESULTS);
			
			if (handlerResults != null)
			{
				WSHandlerResult rResult = handlerResults.get(0);
			    
			    if (rResult != null)
			    {
			    
				    List<WSSecurityEngineResult> results = rResult.getResults();
		
				   if (results != null)
				    {
					    WSSecurityEngineResult actionResult = WSSecurityUtil.fetchActionResult(results, WSConstants.SIGN);
			
					    if (actionResult != null) {
					    	X509Certificate returnCert = (X509Certificate) actionResult.get(WSSecurityEngineResult.TAG_X509_CERTIFICATE);
					    	
					    	if (returnCert != null)
						    {
					    		PublicKey pk = returnCert.getPublicKey();
					    		if (pk != null)
					    		{
					    			byte[] encodedPk = pk.getEncoded();
					    			 
					    			DERInputStream inp = new DERInputStream(new ByteArrayInputStream(encodedPk));
					    			
					    			StringBuilder pkBuilder = new StringBuilder();
					    			getPk(inp.readObject(), pkBuilder);
					    			
					    			stringPk = pkBuilder.toString();

					    		}
						    }
					    	
					    }
				    }
			    }
			}
		}
		} catch(Exception ex) {
			System.out.println("Exception when getting Public key"+ex);
		}
		
		return stringPk;
	}
	
	static void getPk(DEREncodable obj, StringBuilder sb) 
	{
		if (obj instanceof ASN1Sequence) {
			Enumeration seq = ((ASN1Sequence) obj).getObjects();
			while (seq.hasMoreElements()) {
				getPk((DEREncodable) seq.nextElement(), sb);
				 
			}
		} else {
			if (obj instanceof DERObjectIdentifier) {
			//	System.out.println(((DERObjectIdentifier) obj).getId());
			}
			if (obj instanceof DERBitString) {
				sb.append((new BigInteger(((DERBitString) obj).getBytes())).toString(16));
			}
		}
	}
	
	private boolean validatePk(String pk, String consumerId, long transactionId) 
	{
		boolean okValues = false;
		
		if (pk != null && pk.length() > 0 )
		{
			if (consumerId != null && consumerId.length() > 0)
			{
				if((consumerId.length() > ProviderConstants.MAX_CONSUMERID_LENGTH))
				{
					theLogger.error(transactionId,"ConsumerId exceeds maximum length: " + consumerId);
				}
				else
				{
					okValues = true;
				}
			}
			else
			{
				theLogger.error(transactionId, "ConsumerId not found in the request");
				
			}
		}
		else
		{
			theLogger.error(transactionId, "Public key  not found in the request");
		}
			
		return okValues;
	}
	
	private String getMessage(String fieldId, String[] fieldValues){
		return messageSource.getMessage(fieldId, fieldValues, Locale.US);
	}
	
	@Override
	public CreateL2AppealResponse createL2Appeals(CreateL2AppealRequest request) throws CreateL2AppealException 
	{	
		long startTime = System.currentTimeMillis();
		
		long transUID = theLogger.generateUID();
		//theLogger.debug("********Invoking CreateAppeal "+ ProviderConstants.VERSION);	
		theLogger.debug(transUID, "createL2Appeal - WebService Method Call Received for createL2Appeal: ");
		CreateL2AppealResponse response = new CreateL2AppealResponse();				
		String pk = getPublicKey(context);
		String consumerId = request.getConsumerId();
		String jurisdiction = request.getJurisdiction();
	
		
		BindException bindingException = new BindException(request, "CreateL2AppealRequest");
		createL2AppealValidator.validate(request,pk, transUID, bindingException);		
		if (bindingException.hasErrors()){				
			MessageList messageList = new MessageList();
			response.setTransactionId(transUID);			
			List<ObjectError> errorList = bindingException.getAllErrors();
			StringBuilder errorStrBuilder = new StringBuilder();						
			for (ObjectError error: errorList){
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorStrBuilder.append(error.getDefaultMessage());
				errorStrBuilder.append("\n");				
				errorMessageDetail.setErrorCode(error.getCode());
				errorMessageDetail.setErrorMessage(error.getDefaultMessage());
				messageList.getErrorMessage().add(errorMessageDetail);
			}
			theLogger.error(transUID, "Detect request problem: "+errorStrBuilder.toString());			
			response.setAppealNumber(null);
			response.setStatus(false);
			response.setMessageList(messageList);			
			return response;
		}
		
		
			MessageList messageList = new MessageList();	
			String org = request.getJurisdiction();		
			UserDto userAccount = getSiebelUserAccount(jurisdiction,consumerId,pk, transUID);
			String siebelAppealFolder = null;
			
			if(userAccount!= null) { //Validate user information
				Object[] returnedItems = setupCreateAutoAppealSiebelRequest(request, pk,transUID, userAccount.getSiebelUserId());
				CreateL2AutoAppealInput createAutoAppealInput = (CreateL2AutoAppealInput)returnedItems[0];
				response = siebelService.createL2Appeal(createAutoAppealInput, transUID,userAccount);
			}
			else{
				theLogger.error(transUID, "Error while calling the Siebel siebel getUser Account web service: ");

				
				
				MessageDetail errorMessageDetail = new MessageDetail();							
				errorMessageDetail.setErrorCode(errorCode);
				errorMessageDetail.setErrorMessage(errorMsg);
				messageList.getErrorMessage().add(errorMessageDetail);
								
				response.setStatus(false);
				response.setMessageList(messageList);
				response.setTransactionId(transUID);
			}
				
			response.setTransactionId(transUID);
			theLogger.debug(transUID, "createL2Appeal - WebService Method Call Finished");
			
			theLogger.performanceStartOnly(transUID, "createL2Appeal", startTime);
			return response;
		
	}
	
	
	private UserDto getSiebelUserAccount(String jurisdiction, String consumerId, String publicKey, long transId){
		L2UserAuthenticationInput input = new L2UserAuthenticationInput();
		UserDto userAccount = new UserDto();
		theLogger.debug(transId, "Calling GetUserAccount: ");
		theLogger.debug(transId, "consumerId: "+consumerId);
		theLogger.debug(transId, "Jurisdiciton: "+jurisdiction);
		input.setJurisdiction(jurisdiction);
		input.setConsumerId(consumerId);
		input.setPublicKey(publicKey);
		input.setTransId(String.valueOf(transId));
		L2UserAuthenticationOutput output = siebelService.getUserL2Account(input);
		//String errorMessage = output.getErrorMsg();
		if(output.getErrCode()!=null ){
		errorCode = output.getErrCode();
		errorMsg = output.getErrMsg();
			return null;
		 }else {
			
			userAccount.setSiebelPassWord(output.getUserPassword());
			userAccount.setSiebelUserId(output.getUserId());			
			userAccount.setJurisdiction(jurisdiction);
			
			return userAccount;			
		}
		
		
	}
	private Object[] setupCreateAutoAppealSiebelRequest(CreateL2AppealRequest request,String pk, long transId, String userName){
		CreateL2AutoAppealInput input = new CreateL2AutoAppealInput();
		Appeal appeal = setupAppeals(request);
		ListOfMasL2AppealPartcdIo tt = new ListOfMasL2AppealPartcdIo();
		tt.setAppeal(appeal);
		
		input.setListOfMasL2AppealPartcdIo(tt);
		input.setJurisdiction(request.getJurisdiction());
		input.setConsumerId(request.getConsumerId());
		input.setPublicKey(pk);
		input.setTransId(String.valueOf(transId));
		input.setUserName(userName);
		Object[] returnItems = new Object[1];
		returnItems[0] = input;		
		return returnItems;
	}
	
	
		private Appeal setupAppeals(CreateL2AppealRequest request){
			Appeal appeal = new Appeal();
			appeal.setRequestReceivedDate(request.getAppeal().getRequestReceivedDate());
			appeal.setRequestDescription(request.getAppeal().getRequestDescription());
			appeal.setPlanContractNum(request.getAppeal().getPlanContractNum());
			appeal.setCorrectMCORequestDate(request.getAppeal().getCorrectMCORequestDate());
			appeal.setDenialReasonCategory(request.getAppeal().getDenialReasonCategory());
			appeal.setDenialReasonSubCategory(request.getAppeal().getDenialReasonSubCategory());
			appeal.setLevel1AppealPriority(request.getAppeal().getLevel1AppealPriority());
			appeal.setMCODecisionDate(request.getAppeal().getMCODecisionDate());
			appeal.setMCODenialType(request.getAppeal().getMCODenialType());
			appeal.setMCORequestDate(request.getAppeal().getMCORequestDate());
			appeal.setODDecisionDate(request.getAppeal().getODDecisionDate());
			appeal.setODRequestDate(request.getAppeal().getODRequestDate());
			appeal.setBeneficiaryIdentifier(request.getAppeal().getBeneficiaryIdentifier());
			
			return appeal;
		}
	
	
		@Override
		public TestAppealResponse testWebService(TestAppealRequest request) throws TestAppealException 
		{		
			long startTime = System.currentTimeMillis();
			
			long transUID = theLogger.generateUID();
			
			theLogger.debug(transUID, "testWebService - WebService Method Call Received for Appeal Number: " + request.getAppealNumber());
			
			String pk = getPublicKey(context);
			String consumerId = request.getConsumerId();
			boolean consumerIdMatch = validatePk(pk, consumerId, transUID);
			
			TestAppealResponse response = new TestAppealResponse();
			response.setTransactionId(transUID);
			response.setTransactionStatus(false);
			if( (request.getAppealNumber() == null) || (request.getAppealNumber().length() <= ProviderConstants.MAX_APPEAL_NUMBER_LENGTH) )
			{
				response.setAppealNumber(request.getAppealNumber());
			}
			
			if (consumerIdMatch == false)
			{
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorMessageDetail.setErrorCode(ErrorFieldConstant.BAD_CONSUMERID);
				errorMessageDetail.setErrorMessage(messageSource.getMessage(ErrorFieldConstant.BAD_CONSUMERID, null, Locale.US)  );
				messageList.getErrorMessage().add(errorMessageDetail);

				response.setMessageList(messageList);			
				return response;	
			}
					 
			BindException bindingException = new BindException(request, "TestAppealRequest");
			testAppealValidator.validate(request, bindingException);	
			
			if (bindingException.hasErrors())
			{
				MessageList messageList = new MessageList();
				List<ObjectError> errorList = bindingException.getAllErrors();
				StringBuilder errorStrBuilder = new StringBuilder();						
				for (ObjectError error: errorList){
					MessageDetail errorMessageDetail = new MessageDetail();				
					errorStrBuilder.append(error.getDefaultMessage());
					errorStrBuilder.append("\n");				
					errorMessageDetail.setErrorCode(error.getCode());
					errorMessageDetail.setErrorMessage(error.getDefaultMessage());
					messageList.getErrorMessage().add(errorMessageDetail);
				}
				theLogger.error(transUID, "testWebService - Validation Errors: " + errorStrBuilder.toString());			
				
				response.setMessageList(messageList);			
				return response;			
			}
			
	 
			String appealNumber = "";
			int ecmIndex = 0;
			String ecmUsername = "";
			String ecmPassword = "";
			List<String> documentList = new ArrayList<String>();
			
			
			GetL2AppealDocumentsOutput appealDocs = siebelService.testAppeal(request.getAppealNumber(),  transUID, consumerId, pk);
			
			String errCode = null;
			String errMsg = null;
			
			if (appealDocs != null)
			{
				
				String siebelStatus = appealDocs.getStatus();
				
				if ("Success".compareToIgnoreCase(siebelStatus) == 0)
				{
					com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.ListOfL2DocumentsIO docsList = appealDocs.getListOfL2DocumentsIO();
					
					if (docsList != null)
					{
						List<com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.Appeal> appealList = docsList.getAppeal();
						if (appealList != null)
						{
							if (appealList.size() == 1)
							{
								com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.Appeal appeal = appealList.get(0);
								if (appeal != null)
								{

									appealNumber = appeal.getAppealNumber();
									ecmUsername =  appeal.getECMUserId();
									ecmPassword =  appeal.getECMPassword();
									String strEcmIndex = appeal.getECMIndex();
									
									if (appealNumber != null && ecmUsername != null && ecmPassword != null && strEcmIndex != null &&
										 appealNumber.length() > 0 && ecmUsername.length() > 0  && ecmPassword.length() > 0  && strEcmIndex.length() > 0 )
									{
										try
										{
											ecmIndex = Integer.valueOf(strEcmIndex).intValue(); 
										} 
										catch (Exception conex)
										{
											errCode = ErrorFieldConstant.SIEBEL_ERROR;
											errMsg = "The Siebel getAppealDocuments returned  an ecmIndex that is not a valid integer: " + 	strEcmIndex;				
											
										}
										
										if (errCode == null)
										{
											com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.ListOfEcmDocuments ecmDocsContainer = appeal.getListOfEcmDocuments();
											if (ecmDocsContainer != null)
											{
												List<com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.EcmDocument> ecmDocs = ecmDocsContainer.getEcmDocument();
												
												if (ecmDocs != null)
												{
													for (int ecmIdx = 0; ecmIdx < ecmDocs.size(); ecmIdx++)
													{
														com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.EcmDocument ecmDoc = ecmDocs.get(ecmIdx);
														if (ecmDoc != null)
														{
															String ecmId = ecmDoc.getDocECMId();
															if (ecmId != null)
															{
																documentList.add(ecmId);
															}
														}
													}
												}
											}
											
											 
											
										}
									}
									else
									{
										errCode = ErrorFieldConstant.SIEBEL_ERROR;
										errMsg = "The Siebel getAppealDocuments returned some invalid values: appealNumber=" + appealNumber + " ecmUsername=" + ecmUsername + " ecmPassword=" + ecmPassword + " strEcmIndex=" +  strEcmIndex;										 
									}

								}
								else
								{
									errCode = ErrorFieldConstant.SIEBEL_ERROR;
									errMsg = "The Siebel getAppealDocuments web service returned a null appeal";					
									
								}
							}
							else
							{
								errCode = ErrorFieldConstant.SIEBEL_ERROR;
								errMsg = "The Siebel getAppealDocuments web service returned an appealList that had an invalid size: " + appealList.size();					
							}
						}
						else
						{
							errCode = ErrorFieldConstant.SIEBEL_ERROR;
							errMsg = "The Siebel getAppealDocuments web service returned a null appealList.";					
						}
					}
					else
					{
						errCode = ErrorFieldConstant.SIEBEL_ERROR;
						errMsg = "The Siebel getAppealDocuments web service returned a null documentList.";
					}
				}
				else
				{
					errCode = appealDocs.getErrCode();
					errMsg = appealDocs.getErrMsg();
					
					if (errCode == null)
					{
						errCode = ErrorFieldConstant.SIEBEL_ERROR;
					}
				}
				 
				
				
			}
			else 
			{
				errCode = ErrorFieldConstant.SIEBEL_ERROR;
				errMsg = "Exception while calling the Siebel getAppealDocuments web service.";
			}
			
			if (errCode != null)
			{
				theLogger.error(transUID, "testWebService - " + errMsg + " (Error Code: " + errCode + ")");			
				
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorMessageDetail.setErrorCode(errCode);
				errorMessageDetail.setErrorMessage(errMsg);
				messageList.getErrorMessage().add(errorMessageDetail);

				response.setMessageList(messageList);			
				return response;	
			}
			
			
			
			 
			
			StringBuilder tempAppealFolderBuilder = new StringBuilder();
			tempAppealFolderBuilder.append(constantConfig.getTempFileLocation());
			tempAppealFolderBuilder.append("/");
			tempAppealFolderBuilder.append(appealNumber);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(transUID);
			tempAppealFolderBuilder.append("_");
			tempAppealFolderBuilder.append(Util.getCurrentTimeStamp());
			
			theLogger.debug(transUID, "Appeal export directory for test webservice: " + tempAppealFolderBuilder.toString());
			 
			if (false == Util.directoryCheck(tempAppealFolderBuilder.toString(), true) )
			{
				errCode = ErrorFieldConstant.MISS_PARAMETERS;
				errMsg = "Appeal export directory does not exist and could not be created: " + tempAppealFolderBuilder.toString();
						 
				theLogger.error(transUID, errMsg);
				
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorMessageDetail.setErrorCode(errCode);
				errorMessageDetail.setErrorMessage(errMsg);
				messageList.getErrorMessage().add(errorMessageDetail);

				response.setMessageList(messageList);			
				return response; 
			}
			
			
			
			theLogger.debug(transUID, "Downloaded Siebel Files for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
			
			String ecmDocId = null;
			
			if (documentList != null)
			{
				if (documentList.size() > 0)
				{
					if (documentList.get(0) != null)
					{
						ecmDocId = documentList.get(0);
					}
				}
			}
			
			if (ecmDocId == null)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				errCode = ErrorFieldConstant.BAD_PARAMETERS;
				errMsg = "The provided appeal number does not have any ECM Documents.";
				
				theLogger.error(transUID, errMsg);
				
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorMessageDetail.setErrorCode(ErrorFieldConstant.MISS_PARAMETERS);
				errorMessageDetail.setErrorMessage(errMsg);
				messageList.getErrorMessage().add(errorMessageDetail);

				response.setMessageList(messageList);		
				return response;
			}
			
			String ecmErrMsg  = ecmService.exportTestDoc( tempAppealFolderBuilder.toString(), ecmDocId, ecmUsername, ecmPassword,  transUID);
			
			 
			if (ecmErrMsg != null)
			{
				Util.deleteDirectory(tempAppealFolderBuilder.toString());
				
				errCode = ErrorFieldConstant.SIEBEL_ERROR;
				errMsg = ecmErrMsg;
				
				theLogger.error(transUID, errMsg);
				
				MessageList messageList = new MessageList();
				MessageDetail errorMessageDetail = new MessageDetail();				
				errorMessageDetail.setErrorCode(ErrorFieldConstant.MISS_PARAMETERS);
				errorMessageDetail.setErrorMessage(errMsg);
				messageList.getErrorMessage().add(errorMessageDetail);

				response.setMessageList(messageList);		
				return response;  
			}
			 
			theLogger.debug(transUID, "Downloaded ECM Files for appeal: " + appealNumber + " in: " + tempAppealFolderBuilder.toString());
			
			
	 
			Util.deleteDirectory(tempAppealFolderBuilder.toString());
			
			response.setTransactionStatus(true);
	 
			theLogger.debug(transUID, "testWebService - WebService Method Call Finished");
			
			theLogger.performanceStartOnly(transUID, "testWebService", startTime);
			
			 
			return response;
	 
		}
	
		

}
