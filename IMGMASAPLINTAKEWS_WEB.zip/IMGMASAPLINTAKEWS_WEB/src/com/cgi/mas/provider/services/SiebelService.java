package com.cgi.mas.provider.services;

import java.io.File;
import java.net.URL;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

import javax.swing.SwingWorker;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.exceptions.CMAplIntakeWSException;
import com.cgi.mas.provider.logger.CustomLogger;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.cgi.mas.provider.services.dto.UserDto;
import com.cgi.mas.provider.util.EncryptionUtil;
import com.siebel.customui.CreateAddlnDocumentInput;
import com.siebel.customui.CreateAddlnDocumentOutput;
import com.siebel.customui.CreateAutoAppealInput;
import com.siebel.customui.CreateAutoAppealOutput;
import com.siebel.customui.CreateDocErrorLogInput;
import com.siebel.customui.CreateDocErrorLogOutput;
import com.siebel.customui.GetFileIdInput;
import com.siebel.customui.GetFileIdOutput;
import com.siebel.customui.MASL1AutoAppealWebService;
import com.siebel.customui.MASL1AutoAppealWebService_Service;
import com.siebel.customui.UpdateFileIdInput;
import com.siebel.customui.UpdateFileIdOutput;
import com.siebel.customui.UserAuthenticationInput;
import com.siebel.customui.UserAuthenticationOutput;

@Service
public class SiebelService implements ISiebelService {

	public SiebelService() {
		super();
		logger.debug(ProviderConstants.VERSION);
	}

	@Override
	public boolean createSiebelDocError(Object input, boolean shouldReturn) {
		logger.debug("************createSiebelDocError");
		
		Vector<CreateDocErrorLogInput> inputVector = new Vector<CreateDocErrorLogInput>();
		if(input instanceof CreateDocErrorLogInput) {
			inputVector.add((CreateDocErrorLogInput)input);
		} else if(input instanceof Vector) {
			inputVector = (Vector<CreateDocErrorLogInput>)input;
		}
		
		CreateSiebelDocErrorsThread csdet = new CreateSiebelDocErrorsThread(inputVector);
		csdet.execute();
		
		boolean success = true;
		if(shouldReturn) {
			try {
				success = (Boolean)csdet.get();
			} catch (InterruptedException e) {
				logger.error("", e);
			} catch (ExecutionException e) {
				logger.error("", e);
			}
		}
		
		return success;
	}
	
	public class CreateSiebelDocErrorsThread extends SwingWorker {
		long startTime = System.currentTimeMillis();
		Vector<CreateDocErrorLogInput> inputs = null;
		public CreateSiebelDocErrorsThread(Vector<CreateDocErrorLogInput> inputs) {
			this.inputs = inputs;
		}

		@Override
		protected Boolean doInBackground() {
			boolean noErrors = true;
			for(CreateDocErrorLogInput input : inputs) {
				try {
					if(isTest){
						return true;
					}
					
					logger.debug("Error message: " + input.getErrorCode() + " for appeal: " + input.getAppealNumber());	
					MASL1AutoAppealWebService port = getSiebelWSClient(null);	
					CreateDocErrorLogOutput output = port.createDocErrorLog(input);
					String result = output.getBlogFlag();
					logger.debug("Flag : " + result);
					
					if(result.toUpperCase().trim().equals("Y")) {
						logger.debug("************Done: createSiebelDocError");
					} else {
						logger.debug("ERROR \"" + input.getErrorCode() + "\" failed to create in Siebel!");
					}
				} catch(Error e) {
					logger.error("ERROR \"" + input.getErrorCode() + "\" failed to create in Siebel!", e);
				} catch(Exception e) {
					logger.error("ERROR \"" + input.getErrorCode() + "\" failed to create in Siebel!", e);
				} finally {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {}
				}
			}
			
			theLogger.performanceStartOnly("Done creating Siebel Errors for " + inputs.size() + " errors!", startTime);
			
			return noErrors;
		}
	}

	@Override
	public UserAuthenticationOutput getUserAccount(UserAuthenticationInput siebelRequest) {
		long startTime = System.currentTimeMillis();
		logger.debug("************getUserAccount");
		logger.debug("Jurisdiction: "+siebelRequest.getJurisdiction());
		logger.debug("MAC: "+siebelRequest.getMac());
		UserAuthenticationOutput output = null;
		try {
			if(isTest) {
				output = new UserAuthenticationOutput();
				output.setEcmUserId("testECM");
				output.setEcmUserPassword("testECMUser");
				output.setUserId("testSiebelId");
				output.setUserPassword("testPassword");
				output.setLoginUserId("testLogUserId");
			} else {
				MASL1AutoAppealWebService port = getSiebelWSClient(null);
				output = port.userAuthentication(siebelRequest);
			}
			
			theLogger.performanceStartOnly("Done Invoking Siebel getUserAccount", startTime);
			logger.debug("************Done-getUserAccount");
		} catch(Error e) {
			if(output != null) {
				logger.error("UserAuthenticationOutput: \n" + output, e);
			} else logger.error("", e);
		} catch(Exception e) {
			if(output != null) {
				logger.error("UserAuthenticationOutput: \n" + output, e);
			} else logger.error("", e);
		}
		
		return output;
	}

	@Override
	public boolean updateSiebelDocId(DocumentResultDto ecmDto) {
		long startTime = System.currentTimeMillis();
		logger.debug("************updateSiebelDocId");
		logger.debug(ecmDto.toString());
		UpdateFileIdInput updateFileIdInput = new UpdateFileIdInput();
		updateFileIdInput.setDocId(ecmDto.getSiebeldocId());
		updateFileIdInput.setEcmDocId(ecmDto.getEcmItemId());
		updateFileIdInput.setFileSize(String.valueOf(ecmDto.getSizeInKB()));
		updateFileIdInput.setPageCount(ecmDto.getPageCount());

		UpdateFileIdOutput output = null;
		if(isTest) {
			return true;	
		} else {
			MASL1AutoAppealWebService port = getSiebelWSClient(null);
			output = port.updateFileId(updateFileIdInput);
			String status = output.getBUpdateFlag();
			logger.debug(output.getErrorMsg());
			theLogger.performanceStartOnly("Done Invoking Siebel updateSiebelDocId", startTime);
			if(status.equalsIgnoreCase("Y")) {
				return true;
			} else {
				return false;
			}
		}
	}

	@Override
	public ResourceSiebelDto getDocInforFromFileId(String fileId) {

		logger.debug("************getDocInforFromFileId "+fileId);
		logger.debug("FileId: " + fileId);
		ResourceSiebelDto result = new ResourceSiebelDto();
		UserDto userAccount = new UserDto();
		try {			
			GetFileIdInput request = new GetFileIdInput();		
			request.setFileId(fileId);

			GetFileIdOutput output = null;
			if(!isTest) {
				MASL1AutoAppealWebService port = getSiebelWSClient(null);
				output = port.getFileId(request); 
			} else {
				result.setEcmId("1-test");
				result.setSiebelId("sId_"+fileId);
				/*if (fileId.equalsIgnoreCase("DDYCK7ZI")){
					result.setOriginalName("test.tiff");	
				}else{
					result.setOriginalName("test.PDF");
				}*/

				result.setOriginalName("testWithNoExtension.DOC");

				result.setAppealNumber("test"); //A1001001A13B24B55741F25026			

				userAccount.setEcmUserName("MAS_MAC_JF_SYS_ADMIN_USER");
				userAccount.setEcmPassword("DB2master");
				userAccount.setSiebelUserId("TMJF5");
				userAccount.setSiebelPassWord("CMSMAS01");
				result.setUserAccount(userAccount);	

				result.setFileId(fileId);
				//result.setChecksum("8d90613b0a87eedbe80597ce6d58c9e0");
				result.setChecksum(getTestCheckSum(fileId));

				userAccount.setOrg("MAC - Noridian Administrative Services LLC - JF");
				result.setAppealLevel("Level 1");
				result.setUserAccount(userAccount);		
			}
			
			if(output!= null) {				
				logger.debug("Trying to parsing result");
				String errorMessage = output.getErrorMsg();				
				if(StringUtils.hasText(errorMessage)) {
					logger.error("Got error while trying to retrieve siebel: "+errorMessage);
					return null;
				} else {
					result.setFileId(fileId);
					result.setEcmId(output.getEcmDocId());
					result.setSiebelId(output.getDocId());
					result.setOriginalName(output.getOrginialFileName());				
					result.setAppealNumber(output.getAppealNumber());
					result.setChecksum(output.getChecksum());
					userAccount.setEcmUserName(output.getEcmUserId());
					userAccount.setEcmPassword(output.getEcmUserPassword());
					userAccount.setSiebelUserId(output.getUserId());
					userAccount.setSiebelPassWord(output.getUserPassword());
					userAccount.setOrg(output.getOrganization());
					result.setUserAccount(userAccount);		
					result.setAppealLevel(output.getAppealLevel());
					result.setDocCategory(output.getDocCategory());
					result.setDocType(output.getDocType());
				}
			}

			logger.debug("************Done: getDocInforFromFileId");
		} catch (Error e) {
			logger.error("", e);
			return null;
		} catch (Exception e) {
			logger.error("", e);
			return null;
		}
		return result;
	}

	@Override
	public CreateAutoAppealOutput createAppeal(CreateAutoAppealInput siebelRequest, UserDto userDto) {
		long startTime = System.currentTimeMillis();
		logger.debug("**********Invoking Siebel createAppeal");
		//CreateAutoAppeal1Output appealNumber = null; //A1001001A13B24B55741F25026 test
		CreateAutoAppealOutput output = new CreateAutoAppealOutput();
		try {
			if (isTest) {
				//return "test";			
				output.setAppealNumber("test");
			}
			MASL1AutoAppealWebService port = getSiebelWSClient(userDto);
			String org = siebelRequest.getOrganization();
			String userName = siebelRequest.getUserName();
			siebelRequest.setOrganization(org != null ? org : userDto.getOrg());
			siebelRequest.setUserName(userName != null ? userName : userDto.getSiebelUserId());
			output = port.createAutoAppeal(siebelRequest);				
		} catch(Error e) {
			logger.error("", e);
			output.setErrorMsg(e.getMessage());
			output.setStatus("false");
		} catch(Exception e) {
			logger.error("", e);
			output.setErrorMsg(e.getMessage());
			output.setStatus("false");
		}

		logger.debug("**********Done Invoking Siebel createAppeal");
		theLogger.performanceStartOnly("Done Invoking Siebel createAppeal", startTime);

		return output;
	}

	private UserAuthenticationOutput getUserAccountFromOrg(String jurisdiction, String mac){
		long startTime = System.currentTimeMillis();
		try {
			UserAuthenticationInput userInput = new UserAuthenticationInput();
			userInput.setMac(mac);
			userInput.setJurisdiction(jurisdiction);
			MASL1AutoAppealWebService port = getSiebelWSClient(null);
			UserAuthenticationOutput userOutput = port.userAuthentication(userInput);

			theLogger.performanceStartOnly("Done Invoking Siebel getUserAccountFromOrg", startTime);

			return userOutput;
		} catch(Error e) {
			logger.error("", e);
			return null;
		} catch(Exception e) {
			logger.error("", e);
			return null;
		}
	}	

	public CreateAddlnDocumentOutput requestAdditionalInfo(CreateAddlnDocumentInput siebelRequest, UserDto userDto) {
		long startTime = System.currentTimeMillis();
		logger.debug("**********Invoking Siebel requestAdditionalInfo");
		//CreateAutoAppeal1Output appealNumber = null; //A1001001A13B24B55741F25026 test
		CreateAddlnDocumentOutput output = new CreateAddlnDocumentOutput();
		try {
			MASL1AutoAppealWebService port = getSiebelWSClient(userDto);
			String org = siebelRequest.getOrganization();
			String userName = siebelRequest.getUserName();
			siebelRequest.setOrganization(org != null ? org : userDto.getOrg());
			siebelRequest.setUserName(userName != null ? userName : userDto.getSiebelUserId());
			logger.debug("userName: "+siebelRequest.getUserName());
			logger.debug("Org: "+siebelRequest.getOrganization());
			output = port.createAddlnDocument(siebelRequest);				
		} catch(Error e) {
			logger.error("", e);
			output.setErrorMsg(e.getMessage());
			output.setStatus("false");
		} catch(Exception e) {
			logger.error("", e);
			output.setErrorMsg(e.getMessage());
			output.setStatus("false");
		}

		logger.debug("**********Done Invoking Siebel requestAdditionalInfo");
		theLogger.performanceStartOnly("Done Invoking Siebel requestAdditionalInfo", startTime);

		return output;
	}
	
	//---------------Private Methods
	private CustomLogger theLogger = new CustomLogger(this.getClass());
	private Logger logger = theLogger.getLogger();
	private static final QName SERVICE_NAME = new QName("http://siebel.com/CustomUI", "MASL1AutoAppealWebService");
	private static boolean isTest = false;	
	@Autowired
	private ConstantConfig constantConfig;

	private MASL1AutoAppealWebService getSiebelWSClient(UserDto userDto) {
		MASL1AutoAppealWebService port = null;
		logger.debug("--initialize SiebelWS");
		ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
		URL wsdlURL = classLoader.getResource(ProviderConstants.S_WSDL_NAME);
		if (wsdlURL == null){
			logger.debug("Detect WSDL again");
			wsdlURL = this.getClass().getClassLoader().getResource(ProviderConstants.S_WSDL_NAME);					
		}
		logger.debug("Initialize: "+wsdlURL.toString());
		MASL1AutoAppealWebService_Service ss = new MASL1AutoAppealWebService_Service(wsdlURL, SERVICE_NAME);				
		port = ss.getMASL1AutoAppealWebService();		
		BindingProvider bindingProvider = ((BindingProvider)port);
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getSiebelAddress(userDto));
		
		return port;
	}

	private String getSiebelAddress(UserDto userDto) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(constantConfig.getSiebelWSAddress());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_USER_NAME);
		strBuilder.append("=");
		strBuilder.append(userDto != null ? userDto.getSiebelUserId() : constantConfig.getSiebelUserName());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_PASSWORD);
		strBuilder.append("=");
		
		String password = userDto != null ? userDto.getSiebelPassWord() : constantConfig.getSiebelPassWord();
		
		try {
			EncryptionUtil encryptionUtil = new EncryptionUtil();
			
			logger.debug("--Siebel EndPoint: " + strBuilder.toString() + encryptionUtil.encryptIt(password));
		} catch (CMAplIntakeWSException e) {
			logger.error("", e);
		} catch (Error e) {
			logger.error("", e);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		strBuilder.append(password);
		
		return strBuilder.toString();
	}

	private String getTestCheckSum(String fileId){
		File directory = new File(constantConfig.getTempFileLocation());
		File fileCol [] = directory.listFiles();
		for (File file : fileCol){
			String fileName = file.getName();
			int index = fileName.indexOf(fileId);
			if (index>-1){
				return ProviderUtils.getMD5CheckSum(file.getPath());
			}
		}
		
		return null;
	}
}
