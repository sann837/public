package com.cgi.mas.provider.services;

import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.apache.log4j.Logger;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;
import org.apache.ws.security.util.WSSecurityUtil;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import com.cgi.cms.services.schema.mas.MessageDetail;
import com.cgi.cms.services.schema.mas.MessageList;
import com.cgi.cms.services.schema.mas.RACCFMockRequest;
import com.cgi.cms.services.schema.mas.RACCFMockResponse;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.logger.RACCFMockCustomLogger;
import com.cgi.mas.provider.validations.RACCFMockRequestValidator;
import com.cgi.services.mas.RACCFMockException;
import com.cgi.services.mas.RACCFRequestMockWebServiceImpl;

@Service
public class RACCFMockServiceProvider extends RACCFRequestMockWebServiceImpl {

	private RACCFMockCustomLogger theLogger = new RACCFMockCustomLogger(
			RACCFMockServiceProvider.class);
	private Logger logger = theLogger.getRaccfMockLogger();

	@Autowired
	private ConstantConfig constantConfig;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private RACCFMockRequestValidator RACCFMockRequestValidator;

	@Resource
	private WebServiceContext context;

	public RACCFMockServiceProvider() {
		theLogger.setConstantConfig(constantConfig);
		// logger.debug("Version: " + ProviderConstants.VERSION);
	}
	

	@Override
	public RACCFMockResponse requestForRACCaseFile(RACCFMockRequest request)
	throws RACCFMockException {
		
		long startTime = System.currentTimeMillis();

		RACCFMockResponse response = new RACCFMockResponse();
		response.setAppealNumber(request.getAppealNumber());
		response.setTransactionId(request.getTransactionId());

		logger
		.debug("requestForRACCaseFile - MockWebService Method Call Received With Transaction Id: "
				+ request.getTransactionId());

		String publicky = getPublicKey(context);
		/*boolean isValidRequest = validatePk(publicky,  request
				.getPublicKey(),request.getTransactionId());

		if (isValidRequest == false) {
			MessageList messageList = new MessageList();
			MessageDetail errorMessageDetail = new MessageDetail();

			response.setTransactionId(request.getTransactionId());
			response.setTransactionStatus(false);
			errorMessageDetail
			.setErrorCode(ErrorFieldConstant.BAD_PUBLICKEY);
			errorMessageDetail.setErrorMessage(messageSource.getMessage(
					ErrorFieldConstant.BAD_PUBLICKEY, null, Locale.US));
			messageList.getErrorMessage().add(errorMessageDetail);
			response.setMessageList(messageList);
			return response;
		}*/

		BindException bindingException = new BindException(request,
				"RACCFMockRequest");
		RACCFMockRequestValidator.validate(request, bindingException);

		if (bindingException.hasErrors()) {

			response.setTransactionId(request.getTransactionId());

			MessageList messageList = new MessageList();
			List<ObjectError> errorList = bindingException.getAllErrors();
			StringBuilder errorStrBuilder = new StringBuilder();
			for (ObjectError error : errorList) {
				MessageDetail errorMessageDetail = new MessageDetail();
				errorStrBuilder.append(error.getDefaultMessage());
				errorStrBuilder.append("\n");
				errorMessageDetail.setErrorCode(error.getCode());
				errorMessageDetail.setErrorMessage(error.getDefaultMessage());
				messageList.getErrorMessage().add(errorMessageDetail);
			}
			logger.error("RACCF Request with TransactionId: "
					+ request.getTransactionId() + " have Validation Errors: "
					+ errorStrBuilder.toString());

			response.setTransactionStatus(false);
			response.setMessageList(messageList);
			return response;
		}

		
		response.setTransactionStatus(true);
		
		//response.setMessageList(null);

		return response;

	}

	private String getPublicKey(WebServiceContext context) {
		String stringPk = null;

		try {
			MessageContext msgCtx = context.getMessageContext();
			HttpServletRequest httpSR = (HttpServletRequest) msgCtx
			.get(MessageContext.SERVLET_REQUEST);

			if (httpSR != null) {
				List<WSHandlerResult> handlerResults = (List<WSHandlerResult>) msgCtx
				.get(WSHandlerConstants.RECV_RESULTS);

				if (handlerResults != null) {
					WSHandlerResult rResult = handlerResults.get(0);

					if (rResult != null) {

						List<WSSecurityEngineResult> results = rResult
						.getResults();

						if (results != null) {
							WSSecurityEngineResult actionResult = WSSecurityUtil
							.fetchActionResult(results,
									WSConstants.SIGN);

							if (actionResult != null) {
								X509Certificate returnCert = (X509Certificate) actionResult
								.get(WSSecurityEngineResult.TAG_X509_CERTIFICATE);

								if (returnCert != null) {
									PublicKey pk = returnCert.getPublicKey();
									if (pk != null) {
										byte[] encodedPk = pk.getEncoded();

										DERInputStream inp = new DERInputStream(
												new ByteArrayInputStream(
														encodedPk));

										StringBuilder pkBuilder = new StringBuilder();
										getPk(inp.readObject(), pkBuilder);

										stringPk = pkBuilder.toString();

									}
								}

							}
						}
					}
				}
			}
		} catch (Exception ex) {
			System.out.println("Exception when getting Public key" + ex);
		}

		return stringPk;
	}

	static void getPk(DEREncodable obj, StringBuilder sb) {
		if (obj instanceof ASN1Sequence) {
			Enumeration seq = ((ASN1Sequence) obj).getObjects();
			while (seq.hasMoreElements()) {
				getPk((DEREncodable) seq.nextElement(), sb);

			}
		} else {
			if (obj instanceof DERObjectIdentifier) {
				// System.out.println(((DERObjectIdentifier) obj).getId());
			}
			if (obj instanceof DERBitString) {
				sb.append((new BigInteger(((DERBitString) obj).getBytes()))
						.toString(16));
			}
		}
	}

	private boolean validatePk(String pk,String requestPK,long transactionId) {
		boolean isValuesOk = false;

		if (pk != null && pk.length() > 0) {
			if (requestPK != null && requestPK.length() > 0) {
				if (!pk.equals(requestPK)) {
					logger.error("Invalid publickey");
				} else {
					isValuesOk = true;
				}
			} else {
				logger
				.error("publicKey not found in the request with TransactionId: "
						+ transactionId);
			}
		} 

		return isValuesOk;
	}

	/*
	 * private boolean validatePky(String pk, String consumerId, long
	 * transactionId) { boolean matchKey = false;
	 * 
	 * if (pk != null && pk.length() > 0) { if (consumerId != null &&
	 * consumerId.length() > 0) { int cidIdx =
	 * constantConfig.getCertList().indexOf(consumerId);
	 * 
	 * if (cidIdx >= 0) { // int pkIdx = //
	 * constantConfig.getPkList().indexOf(pk); if (cidIdx <
	 * constantConfig.getPkList().size()) { String thisPk =
	 * constantConfig.getPkList().get(cidIdx);
	 * 
	 * if (thisPk != null && thisPk.equals(pk)) { matchKey = true; } else {
	 * theLogger .error( transactionId, "Public Key for consumer Id: " +
	 * consumerId + " did not match the received Public Key: " + pk); } } else {
	 * theLogger .error( transactionId, "ConsumerId index for: " + consumerId +
	 * " exceeds the number of availble Public Key values for: " + pk); }
	 * 
	 * } else { theLogger.error(transactionId,
	 * "ConsumerId not found in config file: " + consumerId); } } else {
	 * theLogger.error(transactionId, "ConsumerId not found in the request"); }
	 * } else { theLogger.error(transactionId,
	 * "Public key  not found in the request"); }
	 * 
	 * return matchKey; }
	 */

}
