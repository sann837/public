package com.cgi.mas.provider.services;

import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.log4j.Logger;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;
import org.apache.ws.security.util.WSSecurityUtil;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEREncodable;
import org.bouncycastle.asn1.DERInputStream;
import org.bouncycastle.asn1.DERObjectIdentifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import com.cgi.cms.services.schema.mas.MessageDetail;
import com.cgi.cms.services.schema.mas.MessageList;
import com.cgi.cms.services.schema.mas.RACCFMockRequest;
import com.cgi.cms.services.schema.mas.RACCFMockResponse;
import com.cgi.cms.services.schema.mas.RACCaseFileRequest;
import com.cgi.cms.services.schema.mas.RACCaseFileResponse;
import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ErrorFieldConstant;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.logger.RACCFCustomLogger;
import com.cgi.mas.provider.validations.RACCaseFileRequestValidator;
import com.cgi.services.mas.RACCFMockException;
import com.cgi.services.mas.RACCFRequestMockWebService;
import com.cgi.services.mas.RACCFRequestMockWebService_Service;
import com.cgi.services.mas.RACCFRequestWebServiceImpl;
import com.cgi.services.mas.RACCaseFileException;

@Service
public class RACCaseFileServiceProvider extends RACCFRequestWebServiceImpl {

	private RACCFCustomLogger theLogger = new RACCFCustomLogger(
			RACCaseFileServiceProvider.class);
	private Logger logger = theLogger.getRacCFLogger();

	@Autowired
	private ConstantConfig constantConfig;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private RACCaseFileRequestValidator RACCaseFileRequestValidator;

	/*
	 * @Autowired private WSS4JOutInterceptor wss4jOut;
	 */

	@Resource
	private WebServiceContext context;

	public RACCaseFileServiceProvider() {
		theLogger.setConstantConfig(constantConfig);
		// logger.debug("Version: " + ProviderConstants.VERSION);
	}

	@Override
	public RACCaseFileResponse requestForRACCaseFile(RACCaseFileRequest request)
			throws RACCaseFileException {

		long startTime = System.currentTimeMillis();
		long transactionId = theLogger.generateUID();
		
		theLogger.debug(transactionId, "Received claimnumber: "+request.getClaimNumber()+" and contarctnumber "+request.getContractNumber()+" from siebel intial request");
		

		RACCaseFileResponse response = new RACCaseFileResponse();
		RACCFMockRequest racCFMockRequest = new RACCFMockRequest();
		RACCFMockResponse mockResponse = new RACCFMockResponse();
		MessageList messageList = new MessageList();
		MessageDetail errorMessageDetail = new MessageDetail();
		response.setTransactionStatus(false);
		response.setTransactionId(transactionId);
		

		theLogger.debug(transactionId,
				"requestForRACCaseFile - WebService Method Call Received");

		BindException bindingException = new BindException(request,
				"RACCFRequest");
		RACCaseFileRequestValidator.validate(request, transactionId,
				bindingException);

		if (bindingException.hasErrors()) {

			
			List<ObjectError> errorList = bindingException.getAllErrors();
			StringBuilder errorStrBuilder = new StringBuilder();
			for (ObjectError error : errorList) {
				
				errorStrBuilder.append(error.getDefaultMessage());
				errorStrBuilder.append("\n");
				errorMessageDetail.setErrorCode(error.getCode());
				errorMessageDetail.setErrorMessage(error.getDefaultMessage());
				messageList.getErrorMessage().add(errorMessageDetail);
			}
			theLogger.error(transactionId, "Detect request problem: "
					+ errorStrBuilder.toString());

			response.setMessageList(messageList);

			theLogger.debug(transactionId,
					"RACCF Request - WebService Method Call Finished");

			theLogger.performanceStartOnly(transactionId, "RACCF Request",
					startTime);
			return response;
		}
		
		theLogger.debug(transactionId, "request RAC CaseFiles - Calling  external RACCF web service ");

		try {
			
			RACCFRequestMockWebService port = getRACWSClient(transactionId, true);
			

			String pk = getPublicKey(context);
			racCFMockRequest.setPublicKey(pk);

			/*
			 * Map<String,Object> outProps = new HashMap<String,Object>();
			 * outProps.put(WSHandlerConstants.ACTION,
			 * WSHandlerConstants.TIMESTAMP + " "
			 * +WSHandlerConstants.SIGNATURE);
			 * outProps.put(WSHandlerConstants.USER,
			 * "mascgiwsclient.cgifederal.com");
			 * outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS,
			 * RACCFClientKeystorePasswordCallbackHandler.class.getName());
			 * outProps.put(WSHandlerConstants.SIG_PROP_FILE,
			 * "client_sign.properties");
			 * outProps.put(WSHandlerConstants.SIG_KEY_ID, "DirectReference");
			 * outProps.put(WSHandlerConstants.SIGNATURE_PARTS,
			 * "{Element}{http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd}Timestamp;{Element}{http://schemas.xmlsoap.org/soap/envelope/}Body"
			 * );outProps.put(WSHandlerConstants.ENC_PROP_FILE,
			 * "client_sign.properties");
			 * outProps.put(WSHandlerConstants.USE_SINGLE_CERTIFICATE,"true");
			 * outProps.put(WSHandlerConstants.ENCRYPTION_PARTS,
			 * "{Element}{http://www.w3.org/2000/09/xmldsig#}Signature;{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body"
			 * );outProps.put(WSHandlerConstants.ENC_SYM_ALGO,
			 * "http://www.w3.org/2001/04/xmlenc#sha256"); WSS4JOutInterceptor
			 * wss4jOut = new WSS4JOutInterceptor(outProps);
			 * 
			 * client.getOutInterceptors().add(wss4jOut);
			 */

			racCFMockRequest.setAppealNumber(request.getAppealNumber());
			racCFMockRequest.setClaimNumber(request.getClaimNumber());
			racCFMockRequest.setContractNumber(request.getContractNumber());
			racCFMockRequest.setTransactionId(transactionId);
			
			mockResponse = port.requestForRACCaseFile(racCFMockRequest);
			
			if(mockResponse != null){
				
				if(transactionId == mockResponse.getTransactionId() && request.getAppealNumber().equals(mockResponse.getAppealNumber())){
					
					theLogger.debug(transactionId, "Response from RACService External transaction status:  "+mockResponse.isTransactionStatus()+" and error message: ");
					
					response.setTransactionId(mockResponse.getTransactionId());
					response.setAppealNumber(mockResponse.getAppealNumber());
					response.setTransactionStatus(mockResponse.isTransactionStatus());
					response.setMessageList(mockResponse.getMessageList());
					
					

					
					
				}
				else{
					
					response.setTransactionStatus(false);
					errorMessageDetail.setErrorCode(null);
					errorMessageDetail.setErrorMessage("received appealNumber and transaction id in the response does not match those sent in the request");
					messageList.getErrorMessage().add(errorMessageDetail);
					response.setMessageList(messageList);
					
					theLogger.error(transactionId, "received appealNumber and transaction id in the response does not match those sent in the request");
					
					
				}
				
				
			}
			else{
				response.setTransactionStatus(false);
				errorMessageDetail.setErrorCode(ErrorFieldConstant.MISS_PARAMETERS_RAC);
				errorMessageDetail.setErrorMessage("received null response from external RAC webservice");
				messageList.getErrorMessage().add(errorMessageDetail);
				
				theLogger.error(transactionId, "received null response from external RAC webservice");
			}

			

		} catch(Error er) 
		{
			response.setTransactionStatus(false);
			errorMessageDetail.setErrorCode(null);
			errorMessageDetail.setErrorMessage("Error while calling the RAC external web service: ");
			messageList.getErrorMessage().add(errorMessageDetail);
			response.setMessageList(messageList);
			
			theLogger.error(transactionId, "request for RAC casefiles  - Error while calling the RAC web service: ", er);
			
			
		} catch (RACCFMockException e) {
			
			response.setTransactionStatus(false);
			errorMessageDetail.setErrorCode(null);
			errorMessageDetail.setErrorMessage("Exception while calling the RAC external web service: ");
			messageList.getErrorMessage().add(errorMessageDetail);
			response.setMessageList(messageList);
			
			theLogger.error(transactionId, "request for RAC casefiles  - Exception while calling the RAC web service: ", e);
			
		}


		return response;

	}

	private String getPublicKey(WebServiceContext context) {
		String stringPk = null;

		try {
			MessageContext msgCtx = context.getMessageContext();
			HttpServletRequest httpSR = (HttpServletRequest) msgCtx
					.get(MessageContext.SERVLET_REQUEST);

			if (httpSR != null) {
				List<WSHandlerResult> handlerResults = (List<WSHandlerResult>) msgCtx
						.get(WSHandlerConstants.RECV_RESULTS);

				if (handlerResults != null) {
					WSHandlerResult rResult = handlerResults.get(0);

					if (rResult != null) {

						List<WSSecurityEngineResult> results = rResult
								.getResults();

						if (results != null) {
							WSSecurityEngineResult actionResult = WSSecurityUtil
									.fetchActionResult(results,
											WSConstants.SIGN);

							if (actionResult != null) {
								X509Certificate returnCert = (X509Certificate) actionResult
										.get(WSSecurityEngineResult.TAG_X509_CERTIFICATE);

								if (returnCert != null) {
									PublicKey pk = returnCert.getPublicKey();
									if (pk != null) {
										byte[] encodedPk = pk.getEncoded();

										DERInputStream inp = new DERInputStream(
												new ByteArrayInputStream(
														encodedPk));

										StringBuilder pkBuilder = new StringBuilder();
										getPk(inp.readObject(), pkBuilder);

										stringPk = pkBuilder.toString();

									}
								}

							}
						}
					}
				}
			}
		} catch (Exception ex) {
			System.out.println("Exception when getting Public key" + ex);
		}

		return stringPk;
	}

	static void getPk(DEREncodable obj, StringBuilder sb) {
		if (obj instanceof ASN1Sequence) {
			Enumeration seq = ((ASN1Sequence) obj).getObjects();
			while (seq.hasMoreElements()) {
				getPk((DEREncodable) seq.nextElement(), sb);

			}
		} else {
			if (obj instanceof DERObjectIdentifier) {
				// System.out.println(((DERObjectIdentifier) obj).getId());
			}
			if (obj instanceof DERBitString) {
				sb.append((new BigInteger(((DERBitString) obj).getBytes()))
						.toString(16));
			}
		}
	}
	
	private RACCFRequestMockWebService getRACWSClient(long transactionId, boolean setTimeout) {
		
		RACCFRequestMockWebService port = null;
		
		//theLogger.debug(transactionId, "Initializing RAC Web Service");
		
		
		try
		{
			final QName SERVICE_NAME = new QName("http://mas.services.cgi.com","RACCFRequestMockWebService");
			ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
			URL wsdlURL = classLoader.getResource(ProviderConstants.J_RAC_WSDL_NAME);
			if (wsdlURL == null){
				//theLogger.debug(transactionId, "RAC Web Service WSDL location for default Class Loader was null; Using this Class Loader instead");
				wsdlURL = this.getClass().getClassLoader().getResource(ProviderConstants.J_RAC_WSDL_NAME);					
			}
			theLogger.debug(transactionId, "Initializing RAC Web Service URL: "+wsdlURL.toString());
			
			RACCFRequestMockWebService_Service ss = new RACCFRequestMockWebService_Service(wsdlURL, SERVICE_NAME);				
			port = ss.getRACCFRequestMockWebService();		
				
			Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
	
			// Set RAC Endpoint
			requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, constantConfig.getRacWSAddress());
			
			// Set RAC Timeouts
			long connectTimeout = 300000;   // 300 seconds for internal calls between Java and RAC
			long respondTimeout = 300000;
			if (setTimeout == true)
			{
				 connectTimeout = constantConfig.getSiebelWsConnectTimeout();
				 
				 respondTimeout = constantConfig.getSiebelWsRespondTimeout();
				
			}
			 
			
			requestContext.put("javax.xml.ws.client.receiveTimeout", respondTimeout); // Timeout in millis - BindingProviderProperties.REQUEST_TIMEOUT
			requestContext.put("javax.xml.ws.client.connectionTimeout", connectTimeout); // Timeout in millis
			
     
			theLogger.debug(transactionId, "RAC Web Service initilized from URL: "+wsdlURL.toString());
		}
		catch (Exception ex)
		{
			theLogger.error(transactionId, "Failed to instantiate RAC Web Service: ", ex);
		}
		
		return port;
	}

}
