package com.cgi.mas.provider.services;

import java.net.URL;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.exceptions.CMAplIntakeWSException;
import com.cgi.mas.provider.logger.RACCFCustomLogger;
import com.cgi.mas.provider.util.EncryptionUtil;
import com.siebel.racappealvalidation.MASSpcRACSpcTransactionSpcValidationSpcWF;
import com.siebel.racappealvalidation.MASSpcRACSpcTransactionSpcValidationSpcWF_Service;
import com.siebel.racappealvalidation.ValidateTransctnId1Input;
import com.siebel.racappealvalidation.ValidateTransctnId1Output;

@Service
public class SiebelRACService implements ISiebelRACService {
	
	
	//---------------Private Methods
	private RACCFCustomLogger theLogger = new RACCFCustomLogger( SiebelRACService.class);
	
	private static final QName SERVICE_NAME = new QName("http://siebel.com/RACAppealValidation", "MAS_spcRAC_spcTransaction_spcValidation_spcWF");
	private static boolean isTest = false;	
	@Autowired
	private ConstantConfig constantConfig;
	@Autowired
	private MessageSource messageSource;



	public SiebelRACService() {
		super();
		//theLogger.debug("",ProviderConstants.VERSION);
	}
	
	
	
	
	
	

	@Override
	public ValidateTransctnId1Output validateRACAppeal(
			ValidateTransctnId1Input input) {
		
		
        long startTime = System.currentTimeMillis();
        long transactionId = Long.parseLong(input.getTransId());
        ValidateTransctnId1Output response = new ValidateTransctnId1Output();
		
		theLogger.debug(transactionId, "ValidateRACAppeal - Calling Siebel validateTransctnId1 web service ");
 
		
	 
		try {

			MASSpcRACSpcTransactionSpcValidationSpcWF port = getSiebelRACWSClient(transactionId, true);
 
			 response = port.validateTransctnId1(input);
			 
			 theLogger.debug(transactionId, "ValidateRACAppeal - received resonse from Siebel validateTransctnId1 web service ");
 
			if (response != null)
			{			
				String successOrNot = response.getStatus();

				if (successOrNot != null && successOrNot.compareToIgnoreCase("Success") == 0)
				{
					
					 
					
				} 
				else
				{
					String errCode = response.getErrorSpcCode();
					String errMsg = response.getErrorSpcMessage();
					
					
					if (errMsg == null)
						errMsg = "NULL";
					
					
					theLogger.error(transactionId, "ValidateRACAppeal - Received error from Siebel. Error Code: " + errCode + ". Error Message: " + errMsg);
				}
			}
			else
			{
				theLogger.error(transactionId, "ValidateRACAppeal - Received null response from Siebel validateTransctnId1 webservice");
			}
			 
		} catch(Error er) 
		{
			theLogger.error(transactionId, "ValidateRACAppeal - Error while calling the Siebel validateTransctnId1 web service: ", er);	 			
		} catch(Exception ex) 
		{
			theLogger.error(transactionId, "ValidateRACAppeal - Exception while calling the Siebel validateTransctnId1 web service: ", ex);
		}

		theLogger.debug(transactionId, "ValidateRACAppeal - Siebel validateTransctnId1 web service call finished");
		
		theLogger.performanceStartOnly(transactionId, "Siebel validateTransctnId1 Web Service", startTime);
		
		return response;
		
		
		
		
		
	
	}
	
	
	private MASSpcRACSpcTransactionSpcValidationSpcWF getSiebelRACWSClient(long transactionId, boolean setTimeout) {
		MASSpcRACSpcTransactionSpcValidationSpcWF port = null;
		//theLogger.debug(transactionId, "Initializing Siebel Web Service");
		
		try
		{
			ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
			URL wsdlURL = classLoader.getResource(ProviderConstants.S_RAC_WSDL_NAME);
			if (wsdlURL == null){
				//theLogger.debug(transactionId, "Siebel Web Service WSDL location for default Class Loader was null; Using this Class Loader instead");
				wsdlURL = this.getClass().getClassLoader().getResource(ProviderConstants.S_RAC_WSDL_NAME);					
			}
			theLogger.debug(transactionId, "Initializing Siebel Web Service URL: "+wsdlURL.toString());
			
			MASSpcRACSpcTransactionSpcValidationSpcWF_Service ss = new MASSpcRACSpcTransactionSpcValidationSpcWF_Service(wsdlURL, SERVICE_NAME);				
			port = ss.getMASSpcRACSpcTransactionSpcValidationSpcWF();		
				
			Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
	
			// Set Siebel Endpoint
			requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getSiebelAddress(transactionId));
			
			// Set Siebel Timeouts
			long connectTimeout = 300000;   // 300 seconds for internal calls between Java and Siebel
			long respondTimeout = 300000;
			if (setTimeout == true)
			{
				 connectTimeout = constantConfig.getSiebelWsConnectTimeout();
				 
				 respondTimeout = constantConfig.getSiebelWsRespondTimeout();
				
			}
			 
			
			requestContext.put("javax.xml.ws.client.receiveTimeout", respondTimeout); // Timeout in millis - BindingProviderProperties.REQUEST_TIMEOUT
			requestContext.put("javax.xml.ws.client.connectionTimeout", connectTimeout); // Timeout in millis
			
			// Set Siebel Username / Password
			/*
			final String SECURITY_NAMESPACE =
	                "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";
	
	        SOAPFactory soapFactory = SOAPFactory.newInstance();
	        QName securityQName = new QName(SECURITY_NAMESPACE, "Security");
	        SOAPElement security = soapFactory.createElement(securityQName);
	        QName tokenQName = new QName(SECURITY_NAMESPACE, "UsernameToken");
	        SOAPElement token = soapFactory.createElement(tokenQName);
	        QName userQName = new QName(SECURITY_NAMESPACE, "Username");
	        SOAPElement soapUsername = soapFactory.createElement(userQName);
	        soapUsername.addTextNode(constantConfig.getSiebelUserName());
	        QName passwordQName = new QName(SECURITY_NAMESPACE, "Password");
	        SOAPElement soapPassword = soapFactory.createElement(passwordQName);
	        soapPassword.addTextNode(constantConfig.getSiebelPassWord());
	        token.addChildElement(soapUsername);
	        token.addChildElement(soapPassword);
	        security.addChildElement(token);
	              
	        List<Header> headersList = new ArrayList<Header>();
	        
	        SoapHeader securityHeader = new SoapHeader( new QName(null, "Security"), security);
          
	        headersList.add(securityHeader);

	        requestContext.put(Header.HEADER_LIST, headersList);
	        */
     
			theLogger.debug(transactionId, "Siebel Web Service initilized from URL: "+wsdlURL.toString());
		}
		catch (Exception ex)
		{
			theLogger.error(transactionId, "Failed to instantiate Siebel Web Service: ", ex);
		}
		
		return port;
	}
	
	
	
	
	
	
	private String getSiebelAddress(long transactionId) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(constantConfig.getSiebelWSAddress());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_USER_NAME);
		strBuilder.append("=");
		strBuilder.append(constantConfig.getSiebelRacUsername());
		strBuilder.append("&");
		strBuilder.append(ProviderConstants.S_PASSWORD);
		strBuilder.append("=");
		
		
		String password = constantConfig.getSiebelPassWord();
		
		try {
			EncryptionUtil encryptionUtil = new EncryptionUtil();
			
			theLogger.debug(transactionId,"--Siebel EndPoint: " + strBuilder.toString() + encryptionUtil.encryptIt(password));
		} catch (CMAplIntakeWSException e) {
			theLogger.error(transactionId, e);
		} catch (Error e) {
			theLogger.error(transactionId, e);
		} catch (Exception e) {
			theLogger.error(transactionId, e);
		}
		
		strBuilder.append(password);
		
		return strBuilder.toString();
	}

}
