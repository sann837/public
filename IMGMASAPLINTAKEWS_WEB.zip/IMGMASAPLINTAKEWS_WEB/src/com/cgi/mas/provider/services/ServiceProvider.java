package com.cgi.mas.provider.services;


public class ServiceProvider {/*
	private Logger logger = Logger.getLogger(ServiceProvider.class);	
	private ResourceBundle rb = null;
	private ResourceBundle errorMessageBundle = null;
	private SiebelService massiebelService = null;
	public ServiceProvider() {
		super();
		List<String>serverList = new ArrayList<String>();
		//serverList.add("ffxmas08");
		serverList.add("localhost:8078");
		//massiebelService = new MASSiebelService(serverList);
	}	
	public String sayHello(String name){
		return "You just enter "+name;
	}
	public CreateAppealResponse createAppealFolder(CreateAppealRequest request)
			throws CreateAppealException {
		CreateAppealResponse response = new CreateAppealResponse();
		RequestType type = request.getAppealRequestType();
		Calendar requestDate = request.getAppealRequestDate();
		String jurisdiction = request.getJurisdiction();
		logger.debug("*********createAppealFolder****");
		logger.debug("AppealRequestType: " + type);
		// logger.debug("AppealRequestDate: "+);
		logger.debug("Siebel UserId: " + request.getSiebelUserId());
		StringBuilder missParameter = new StringBuilder();
		boolean isMissingParameter = false;
		Status status = new Status();
		if (type == null) {
			missParameter.append("Request Type");
			missParameter.append(",");
			isMissingParameter = true;
		}
		if (requestDate == null) {
			missParameter.append("Request Date");
			missParameter.append(",");
			isMissingParameter = true;
		}
		if (jurisdiction == null) {
			missParameter.append("Jurisdiction");
			missParameter.append(",");
			isMissingParameter = true;
		}
		if (request.getSiebelUserId() == null) {
			missParameter.append("Siebel User Name");
			missParameter.append(",");
			isMissingParameter = true;
		}
		if (request.getSiebelPassword() == null) {
			missParameter.append("Siebel Password");
			missParameter.append(",");
			isMissingParameter = true;
		}
		if (isMissingParameter) {
			throw new CreateAppealException(getErrorMessage(
					"missing.parameters", new String[] { missParameter
							.substring(0, missParameter.lastIndexOf(",")) }));
		} else {

			MASCreateAppeal1Input siebelInput = new MASCreateAppeal1Input();
			siebelInput.setOrganization(jurisdiction);
			siebelInput.setReqRcdDate(requestDate.toString());
			siebelInput.setReqType(request.getAppealRequestType().name());
			MASCreateAppeal1Output output = massiebelService.createAppeal(siebelInput);
			logger.debug("Get Appeal Number: "+output.getAppealNumber());
			return null;
			
			List<DataHandler>documentList = request.getDocumentList();
			if ((documentList!= null)&&(!documentList.isEmpty())){
				logger.debug("Detect document content....");
				for (DataHandler documentHandler : documentList){
					try {
						InputStream s = documentHandler.getInputStream();
						
					} catch (IOException e) {						
						logger.error("Unable to read content----");
					}
				}
			}
			response.setStatus(status);
			response.setAppealNumber("fake appealNumber");
			response.setHasMessage(true);
			return response;
		}
	}
	private ResourceBundle getErrorBundle() {
		if (errorMessageBundle != null) {
			return errorMessageBundle;
		} else {
			try {
				errorMessageBundle = ResourceBundle
						.getBundle(ProviderConstants.Provider_ERROR_PROPERTY);
				return errorMessageBundle;
			} catch (MissingResourceException r) {
				logger.error(r.getMessage(), r);
				return null;
			}
		}
	}

	private String getErrorMessage(String key, Object[] arguments) {
		if (arguments != null) {
			return MessageFormat.format(getErrorBundle().getString(key),
					arguments);
		} else {
			return getErrorBundle().getString(key);
		}
	}

	private ResourceBundle getResource() {
		if (rb != null) {
			return rb;
		} else {
			try {
				rb = ResourceBundle
						.getBundle(ProviderConstants.Provider_PROPERTY);
				return rb;
			} catch (MissingResourceException r) {
				logger.error(r.getMessage(), r);
				return null;
			}

		}
	}

*/}
