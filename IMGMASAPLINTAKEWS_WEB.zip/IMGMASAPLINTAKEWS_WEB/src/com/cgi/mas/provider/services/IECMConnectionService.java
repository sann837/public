package com.cgi.mas.provider.services;

import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBConnectionPool;


public interface IECMConnectionService {
	public CMBConnectionPool createNewConnectionPool(String serverName, String dsType);
	public CMBConnection getIBMConnectionFromPool(String userName, String password, String serverName, String serverType);
	public CMBConnection releaseIBMConnectionToPool(CMBConnection con);
	
	
	//QIC Webservice
	
	public CMBConnectionPool createNewConnectionPool(String serverName, String dsType, long transactionId);
	public CMBConnection getIBMConnectionFromPool(String userName, String password, String serverName, String serverType, long transactionId);
	public CMBConnection releaseIBMConnectionToPool(CMBConnection con, long transactionId);
	
//	public CMBConnection connectIBM(String userName, String password, String serverName, String dsType);
//	public CMBConnection releaseIBMConnection(CMBConnection con);
}
