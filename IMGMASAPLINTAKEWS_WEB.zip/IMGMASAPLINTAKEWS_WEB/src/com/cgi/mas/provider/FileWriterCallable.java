package com.cgi.mas.provider;

import java.util.concurrent.Callable;

import org.apache.log4j.Logger;





public class FileWriterCallable implements Callable {
	private Logger logger = Logger.getLogger(FileWriterCallable.class.getName());
	//private DocumentContent documentHandler = null;	
	private String tempLocation = null;
	private ConstantConfig constantConfig = null;
	/*public FileWriterCallable(DocumentContent docHandler, String tempLocation, ConstantConfig constantConfig) {
		this.documentHandler = docHandler;
		this.tempLocation = tempLocation;
		this.constantConfig = constantConfig;
	}*/

	@Override
	public Object call() throws Exception {/*
		logger.debug("---------Calling FileWriterCallable---------");
		ECMDocumentDto dto = new ECMDocumentDto();
		FileOutputStream fileOutputStream = null;
		try {							
			InputStream inputStream = documentHandler.getFileContent().getInputStream();							
			String fileName = documentHandler.getFileName();
			String fileExtension = FilenameUtils.getExtension(fileName);			
			dto.setContentInputStream(inputStream);
			dto.setFileExtension(fileExtension);			
			dto.setFileName(fileName);			
			dto.setEntityName(constantConfig.getLevel1ItemType());
			dto.setMimeType(getMimeType(fileExtension));
			

			
			String tempFileLocation = tempLocation+fileName;
			fileOutputStream = new FileOutputStream(tempFileLocation);
			documentHandler.getFileContent().writeTo(fileOutputStream);			
			File tempFileLocationFile = new File(tempFileLocation);
			dto.setFileSize(tempFileLocationFile.length());
			return dto;
		} catch (IOException e) {						
			logger.error("Unable to read content----");
		}finally{
			if (fileOutputStream != null){
				fileOutputStream.close();
			}
		}*/
		return null;
	}
	private String getMimeType(String fileExtension) {
		return constantConfig.getMimeType().get(fileExtension.toLowerCase());
	}

}
