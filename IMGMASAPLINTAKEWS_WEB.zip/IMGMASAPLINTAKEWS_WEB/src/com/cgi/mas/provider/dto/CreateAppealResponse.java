package com.cgi.mas.provider.dto;

public class CreateAppealResponse {
	private Status status;
	private String appealNumber;
	private boolean hasMessage;
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public String getAppealNumber() {
		return appealNumber;
	}
	public void setAppealNumber(String appealNumber) {
		this.appealNumber = appealNumber;
	}
	public boolean isHasMessage() {
		return hasMessage;
	}
	public void setHasMessage(boolean hasMessage) {
		this.hasMessage = hasMessage;
	}
	
}
