package com.cgi.mas.provider.dto;

public enum RequestType {
	NEW_APPEAL("New"), EXISTING_APPEAL("Existing"), REOPEN_APPEAL("Reopen");	
	private String name;
	RequestType(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return name;
	}
}
