
package com.cgi.cms.services.schema.mas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fileId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="checksum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="fileName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listOfClaimNumbers" type="{http://mas.schema.services.cms.cgi.com/}listOfClaimNumbers" minOccurs="0"/>
 *         &lt;element name="listOfHICNumbers" type="{http://mas.schema.services.cms.cgi.com/}listOfHICNumbers" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentDetail", propOrder = {
    "fileId",
    "checksum",
    "fileName",
    "type",
    "listOfClaimNumbers",
    "listOfHICNumbers"
})
public class DocumentDetail
    implements Serializable
{

    private final static long serialVersionUID = 12345L;
    @XmlElement(required = true)
    protected String fileId;
    @XmlElement(required = true)
    protected String checksum;
    @XmlElement(required = true)
    protected String fileName;
    protected String type;
    protected ListOfClaimNumbers listOfClaimNumbers;
    protected ListOfHICNumbers listOfHICNumbers;

    /**
     * Gets the value of the fileId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the value of the fileId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileId(String value) {
        this.fileId = value;
    }

    /**
     * Gets the value of the checksum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChecksum() {
        return checksum;
    }

    /**
     * Sets the value of the checksum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChecksum(String value) {
        this.checksum = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the listOfClaimNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfClaimNumbers }
     *     
     */
    public ListOfClaimNumbers getListOfClaimNumbers() {
        return listOfClaimNumbers;
    }

    /**
     * Sets the value of the listOfClaimNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfClaimNumbers }
     *     
     */
    public void setListOfClaimNumbers(ListOfClaimNumbers value) {
        this.listOfClaimNumbers = value;
    }

    /**
     * Gets the value of the listOfHICNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfHICNumbers }
     *     
     */
    public ListOfHICNumbers getListOfHICNumbers() {
        return listOfHICNumbers;
    }

    /**
     * Sets the value of the listOfHICNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfHICNumbers }
     *     
     */
    public void setListOfHICNumbers(ListOfHICNumbers value) {
        this.listOfHICNumbers = value;
    }

}
