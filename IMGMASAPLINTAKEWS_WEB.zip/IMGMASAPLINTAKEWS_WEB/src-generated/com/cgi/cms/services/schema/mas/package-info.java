@javax.xml.bind.annotation.XmlSchema(namespace = "http://mas.schema.services.cms.cgi.com/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.cgi.cms.services.schema.mas;
