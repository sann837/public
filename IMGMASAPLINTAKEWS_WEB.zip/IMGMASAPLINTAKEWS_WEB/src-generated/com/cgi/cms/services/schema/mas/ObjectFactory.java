
package com.cgi.cms.services.schema.mas;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.cgi.cms.services.schema.mas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RACCFMockResponse_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "RACCFMockResponse");
    private final static QName _RACCFMockRequest_QNAME = new QName("http://mas.schema.services.cms.cgi.com/", "RACCFMockRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.cgi.cms.services.schema.mas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RACCFMockResponse }
     * 
     */
    public RACCFMockResponse createRACCFMockResponse() {
        return new RACCFMockResponse();
    }

    /**
     * Create an instance of {@link RACCFMockException }
     * 
     */
    public RACCFMockException createRACCFMockException() {
        return new RACCFMockException();
    }

    /**
     * Create an instance of {@link MessageList }
     * 
     */
    public MessageList createMessageList() {
        return new MessageList();
    }

    /**
     * Create an instance of {@link RACCFMockRequest }
     * 
     */
    public RACCFMockRequest createRACCFMockRequest() {
        return new RACCFMockRequest();
    }

    /**
     * Create an instance of {@link MessageDetail }
     * 
     */
    public MessageDetail createMessageDetail() {
        return new MessageDetail();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RACCFMockResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "RACCFMockResponse")
    public JAXBElement<RACCFMockResponse> createRACCFMockResponse(RACCFMockResponse value) {
        return new JAXBElement<RACCFMockResponse>(_RACCFMockResponse_QNAME, RACCFMockResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RACCFMockRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.services.cms.cgi.com/", name = "RACCFMockRequest")
    public JAXBElement<RACCFMockRequest> createRACCFMockRequest(RACCFMockRequest value) {
        return new JAXBElement<RACCFMockRequest>(_RACCFMockRequest_QNAME, RACCFMockRequest.class, null, value);
    }

}
