
package com.cgi.cms.l2services.schema.mas;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.cgi.cms.l2services.schema.mas package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreateL2AppealRequest_QNAME = new QName("http://mas.schema.L2services.cms.cgi.com/", "createL2AppealRequest");
    private final static QName _TestAppealRequest_QNAME = new QName("http://mas.schema.L2services.cms.cgi.com/", "testAppealRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.cgi.cms.l2services.schema.mas
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TestAppealResponse }
     * 
     */
    public TestAppealResponse createTestAppealResponse() {
        return new TestAppealResponse();
    }

    /**
     * Create an instance of {@link MessageList }
     * 
     */
    public MessageList createMessageList() {
        return new MessageList();
    }

    /**
     * Create an instance of {@link CreateL2AppealResponse }
     * 
     */
    public CreateL2AppealResponse createCreateL2AppealResponse() {
        return new CreateL2AppealResponse();
    }

    /**
     * Create an instance of {@link TestAppealException }
     * 
     */
    public TestAppealException createTestAppealException() {
        return new TestAppealException();
    }

    /**
     * Create an instance of {@link TestAppealRequest }
     * 
     */
    public TestAppealRequest createTestAppealRequest() {
        return new TestAppealRequest();
    }

    /**
     * Create an instance of {@link CreateL2AppealException }
     * 
     */
    public CreateL2AppealException createCreateL2AppealException() {
        return new CreateL2AppealException();
    }

    /**
     * Create an instance of {@link CreateL2AppealRequest }
     * 
     */
    public CreateL2AppealRequest createCreateL2AppealRequest() {
        return new CreateL2AppealRequest();
    }

    /**
     * Create an instance of {@link MessageDetail }
     * 
     */
    public MessageDetail createMessageDetail() {
        return new MessageDetail();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateL2AppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.L2services.cms.cgi.com/", name = "createL2AppealRequest")
    public JAXBElement<CreateL2AppealRequest> createCreateL2AppealRequest(CreateL2AppealRequest value) {
        return new JAXBElement<CreateL2AppealRequest>(_CreateL2AppealRequest_QNAME, CreateL2AppealRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TestAppealRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://mas.schema.L2services.cms.cgi.com/", name = "testAppealRequest")
    public JAXBElement<TestAppealRequest> createTestAppealRequest(TestAppealRequest value) {
        return new JAXBElement<TestAppealRequest>(_TestAppealRequest_QNAME, TestAppealRequest.class, null, value);
    }

}
