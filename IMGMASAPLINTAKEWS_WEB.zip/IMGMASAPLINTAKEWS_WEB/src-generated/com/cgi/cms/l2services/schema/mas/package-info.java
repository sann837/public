@javax.xml.bind.annotation.XmlSchema(namespace = "http://mas.schema.L2services.cms.cgi.com/")
package com.cgi.cms.l2services.schema.mas;
