package test.com.cgi.mas.provider.services;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.mas.provider.services.ISiebelService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ResourceSiebelDto;
import com.cgi.mas.provider.services.dto.UserDto;
import com.siebel.customui.CreateAutoAppealInput;
import com.siebel.customui.CreateAutoAppealOutput;
import com.siebel.customui.UserAuthenticationInput;
import com.siebel.customui.UserAuthenticationOutput;
import com.siebel.xml.mas_20l1_20ecm_20bc.L1DocumentList;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfL1Documentlist;

public class TestSiebelService extends TestBaseConfig{
	@Autowired
	private ISiebelService siebelService;
	private UserDto userDto;
	@Before
	public void setUp() throws Exception {
		userDto = new UserDto();
		testGetUserAccount();
	}

	@After
	public void tearDown() throws Exception {
		userDto = null;
	}	
	
	public void testGetUserAccount(){
		UserAuthenticationInput siebelRequest = new UserAuthenticationInput();
		siebelRequest.setJurisdiction("JF");
		siebelRequest.setMac("MAC - Noridian Administrative Services LLC");
		UserAuthenticationOutput response = siebelService.getUserAccount(siebelRequest);
		assertNotNull(response);
		displayMessage("ECM Id: "+response.getEcmUserId());
		displayMessage("ECM password: "+response.getEcmUserPassword());
		displayMessage("Siebel Id: "+response.getUserId());
		displayMessage("Siebel Password: "+response.getUserPassword());
		displayMessage("ErrorMessage: "+response.getErrorMsg());
		userDto.setSiebelUserId(response.getUserId());
		userDto.setSiebelPassWord(response.getUserPassword());
		//displayMessage("ECM Id: "+response.getEcmUserId());
	}
	
	public void testGetDocInforFromFileId(){
		String fileId = "f38ca1cf";
		ResourceSiebelDto resultDto = siebelService.getDocInforFromFileId(fileId);
		assertNotNull(resultDto);
		System.out.println(resultDto.getEcmId()+"-->AppealNubmer: "+resultDto.getAppealNumber());
	}	

	public void testUpdateDocInfo(){
		DocumentResultDto ecm = new DocumentResultDto();
		ecm.setEcmItemId("wwwwwwwww");		//A1001001A13C11B10400D27666
		ecm.setPageCount("11");
		ecm.setSizeInKB(20);
		ecm.setSiebeldocId("1-PJGOL");		
		Assert.assertTrue(siebelService.updateSiebelDocId(ecm));
	}
	
	/*public void testCreateAppeal() {
		assertNotNull(siebelService);		
		String appealNumber = siebelService.createAppeal(createSiebelRequest(), null, null);
		assertNotNull(appealNumber);
		System.out.println("Appeal number: "+appealNumber);
	}	*/
	public void testCreateSiebelDocRecord(){
		
	}
	@Test
	public void createAppealWithDoc(){
		CreateAutoAppealInput request = new CreateAutoAppealInput();		
		
		String jurisdiction = "JF";
		String mac = "MAC - Noridian Administrative Services LLC";		
		ListOfL1Documentlist documentLIst = new ListOfL1Documentlist();		
		List<L1DocumentList> docList =documentLIst.getL1DocumentList();
		
		L1DocumentList doc = new L1DocumentList();
		doc.setFileId("EYLG2P8F");
		doc.setFileName("Test.pdf");
		doc.setChecksum("f38cacf43de88f805ac2dbb5698b2c7d");
		doc.setType("Appeal Case File Batch");
		docList.add(doc);
		
		L1DocumentList doc1 = new L1DocumentList();
		doc1.setFileId("DF8OJFBT");
		doc1.setFileName("00000023.pdf");
		doc1.setChecksum("1570298cad01005a403ababa9c75d4371");
		doc1.setType("Appeal Case File Batch");
		docList.add(doc1);
		userDto.setMac(mac);
		userDto.setJurisdiction(jurisdiction);
		
		request.setOrganization(userDto.getOrg());
		request.setListOfL1Documentlist(documentLIst);
		request.setUserName(userDto.getSiebelUserId());
		
		
		CreateAutoAppealOutput output  = siebelService.createAppeal(request, userDto);
		assertNotNull(output);
		System.out.println("Appeal-number: "+output.getAppealNumber());
		System.out.println("Message: "+output.getErrorMsg());
		
	}

}
