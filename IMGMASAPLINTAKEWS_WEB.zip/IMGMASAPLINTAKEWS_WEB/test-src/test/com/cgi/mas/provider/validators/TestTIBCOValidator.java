package test.com.cgi.mas.provider.validators;

import java.io.File;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.validation.BeanPropertyBindingResult;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.validations.TIBCOValidator;

public class TestTIBCOValidator extends TestBaseConfig{
	@Autowired
	private TIBCOValidator tibcoValiator;
	@Autowired
	private ConstantConfig constantConfig;
	@Test
	public void testValidator(){
		String fileName = "Atest.fsdfsdf.csv";
		File file = new File(constantConfig.getTempFileLocation()+"/"+fileName);
		Resource resource = new FileSystemResource(file);
		BeanPropertyBindingResult errors = new BeanPropertyBindingResult(resource, "item");
		tibcoValiator.validate(resource, errors);
		Assert.assertTrue(true);
	}

}
