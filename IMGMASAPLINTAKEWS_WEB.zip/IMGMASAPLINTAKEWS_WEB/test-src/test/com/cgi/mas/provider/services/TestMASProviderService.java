package test.com.cgi.mas.provider.services;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import junit.framework.Assert;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.cms.services.schema.mas.CreateAppealRequest;
import com.cgi.cms.services.schema.mas.CreateAppealResponse;
import com.cgi.cms.services.schema.mas.DocumentDetail;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.cms.services.schema.mas.MessageDetail;
import com.cgi.cms.services.schema.mas.MessageList;
import com.cgi.cms.services.schema.mas.Org;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.services.MASProviderService;

public class TestMASProviderService extends TestBaseConfig {
	@Autowired
	private MASProviderService masWebservice;
	private String fileDirectory = "C:/my_data/Imaging Dummy Files/Oversized Docs/";
	private String sourceFolder = "C:/my_data/Imaging Dummy Files/Single Page PDF";
	private String targetFolder = "c:/temp_m/delete/print2";
	private String ALPHA_NUMERIC_START_OPTS = "EFG";
	private String envPrefix = "EFG";

	@Before
	public void setUPData() {
		int totalFile = 3;
		deleteDirectory(targetFolder);
		File targetDirectory = new File(targetFolder);
		Assert.assertTrue(targetDirectory.listFiles().length == 0);
		copyFile(sourceFolder, targetFolder, totalFile);
		Assert.assertTrue(targetDirectory.listFiles().length == totalFile);
	}

	@Test
	public void TestCreateAppeal() {
		CreateAppealRequest request = new CreateAppealRequest();
		Org org = new Org();
		org.setJurisdiction("JF");
		org.setMac("MAC - Noridian Administrative Services LLC");
		request.setOrg(org);
		String requestDate = "2013-03-28";
		request.setRequestDate(ProviderUtils.convertStringToCalendar(
				requestDate, "yyyy-MM-dd"));
		request.setClaimList(null);

		DocumentList documentList = new DocumentList();
		documentList.getDocument().addAll(getDataFromDirectory(targetFolder));
		request.setDocumentList(documentList);

		try {
			CreateAppealResponse response = masWebservice.createAppeal(request);
			assertNotNull(response);
			displayMessage("Appeal number: " + response.getAppealNumber());
			displayMessage("Status: " + response.isStatus());
			MessageList messageList = response.getMessageList();
			if (messageList != null) {
				List<MessageDetail> errorList = messageList.getErrorMessage();
				for (MessageDetail detail : errorList) {
					displayMessage("ErrorCode: " + detail.getErrorCode()
							+ "-->" + detail.getErrorMessage());
				}
			}

		} catch (Exception e) {
			fail(e.getMessage());
		}

	}

	private List<String> getAllDocumentName(String directory) {
		File fileDirectory = new File(directory);
		List<String> fileNameList = new ArrayList<String>();
		Collection<File> fileCol = FileUtils.listFiles(fileDirectory,
				new String[] { "pdf", "tiff", "tif" }, false);
		Iterator<File> fileIterator = fileCol.iterator();
		while (fileIterator.hasNext()) {
			File file = fileIterator.next();
			fileNameList.add(file.getName());
		}
		return fileNameList;
	}

	private List<DocumentDetail> getDataFromDirectory(String targetDirectory) {
		List<DocumentDetail> docList = new ArrayList<DocumentDetail>();
		final String ALPHA_NUMERIC_OPTIONS = "0ABC1DEF2GHIJ3KLM4NOP5QRS6TUV7WXY8Z9";
		final String DELIMITER = ",";
		boolean envSuffixBool = true;
		String tibcoTimeStampFormat = "HHmmss";
		String tibcoDateStampFormat = "yyMMdd";

		SimpleDateFormat formatDate = new SimpleDateFormat(tibcoDateStampFormat);
		SimpleDateFormat formatTime = new SimpleDateFormat(tibcoTimeStampFormat);

		long date = System.currentTimeMillis();
		String envSuffix = ".D" + formatDate.format(date) + ".T"
				+ formatTime.format(date) + "4";
		File folderFile = new File(targetDirectory);
		Random random = new Random();
		int startInd = random.nextInt(ALPHA_NUMERIC_START_OPTS.length());
		String firstLetter = ALPHA_NUMERIC_START_OPTS.substring(startInd,
				startInd + 1);

		try {

			File[] theFiles = folderFile.listFiles();
			for (File file : theFiles) {
				String originalFileName = file.getName();
				String extension = originalFileName.substring(originalFileName
						.lastIndexOf("."));
				StringBuilder fileRenameValueSb = new StringBuilder();
				for (int i = 0; i < 7; i++) {
					int index = random.nextInt(ALPHA_NUMERIC_OPTIONS.length());
					fileRenameValueSb.append(ALPHA_NUMERIC_OPTIONS.substring(
							index, index + 1));
				}
				startInd = random.nextInt(ALPHA_NUMERIC_START_OPTS.length());
				firstLetter = ALPHA_NUMERIC_START_OPTS.substring(startInd,
						startInd + 1);
				String fileRenameValue = firstLetter
						+ fileRenameValueSb.toString();
				date = System.currentTimeMillis();
				if (envSuffixBool)
					envSuffix = ".D" + formatDate.format(date) + ".T"
							+ formatTime.format(date) + "4";

				File renameFile = new File(targetFolder + "/"
						+ /* envPrefix + */fileRenameValue + envSuffix
						+ extension);

				file.renameTo(renameFile);

				StringBuilder sb = new StringBuilder();

				sb.append(fileRenameValue);
				sb.append(DELIMITER);
				sb.append("");
				sb.append(DELIMITER);
				sb.append(originalFileName);
				sb.append(DELIMITER);
				String checkSum = ProviderUtils.getMD5CheckSum(renameFile);
				sb.append(checkSum);
				displayMessage(sb.toString());
				/*
				 * L1DocumentList siebelDoc = new L1DocumentList();
				 * siebelDoc.setChecksum(checkSum);
				 * siebelDoc.setFileId(fileRenameValue);
				 * siebelDoc.setFileName(originalFileName);
				 */
				DocumentDetail siebelDoc = new DocumentDetail();
				siebelDoc.setChecksum(checkSum);
				siebelDoc.setFileId(fileRenameValue);
				siebelDoc.setFileName(originalFileName);
				docList.add(siebelDoc);

			}

		} catch (Exception e) {

		}

		return docList;
	}

	private DataHandler addTestDocument(String fileLocation) {
		FileDataSource dataSource = new FileDataSource(fileLocation);
		DataHandler contentHanlder = new DataHandler(dataSource);
		return contentHanlder;
	}

	private void deleteDirectory(String targetDirectory) {
		File targetFile = new File(targetDirectory);
		File fileList[] = targetFile.listFiles();
		for (File file : fileList) {
			file.delete();
		}
	}

	private void copyFile(String sourceFolder, String targetFolder, int count) {

		try {
			// fInputStream = new FileInputStream(new File(sourceFolder));
			File sourceFolderFile = new File(sourceFolder);
			File sourceFile[] = sourceFolderFile.listFiles();
			int index = 0;
			for (File file : sourceFile) {
				if (index >= count) {
					return;
				}
				FileInputStream fInputStream = null;
				FileOutputStream fOutputStream = null;
				FileChannel fInchannel = null, fOutChannel = null;
				MappedByteBuffer mapByteBuffer = null;
				try {
					fInputStream = new FileInputStream(file);
					fOutputStream = new FileOutputStream(new File(targetFolder
							+ "/" + file.getName()));
					fInchannel = fInputStream.getChannel();
					fOutChannel = fOutputStream.getChannel();
					long size = fInchannel.size();
					mapByteBuffer = fInchannel.map(
							FileChannel.MapMode.READ_ONLY, 0, size);
					fOutChannel.write(mapByteBuffer);
					fInchannel.close();
					fOutChannel.close();
					fInputStream.close();
					fOutputStream.close();
				} catch (Exception e) {

				}
				index++;
			}

		} catch (Exception e) {

		}
	}

}
