package test.com.cgi.mas.provider.services;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.mas.provider.services.IECMConnectionService;
import com.cgi.mas.provider.services.IECMService;
import com.ibm.mm.beans.CMBConnection;

public class TestECMConnectionService extends TestBaseConfig{
	@Autowired
	private IECMConnectionService ecmConnectionService;
	@Autowired
	private IECMService ecmService;
	private CMBConnection session = null;
	@Before
	public void setUp() throws Exception {
		String userName = "icmadmin";
		String password = "DB2master";
		String serverName = "ecmlsdev";
		String dsType = "ICM";
		session = ecmConnectionService.getIBMConnectionFromPool(userName, password, serverName, dsType);
		assertNotNull(session);
		
	}

	@After
	public void tearDown() throws Exception {
		session = ecmConnectionService.releaseIBMConnectionToPool(session);
		assertNotNull(session);
	}
	public void testConnectIBM()throws Exception {
		String userName = "icmadmin";
		String password = "DB2master";
		String serverName = "ecmlsdev";
		String dsType = "ICM";
		CMBConnection session = ecmConnectionService.getIBMConnectionFromPool(userName, password, serverName, dsType);
		assertNotNull(session);
		assertTrue(session.isConnected());
		ecmConnectionService.releaseIBMConnectionToPool(session);
		assertFalse(session.isConnected());
	}	
	

}
