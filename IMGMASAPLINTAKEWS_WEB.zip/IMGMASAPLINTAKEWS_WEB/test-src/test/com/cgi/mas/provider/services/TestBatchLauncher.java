package test.com.cgi.mas.provider.services;

import java.io.File;
import java.util.Scanner;

import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.batch.BatchLauncher;

public class TestBatchLauncher extends TestBaseConfig{
	@Autowired
	private BatchLauncher batchLauncher;
	@Autowired
	private ConstantConfig constantConfig;
	private String directory = null;
	@Before
	public void setUp(){
		directory = constantConfig.getTempFileLocation();
	}	
	@Test
	public void testRenameBack() throws Exception{
		//String directory = constantConfig.getTempFileLocation();
		File directoryFile = new File(directory);
		File fileCol[] = directoryFile.listFiles();
		boolean isDetectLockFile = false;
		for (File file : fileCol){
			String path = file.getPath();
			String extension = FilenameUtils.getExtension(path);						
			if (extension.equalsIgnoreCase(ProviderConstants.LOCK_EXTENSION)){
				String originalString = path.substring(0,path.indexOf(ProviderConstants.LOCK_EXTENSION)-1);
				//String originalName = FilenameUtils.getBaseName(originalString);
				File renameFile = new File(originalString);
				file.renameTo(renameFile);
				isDetectLockFile = true;				
			}			
		}
		if (isDetectLockFile){
			System.out.print("Please press any keys to continue: ");
			Scanner in = new Scanner(System.in);
			System.out.println("you enter: "+in.nextLine());	
		}
		String keyPress = "test";
		while(keyPress!= null){
			System.out.print("Please press any keys to continue: ");
			Scanner in = new Scanner(System.in);
			keyPress = in.nextLine();
			if (!keyPress.equalsIgnoreCase("q")){
				keyPress = null;
			}
		}
		
	}
	
	public void testRenameToInvalidTibCo(){
		//String directory = constantConfig.getTempFileLocation();
		File directoryFile = new File(directory);
		File fileCol[] = directoryFile.listFiles();
		for (File file : fileCol){
			String path = file.getPath();
			String extension = FilenameUtils.getExtension(path);
			String originalName = FilenameUtils.getBaseName(path);
			String prefixValidName = originalName.substring(1);
			String validName = "C"+prefixValidName;
			File renameFile = new File(directory+"/"+validName+"."+extension);
			file.renameTo(renameFile);
		
			
		}
	
	}
	
	public void testLaunchBatch() {
		boolean isDone = false;
		while (!isDone) {
			try {
				Thread.currentThread().sleep(2* 1000);
				batchLauncher.startProcess();
				System.err.println("----------Prepare to sleep");
				
				System.err.println("----------Done sleep");
				isDone = true;
			} catch (Exception e) {
				System.err.println(e.getMessage());
			}

		}
	}
	
}
