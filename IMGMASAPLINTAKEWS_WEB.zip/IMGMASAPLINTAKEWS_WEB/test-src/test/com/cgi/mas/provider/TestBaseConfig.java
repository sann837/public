package test.com.cgi.mas.provider;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations = {"/IMGMASAPLINTAKEWS-servlet.xml"}
		)
public class TestBaseConfig{
	public void displayMessage(String message){
		System.out.println(message);
	}
}
