package test.com.cgi.mas.provider;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

public class TestFileWriterCallable {
	
	public void testWrite(){/*
		ExecutorService pool = Executors.newFixedThreadPool(3);
		DocumentContent documentContent = new DocumentContent();
		documentContent.setFileContent(addTestDocument("c:/temp_m/delete/"+fileName));
		documentContent.setFileName(fileName);
		
		FileWriterCallable callable = new FileWriterCallable(null);
		Future<ECMDocumentDto>t =  pool.submit(callable);
		while(t.isDone()){
			try {
				
				ECMDocumentDto test = (ECMDocumentDto)t.get();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	*/}
	private DataHandler addTestDocument(String fileLocation){
		FileDataSource dataSource = new FileDataSource(fileLocation);
		DataHandler contentHanlder = new DataHandler(dataSource);		
		return contentHanlder;		
	}
}
