package test.com.cgi.mas.provider;

import java.io.File;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.TaskCleaner;
import com.cgi.mas.provider.ConstantConfig;

public class TestTaskCleaner extends TestBaseConfig{
	@Autowired
	private TaskCleaner taskCleaner;
	@Autowired
	private ConstantConfig constantConfig;
	
	@Before
	public void setup(){		
	}	
	
	public void testExpiredFile(){
		String directory = constantConfig.getTempFileLocation();
		List<File> expiredFileCol = taskCleaner.getExpiredFile();
		displayMessage("Total File: "+expiredFileCol.size());
		for (File expiredFile : expiredFileCol){
			displayMessage(expiredFile.getName());
		}
	}	
	@Test
	public void testRemoveLockFile(){
		taskCleaner.removeLockFile();
	}
	
	public void testAddLockFile(){
		String directory = constantConfig.getTempFileLocation();
		File directoryFile = new File(directory);
		File[]fileCol = directoryFile.listFiles();
		for (File file : fileCol){
			File lockFile = new File(file.getPath()+"."+ProviderConstants.LOCK_EXTENSION);
			file.renameTo(lockFile);
		}
	}
	

}
