package test.com.cgi.mas.provider;

import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.AndFileFilter;
import org.apache.commons.io.filefilter.PrefixFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.junit.Assert;
import org.junit.Test;

import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.exceptions.CMAplIntakeWSException;
import com.cgi.mas.provider.util.EncryptionUtil;

public class TestProviderUtils {
	private String sourceFolder = "C:/Users/mpnguyen/Documents/Imaging Dummy Files/Test_Sample/source";	
	private String targetFolder = "C:/Users/mpnguyen/Documents/Imaging Dummy Files/Test_Sample/target";
	
	public void testencryption(){
		try {
			EncryptionUtil encryptionUtil = new EncryptionUtil();
			String password ="R1403mac";
			String encrypt = encryptionUtil.encryptIt(password);
			String decryptPassword = encryptionUtil.decryptIt(encrypt);
			System.out.println("Encrypt: "+encrypt+"-->"+decryptPassword);			
		} catch (CMAplIntakeWSException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public void testCopyFile(){
		long time = TimeUnit.MILLISECONDS.convert(5, TimeUnit.MINUTES);
		long start = TimeUnit.MINUTES.toMillis(5);
		System.out.println(time+"__>"+start);
		File targetDirectory = new File(targetFolder);
		try {
			
			FileUtils.deleteDirectory(targetDirectory);
			
		} catch (IOException e) {
			fail(e.getMessage());
		}		
		Assert.assertFalse("Directory should be deleted",targetDirectory.exists());
		Assert.assertTrue("Directory should be created",targetDirectory.mkdir());
		Assert.assertTrue(targetDirectory.listFiles().length == 0);
		copyFile2(sourceFolder, targetFolder, 4000);
		Assert.assertTrue(targetDirectory.listFiles().length == 4000);
	}
	
	public void removeLockFile() {
		
		File directoryFile = new File("C:\\server_upload");
		Collection<File> fileCol = FileUtils.listFiles(directoryFile, new String[] {"readLock" }, false);
		
		if(fileCol.size() > 0) System.out.println("*****Remove Lock File");
		
		for (File file : fileCol) {
			String path = file.getPath();
			String originialName = path.substring(0,path.indexOf("readLock")-1);
			File renameFile = new File(originialName);
			boolean isSuccesful = file.renameTo(renameFile);
			System.out.println(path+" --> rename to : " + originialName + " --> " + isSuccesful);
		}
		
		if(fileCol.size() > 0) System.out.println("*****Done Lock File");
	}
	public void testFilter(){
		String sourcePath = "C:/Users/mpnguyen/Documents/Imaging Dummy Files/Test_Sample/Create Appeal Testing_20131011_1454009";
		File file = new File(sourcePath);
		String fileExensionList[]=new String[]{"PDF"};
		List<String>tibcoPrefix = new ArrayList<String>();
		tibcoPrefix.add("G");
		tibcoPrefix.add("C");
		tibcoPrefix.add("D");
		tibcoPrefix.add("E");
		tibcoPrefix.add("F");
		AndFileFilter andFileFilter = new AndFileFilter(new SuffixFileFilter(fileExensionList,IOCase.INSENSITIVE),new PrefixFileFilter(tibcoPrefix));
		//String[] fileCol = fileDir.listFiles(new SuffixFileFilter(fileExensionList));
		Collection<File>fileCol = FileUtils.listFiles(file, andFileFilter,null);
		for (File t : fileCol){
			System.out.println(t.getName());
		}
		System.out.println("************Size: "+fileCol.size());
	}	
	public void testGetExpiredFile(){
		long expiredTime = 86400000;				
		long start = System.currentTimeMillis();
		long countDownTime = start - expiredTime;
		Calendar countDownCalendar = Calendar.getInstance();
		countDownCalendar.setTimeInMillis(countDownTime);
		
		StringBuilder strBuilder = new StringBuilder();
			strBuilder.append("Before this date:  ");
			strBuilder.append(ProviderUtils.convertCalendarToString(countDownCalendar, ProviderConstants.DT_FORMAT));
			strBuilder.append(" will consider expired");
		System.out.println(strBuilder.toString());
	}
	
	public void testInvalidFileName(){
		String fileName="t\"es<>twe.pdf";
		String value="0.3";
		long longt = Long.valueOf(value);
		
		System.out.println("Value: "+longt);
		//Assert.assertFalse(ProviderUtils.validateFileName(fileName));
		Assert.assertTrue("it should not have invalid character",ProviderUtils.validateFileName(fileName));
		
	}
	public void testDeleteInvalidTibCoFile(){
		String direcotry="C:/temp_m/delete/print";
		File directoryFile = new File(direcotry);
		List<String>prefixList = new ArrayList<String>();
		prefixList.add("A");
		prefixList.add("B");
		prefixList.add("C");
		while(true){
			File[] fileCol = directoryFile.listFiles();
			for (File file: fileCol){
				String name = FilenameUtils.getBaseName(file.getPath());
				if (prefixList.contains(name.substring(0,1))){
					file.delete();
				}
			}
			
		}
	}
	@Test
	public void testMD5() throws Exception {		
		File directory = new File("C:/Users/mpnguyen/Desktop/test_EAR");
		File fileCol [] = directory.listFiles();
		for (File file : fileCol){
			if (!file.isDirectory()){
				String fileName = file.getName();
				System.out.println(fileName+"-->"+ProviderUtils.getMD5CheckSum(file.getPath()));	
			}
			
		}
	}
	
	
	public void testConvertCalendarToString() {/*
		Calendar dateRequest = Calendar.getInstance();
		Assert.assertEquals("01/28/2013", ProviderUtils
				.convertCalendarToString(dateRequest,
						ProviderConstants.SIEBEL_DATE_FORMAT));
		System.out.println("New REquest: " + RequestType.NEW_APPEAL.toString());
		System.out.println("New REquest: "
				+ RequestType.EXISTING_APPEAL.toString());
	*/}
	private void copyFile2(String sourceFolder, String targetFolder, int count){
		File sourceFolderFile = new File(sourceFolder);
		File sourceFile[] = sourceFolderFile.listFiles();
		File file= sourceFile[0];
		for (int x=1;x<=count;x++){
			
			
			FileInputStream fInputStream = null;
			FileOutputStream fOutputStream = null;
			FileChannel fInchannel = null, fOutChannel = null;
			MappedByteBuffer mapByteBuffer = null;
			try {
				fInputStream = new FileInputStream(file);
				File newFile = new File(targetFolder+ "/" + file.getName());
				if (newFile.exists()){
					String fileName = FilenameUtils.getBaseName(newFile.getPath());
					String newFileName =  fileName+"_"+x;
					newFile = new File(targetFolder+"/"+newFileName+"."+FilenameUtils.getExtension(newFile.getPath()));
					
				}
				fOutputStream = new FileOutputStream(newFile);
				fInchannel = fInputStream.getChannel();
				fOutChannel = fOutputStream.getChannel();
				long size = fInchannel.size();
				mapByteBuffer = fInchannel.map(
						FileChannel.MapMode.READ_ONLY, 0, size);
				fOutChannel.write(mapByteBuffer);
				fInchannel.close();
				fOutChannel.close();
				fInputStream.close();
				fOutputStream.close();
				System.out.println("Done--"+newFile.getPath());
			} catch (Exception e) {
				System.err.println(e);
			}			
			
		}
	}

}
