package test.com.cgi.mas.provider;

import static org.junit.Assert.assertNotNull;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.cgi.mas.provider.ConstantConfig;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.exceptions.ECMServiceException;
import com.cgi.mas.provider.services.IECMConnectionService;
import com.cgi.mas.provider.services.IECMService;
import com.cgi.mas.provider.services.dto.DocumentResultDto;
import com.cgi.mas.provider.services.dto.ECMDocumentDto;
import com.ibm.mm.beans.CMBConnection;
import com.ibm.mm.beans.CMBDataManagement;
import com.ibm.mm.beans.CMBException;
import com.ibm.mm.beans.CMBItem;
import com.ibm.mm.beans.CMBObject;

public class TestECMService extends TestBaseConfig{
	@Autowired
	private IECMService ecmService = null;
	@Autowired
	private IECMConnectionService ecmConnectionService;
	@Autowired
	private ConstantConfig constantConfig;
	//private final String fileDirectory="C:/my_data/Imaging Dummy Files/Single Page TIF/";
	private CMBConnection ibmSession = null;
	
	@Before
	public void setUp() throws Exception {
		//String userName = "MAS_MAC_JF_SYS_ADMIN_USER";
		String userName ="MAS_IMG_USER";
		String password = "DB2master";
		String serverName = "ecmlsdev";
		String dsType = "ICM";
		ibmSession = ecmConnectionService.getIBMConnectionFromPool(userName, password, serverName, dsType);
		Assert.assertTrue(ibmSession.isConnected());
	}

	@After
	public void tearDown() throws Exception {
		ecmConnectionService.releaseIBMConnectionToPool(ibmSession);
		Assert.assertTrue(!ibmSession.isConnected());
	}
	
	/*
	@Ignore
	public void testDeleteDoc(){
		String appealNumber="test";
		Assert.assertTrue(ecmService.deleteDoc(ibmSession, appealNumber));
	}
	*/
	
	/*
	@Ignore
	public void testVerifyImport() throws Exception{
		String docId = "A1001001A13D03B40140C39038";
		CMBItem docItem = ecmService.searchItemById(ibmSession, docId);
		String directory = "C:/temp_m/delete";
		String filePath = exportContent(docItem, ibmSession, directory);
		displayMessage("Export Path : "+filePath);
		Assert.assertNotNull(filePath);		
		String exportMD5 = ProviderUtils.getMD5CheckSum(filePath);
		displayMessage("Export md5 : "+exportMD5);
		String description = docItem.getAttrValue(ProviderConstants.ECM_DESCRIPTION);		
		String md5 = description.substring(description.indexOf("-")+1);
		Assert.assertEquals("Md5 not match",exportMD5, md5);
	}
	*/
	@Ignore
	public void testSearchItemByDescription(){
		String appealNumber="test";
		String desc ="DF8OJFBT-md5";
		CMBItem item = null;
//			ecmService.getItemByDescription(ibmSession, null, desc);
		Assert.assertNotNull(item);
		displayMessage(item.getDDO().getPid().getPrimaryId());
		
	}
	
	/*
	@Ignore
	public void testGetSiebelId(){
		String appealNumber="test";
		List<String>idList = ecmService.getSiebelIdTest(ibmSession, appealNumber);	
		String csvFile = "G1234567.D130401.T1521314.csv";
		List<String>csvFileId = loadCSV(csvFile);
		System.out.println("Total document: "+idList.size()+"--CSV: "+(csvFileId!= null ? csvFileId.size() : "null"));
		for (int index=0;index<idList.size();index++){
			String ecmLIne = idList.get(index);

			System.out.println(ecmLIne);
		}
	}
	*/
	
	@Ignore
	public List<String> loadCSV(String csvName){		
		String directory = constantConfig.getTempFileLocation();
		String csvFile = directory+"/"+csvName;
		try {
			
			LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(csvFile));
			String line= null;
			List<String>fileIdList = new ArrayList<String>();			
			do{				
				line = lineNumberReader.readLine();
				int lineNumber = lineNumberReader.getLineNumber();
				if ((lineNumber!=1)&&(line!=null)){
					fileIdList.add(line.split(",")[0]/*.substring(1)*/);
				}
								
			}while(line!= null);
			Collections.sort(fileIdList);
			Assert.assertTrue(true);
			System.out.println("------Done------");
			/*for (String id : fileIdList){
				System.out.println(id);
			}*/
			return fileIdList;
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		
	}

	/*
	@Test
	public void testLinkICMBase(){
		String sourcedocId = "A1001001A12A09B31827H01587"; //A1001001A12A09B31827H05428
		String targetDocId = "A1001001A13C12B45717C41977";
		boolean isAddLink = true;
		String target = null;
//			ecmService.linkICBMBase(ibmSession,sourcedocId, targetDocId,isAddLink);
		System.out.println(target);
		assertNotNull(target);
	}
	*/
	
	/*
	@Ignore
	public void exportContent(){
		//String targetDocId = "A1001001A13C12B45717C41977";
		String target = ecmService.exportContent(ibmSession, "A1001001A13C12B45717C41977");
		System.out.println("Export content; "+target);
	}
	*/
	
	@Ignore
	public void testImportDocumentIntoAppeal() throws FileNotFoundException, ECMServiceException {
		List<ECMDocumentDto>documentList = new ArrayList<ECMDocumentDto>();				
		Assert.assertNotNull(ecmService);
		String appealNumber = "test";		
		ECMDocumentDto dto = new ECMDocumentDto();
		dto.setAppealNumber(appealNumber);
		String fileDirectory = constantConfig.getTempFileLocation()+"/";
		//dto.setContentInputStream(setUpContentStream(fileDirectory+"2_17_11.pdf"));
		String fileName = "EPCMMT4O.D130402.T1632574.doc";
		File file = new File(fileDirectory+fileName);
		dto.setContentLocation(file.getPath());
		//dto.setFileExtension(FilenameUtils.getExtension(fileName));
		dto.setContentInputStream(setUpContentStream(file.getPath()));
		dto.setEntityName(constantConfig.getLevel1ItemType());
		dto.setFileName(fileName);
		dto.setFileSize(file.length());
		dto.setMimeType(constantConfig.getMimeType().get(FilenameUtils.getExtension(fileName).toLowerCase()));
		dto.setAttributeMap(setupECMDocumentAttributeMap(appealNumber,"testsiebelid","MAC - Noridian Administrative Services LLC - JF","EPCMMT4O",ProviderUtils.getMD5CheckSum(file),"Level 1"));
		documentList.add(dto);
		
		List<DocumentResultDto>idList = ecmService.importDocumentIntoAppeal(ibmSession,appealNumber,documentList);
		Assert.assertNotNull(idList);
		for (DocumentResultDto resultDto : idList){
			System.out.println(resultDto.getEcmItemId()+"-->"+resultDto.getSizeInKB()+"-->"+resultDto.getPageCount());
		}
		Assert.assertFalse(idList.isEmpty());
		Assert.assertEquals(0, idList.get(0));
		
	}
	
	@Ignore
	private InputStream setUpContentStream(String fileLocation) throws FileNotFoundException{
		FileInputStream fileInputStream = new FileInputStream(fileLocation);
		return fileInputStream;
		
	}
	
	@Ignore
	private Map<String,String> setupECMDocumentAttributeMap(String appealNumber,String siebelId,String org,String fileId, String md5,String appealLevel){
		HashMap<String,String> ecmAttrMap = new HashMap<String,String>();
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel2DocCategory());
		}
		else if(appealLevel.contains(constantConfig.getLevel1())){
			ecmAttrMap.put(ProviderConstants.ECM_CATEGORY,constantConfig.getSiebelLevel1DocCategory());
		}
		ecmAttrMap.put(ProviderConstants.ECM_RECEIVED_DT, ProviderUtils.convertCalendarToString(Calendar.getInstance(), ProviderConstants.ECM_DT_FORMAT));
		
		ecmAttrMap.put(ProviderConstants.ECM_AUDT_CD, constantConfig.getDocAuditCode().get(org));
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel2Code());
		}
		if(appealLevel.contains(constantConfig.getLevel2())){
			ecmAttrMap.put(ProviderConstants.ECM_DOCTYPE, constantConfig.getEcmDocTypeLevel1Code());
		}
		ecmAttrMap.put(ProviderConstants.ECM_DESCRIPTION, fileId+"-"+md5);
		ecmAttrMap.put(ProviderConstants.ECM_APPEAL_NUM, appealNumber);
		if (StringUtils.hasText(siebelId)){
			ecmAttrMap.put(ProviderConstants.ECM_SIEBEL_LVL_1_ID, siebelId);	
		}
		return ecmAttrMap;
	}
	
	/*
	@Ignore
	private String exportContent(CMBItem item,CMBConnection ibmSession,String directory){
		CMBDataManagement dataManager = null;
		try{
			dataManager = ibmSession.getDataManagement();
			dataManager.setDataObject(item);
			dataManager.retrieveItem();
			CMBObject[] contentList = dataManager.getContent();
			for (CMBObject contentObj : contentList){
				if (contentObj.getPartType().equalsIgnoreCase("ICMBASE")){
					return writeContentToFileChannel(contentObj,directory);
				}						
			}
		}catch(Exception e){
			
		}
		return null;
	}
	*/
	
	@Ignore
	private String writeContentToFileChannel(CMBObject content,
			String targetDirectory) throws CMBException {

		String fileName = null;

		fileName = content.getOriginalFileName();
		String mimeType = content.getMimeType();
		BufferedInputStream bufferInputStream = null;

		String targetFile = targetDirectory + "/"+fileName;		
		File targetfileItem = new File(targetFile);
		if (targetfileItem.exists()){
			targetfileItem.delete();
		}
		FileOutputStream fileOutStream = null;
		InputStream contentInputStream = content.getDataStream();
		FileChannel outChanel = null;
		ReadableByteChannel readByteChannel = null;
		try {
			
			fileOutStream = new FileOutputStream(targetFile);
			outChanel = fileOutStream.getChannel();
			readByteChannel = Channels.newChannel(contentInputStream);			
			ByteBuffer byteBuffer = ByteBuffer.allocateDirect(2*1024);
			while (readByteChannel.read(byteBuffer) != -1) {
				// prepare the buffer to be drained
				byteBuffer.flip();
				// write to the channel, may block
				outChanel.write(byteBuffer);
				// If partial transfer, shift remainder down
				// If buffer is empty, same as doing clear()
				byteBuffer.compact();
			}
			// EOF will leave buffer in fill state
			byteBuffer.flip();
			// make sure the buffer is fully drained.
			while (byteBuffer.hasRemaining()) {
				outChanel.write(byteBuffer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			targetFile = null;
		} finally {
			if (readByteChannel != null) {
				try {
					readByteChannel.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (outChanel != null) {
				try {
					outChanel.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (contentInputStream != null) {
				try {
					contentInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (bufferInputStream != null) {
				try {
					bufferInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fileOutStream != null) {
				try {
					fileOutStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		content.getXDO().setNull();
		return targetFile;
	}
	

}
