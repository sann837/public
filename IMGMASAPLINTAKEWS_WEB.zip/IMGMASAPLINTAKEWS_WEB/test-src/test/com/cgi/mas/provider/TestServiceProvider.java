package test.com.cgi.mas.provider;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cgi.mas.provider.services.ServiceProvider;

public class TestServiceProvider {
	private ServiceProvider serviceProvider = null;
	@Before
	public void setUp() throws Exception {
		serviceProvider = new ServiceProvider();
	}

	@After
	public void tearDown() throws Exception {
		serviceProvider = null;
	}

	@Test
	public void testCreateAppealFolder() {/*
		CreateAppealRequest request = new CreateAppealRequest();	
		request.setAppealRequestDate(Calendar.getInstance());
		request.setAppealRequestType(RequestType.NEW_APPEAL);
		request.setJurisdiction("Test Jurisdiction");
		request.setSiebelUserId("TJO");
		request.setSiebelPassword("CMSMAS01");
		try {
			CreateAppealResponse response =  serviceProvider.createAppealFolder(request);
			assertNotNull(response);
			assertNotNull(null);
		} catch (CreateAppealException e) {			
			fail(e.getMessage());
		}
	*/}

}
