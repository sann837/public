package test.com.cgi.mas.provider.validators;

import java.util.Calendar;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.ObjectError;

import test.com.cgi.mas.provider.TestBaseConfig;

import com.cgi.cms.services.schema.mas.CreateAppealRequest;
import com.cgi.cms.services.schema.mas.DocumentDetail;
import com.cgi.cms.services.schema.mas.DocumentList;
import com.cgi.cms.services.schema.mas.Org;
import com.cgi.mas.provider.ProviderConstants;
import com.cgi.mas.provider.ProviderUtils;
import com.cgi.mas.provider.validations.CreateAppealDocValidator;

public class TestCreateAppealDocValidator extends TestBaseConfig{
	@Autowired
	private CreateAppealDocValidator  createAppealValidator;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidate() {
		CreateAppealRequest request = createAppealRequest();
		BeanPropertyBindingResult errors = new BeanPropertyBindingResult(request, "item");
		createAppealValidator.validate(request, errors);
		displayMessage("Got Error: "+errors.hasErrors());
		List<ObjectError>errorList = errors.getAllErrors();
		for (ObjectError error : errorList){
			displayMessage(error.getCode()+"-->"+error.getDefaultMessage());
			
		}
		Assert.assertTrue(true);
		
	}
	private CreateAppealRequest createAppealRequest(){
		CreateAppealRequest request = new CreateAppealRequest();
		Org org = new Org();
		org.setJurisdiction("JF");
		org.setMac("MAC - Noridian Administrative Services LLC");
		request.setOrg(org);
		String date ="03/26/2013";
		request.setRequestDate(ProviderUtils.convertStringToCalendar(date,ProviderConstants.S_DT_FORMAT));
		request.setClaimList(null);
		
		DocumentList documentList = new DocumentList();
		
		DocumentDetail docDetail = new DocumentDetail();
		docDetail.setChecksum("8d90613b0a87eedbe80597ce6d58c9e0");
		docDetail.setFileId("D6BK6YMO3");
		docDetail.setFileName("00000001.pdf");
		
		documentList.getDocument().add(docDetail);
		
		DocumentDetail docDetail1 = new DocumentDetail();
		docDetail1.setChecksum("8d90613b0a87eedbe80597ce6d58c9e0");
		docDetail1.setFileId("D6BK6YMO2");
		docDetail1.setFileName("00000002.pdf");
		
		documentList.getDocument().add(docDetail1);
		
		
		DocumentDetail docDetail3 = new DocumentDetail();
		docDetail3.setChecksum("8d90613b0a87eedbe80597ce6d58c9e0");
		docDetail3.setFileId("E6BK6YMO1");
		docDetail3.setFileName("00000001.pdf");
		
		documentList.getDocument().add(docDetail3);
		
		DocumentDetail docDetail4 = new DocumentDetail();
		docDetail4.setChecksum("8d90613b0a87eedbe80597ce6d58c9e0");
		docDetail4.setFileId("D6BK6YMO3");
		docDetail4.setFileName("00000001.pdf");
		
		documentList.getDocument().add(docDetail4);
		
		request.setDocumentList(documentList);
		return request;
	}

}
