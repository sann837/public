
package com.siebel.xml.masassociatedocsio;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfMasassociatedocsio complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfMasassociatedocsio">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MasBcValidateDocuments-Appeal" type="{http://www.siebel.com/xml/MASAssociateDocsIO}MasBcValidateDocuments-Appeal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfMasassociatedocsio", propOrder = {
    "masBcValidateDocumentsAppeal"
})
public class ListOfMasassociatedocsio {

    @XmlElement(name = "MasBcValidateDocuments-Appeal", required = true)
    protected MasBcValidateDocumentsAppeal masBcValidateDocumentsAppeal;

    /**
     * Gets the value of the masBcValidateDocumentsAppeal property.
     * 
     * @return
     *     possible object is
     *     {@link MasBcValidateDocumentsAppeal }
     *     
     */
    public MasBcValidateDocumentsAppeal getMasBcValidateDocumentsAppeal() {
        return masBcValidateDocumentsAppeal;
    }

    /**
     * Sets the value of the masBcValidateDocumentsAppeal property.
     * 
     * @param value
     *     allowed object is
     *     {@link MasBcValidateDocumentsAppeal }
     *     
     */
    public void setMasBcValidateDocumentsAppeal(MasBcValidateDocumentsAppeal value) {
        this.masBcValidateDocumentsAppeal = value;
    }

}
