
package com.siebel.xml.masassociatedocsio;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MasBcValidateDocuments-Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MasBcValidateDocuments-Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AppealRequestDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ListOfMasBcAssociateDocuments" type="{http://www.siebel.com/xml/MASAssociateDocsIO}ListOfMasBcAssociateDocuments" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MasBcValidateDocuments-Appeal", propOrder = {
    "appealNum",
    "appealRequestDate",
    "transactionID",
    "listOfMasBcAssociateDocuments"
})
public class MasBcValidateDocumentsAppeal {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "AppealRequestDate", required = true)
    protected String appealRequestDate;
    @XmlElement(name = "TransactionID", required = true)
    protected String transactionID;
    @XmlElement(name = "ListOfMasBcAssociateDocuments")
    protected ListOfMasBcAssociateDocuments listOfMasBcAssociateDocuments;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the appealRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealRequestDate() {
        return appealRequestDate;
    }

    /**
     * Sets the value of the appealRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealRequestDate(String value) {
        this.appealRequestDate = value;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the listOfMasBcAssociateDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasBcAssociateDocuments }
     *     
     */
    public ListOfMasBcAssociateDocuments getListOfMasBcAssociateDocuments() {
        return listOfMasBcAssociateDocuments;
    }

    /**
     * Sets the value of the listOfMasBcAssociateDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasBcAssociateDocuments }
     *     
     */
    public void setListOfMasBcAssociateDocuments(ListOfMasBcAssociateDocuments value) {
        this.listOfMasBcAssociateDocuments = value;
    }

}
