
package com.siebel.xml.masassociatedocsio;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.masassociatedocsio package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasassociatedocsio_QNAME = new QName("http://www.siebel.com/xml/MASAssociateDocsIO", "ListOfMasassociatedocsio");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.masassociatedocsio
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasassociatedocsio }
     * 
     */
    public ListOfMasassociatedocsio createListOfMasassociatedocsio() {
        return new ListOfMasassociatedocsio();
    }

    /**
     * Create an instance of {@link ListOfMasBcAssociateDocuments }
     * 
     */
    public ListOfMasBcAssociateDocuments createListOfMasBcAssociateDocuments() {
        return new ListOfMasBcAssociateDocuments();
    }

    /**
     * Create an instance of {@link MasBcAssociateDocuments }
     * 
     */
    public MasBcAssociateDocuments createMasBcAssociateDocuments() {
        return new MasBcAssociateDocuments();
    }

    /**
     * Create an instance of {@link MasBcValidateDocumentsAppeal }
     * 
     */
    public MasBcValidateDocumentsAppeal createMasBcValidateDocumentsAppeal() {
        return new MasBcValidateDocumentsAppeal();
    }

    /**
     * Create an instance of {@link ListOfMasassociatedocsioTopElmt }
     * 
     */
    public ListOfMasassociatedocsioTopElmt createListOfMasassociatedocsioTopElmt() {
        return new ListOfMasassociatedocsioTopElmt();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasassociatedocsio }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MASAssociateDocsIO", name = "ListOfMasassociatedocsio")
    public JAXBElement<ListOfMasassociatedocsio> createListOfMasassociatedocsio(ListOfMasassociatedocsio value) {
        return new JAXBElement<ListOfMasassociatedocsio>(_ListOfMasassociatedocsio_QNAME, ListOfMasassociatedocsio.class, null, value);
    }

}
