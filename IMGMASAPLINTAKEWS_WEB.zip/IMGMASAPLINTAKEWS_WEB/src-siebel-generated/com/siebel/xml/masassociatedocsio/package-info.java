@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MASAssociateDocsIO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.masassociatedocsio;
