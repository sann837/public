
package com.siebel.xml.mas_20l1_20ecm_20bc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfL1documentlist complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfL1documentlist">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="L1DocumentList" type="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}L1DocumentList" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfL1documentlist", propOrder = {
    "l1DocumentList"
})
public class ListOfL1Documentlist {

    @XmlElement(name = "L1DocumentList")
    protected List<L1DocumentList> l1DocumentList;

    /**
     * Gets the value of the l1DocumentList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the l1DocumentList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getL1DocumentList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link L1DocumentList }
     * 
     * 
     */
    public List<L1DocumentList> getL1DocumentList() {
        if (l1DocumentList == null) {
            l1DocumentList = new ArrayList<L1DocumentList>();
        }
        return this.l1DocumentList;
    }

}
