
package com.siebel.xml.mas_20l1_20ecm_20bc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for L1DocumentList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="L1DocumentList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Checksum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FileId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FileName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ListOfHICNumbers" type="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}ListOfHICNumbers" minOccurs="0"/>
 *         &lt;element name="ListOfClaimNumbers" type="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}ListOfClaimNumbers" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "L1DocumentList", propOrder = {
    "checksum",
    "fileId",
    "fileName",
    "type",
    "listOfHICNumbers",
    "listOfClaimNumbers"
})
public class L1DocumentList {

    @XmlElement(name = "Checksum")
    protected String checksum;
    @XmlElement(name = "FileId")
    protected String fileId;
    @XmlElement(name = "FileName")
    protected String fileName;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "ListOfHICNumbers")
    protected ListOfHICNumbers listOfHICNumbers;
    @XmlElement(name = "ListOfClaimNumbers")
    protected ListOfClaimNumbers listOfClaimNumbers;

    /**
     * Gets the value of the checksum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChecksum() {
        return checksum;
    }

    /**
     * Sets the value of the checksum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChecksum(String value) {
        this.checksum = value;
    }

    /**
     * Gets the value of the fileId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the value of the fileId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileId(String value) {
        this.fileId = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the listOfHICNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfHICNumbers }
     *     
     */
    public ListOfHICNumbers getListOfHICNumbers() {
        return listOfHICNumbers;
    }

    /**
     * Sets the value of the listOfHICNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfHICNumbers }
     *     
     */
    public void setListOfHICNumbers(ListOfHICNumbers value) {
        this.listOfHICNumbers = value;
    }

    /**
     * Gets the value of the listOfClaimNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfClaimNumbers }
     *     
     */
    public ListOfClaimNumbers getListOfClaimNumbers() {
        return listOfClaimNumbers;
    }

    /**
     * Sets the value of the listOfClaimNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfClaimNumbers }
     *     
     */
    public void setListOfClaimNumbers(ListOfClaimNumbers value) {
        this.listOfClaimNumbers = value;
    }

}
