@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20L1%20ECM%20BC", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20l1_20ecm_20bc;
