
package com.siebel.xml.mas_20l1_20ecm_20bc;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l1_20ecm_20bc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfL1Documentlist_QNAME = new QName("http://www.siebel.com/xml/MAS%20L1%20ECM%20BC", "ListOfL1documentlist");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l1_20ecm_20bc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfL1Documentlist }
     * 
     */
    public ListOfL1Documentlist createListOfL1Documentlist() {
        return new ListOfL1Documentlist();
    }

    /**
     * Create an instance of {@link ListOfL1DocumentlistTopElmt }
     * 
     */
    public ListOfL1DocumentlistTopElmt createListOfL1DocumentlistTopElmt() {
        return new ListOfL1DocumentlistTopElmt();
    }

    /**
     * Create an instance of {@link ClaimNumberList }
     * 
     */
    public ClaimNumberList createClaimNumberList() {
        return new ClaimNumberList();
    }

    /**
     * Create an instance of {@link ListOfClaimNumbers }
     * 
     */
    public ListOfClaimNumbers createListOfClaimNumbers() {
        return new ListOfClaimNumbers();
    }

    /**
     * Create an instance of {@link HICNumberList }
     * 
     */
    public HICNumberList createHICNumberList() {
        return new HICNumberList();
    }

    /**
     * Create an instance of {@link ListOfHICNumbers }
     * 
     */
    public ListOfHICNumbers createListOfHICNumbers() {
        return new ListOfHICNumbers();
    }

    /**
     * Create an instance of {@link L1DocumentList }
     * 
     */
    public L1DocumentList createL1DocumentList() {
        return new L1DocumentList();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfL1Documentlist }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L1%20ECM%20BC", name = "ListOfL1documentlist")
    public JAXBElement<ListOfL1Documentlist> createListOfL1Documentlist(ListOfL1Documentlist value) {
        return new JAXBElement<ListOfL1Documentlist>(_ListOfL1Documentlist_QNAME, ListOfL1Documentlist.class, null, value);
    }

}
