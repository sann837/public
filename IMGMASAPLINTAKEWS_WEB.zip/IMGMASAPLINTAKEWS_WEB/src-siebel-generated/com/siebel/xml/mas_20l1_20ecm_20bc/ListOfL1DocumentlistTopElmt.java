
package com.siebel.xml.mas_20l1_20ecm_20bc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfL1documentlistTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfL1documentlistTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfL1documentlist" type="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}ListOfL1documentlist"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfL1documentlistTopElmt", propOrder = {
    "listOfL1Documentlist"
})
public class ListOfL1DocumentlistTopElmt {

    @XmlElement(name = "ListOfL1documentlist", required = true)
    protected ListOfL1Documentlist listOfL1Documentlist;

    /**
     * Gets the value of the listOfL1Documentlist property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public ListOfL1Documentlist getListOfL1Documentlist() {
        return listOfL1Documentlist;
    }

    /**
     * Sets the value of the listOfL1Documentlist property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public void setListOfL1Documentlist(ListOfL1Documentlist value) {
        this.listOfL1Documentlist = value;
    }

}
