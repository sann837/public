
package com.siebel.xml.mas_20validate_20documents_20request_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20validate_20documents_20request_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfRequestDocsIO_QNAME = new QName("http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO", "ListOfRequestDocsIO");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20validate_20documents_20request_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfRequestDocsIO }
     * 
     */
    public ListOfRequestDocsIO createListOfRequestDocsIO() {
        return new ListOfRequestDocsIO();
    }

    /**
     * Create an instance of {@link ListOfRequestDocsIOTopElmt }
     * 
     */
    public ListOfRequestDocsIOTopElmt createListOfRequestDocsIOTopElmt() {
        return new ListOfRequestDocsIOTopElmt();
    }

    /**
     * Create an instance of {@link RequestDocuments }
     * 
     */
    public RequestDocuments createRequestDocuments() {
        return new RequestDocuments();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfRequestDocsIO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO", name = "ListOfRequestDocsIO")
    public JAXBElement<ListOfRequestDocsIO> createListOfRequestDocsIO(ListOfRequestDocsIO value) {
        return new JAXBElement<ListOfRequestDocsIO>(_ListOfRequestDocsIO_QNAME, ListOfRequestDocsIO.class, null, value);
    }

}
