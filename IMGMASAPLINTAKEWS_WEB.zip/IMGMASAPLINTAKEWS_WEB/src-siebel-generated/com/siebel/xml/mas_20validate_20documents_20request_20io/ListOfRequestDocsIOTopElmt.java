
package com.siebel.xml.mas_20validate_20documents_20request_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfRequestDocsIOTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfRequestDocsIOTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfRequestDocsIO" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO}ListOfRequestDocsIO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfRequestDocsIOTopElmt", propOrder = {
    "listOfRequestDocsIO"
})
public class ListOfRequestDocsIOTopElmt {

    @XmlElement(name = "ListOfRequestDocsIO", required = true)
    protected ListOfRequestDocsIO listOfRequestDocsIO;

    /**
     * Gets the value of the listOfRequestDocsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfRequestDocsIO }
     *     
     */
    public ListOfRequestDocsIO getListOfRequestDocsIO() {
        return listOfRequestDocsIO;
    }

    /**
     * Sets the value of the listOfRequestDocsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfRequestDocsIO }
     *     
     */
    public void setListOfRequestDocsIO(ListOfRequestDocsIO value) {
        this.listOfRequestDocsIO = value;
    }

}
