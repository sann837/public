@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20validate_20documents_20request_20io;
