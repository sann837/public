
package com.siebel.xml.mas_20validate_20documents_20request_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO}string100"/>
 *         &lt;element name="TransactionID" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO}string50"/>
 *         &lt;element name="RequestDocuments" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Request%20IO}RequestDocuments" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "appealNum",
    "transactionID",
    "requestDocuments"
})
public class Appeal {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "TransactionID", required = true)
    protected String transactionID;
    @XmlElement(name = "RequestDocuments")
    protected RequestDocuments requestDocuments;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the requestDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link RequestDocuments }
     *     
     */
    public RequestDocuments getRequestDocuments() {
        return requestDocuments;
    }

    /**
     * Sets the value of the requestDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestDocuments }
     *     
     */
    public void setRequestDocuments(RequestDocuments value) {
        this.requestDocuments = value;
    }

}
