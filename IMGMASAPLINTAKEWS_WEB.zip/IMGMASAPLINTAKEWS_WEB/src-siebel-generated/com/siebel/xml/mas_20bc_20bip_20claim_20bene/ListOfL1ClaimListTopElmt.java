
package com.siebel.xml.mas_20bc_20bip_20claim_20bene;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfL1ClaimListTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfL1ClaimListTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfL1ClaimList" type="{http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene}ListOfL1ClaimList"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfL1ClaimListTopElmt", propOrder = {
    "listOfL1ClaimList"
})
public class ListOfL1ClaimListTopElmt {

    @XmlElement(name = "ListOfL1ClaimList", required = true)
    protected ListOfL1ClaimList listOfL1ClaimList;

    /**
     * Gets the value of the listOfL1ClaimList property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL1ClaimList }
     *     
     */
    public ListOfL1ClaimList getListOfL1ClaimList() {
        return listOfL1ClaimList;
    }

    /**
     * Sets the value of the listOfL1ClaimList property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL1ClaimList }
     *     
     */
    public void setListOfL1ClaimList(ListOfL1ClaimList value) {
        this.listOfL1ClaimList = value;
    }

}
