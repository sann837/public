
package com.siebel.xml.mas_20bc_20bip_20claim_20bene;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20bc_20bip_20claim_20bene package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfL1ClaimList_QNAME = new QName("http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene", "ListOfL1ClaimList");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20bc_20bip_20claim_20bene
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfL1ClaimList }
     * 
     */
    public ListOfL1ClaimList createListOfL1ClaimList() {
        return new ListOfL1ClaimList();
    }

    /**
     * Create an instance of {@link ListOfL1ClaimListTopElmt }
     * 
     */
    public ListOfL1ClaimListTopElmt createListOfL1ClaimListTopElmt() {
        return new ListOfL1ClaimListTopElmt();
    }

    /**
     * Create an instance of {@link L1ClaimLists }
     * 
     */
    public L1ClaimLists createL1ClaimLists() {
        return new L1ClaimLists();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfL1ClaimList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene", name = "ListOfL1ClaimList")
    public JAXBElement<ListOfL1ClaimList> createListOfL1ClaimList(ListOfL1ClaimList value) {
        return new JAXBElement<ListOfL1ClaimList>(_ListOfL1ClaimList_QNAME, ListOfL1ClaimList.class, null, value);
    }

}
