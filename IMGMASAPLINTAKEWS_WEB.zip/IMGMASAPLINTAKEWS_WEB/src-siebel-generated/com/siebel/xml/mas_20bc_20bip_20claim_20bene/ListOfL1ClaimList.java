
package com.siebel.xml.mas_20bc_20bip_20claim_20bene;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfL1ClaimList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfL1ClaimList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="L1ClaimLists" type="{http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene}L1ClaimLists" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfL1ClaimList", propOrder = {
    "l1ClaimLists"
})
public class ListOfL1ClaimList {

    @XmlElement(name = "L1ClaimLists")
    protected List<L1ClaimLists> l1ClaimLists;

    /**
     * Gets the value of the l1ClaimLists property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the l1ClaimLists property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getL1ClaimLists().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link L1ClaimLists }
     * 
     * 
     */
    public List<L1ClaimLists> getL1ClaimLists() {
        if (l1ClaimLists == null) {
            l1ClaimLists = new ArrayList<L1ClaimLists>();
        }
        return this.l1ClaimLists;
    }

}
