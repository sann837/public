
package com.siebel.xml.mas_20validate_20documents_20response_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppealNum" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AppealOrganization" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AppealRequestDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ECMPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ECMUserId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AppealDocuments" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Response%20IO}AppealDocuments" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "appealNum",
    "appealOrganization",
    "appealRequestDate",
    "ecmPassword",
    "ecmUserId",
    "transactionID",
    "appealDocuments"
})
public class Appeal {

    @XmlElement(name = "AppealNum", required = true)
    protected String appealNum;
    @XmlElement(name = "AppealOrganization", required = true)
    protected String appealOrganization;
    @XmlElement(name = "AppealRequestDate", required = true)
    protected String appealRequestDate;
    @XmlElement(name = "ECMPassword", required = true)
    protected String ecmPassword;
    @XmlElement(name = "ECMUserId", required = true)
    protected String ecmUserId;
    @XmlElement(name = "TransactionID", required = true)
    protected String transactionID;
    @XmlElement(name = "AppealDocuments")
    protected AppealDocuments appealDocuments;

    /**
     * Gets the value of the appealNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNum() {
        return appealNum;
    }

    /**
     * Sets the value of the appealNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNum(String value) {
        this.appealNum = value;
    }

    /**
     * Gets the value of the appealOrganization property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealOrganization() {
        return appealOrganization;
    }

    /**
     * Sets the value of the appealOrganization property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealOrganization(String value) {
        this.appealOrganization = value;
    }

    /**
     * Gets the value of the appealRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealRequestDate() {
        return appealRequestDate;
    }

    /**
     * Sets the value of the appealRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealRequestDate(String value) {
        this.appealRequestDate = value;
    }

    /**
     * Gets the value of the ecmPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECMPassword() {
        return ecmPassword;
    }

    /**
     * Sets the value of the ecmPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECMPassword(String value) {
        this.ecmPassword = value;
    }

    /**
     * Gets the value of the ecmUserId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECMUserId() {
        return ecmUserId;
    }

    /**
     * Sets the value of the ecmUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECMUserId(String value) {
        this.ecmUserId = value;
    }

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the appealDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link AppealDocuments }
     *     
     */
    public AppealDocuments getAppealDocuments() {
        return appealDocuments;
    }

    /**
     * Sets the value of the appealDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link AppealDocuments }
     *     
     */
    public void setAppealDocuments(AppealDocuments value) {
        this.appealDocuments = value;
    }

}
