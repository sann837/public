
package com.siebel.xml.mas_20validate_20documents_20response_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfResponseDocsIOTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfResponseDocsIOTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfResponseDocsIO" type="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Response%20IO}ListOfResponseDocsIO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfResponseDocsIOTopElmt", propOrder = {
    "listOfResponseDocsIO"
})
public class ListOfResponseDocsIOTopElmt {

    @XmlElement(name = "ListOfResponseDocsIO", required = true)
    protected ListOfResponseDocsIO listOfResponseDocsIO;

    /**
     * Gets the value of the listOfResponseDocsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfResponseDocsIO }
     *     
     */
    public ListOfResponseDocsIO getListOfResponseDocsIO() {
        return listOfResponseDocsIO;
    }

    /**
     * Sets the value of the listOfResponseDocsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfResponseDocsIO }
     *     
     */
    public void setListOfResponseDocsIO(ListOfResponseDocsIO value) {
        this.listOfResponseDocsIO = value;
    }

}
