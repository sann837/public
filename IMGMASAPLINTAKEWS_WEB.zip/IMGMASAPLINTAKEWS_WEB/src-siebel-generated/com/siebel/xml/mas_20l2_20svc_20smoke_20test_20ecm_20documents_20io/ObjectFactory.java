
package com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfL2DocumentsIO_QNAME = new QName("http://www.siebel.com/xml/MAS%20L2%20Svc%20Smoke%20Test%20ECM%20Documents%20IO", "ListOfL2DocumentsIO");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfL2DocumentsIO }
     * 
     */
    public ListOfL2DocumentsIO createListOfL2DocumentsIO() {
        return new ListOfL2DocumentsIO();
    }

    /**
     * Create an instance of {@link ListOfL2DocumentsIOTopElmt }
     * 
     */
    public ListOfL2DocumentsIOTopElmt createListOfL2DocumentsIOTopElmt() {
        return new ListOfL2DocumentsIOTopElmt();
    }

    /**
     * Create an instance of {@link EcmDocument }
     * 
     */
    public EcmDocument createEcmDocument() {
        return new EcmDocument();
    }

    /**
     * Create an instance of {@link ListOfEcmDocuments }
     * 
     */
    public ListOfEcmDocuments createListOfEcmDocuments() {
        return new ListOfEcmDocuments();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfL2DocumentsIO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L2%20Svc%20Smoke%20Test%20ECM%20Documents%20IO", name = "ListOfL2DocumentsIO")
    public JAXBElement<ListOfL2DocumentsIO> createListOfL2DocumentsIO(ListOfL2DocumentsIO value) {
        return new JAXBElement<ListOfL2DocumentsIO>(_ListOfL2DocumentsIO_QNAME, ListOfL2DocumentsIO.class, null, value);
    }

}
