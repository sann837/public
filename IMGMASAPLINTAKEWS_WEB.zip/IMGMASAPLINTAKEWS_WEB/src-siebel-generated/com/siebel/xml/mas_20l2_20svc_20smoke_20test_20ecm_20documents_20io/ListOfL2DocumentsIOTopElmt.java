
package com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfL2DocumentsIOTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfL2DocumentsIOTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfL2DocumentsIO" type="{http://www.siebel.com/xml/MAS%20L2%20Svc%20Smoke%20Test%20ECM%20Documents%20IO}ListOfL2DocumentsIO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfL2DocumentsIOTopElmt", propOrder = {
    "listOfL2DocumentsIO"
})
public class ListOfL2DocumentsIOTopElmt {

    @XmlElement(name = "ListOfL2DocumentsIO", required = true)
    protected ListOfL2DocumentsIO listOfL2DocumentsIO;

    /**
     * Gets the value of the listOfL2DocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL2DocumentsIO }
     *     
     */
    public ListOfL2DocumentsIO getListOfL2DocumentsIO() {
        return listOfL2DocumentsIO;
    }

    /**
     * Sets the value of the listOfL2DocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL2DocumentsIO }
     *     
     */
    public void setListOfL2DocumentsIO(ListOfL2DocumentsIO value) {
        this.listOfL2DocumentsIO = value;
    }

}
