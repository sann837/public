@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.xml.mas_20l2_20appeal_20partcd_20io;
