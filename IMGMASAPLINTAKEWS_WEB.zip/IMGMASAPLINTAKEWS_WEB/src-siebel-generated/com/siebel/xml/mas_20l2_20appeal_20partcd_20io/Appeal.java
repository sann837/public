
package com.siebel.xml.mas_20l2_20appeal_20partcd_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Appeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Appeal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RequestReceivedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RequestDescription" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string255"/>
 *         &lt;element name="PlanContractNum" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string50"/>
 *         &lt;element name="BeneficiaryIdentifier" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string50" minOccurs="0"/>
 *         &lt;element name="Level1AppealPriority" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string50" minOccurs="0"/>
 *         &lt;element name="MCODenialType" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string30" minOccurs="0"/>
 *         &lt;element name="ODRequestDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CorrectMCORequestDate" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string5" minOccurs="0"/>
 *         &lt;element name="MCODecisionDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MCORequestDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ODDecisionDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DenialReasonCategory" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string100" minOccurs="0"/>
 *         &lt;element name="DenialReasonSubCategory" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}string100" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Appeal", propOrder = {
    "requestReceivedDate",
    "requestDescription",
    "planContractNum",
    "beneficiaryIdentifier",
    "level1AppealPriority",
    "mcoDenialType",
    "odRequestDate",
    "correctMCORequestDate",
    "mcoDecisionDate",
    "mcoRequestDate",
    "odDecisionDate",
    "denialReasonCategory",
    "denialReasonSubCategory"
})
public class Appeal {

    @XmlElement(name = "RequestReceivedDate", required = true)
    protected String requestReceivedDate;
    @XmlElement(name = "RequestDescription", required = true)
    protected String requestDescription;
    @XmlElement(name = "PlanContractNum", required = true)
    protected String planContractNum;
    @XmlElement(name = "BeneficiaryIdentifier")
    protected String beneficiaryIdentifier;
    @XmlElement(name = "Level1AppealPriority")
    protected String level1AppealPriority;
    @XmlElement(name = "MCODenialType")
    protected String mcoDenialType;
    @XmlElement(name = "ODRequestDate")
    protected String odRequestDate;
    @XmlElement(name = "CorrectMCORequestDate")
    protected String correctMCORequestDate;
    @XmlElement(name = "MCODecisionDate")
    protected String mcoDecisionDate;
    @XmlElement(name = "MCORequestDate")
    protected String mcoRequestDate;
    @XmlElement(name = "ODDecisionDate")
    protected String odDecisionDate;
    @XmlElement(name = "DenialReasonCategory")
    protected String denialReasonCategory;
    @XmlElement(name = "DenialReasonSubCategory")
    protected String denialReasonSubCategory;

    /**
     * Gets the value of the requestReceivedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestReceivedDate() {
        return requestReceivedDate;
    }

    /**
     * Sets the value of the requestReceivedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestReceivedDate(String value) {
        this.requestReceivedDate = value;
    }

    /**
     * Gets the value of the requestDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDescription() {
        return requestDescription;
    }

    /**
     * Sets the value of the requestDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDescription(String value) {
        this.requestDescription = value;
    }

    /**
     * Gets the value of the planContractNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanContractNum() {
        return planContractNum;
    }

    /**
     * Sets the value of the planContractNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanContractNum(String value) {
        this.planContractNum = value;
    }

    /**
     * Gets the value of the beneficiaryIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryIdentifier() {
        return beneficiaryIdentifier;
    }

    /**
     * Sets the value of the beneficiaryIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryIdentifier(String value) {
        this.beneficiaryIdentifier = value;
    }

    /**
     * Gets the value of the level1AppealPriority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLevel1AppealPriority() {
        return level1AppealPriority;
    }

    /**
     * Sets the value of the level1AppealPriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLevel1AppealPriority(String value) {
        this.level1AppealPriority = value;
    }

    /**
     * Gets the value of the mcoDenialType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCODenialType() {
        return mcoDenialType;
    }

    /**
     * Sets the value of the mcoDenialType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCODenialType(String value) {
        this.mcoDenialType = value;
    }

    /**
     * Gets the value of the odRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getODRequestDate() {
        return odRequestDate;
    }

    /**
     * Sets the value of the odRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setODRequestDate(String value) {
        this.odRequestDate = value;
    }

    /**
     * Gets the value of the correctMCORequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrectMCORequestDate() {
        return correctMCORequestDate;
    }

    /**
     * Sets the value of the correctMCORequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrectMCORequestDate(String value) {
        this.correctMCORequestDate = value;
    }

    /**
     * Gets the value of the mcoDecisionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCODecisionDate() {
        return mcoDecisionDate;
    }

    /**
     * Sets the value of the mcoDecisionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCODecisionDate(String value) {
        this.mcoDecisionDate = value;
    }

    /**
     * Gets the value of the mcoRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMCORequestDate() {
        return mcoRequestDate;
    }

    /**
     * Sets the value of the mcoRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMCORequestDate(String value) {
        this.mcoRequestDate = value;
    }

    /**
     * Gets the value of the odDecisionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getODDecisionDate() {
        return odDecisionDate;
    }

    /**
     * Sets the value of the odDecisionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setODDecisionDate(String value) {
        this.odDecisionDate = value;
    }

    /**
     * Gets the value of the denialReasonCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenialReasonCategory() {
        return denialReasonCategory;
    }

    /**
     * Sets the value of the denialReasonCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenialReasonCategory(String value) {
        this.denialReasonCategory = value;
    }

    /**
     * Gets the value of the denialReasonSubCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDenialReasonSubCategory() {
        return denialReasonSubCategory;
    }

    /**
     * Sets the value of the denialReasonSubCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDenialReasonSubCategory(String value) {
        this.denialReasonSubCategory = value;
    }

}
