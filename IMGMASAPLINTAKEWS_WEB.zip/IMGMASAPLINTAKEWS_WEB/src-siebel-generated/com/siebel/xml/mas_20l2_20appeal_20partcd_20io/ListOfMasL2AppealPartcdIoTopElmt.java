
package com.siebel.xml.mas_20l2_20appeal_20partcd_20io;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ListOfMasL2AppealPartcdIoTopElmt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ListOfMasL2AppealPartcdIoTopElmt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListOfMasL2AppealPartcdIo" type="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}ListOfMasL2AppealPartcdIo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfMasL2AppealPartcdIoTopElmt", propOrder = {
    "listOfMasL2AppealPartcdIo"
})
public class ListOfMasL2AppealPartcdIoTopElmt {

    @XmlElement(name = "ListOfMasL2AppealPartcdIo", required = true)
    protected ListOfMasL2AppealPartcdIo listOfMasL2AppealPartcdIo;

    /**
     * Gets the value of the listOfMasL2AppealPartcdIo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL2AppealPartcdIo }
     *     
     */
    public ListOfMasL2AppealPartcdIo getListOfMasL2AppealPartcdIo() {
        return listOfMasL2AppealPartcdIo;
    }

    /**
     * Sets the value of the listOfMasL2AppealPartcdIo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL2AppealPartcdIo }
     *     
     */
    public void setListOfMasL2AppealPartcdIo(ListOfMasL2AppealPartcdIo value) {
        this.listOfMasL2AppealPartcdIo = value;
    }

}
