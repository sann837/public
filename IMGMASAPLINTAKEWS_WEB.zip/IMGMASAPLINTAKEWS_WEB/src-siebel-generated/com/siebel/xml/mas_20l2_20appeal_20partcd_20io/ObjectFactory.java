
package com.siebel.xml.mas_20l2_20appeal_20partcd_20io;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.xml.mas_20l2_20appeal_20partcd_20io package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfMasL2AppealPartcdIo_QNAME = new QName("http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO", "ListOfMasL2AppealPartcdIo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.xml.mas_20l2_20appeal_20partcd_20io
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfMasL2AppealPartcdIo }
     * 
     */
    public ListOfMasL2AppealPartcdIo createListOfMasL2AppealPartcdIo() {
        return new ListOfMasL2AppealPartcdIo();
    }

    /**
     * Create an instance of {@link ListOfMasL2AppealPartcdIoTopElmt }
     * 
     */
    public ListOfMasL2AppealPartcdIoTopElmt createListOfMasL2AppealPartcdIoTopElmt() {
        return new ListOfMasL2AppealPartcdIoTopElmt();
    }

    /**
     * Create an instance of {@link Appeal }
     * 
     */
    public Appeal createAppeal() {
        return new Appeal();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfMasL2AppealPartcdIo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO", name = "ListOfMasL2AppealPartcdIo")
    public JAXBElement<ListOfMasL2AppealPartcdIo> createListOfMasL2AppealPartcdIo(ListOfMasL2AppealPartcdIo value) {
        return new JAXBElement<ListOfMasL2AppealPartcdIo>(_ListOfMasL2AppealPartcdIo_QNAME, ListOfMasL2AppealPartcdIo.class, null, value);
    }

}
