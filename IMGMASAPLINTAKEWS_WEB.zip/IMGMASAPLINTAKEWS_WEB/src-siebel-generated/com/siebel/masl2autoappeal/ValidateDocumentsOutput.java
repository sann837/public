
package com.siebel.masl2autoappeal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20validate_20documents_20response_20io.ListOfResponseDocsIO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20Validate%20Documents%20Response%20IO}ListOfResponseDocsIO" minOccurs="0"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfResponseDocsIO",
    "errCode",
    "errMsg",
    "status"
})
@XmlRootElement(name = "ValidateDocuments_Output")
public class ValidateDocumentsOutput {

    @XmlElement(name = "ListOfResponseDocsIO", namespace = "http://www.siebel.com/xml/MAS%20Validate%20Documents%20Response%20IO")
    protected ListOfResponseDocsIO listOfResponseDocsIO;
    protected String errCode;
    protected String errMsg;
    protected String status;

    /**
     * Gets the value of the listOfResponseDocsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfResponseDocsIO }
     *     
     */
    public ListOfResponseDocsIO getListOfResponseDocsIO() {
        return listOfResponseDocsIO;
    }

    /**
     * Sets the value of the listOfResponseDocsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfResponseDocsIO }
     *     
     */
    public void setListOfResponseDocsIO(ListOfResponseDocsIO value) {
        this.listOfResponseDocsIO = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
