
package com.siebel.masl2autoappeal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l2_20appeal_20partcd_20io.ListOfMasL2AppealPartcdIo;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="jurisdiction" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="consumerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="publicKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO}ListOfMasL2AppealPartcdIo"/>
 *         &lt;element name="transId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "jurisdiction",
    "consumerId",
    "userName",
    "publicKey",
    "listOfMasL2AppealPartcdIo",
    "transId"
})
@XmlRootElement(name = "CreateL2AutoAppeal_Input")
public class CreateL2AutoAppealInput {

    @XmlElement(required = true)
    protected String jurisdiction;
    protected String consumerId;
    @XmlElement(required = true)
    protected String userName;
    protected String publicKey;
    @XmlElement(name = "ListOfMasL2AppealPartcdIo", namespace = "http://www.siebel.com/xml/MAS%20L2%20Appeal%20PartCD%20IO", required = true)
    protected ListOfMasL2AppealPartcdIo listOfMasL2AppealPartcdIo;
    @XmlElement(required = true)
    protected String transId;

    /**
     * Gets the value of the jurisdiction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJurisdiction() {
        return jurisdiction;
    }

    /**
     * Sets the value of the jurisdiction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJurisdiction(String value) {
        this.jurisdiction = value;
    }

    /**
     * Gets the value of the consumerId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * Sets the value of the consumerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerId(String value) {
        this.consumerId = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the publicKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicKey() {
        return publicKey;
    }

    /**
     * Sets the value of the publicKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicKey(String value) {
        this.publicKey = value;
    }

    /**
     * Gets the value of the listOfMasL2AppealPartcdIo property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasL2AppealPartcdIo }
     *     
     */
    public ListOfMasL2AppealPartcdIo getListOfMasL2AppealPartcdIo() {
        return listOfMasL2AppealPartcdIo;
    }

    /**
     * Sets the value of the listOfMasL2AppealPartcdIo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasL2AppealPartcdIo }
     *     
     */
    public void setListOfMasL2AppealPartcdIo(ListOfMasL2AppealPartcdIo value) {
        this.listOfMasL2AppealPartcdIo = value;
    }

    /**
     * Gets the value of the transId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransId() {
        return transId;
    }

    /**
     * Sets the value of the transId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransId(String value) {
        this.transId = value;
    }

}
