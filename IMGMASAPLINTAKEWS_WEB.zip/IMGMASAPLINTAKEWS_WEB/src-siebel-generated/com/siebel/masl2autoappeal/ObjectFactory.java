
package com.siebel.masl2autoappeal;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.siebel.masl2autoappeal package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.siebel.masl2autoappeal
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreateL2AutoAppealOutput }
     * 
     */
    public CreateL2AutoAppealOutput createCreateL2AutoAppealOutput() {
        return new CreateL2AutoAppealOutput();
    }

    /**
     * Create an instance of {@link UpdateL2TransctnIdOutput }
     * 
     */
    public UpdateL2TransctnIdOutput createUpdateL2TransctnIdOutput() {
        return new UpdateL2TransctnIdOutput();
    }

    /**
     * Create an instance of {@link GetL2AppealDocumentsOutput }
     * 
     */
    public GetL2AppealDocumentsOutput createGetL2AppealDocumentsOutput() {
        return new GetL2AppealDocumentsOutput();
    }

    /**
     * Create an instance of {@link L2UserAuthenticationInput }
     * 
     */
    public L2UserAuthenticationInput createL2UserAuthenticationInput() {
        return new L2UserAuthenticationInput();
    }

    /**
     * Create an instance of {@link AssociateDocumentsInput }
     * 
     */
    public AssociateDocumentsInput createAssociateDocumentsInput() {
        return new AssociateDocumentsInput();
    }

    /**
     * Create an instance of {@link AssociateDocumentsOutput }
     * 
     */
    public AssociateDocumentsOutput createAssociateDocumentsOutput() {
        return new AssociateDocumentsOutput();
    }

    /**
     * Create an instance of {@link L2UserAuthenticationOutput }
     * 
     */
    public L2UserAuthenticationOutput createL2UserAuthenticationOutput() {
        return new L2UserAuthenticationOutput();
    }

    /**
     * Create an instance of {@link GetL2AppealDocumentsInput }
     * 
     */
    public GetL2AppealDocumentsInput createGetL2AppealDocumentsInput() {
        return new GetL2AppealDocumentsInput();
    }

    /**
     * Create an instance of {@link UpdateL2TransctnIdInput }
     * 
     */
    public UpdateL2TransctnIdInput createUpdateL2TransctnIdInput() {
        return new UpdateL2TransctnIdInput();
    }

    /**
     * Create an instance of {@link CreateL2AutoAppealInput }
     * 
     */
    public CreateL2AutoAppealInput createCreateL2AutoAppealInput() {
        return new CreateL2AutoAppealInput();
    }

    /**
     * Create an instance of {@link ValidateDocumentsInput }
     * 
     */
    public ValidateDocumentsInput createValidateDocumentsInput() {
        return new ValidateDocumentsInput();
    }

    /**
     * Create an instance of {@link ValidateDocumentsOutput }
     * 
     */
    public ValidateDocumentsOutput createValidateDocumentsOutput() {
        return new ValidateDocumentsOutput();
    }

}
