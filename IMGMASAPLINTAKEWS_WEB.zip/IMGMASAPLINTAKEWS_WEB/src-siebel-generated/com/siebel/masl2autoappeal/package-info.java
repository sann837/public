@javax.xml.bind.annotation.XmlSchema(namespace = "http://siebel.com/MASL2AutoAppeal", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.masl2autoappeal;
