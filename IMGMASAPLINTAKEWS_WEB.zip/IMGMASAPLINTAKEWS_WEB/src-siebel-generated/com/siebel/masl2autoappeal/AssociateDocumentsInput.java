
package com.siebel.masl2autoappeal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.masassociatedocsio.ListOfMasassociatedocsio;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MASAssociateDocsIO}ListOfMasassociatedocsio"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfMasassociatedocsio"
})
@XmlRootElement(name = "AssociateDocuments_Input")
public class AssociateDocumentsInput {

    @XmlElement(name = "ListOfMasassociatedocsio", namespace = "http://www.siebel.com/xml/MASAssociateDocsIO", required = true)
    protected ListOfMasassociatedocsio listOfMasassociatedocsio;

    /**
     * Gets the value of the listOfMasassociatedocsio property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfMasassociatedocsio }
     *     
     */
    public ListOfMasassociatedocsio getListOfMasassociatedocsio() {
        return listOfMasassociatedocsio;
    }

    /**
     * Sets the value of the listOfMasassociatedocsio property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfMasassociatedocsio }
     *     
     */
    public void setListOfMasassociatedocsio(ListOfMasassociatedocsio value) {
        this.listOfMasassociatedocsio = value;
    }

}
