
package com.siebel.masl2autoappeal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l2_20svc_20smoke_20test_20ecm_20documents_20io.ListOfL2DocumentsIO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L2%20Svc%20Smoke%20Test%20ECM%20Documents%20IO}ListOfL2DocumentsIO" minOccurs="0"/>
 *         &lt;element name="errCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="errMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfL2DocumentsIO",
    "errCode",
    "errMsg",
    "status"
})
@XmlRootElement(name = "GetL2AppealDocuments_Output")
public class GetL2AppealDocumentsOutput {

    @XmlElement(name = "ListOfL2DocumentsIO", namespace = "http://www.siebel.com/xml/MAS%20L2%20Svc%20Smoke%20Test%20ECM%20Documents%20IO")
    protected ListOfL2DocumentsIO listOfL2DocumentsIO;
    @XmlElement(required = true)
    protected String errCode;
    @XmlElement(required = true)
    protected String errMsg;
    @XmlElement(required = true)
    protected String status;

    /**
     * Gets the value of the listOfL2DocumentsIO property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL2DocumentsIO }
     *     
     */
    public ListOfL2DocumentsIO getListOfL2DocumentsIO() {
        return listOfL2DocumentsIO;
    }

    /**
     * Sets the value of the listOfL2DocumentsIO property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL2DocumentsIO }
     *     
     */
    public void setListOfL2DocumentsIO(ListOfL2DocumentsIO value) {
        this.listOfL2DocumentsIO = value;
    }

    /**
     * Gets the value of the errCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * Sets the value of the errCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrCode(String value) {
        this.errCode = value;
    }

    /**
     * Gets the value of the errMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * Sets the value of the errMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrMsg(String value) {
        this.errMsg = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
