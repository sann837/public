
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfL1Documentlist;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="appealNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}ListOfL1documentlist"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="organization" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "appealNumber",
    "listOfL1Documentlist",
    "userName",
    "organization"
})
@XmlRootElement(name = "CreateAddlnDocument_Input")
public class CreateAddlnDocumentInput {

    @XmlElement(required = true)
    protected String appealNumber;
    @XmlElement(name = "ListOfL1documentlist", namespace = "http://www.siebel.com/xml/MAS%20L1%20ECM%20BC", required = true)
    protected ListOfL1Documentlist listOfL1Documentlist;
    @XmlElement(required = true)
    protected String userName;
    @XmlElement(required = true)
    protected String organization;

    /**
     * Gets the value of the appealNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealNumber() {
        return appealNumber;
    }

    /**
     * Sets the value of the appealNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealNumber(String value) {
        this.appealNumber = value;
    }

    /**
     * Gets the value of the listOfL1Documentlist property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public ListOfL1Documentlist getListOfL1Documentlist() {
        return listOfL1Documentlist;
    }

    /**
     * Sets the value of the listOfL1Documentlist property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public void setListOfL1Documentlist(ListOfL1Documentlist value) {
        this.listOfL1Documentlist = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the organization property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganization() {
        return organization;
    }

    /**
     * Sets the value of the organization property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganization(String value) {
        this.organization = value;
    }

}
