
package com.siebel.customui;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.siebel.xml.mas_20bc_20bip_20claim_20bene.ListOfL1ClaimList;
import com.siebel.xml.mas_20l1_20ecm_20bc.ListOfL1Documentlist;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene}ListOfL1ClaimList" minOccurs="0"/>
 *         &lt;element name="contractNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requestDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.siebel.com/xml/MAS%20L1%20ECM%20BC}ListOfL1documentlist" minOccurs="0"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="organization" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "listOfL1ClaimList",
    "contractNumber",
    "requestDate",
    "listOfL1Documentlist",
    "userName",
    "organization"
})
@XmlRootElement(name = "CreateAutoAppeal_Input")
public class CreateAutoAppealInput {

    @XmlElement(name = "ListOfL1ClaimList", namespace = "http://www.siebel.com/xml/MAS%20BC%20BIP%20Claim%20Bene")
    protected ListOfL1ClaimList listOfL1ClaimList;
    protected String contractNumber;
    protected String requestDate;
    @XmlElement(name = "ListOfL1documentlist", namespace = "http://www.siebel.com/xml/MAS%20L1%20ECM%20BC")
    protected ListOfL1Documentlist listOfL1Documentlist;
    @XmlElement(required = true)
    protected String userName;
    @XmlElement(required = true)
    protected String organization;

    /**
     * Gets the value of the listOfL1ClaimList property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL1ClaimList }
     *     
     */
    public ListOfL1ClaimList getListOfL1ClaimList() {
        return listOfL1ClaimList;
    }

    /**
     * Sets the value of the listOfL1ClaimList property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL1ClaimList }
     *     
     */
    public void setListOfL1ClaimList(ListOfL1ClaimList value) {
        this.listOfL1ClaimList = value;
    }

    /**
     * Gets the value of the contractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractNumber() {
        return contractNumber;
    }

    /**
     * Sets the value of the contractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractNumber(String value) {
        this.contractNumber = value;
    }

    /**
     * Gets the value of the requestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the value of the requestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDate(String value) {
        this.requestDate = value;
    }

    /**
     * Gets the value of the listOfL1Documentlist property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public ListOfL1Documentlist getListOfL1Documentlist() {
        return listOfL1Documentlist;
    }

    /**
     * Sets the value of the listOfL1Documentlist property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfL1Documentlist }
     *     
     */
    public void setListOfL1Documentlist(ListOfL1Documentlist value) {
        this.listOfL1Documentlist = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the organization property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganization() {
        return organization;
    }

    /**
     * Sets the value of the organization property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganization(String value) {
        this.organization = value;
    }

}
