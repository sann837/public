@javax.xml.bind.annotation.XmlSchema(namespace = "http://siebel.com/CustomUI", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.siebel.customui;
